package com.shengxiaguangnian.ime

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

data class Candidate(
    val word: String,
    val wubiHint: String?,
    val displayCode: String,
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val t14PyAbbr: String,
    val weight: Int
)

object T14WubiEngine {
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    // 将内部 14 键编码还原为纯字母（彻底杜绝 8'7'nv 或 9 等数字出现在左上角浮窗！）
    private val T14_CODE_TO_LETTER = mapOf(
        '1' to "q", '2' to "e", '3' to "t", '4' to "u", '5' to "o",
        '6' to "a", '7' to "d", '8' to "g", '9' to "j", '0' to "l",
        'a' to "z", 'b' to "c", 'c' to "n", 'd' to "m"
    )

    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "dun", "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )

    private val wubiExactIndex = HashMap<String, MutableList<DictEntry>>(20000)
    private val wubiPrefixIndex = HashMap<String, MutableList<DictEntry>>(8000)
    private val pinyinExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val pinyinPrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val pinyinAbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)

    // 26 键英文单词前缀索引（用于英文单词联想补全）
    private val englishPrefixIndex = HashMap<String, MutableList<String>>(6000)

    private val t14SyllableMap = LinkedHashMap<String, String>()
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)

    // 用户导入词库专用 O(1) 哈希索引（即使导入十万条搜狗大词库，每次按键也是 0.05ms 哈希直达，绝不遍历卡顿！）
    private class UserDictIndex(
        val wubiExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val wubiPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinAbbr: HashMap<String, MutableList<DictEntry>> = HashMap()
    )
    @Volatile
    private var userDictIndex = UserDictIndex()

    private val userFreqMap = HashMap<String, Int>()
    private val userCodeMruMap = HashMap<String, Long>()
    private var mruSequenceCounter = System.currentTimeMillis()
    private val userBigramMap = HashMap<String, MutableList<String>>()
    private val builtInAssocMap = HashMap<String, List<String>>(15000)
    private val defaultCommonAssoc = listOf("的", "了", "是", "在", "我", "有", "和", "就", "不", "都", "也", "很", "可以", "什么", "自己", "知道", "觉得", "现在")

    private val isLoaded = AtomicBoolean(false)
    private val isLoading = AtomicBoolean(false)
    private val userDictDirty = AtomicBoolean(false)

    fun markUserDictDirty() {
        userDictDirty.set(true)
    }

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    fun ensureInitializedAsync(context: Context, dbHelper: ImeDatabaseHelper) {
        if (isLoaded.get()) {
            if (userDictDirty.compareAndSet(true, false)) {
                Thread { reloadUserDict(dbHelper) }.start()
            }
            return
        }
        if (!isLoading.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        Thread {
            loadAllInternal(appCtx, dbHelper)
            isLoaded.set(true)
            isLoading.set(false)
        }.start()
    }

    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        ensureInitializedAsync(context, dbHelper)
    }

    private fun loadAllInternal(context: Context, dbHelper: ImeDatabaseHelper) {
        for (syl in VALID_SYLLABLES) {
            val code = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code)) {
                t14SyllableMap[code] = syl
            }
        }

        // 1. 加载英文单词词典（用于 26 键英文单词联想）
        try {
            context.assets.open("english_words.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    val word = (if (tab > 0) line.substring(0, tab) else line).trim()
                    if (word.length >= 2) {
                        val lower = word.lowercase()
                        val maxP = minOf(8, lower.length)
                        for (len in 1..maxP) {
                            val pref = lower.substring(0, len)
                            val list = englishPrefixIndex.getOrPut(pref) { ArrayList(12) }
                            if (list.size < 24) list.add(word)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. 加载单字五笔与拼音码表
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载词语联想表
        try {
            context.assets.open("assoc_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) {
                        val prefix = line.substring(0, tab)
                        val suffixes = line.substring(tab + 1).split(',').filter { it.isNotEmpty() }
                        if (suffixes.isNotEmpty()) {
                            builtInAssocMap[prefix] = suffixes
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. 加载主词库并建立哈希索引
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 65536).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 4) {
                        val word = parts[0]
                        val wcode = parts[1]
                        val segPy = parts[2]
                        val t14W: String
                        val t14P: String
                        val t14A: String
                        val weight: Int
                        if (parts.size >= 7) {
                            t14W = parts[3]
                            t14P = parts[4]
                            t14A = parts[5]
                            weight = parts[6].toIntOrNull() ?: 500
                        } else {
                            t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                            t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                            t14A = extractPyAbbrT14(segPy)
                            weight = parts[3].toIntOrNull() ?: 500
                        }

                        if (word.isNotEmpty()) {
                            val de = DictEntry(word, wcode, segPy, t14W, t14P, t14A, weight)
                            indexEntry(de)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        userFreqMap.putAll(dbHelper.loadUserFreqMap())
        userCodeMruMap.putAll(dbHelper.loadUserCodeMruMap())
        userBigramMap.putAll(dbHelper.loadUserBigramMap())
        reloadUserDict(dbHelper)
    }

    private fun indexEntry(de: DictEntry) {
        if (de.t14Wubi.isNotEmpty()) {
            val exactList = wubiExactIndex.getOrPut(de.t14Wubi) { ArrayList(6) }
            if (exactList.size < 80) exactList.add(de)

            // 扩大五笔前缀索引容量到 250 条，确保敲第 1、2、3 码（如打 "天际" gdbf 敲到 gdb）时永远有五笔候选词！
            val maxPref = minOf(3, de.t14Wubi.length - 1)
            for (len in 1..maxPref) {
                val pref = de.t14Wubi.substring(0, len)
                val pList = wubiPrefixIndex.getOrPut(pref) { ArrayList(12) }
                if (pList.size < 250) pList.add(de)
            }
        }

        if (de.t14Pinyin.isNotEmpty()) {
            val pyExact = pinyinExactIndex.getOrPut(de.t14Pinyin) { ArrayList(6) }
            if (pyExact.size < 60) pyExact.add(de)

            if (de.word.length == 1 && pyExact.size <= 8) {
                val scList = t14SingleCharByPy.getOrPut(de.t14Pinyin) { ArrayList(4) }
                if (scList.size < 8) scList.add(de)
            }

            val maxPyPref = minOf(8, de.t14Pinyin.length - 1)
            for (len in 1..maxPyPref) {
                val pref = de.t14Pinyin.substring(0, len)
                val pList = pinyinPrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 120) pList.add(de)
            }
        }

        if (de.t14PyAbbr.length in 2..5) {
            val aList = pinyinAbbrIndex.getOrPut(de.t14PyAbbr) { ArrayList(6) }
            if (aList.size < 40) aList.add(de)
        }
    }

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        val nextIdx = UserDictIndex()
        try {
            dbHelper.readableDatabase.rawQuery(
                "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val w = c.getString(0)
                    val wc = c.getString(1)
                    val py = c.getString(2).ifEmpty { generateSegmentedPinyinForWord(w) }
                    val de = DictEntry(
                        word = w,
                        wubiCode = wc,
                        segmentedPinyin = py,
                        t14Wubi = c.getString(3),
                        t14Pinyin = c.getString(4),
                        t14PyAbbr = extractPyAbbrT14(py),
                        weight = c.getInt(5)
                    )
                    if (de.t14Wubi.isNotEmpty()) {
                        val exList = nextIdx.wubiExact.getOrPut(de.t14Wubi) { ArrayList(4) }
                        if (exList.size < 60) exList.add(de)
                        val maxPref = minOf(3, de.t14Wubi.length - 1)
                        for (len in 1..maxPref) {
                            val pref = de.t14Wubi.substring(0, len)
                            val pList = nextIdx.wubiPrefix.getOrPut(pref) { ArrayList(8) }
                            if (pList.size < 80) pList.add(de)
                        }
                    }
                    if (de.t14Pinyin.isNotEmpty()) {
                        val pyEx = nextIdx.pinyinExact.getOrPut(de.t14Pinyin) { ArrayList(4) }
                        if (pyEx.size < 50) pyEx.add(de)
                        val maxPyPref = minOf(8, de.t14Pinyin.length - 1)
                        for (len in 2..maxPyPref) {
                            val pref = de.t14Pinyin.substring(0, len)
                            val pList = nextIdx.pinyinPrefix.getOrPut(pref) { ArrayList(6) }
                            if (pList.size < 50) pList.add(de)
                        }
                    }
                    if (de.t14PyAbbr.length in 2..5) {
                        val aList = nextIdx.pinyinAbbr.getOrPut(de.t14PyAbbr) { ArrayList(4) }
                        if (aList.size < 40) aList.add(de)
                    }
                }
            }
            userDictIndex = nextIdx
        } catch (_: Exception) {}
    }

    fun resetUserFrequency(dbHelper: ImeDatabaseHelper) {
        userFreqMap.clear()
        userCodeMruMap.clear()
        userBigramMap.clear()
        dbHelper.resetUserFrequencySorting()
    }

    fun onWordCommitted(word: String, prevWord: String?, dbHelper: ImeDatabaseHelper, t14Code: String = "") {
        if (word.isEmpty()) return
        userFreqMap[word] = (userFreqMap[word] ?: 0) + 1
        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (t14Code.isNotEmpty()) {
            userCodeMruMap["$t14Code|$word"] = mruSequenceCounter
        }
        if (!prevWord.isNullOrEmpty() && prevWord != word) {
            val list = userBigramMap.getOrPut(prevWord) { ArrayList() }
            list.remove(word)
            list.add(0, word)
            if (list.size > 12) list.removeAt(list.lastIndex)
        }
        dbHelper.recordWordUsageAsync(word, prevWord, t14Code, mruSequenceCounter)
    }

    fun getAssociations(committedWord: String, limit: Int = 28): List<String> {
        if (committedWord.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        userBigramMap[committedWord]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }
        val lastCharStr = committedWord.takeLast(1)
        userBigramMap[lastCharStr]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }

        builtInAssocMap[committedWord]?.forEach { suffix ->
            if (seen.add(suffix) && result.size < limit) result.add(suffix)
        }
        if (committedWord.length >= 2) {
            builtInAssocMap[lastCharStr]?.forEach { suffix ->
                if (seen.add(suffix) && result.size < limit) result.add(suffix)
            }
        }

        for (cw in defaultCommonAssoc) {
            if (cw != committedWord && seen.add(cw) && result.size < limit) {
                result.add(cw)
            }
        }
        return result
    }

    /**
     * 26 键英文模式下的单词联想与补全
     */
    fun queryEnglishCandidates(rawInput: String, limit: Int = 24): List<String> {
        if (rawInput.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()
        result.add(rawInput)
        seen.add(rawInput)

        val lower = rawInput.lowercase()
        val isCapitalized = rawInput[0].isUpperCase()
        val matches = englishPrefixIndex[lower.take(8)] ?: emptyList()
        for (w in matches) {
            if (w.lowercase().startsWith(lower)) {
                val formatted = if (isCapitalized) w.replaceFirstChar { it.uppercaseChar() } else w
                if (seen.add(formatted)) {
                    result.add(formatted)
                    if (result.size >= limit) break
                }
            }
        }
        return result
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    /**
     * 将 14 键编码转换为左上角浮窗显示的纯字母串（彻底杜绝 '8'、'7'、'9' 等内部数字编号出现！）
     */
    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code ->
            t14SyllableMap[code] ?: code.map { ch -> T14_CODE_TO_LETTER[ch] ?: ch.toString() }.joinToString("")
        }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    fun queryCandidates(t14Input: String, rawFallback: String, limit: Int = 90): List<Candidate> {
        if (t14Input.isEmpty() || !isLoaded.get()) return emptyList()

        val exactWubi = ArrayList<Candidate>(32)
        val prefixWubi = ArrayList<Candidate>(48)
        val exactPinyin = ArrayList<Candidate>(40)
        val abbrPinyin = ArrayList<Candidate>(24)
        val prefixPinyin = ArrayList<Candidate>(32)
        val seen = HashSet<String>(128)

        val isLongPinyinMode = t14Input.length > 4
        val segmentedDisplay = segmentT14ToPinyinDisplay(t14Input, rawFallback)

        // 方案一（几码归几码）：不跨码长全局加权，仅对当前精确输入码位 t14Input 做专属置顶记忆
        fun userBoost(@Suppress("UNUSED_PARAMETER") word: String): Int = 0

        val uIdx = userDictIndex
        if (!isLongPinyinMode) {
            uIdx.wubiExact[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(Candidate(e.word, null, e.wubiCode, e.weight + 50000, true))
                }
            }
            uIdx.wubiPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(Candidate(e.word, null, e.wubiCode.take(t14Input.length), e.weight + 20000, true))
                }
            }
        }
        uIdx.pinyinExact[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                exactPinyin.add(Candidate(e.word, wHint, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 50000, false))
            }
        }
        if (t14Input.length in 2..5) {
            uIdx.pinyinAbbr[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    abbrPinyin.add(Candidate(e.word, wHint, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 20000, false))
                }
            }
        }
        if (t14Input.length in 2..8) {
            uIdx.pinyinPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    prefixPinyin.add(Candidate(e.word, wHint, segmentedDisplay, e.weight + 10000, false))
                }
            }
        }

        if (!isLongPinyinMode) {
            wubiExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
            wubiPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode.take(t14Input.length),
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
        }

        pinyinExactIndex[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = wHint,
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + userBoost(e.word) + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }

        if (t14Input.length in 2..5) {
            pinyinAbbrIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        if (t14Input.length <= 8) {
            pinyinPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        fun codeMru(word: String): Long = userCodeMruMap["$t14Input|$word"] ?: 0L

        val mruComparator = Comparator<Candidate> { a, b ->
            val luA = codeMru(a.word)
            val luB = codeMru(b.word)
            if (luA != luB) {
                luB.compareTo(luA) // 方案一（几码归几码）：仅在当前完全相同的输入码位下选过的字词直接排第 1！
            } else {
                b.weight.compareTo(a.weight)
            }
        }
        // 仅当用户在【当前完全相同的码长与编码 t14Input】下亲手选过某个候选词时，才在当前编码下提拔置顶；
        // 打 2/3/4 码选过的词语或成语，在打 1 码时 codeMru 为 0，绝不会越级窜到 1 码的第 1 位！
        if (!isLongPinyinMode) {
            val promotedFromPrefix = prefixWubi.filter { codeMru(it.word) > 0L }
            if (promotedFromPrefix.isNotEmpty()) {
                prefixWubi.removeAll(promotedFromPrefix.toSet())
                exactWubi.addAll(promotedFromPrefix)
            }
            val promotedFromPy = exactPinyin.filter { codeMru(it.word) > 0L }
            if (promotedFromPy.isNotEmpty()) {
                exactPinyin.removeAll(promotedFromPy.toSet())
                exactWubi.addAll(promotedFromPy)
            }
        }
        if (exactWubi.size > 1) exactWubi.sortWith(mruComparator)
        if (prefixWubi.size > 1) prefixWubi.sortWith(mruComparator)
        if (exactPinyin.size > 1) exactPinyin.sortWith(mruComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(mruComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(mruComparator)

        val result = ArrayList<Candidate>(limit)

        // 叠字连打快捷识别（如连敲 GH 打 hhhhhhhh 自动出 哈哈哈哈哈哈哈哈，连敲 AS 出 啊啊啊啊，连敲 QW 出 呜呜呜呜）
        if (t14Input.length >= 3 && t14Input.all { it == t14Input[0] }) {
            val n = t14Input.length
            val repeatPresets = when (t14Input[0]) {
                '8' -> listOf("哈" to "h", "嘿" to "h", "哼" to "h")
                '6' -> listOf("啊" to "a", "呀" to "a")
                '1' -> listOf("呜" to "w", "哇" to "w")
                'a' -> listOf("嘻" to "x")
                '5' -> listOf("哦" to "o", "噢" to "o")
                '0' -> listOf("啦" to "l", "略" to "l")
                'd' -> listOf("么" to "m", "喵" to "m")
                else -> emptyList()
            }
            if (repeatPresets.isNotEmpty()) {
                // 若超过 4 码（如 hhhhhhhh），叠字直接排第 1；若为 3~4 码，排在 4 码精确五笔（如 gggg=王）之后
                if (n > 4) {
                    for ((chStr, codeCh) in repeatPresets) {
                        val repWord = chStr.repeat(n)
                        if (seen.add(repWord)) {
                            result.add(Candidate(repWord, null, codeCh.repeat(n), 9999999, false))
                        }
                    }
                } else {
                    for ((chStr, codeCh) in repeatPresets) {
                        val repWord = chStr.repeat(n)
                        exactWubi.add(Candidate(repWord, null, codeCh.repeat(n), 1, false))
                    }
                }
            }
        }

        if (!isLongPinyinMode) {
            for (c in exactWubi) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixWubi) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
        } else {
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
        }

        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight + userBoost(it.word) }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val wHint = generateWubi86CodeForWord(synthWord)
                    val insertPos = if (isLongPinyinMode) exactPinyin.size.coerceAtMost(result.size) else result.size
                    result.add(
                        insertPos,
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = fc.wubiCode,
                            displayCode = segmentedDisplay,
                            weight = fc.weight + userBoost(fc.word),
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        return result
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()

        fun parseAtOffset(startPos: Int): List<String> {
            val words = ArrayList<String>()
            try {
                val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var pos = startPos
                while (pos + 4 < bytes.size) {
                    val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                    val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                    pos += 4 + pyIdxBytesLen
                    if (samePyCount <= 0 || samePyCount > 2500 || pyIdxBytesLen > 256 || pos >= bytes.size) break
                    for (i in 0 until samePyCount) {
                        if (pos + 2 >= bytes.size) break
                        val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2
                        if (wordByteLen <= 0 || wordByteLen > 128 || pos + wordByteLen > bytes.size) break
                        val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                        pos += wordByteLen
                        if (pos + 2 > bytes.size) break
                        val extLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2 + extLen
                        if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 1..16) {
                            words.add(word)
                        }
                    }
                }
            } catch (_: Exception) {}
            return words
        }

        val primaryOffset = if ((bytes[4].toInt() and 0xFF) == 0x45) 0x26C4 else 0x2628
        val primaryWords = parseAtOffset(primaryOffset)
        if (primaryWords.size >= 5) return primaryWords.distinct()
        val fallbackOffset = if (primaryOffset == 0x2628) 0x26C4 else 0x2628
        val fallbackWords = if (bytes.size > fallbackOffset) parseAtOffset(fallbackOffset) else emptyList()
        return (if (fallbackWords.size > primaryWords.size) fallbackWords else primaryWords).distinct()
    }
}
