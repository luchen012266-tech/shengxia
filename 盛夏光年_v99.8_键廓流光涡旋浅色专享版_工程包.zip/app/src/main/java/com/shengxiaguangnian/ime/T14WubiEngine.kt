package com.shengxiaguangnian.ime

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.log10

data class Candidate(
    val word: String,
    val wubiHint: String?,
    val displayCode: String,
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0,
    val selCount: Int = 0,
    val selLastUsed: Long = 0L
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val t14PyAbbr: String,
    val weight: Int
)

object T14WubiEngine {
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    // 将内部 14 键编码还原为纯字母（彻底杜绝 8'7'nv 或 9 等数字出现在左上角浮窗！）
    private val T14_CODE_TO_LETTER = mapOf(
        '1' to "q", '2' to "e", '3' to "t", '4' to "u", '5' to "o",
        '6' to "a", '7' to "d", '8' to "g", '9' to "j", '0' to "l",
        'a' to "z", 'b' to "c", 'c' to "n", 'd' to "m"
    )

    private val T14_CODE_TO_KEY_LABEL = mapOf(
        '1' to "QW", '2' to "ER", '3' to "TY", '4' to "UI", '5' to "OP",
        '6' to "AS", '7' to "DF", '8' to "GH", '9' to "JK", '0' to "L",
        'a' to "ZX", 'b' to "CV", 'c' to "BN", 'd' to "M"
    )

    // 25 个一级简码字的「字 -> 简码字母」反向映射（用于组词双轨容错：无论按拆字根还是按一级简码键都能命中！）
    private val CHAR_TO_LEVEL1_KEY = mapOf(
        '一' to "g", '地' to "f", '在' to "d", '要' to "s", '工' to "a",
        '上' to "h", '是' to "j", '中' to "k", '国' to "l", '同' to "m",
        '和' to "t", '的' to "r", '有' to "e", '人' to "w", '我' to "q",
        '主' to "y", '产' to "u", '不' to "i", '为' to "o", '这' to "p",
        '民' to "n", '了' to "b", '发' to "v", '以' to "c", '经' to "x"
    )

    // 工业/公文/新闻统计类低频后缀与词根（4码重码时自动降权，绝不挡在「或许」「括号」等日常用语前面）
    private val JARGON_SUBSTRINGS = arrayOf(
        "机电", "设备", "机器", "机械", "工程", "管理", "委员会", "代表大会", "有限公司",
        "社会主义", "资本主义", "帝国主义", "企事业", "研究所", "检察院", "国务院", "生产队",
        "加工厂", "流水线", "零部件", "采访中", "摄入量", "排放量", "含水量", "降雨量",
        "生产率", "积极性", "现代化", "工业化", "农业化", "自动化", "电气化", "拖拉机",
        "发电机", "电动机", "变压器", "半导体", "化合物", "混合物", "氧化物"
    )

    private val NEWS_3CHAR_SUFFIXES = charArrayOf(
        '中', '量', '率', '度', '性', '化', '器', '员', '局', '部', '委', '处', '科', '室', '厂', '矿', '队', '制'
    )

    private val ARCHAIC_LOW_PRIORITY_WORDS = setOf(
        "乃是", "腹中", "用嘴", "插嘴", "可放", "划入", "何况乎", "莫过于"
    )

    private val DAILY_3CHAR_WHITELIST = setOf(
        "为什么", "怎么办", "没问题", "差不多", "不知道", "说实话", "打工人", "显眼包",
        "氛围感", "松弛感", "破碎感", "高级感", "呼吸感", "通透感", "少女感", "少年感"
    )

    fun isJargonOrNewsWord(word: String): Boolean {
        if (word in ARCHAIC_LOW_PRIORITY_WORDS) return true
        for (sub in JARGON_SUBSTRINGS) {
            if (word.contains(sub)) return true
        }
        if (word.length == 3 && word !in DAILY_3CHAR_WHITELIST) {
            val lastCh = word[2]
            if (NEWS_3CHAR_SUFFIXES.contains(lastCh)) return true
        }
        return false
    }

    // 25 个标准 86 五笔一级简码字（单键输入时享有最高基准保护权重 14000，防止单次误选改变一级简码首选）
    private val LEVEL1_BREVITY_WORDS = mapOf(
        "g" to "一", "f" to "地", "d" to "在", "s" to "要", "a" to "工",
        "h" to "上", "j" to "是", "k" to "中", "l" to "国", "m" to "同",
        "t" to "和", "r" to "的", "e" to "有", "w" to "人", "q" to "我",
        "y" to "主", "u" to "产", "i" to "不", "o" to "为", "p" to "这",
        "n" to "民", "b" to "了", "v" to "发", "c" to "以", "x" to "经"
    )

    // 自动组词过滤用的句尾语气助词（避免「吃了吗」「好的呢」等日常语法带助词被误合成为词条）
    private val AUTO_PHRASE_STOP_CHARS = setOf(
        '的', '了', '吗', '呢', '吧', '啊', '呀', '啦', '哦', '嘛', '哈', '喔', '噢', '呗', '咧'
    )

    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "dun", "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )

    private val wubiExactIndex = HashMap<String, MutableList<DictEntry>>(28000)
    private val wubiPrefixIndex = HashMap<String, MutableList<DictEntry>>(12000)
    // 盲打拆字记忆容错索引（支持：一级简码双轨组词、三字词 2+1+1、二字词首尾根跳跃拆法）
    private val wubiFaultTolerantIndex = HashMap<String, MutableList<DictEntry>>(18000)
    // 智能成语补全与语境联想索引（如打「莫名」立出「其妙」，打「迫不」立出「及待」）
    private val idiomCompletionMap = HashMap<String, MutableList<String>>(6000)

    data class TypingDiagRecord(
        val timeStr: String,
        val t14Code: String,
        val keyLabels: String,
        val topCandidates: String,
        val committedWord: String
    )
    private val recentTypingLogs = ArrayList<TypingDiagRecord>(20)
    private val pinyinExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val pinyinPrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val pinyinAbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)
    private val builtInWordMap = HashMap<String, MutableList<DictEntry>>(35000)

    // 26 键英文单词前缀索引
    private val englishPrefixIndex = HashMap<String, MutableList<Pair<String, Int>>>(12000)
    private val englishExactSet = HashSet<String>(25000)

    private val t14SyllableMap = LinkedHashMap<String, String>()
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)

    // 用户导入/自定义/自动组词词库专用独立 O(1) 哈希索引（与内置词库完全分离，桶容量 300/350，绝不被内置词库挤占！）
    private class UserDictIndex(
        val wubiExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val wubiPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinAbbr: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val englishPrefix: HashMap<String, MutableList<Pair<String, Int>>> = HashMap()
    )
    @Volatile
    private var userDictIndex = UserDictIndex()

    private val userFreqMap = ConcurrentHashMap<String, Int>()
    private val userCodeSelMap = ConcurrentHashMap<String, CodeSelectionStat>()
    // 二级索引：按 t14Code 分桶存储 (word -> CodeSelectionStat)，彻底消除打字排序与上屏衰减时的全表扫描和字符串拼接分配！
    private val userCodeSelByCode = ConcurrentHashMap<String, ConcurrentHashMap<String, CodeSelectionStat>>()
    @Volatile
    private var mruSequenceCounter = System.currentTimeMillis()
    @Volatile
    private var lastCachedQueryKey: String = ""
    @Volatile
    private var lastCachedQueryMru: Long = -1L
    @Volatile
    private var lastCachedQueryResult: List<Candidate> = emptyList()

    private fun putCodeSelStat(t14Code: String, word: String, stat: CodeSelectionStat) {
        if (t14Code.isEmpty() || word.isEmpty()) return
        userCodeSelMap["$t14Code|$word"] = stat
        userCodeSelByCode.getOrPut(t14Code) { ConcurrentHashMap() }[word] = stat
    }

    private fun removeCodeSelStat(t14Code: String, word: String) {
        if (t14Code.isEmpty() || word.isEmpty()) return
        userCodeSelMap.remove("$t14Code|$word")
        userCodeSelByCode[t14Code]?.remove(word)
    }

    private fun invalidateQueryCache() {
        lastCachedQueryKey = ""
        lastCachedQueryMru = -1L
    }
    private val userBigramMap = ConcurrentHashMap<String, MutableList<String>>()
    private val builtInAssocMap = HashMap<String, List<String>>(15000)
    private val defaultCommonAssoc = listOf("的", "了", "是", "在", "我", "有", "和", "就", "不", "都", "也", "很", "可以", "什么", "自己", "知道", "觉得", "现在")

    // 连续单字打字滑动窗口（用于检测用户高频连续单字输入未收录词，如连打「吐」「槽」满 5 次自动组词收录）
    private data class RecentCharCommit(val text: String, val timestamp: Long)
    private val recentCharWindow = ArrayList<RecentCharCommit>(6)

    private val isLoaded = AtomicBoolean(false)
    private val isLoading = AtomicBoolean(false)
    private val userDictDirty = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pendingReadyCallbacks = CopyOnWriteArrayList<() -> Unit>()

    fun isEngineLoaded(): Boolean = isLoaded.get()

    fun markUserDictDirty() {
        userDictDirty.set(true)
    }

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    /**
     * 将内置词库或外部词条的原始权重统一归一化到 2,500 .. 14,000 区间：
     * - 25 个标准一级简码字在对应单键下固定为 14,000；
     * - 若词库中带有旧版千万级语料词频 (10,000 ~ 169,000,000) 或 99,999，自动对数压缩至 3,500 .. 9,850，
     *   使其与日常高频词库 (8,800..9,650)、导入词库 (7,200..8,800) 和个人学习加分处于同一科学量级！
     */
    // 核心日常高频单字与全套 86 五笔码（确保「你」「他」「她」「它」「忙」等高频单字在 2/3/4 码下全部默认稳居第 1！）
    private val CORE_DAILY_SINGLE_CHARS_WUBI = listOf(
        Triple("你", listOf("wq", "wqi", "wqiy"), "ni"),
        Triple("他", listOf("wb", "wbn", "wbnn"), "ta"),
        Triple("她", listOf("vb", "vbn", "vbnn"), "ta"),
        Triple("它", listOf("px", "pxb", "pxbb"), "ta"),
        Triple("忙", listOf("ny", "nyn", "nynn"), "mang"),
        Triple("们", listOf("wu", "wun", "wunn"), "men"),
        Triple("好", listOf("vb", "vbg", "vbgg"), "hao"),
        Triple("看", listOf("rh", "rhg", "rhgf"), "kan"),
        Triple("想", listOf("sh", "shn", "shnu"), "xiang"),
        Triple("说", listOf("yu", "yuk", "yukq"), "shuo"),
        Triple("吃", listOf("kt", "ktz", "ktzn"), "chi"),
        Triple("睡", listOf("ht", "htg", "htgf"), "shui"),
        Triple("笑", listOf("tt", "ttd", "ttdu"), "xiao"),
        Triple("哭", listOf("kk", "kkd", "kkdu"), "ku"),
        Triple("觉", listOf("ip", "ipm", "ipmq"), "jue"),
        Triple("得", listOf("tj", "tjg", "tjgf"), "de"),
        Triple("感", listOf("dg", "dgt", "dgtn"), "gan"),
        Triple("爱", listOf("ep", "epd", "epdc"), "ai"),
        Triple("快", listOf("nn", "nnw", "nnwy"), "kuai"),
        Triple("慢", listOf("nj", "njl", "njlc"), "man"),
        Triple("早", listOf("jh", "jhn", "jhnh"), "zao"),
        Triple("晚", listOf("jq", "jqk", "jqkq"), "wan"),
        Triple("累", listOf("lx", "lxi", "lxiu"), "lei"),
        Triple("困", listOf("ls", "lsi", "lsii"), "kun"),
        Triple("饿", listOf("qn", "qnt", "qntn"), "e"),
        Triple("痛", listOf("ui", "uie", "uiek"), "tong"),
        Triple("烦", listOf("od", "odm", "odmy"), "fan"),
        Triple("怕", listOf("nr", "nrg", "nrgg"), "pa"),
        Triple("急", listOf("qe", "qev", "qevn"), "ji"),
        Triple("喜", listOf("fk", "fku", "fkuk"), "xi"),
        Triple("欢", listOf("cq", "cqw", "cqwy"), "huan"),
        Triple("谢", listOf("yt", "ytm", "ytmf"), "xie"),
        Triple("懂", listOf("nt", "ntg", "ntgj"), "dong"),
        Triple("知", listOf("td", "tdk", "tdkg"), "zhi"),
        Triple("道", listOf("ut", "uth", "uthp"), "dao"),
        Triple("吧", listOf("kc", "kcb", "kcbn"), "ba"),
        Triple("呢", listOf("kx", "kxn", "kxnv"), "ne"),
        Triple("吗", listOf("kc", "kcy", "kcygg"), "ma"),
        Triple("呀", listOf("kv", "kvt", "kvte"), "ya"),
        Triple("啊", listOf("kb", "kbs", "kbsk"), "a"),
        Triple("啦", listOf("kr", "krg", "krug"), "la"),
        Triple("哦", listOf("kt", "ktr", "ktrt"), "o"),
        Triple("哈", listOf("kw", "kwg", "kwgk"), "ha"),
        Triple("去", listOf("fc", "fcu", "fcuu"), "qu"),
        Triple("来", listOf("go", "gou", "goui"), "lai"),
        Triple("走", listOf("fh", "fhu", "fhuu"), "zou"),
        Triple("给", listOf("xw", "xwg", "xwgk"), "gei"),
        Triple("让", listOf("yh", "yhg", "yhgg"), "rang"),
        Triple("把", listOf("rc", "rcb", "rcbn"), "ba"),
        Triple("被", listOf("pu", "pub", "puby"), "bei"),
        Triple("买", listOf("nu", "nud", "nudu"), "mai"),
        Triple("卖", listOf("fn", "fnu", "fnud"), "mai"),
        Triple("玩", listOf("gf", "gfq", "gfqn"), "wan"),
        Triple("做", listOf("wd", "wdt", "wdty"), "zuo"),
        Triple("找", listOf("ra", "rat", "ratg"), "zhao"),
        Triple("用", listOf("et", "eth", "ethnh"), "yong"),
        Triple("等", listOf("tf", "tff", "tffu"), "deng"),
        Triple("帮", listOf("dt", "dtb", "dtbh"), "bang"),
        Triple("问", listOf("uk", "ukd", "ukdk"), "wen"),
        Triple("听", listOf("kr", "krh", "krhk"), "ting"),
        Triple("写", listOf("pg", "pgh", "pghn"), "xie")
    )

    private val CORE_SINGLE_CHAR_SET: Set<String> = CORE_DAILY_SINGLE_CHARS_WUBI.map { it.first }.toSet()

    private fun normalizeBuiltInWeight(word: String, wubiCode: String, rawWeight: Int): Int {
        if (wubiCode.length == 1 && LEVEL1_BREVITY_WORDS[wubiCode] == word) {
            return 14000
        }
        var base = when {
            rawWeight <= 14500 -> rawWeight.coerceIn(2200, 14000)
            rawWeight in 85000..100000 -> (9800 + (rawWeight - 85000) / 15).coerceIn(9800, 11200)
            else -> {
                val lv = log10(rawWeight.toDouble().coerceAtLeast(10.0))
                (3200.0 + (lv - 3.5) * 1380.0).toInt().coerceIn(3500, 9850)
            }
        }
        if (isJargonOrNewsWord(word)) {
            base = (base - 2600).coerceAtLeast(2200)
        }
        return base
    }

    /**
     * 异步初始化词库，并支持注册主线程完成回调（解决切换输入法后趁词库尚未加载完立即打字导致顶栏空白的 Bug！）
     */
    fun ensureInitializedAsync(
        context: Context,
        dbHelper: ImeDatabaseHelper,
        onReadyMainThread: (() -> Unit)? = null
    ) {
        if (isLoaded.get()) {
            if (userDictDirty.compareAndSet(true, false)) {
                Thread {
                    reloadUserDict(dbHelper)
                    onReadyMainThread?.let { cb -> mainHandler.post { cb.invoke() } }
                }.start()
            } else if (onReadyMainThread != null) {
                mainHandler.post { onReadyMainThread.invoke() }
            }
            return
        }
        if (onReadyMainThread != null) {
            pendingReadyCallbacks.add(onReadyMainThread)
        }
        if (!isLoading.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        Thread {
            loadAllInternal(appCtx, dbHelper)
            isLoaded.set(true)
            isLoading.set(false)
            if (pendingReadyCallbacks.isNotEmpty()) {
                val callbacks = ArrayList(pendingReadyCallbacks)
                pendingReadyCallbacks.clear()
                mainHandler.post {
                    for (cb in callbacks) {
                        try {
                            cb.invoke()
                        } catch (_: Exception) {}
                    }
                }
            }
        }.start()
    }

    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        ensureInitializedAsync(context, dbHelper, null)
    }

    private fun loadAllInternal(context: Context, dbHelper: ImeDatabaseHelper) {
        for (syl in VALID_SYLLABLES) {
            val code = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code)) {
                t14SyllableMap[code] = syl
            }
        }

        // 1. 加载内置高频英文日常与 AI 词库 (en_daily_words.txt) + 主英文词典 (english_words.tsv)
        val seenEngLoaded = HashSet<String>(30000)
        fun indexEnglishWord(word: String, weight: Int) {
            if (word.length < 2) return
            val lower = word.lowercase()
            englishExactSet.add(lower)
            if (!seenEngLoaded.add(lower)) return
            val maxP = minOf(8, lower.length)
            for (len in 1..maxP) {
                val pref = lower.substring(0, len)
                val list = englishPrefixIndex.getOrPut(pref) { ArrayList(16) }
                if (list.size < 250) list.add(word to weight)
            }
        }
        for (assetName in listOf("en_daily_words.txt", "english_words.tsv")) {
            try {
                context.assets.open(assetName).use { ins ->
                    var autoWt = 95000
                    BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                        val clean = line.trim()
                        if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                        val tab = clean.indexOf('\t')
                        val word = (if (tab > 0) clean.substring(0, tab) else clean).trim()
                        val wt = if (tab > 0) clean.substring(tab + 1).trim().toIntOrNull() ?: autoWt else autoWt
                        autoWt = maxOf(1000, autoWt - 5)
                        indexEnglishWord(word, wt)
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. 加载单字五笔与拼音码表
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) {
                            val prev = singleCharWubi[ch]
                            if (prev == null || wcode.length > prev.length) {
                                singleCharWubi[ch] = wcode
                            }
                        }
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载词语联想表
        try {
            context.assets.open("assoc_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) {
                        val prefix = line.substring(0, tab)
                        val suffixes = line.substring(tab + 1).split(',').filter { it.isNotEmpty() }
                        if (suffixes.isNotEmpty()) {
                            builtInAssocMap[prefix] = suffixes
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. 加载主词库并建立哈希索引（同时对原始词频做统一归一化）
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 65536).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 4) {
                        val word = parts[0]
                        val wcode = parts[1].lowercase()
                        val segPy = parts[2].lowercase()
                        val t14W: String
                        val t14P: String
                        val t14A: String
                        val rawWeight: Int
                        if (parts.size >= 7) {
                            t14W = parts[3]
                            t14P = parts[4]
                            t14A = parts[5]
                            rawWeight = parts[6].toIntOrNull() ?: 5000
                        } else {
                            t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                            t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                            t14A = extractPyAbbrT14(segPy)
                            rawWeight = parts[3].toIntOrNull() ?: 5000
                        }

                        if (word.isNotEmpty()) {
                            val effectiveWcode = if (wcode.isNotEmpty()) wcode else generateWubi86CodeForWord(word)
                            val normWt = normalizeBuiltInWeight(word, effectiveWcode, rawWeight)
                            val de = DictEntry(word, effectiveWcode, segPy, t14W, t14P, t14A, normWt)
                            indexEntry(de)
                            if (word.length == 1) {
                                val ch = word[0]
                                if (wcode.isNotEmpty()) {
                                    val prev = singleCharWubi[ch]
                                    if (prev == null || (wcode.length > prev.length && wcode.length <= 4)) {
                                        singleCharWubi[ch] = wcode
                                    }
                                }
                                if (segPy.isNotEmpty() && !singleCharPinyin.containsKey(ch)) {
                                    singleCharPinyin[ch] = segPy.substringBefore("'")
                                }
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4B. 注入核心日常高频单字（你、他、她、它、忙、好、看、想等）的 2/3/4 码全覆盖索引，
        //     并将所有常用单字的最高权重同步继承给其 4 码全码，彻底解决 4 字母单字被排到词语后面的问题！
        val charBestWeight = HashMap<Char, Int>(4096)
        for ((_, list) in builtInWordMap) {
            for (de in list) {
                if (de.word.length == 1) {
                    val ch = de.word[0]
                    val prev = charBestWeight[ch] ?: 0
                    if (de.weight > prev && de.weight < 13500) {
                        charBestWeight[ch] = de.weight
                    }
                }
            }
        }
        for ((ch, fullWcode) in singleCharWubi) {
            val bestW = charBestWeight[ch] ?: continue
            if (bestW >= 5600 && fullWcode.length in 3..4) {
                val py = singleCharPinyin[ch] ?: ""
                val t14Full = letterToT14Code(fullWcode)
                val t14Py = if (py.isNotEmpty()) letterToT14Code(py) else ""
                if (t14Full.isNotEmpty()) {
                    indexEntry(DictEntry(ch.toString(), fullWcode, py, t14Full, t14Py, "", bestW))
                }
                if (fullWcode.length == 3) {
                    val c4 = fullWcode + fullWcode.last()
                    val t14C4 = letterToT14Code(c4)
                    if (t14C4.length == 4) {
                        indexEntry(DictEntry(ch.toString(), c4, py, t14C4, t14Py, "", bestW))
                    }
                }
            }
        }
        for ((idx, triple) in CORE_DAILY_SINGLE_CHARS_WUBI.withIndex()) {
            val (chStr, codes, py) = triple
            val ch = chStr[0]
            val fullCode = codes.last().take(4)
            if (!singleCharWubi.containsKey(ch) || (singleCharWubi[ch]?.length ?: 0) < fullCode.length) {
                singleCharWubi[ch] = fullCode
            }
            if (!singleCharPinyin.containsKey(ch)) {
                singleCharPinyin[ch] = py
            }
            val coreWt = maxOf(10200, 11350 - idx * 12)
            val t14P = letterToT14Code(py)
            for (c in codes) {
                val wcode = c.take(4)
                val t14W = letterToT14Code(wcode)
                if (t14W.isNotEmpty()) {
                    indexEntry(DictEntry(chStr, wcode, py, t14W, t14P, "", coreWt))
                }
            }
        }

        // 5. 运行时加载内置「中文日常高频用语词库」(cn_daily_phrases.txt)
        //    按字长黄金梯度赋权：2字日常词(9600~9920) > 3字日常词(8900~9250) > 4字成语(8150~8550) > 5字以上长句(6850~7300)
        try {
            context.assets.open("cn_daily_phrases.txt").use { ins ->
                var idx2 = 0
                var idx3 = 0
                var idx4 = 0
                var idxLong = 0
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val w = line.trim()
                    if (w.isEmpty() || w.startsWith("#")) return@forEachLine
                    val dailyWt = when (w.length) {
                        2 -> maxOf(9550, 9920 - idx2++ / 3)
                        3 -> maxOf(8850, 9250 - idx3++ / 2)
                        4 -> maxOf(8100, 8550 - idx4++ / 2)
                        else -> maxOf(6800, 7300 - idxLong++)
                    }
                    val wcode = generateWubi86CodeForWord(w)
                    val segPy = generateSegmentedPinyinForWord(w)
                    val t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                    val t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                    val t14A = extractPyAbbrT14(segPy)
                    if (t14W.isNotEmpty() || t14P.isNotEmpty()) {
                        indexEntry(DictEntry(w, wcode, segPy, t14W, t14P, t14A, dailyWt))
                    }
                    if (w.length == 4 && isPureChinese(w)) {
                        registerIdiomForSmartAssoc(w)
                    }
                }
            }
        } catch (_: Exception) {}

        // 6. 将最常用的 AI 与日常英文词同步注入 14 键拼音前缀索引
        val topCrossModeEng = listOf(
            "gemini", "Gemini", "deepseek", "DeepSeek", "chatgpt", "ChatGPT", "gpt", "GPT",
            "claude", "Claude", "grok", "Grok", "openai", "copilot", "github", "android",
            "apk", "css", "oklch", "rgb", "hsv", "hsl", "love", "hello", "baby", "okay"
        )
        for ((idx, ew) in topCrossModeEng.withIndex()) {
            val t14P = letterToT14Code(ew)
            if (t14P.isNotEmpty()) {
                indexEntry(DictEntry(ew, "", ew.lowercase(), "", t14P, "", 9400 - idx * 10))
            }
        }

        reloadUserLearningData(dbHelper)
        reloadUserDict(dbHelper)
    }

    fun reloadUserLearningData(dbHelper: ImeDatabaseHelper) {
        try {
            userFreqMap.clear()
            userFreqMap.putAll(dbHelper.loadUserFreqMap())
            userCodeSelMap.clear()
            userCodeSelByCode.clear()
            val loadedSel = dbHelper.loadUserCodeSelMap()
            for ((k, stat) in loadedSel) {
                userCodeSelMap[k] = stat
                val sep = k.indexOf('|')
                if (sep > 0 && sep + 1 < k.length) {
                    val code = k.substring(0, sep)
                    val w = k.substring(sep + 1)
                    userCodeSelByCode.getOrPut(code) { ConcurrentHashMap() }[w] = stat
                }
                if (stat.lastUsed > mruSequenceCounter) {
                    mruSequenceCounter = stat.lastUsed
                }
            }
            userBigramMap.clear()
            userBigramMap.putAll(dbHelper.loadUserBigramMap())
            invalidateQueryCache()
        } catch (_: Exception) {}
    }

    private fun registerIdiomForSmartAssoc(idiom: String) {
        if (idiom.length != 4 || isJargonOrNewsWord(idiom)) return
        val p2 = idiom.substring(0, 2)
        val s2 = idiom.substring(2, 4)
        val list2 = idiomCompletionMap.getOrPut(p2) { ArrayList(6) }
        if (list2.size < 16 && !list2.contains(s2)) list2.add(s2)

        val p3 = idiom.substring(0, 3)
        val s1 = idiom.substring(3, 4)
        val list3 = idiomCompletionMap.getOrPut(p3) { ArrayList(4) }
        if (list3.size < 10 && !list3.contains(s1)) list3.add(s1)
    }

    /**
     * 为词条生成「盲打拆字肌肉记忆」容错五笔码：
     * 1. 二字词含 25 个一级简码字时，支持「简码键 + 次字根」双轨打法；
     * 2. 二字词中若某字有 >=3 根，支持「首根 + 末根（视觉显著偏旁）」直觉拆法（例如「括」按 r+k、「话」按 y+k）；
     * 3. 三字词支持「2+1+1（首字前两根 + 次字首根 + 末字首根）」与标准「1+1+2」双轨共存。
     */
    private fun generateFaultTolerantT14Codes(word: String, primaryT14: String): List<String> {
        if (word.length !in 2..3 || !isPureChinese(word)) return emptyList()
        val codes = word.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return emptyList()
        val altLetters = ArrayList<String>(4)

        if (word.length == 2) {
            val w1 = codes[0]
            val w2 = codes[1]
            val c1 = word[0]
            val c2 = word[1]
            // (a) 一级简码字替代组词码
            val lv1_1 = CHAR_TO_LEVEL1_KEY[c1]
            val lv1_2 = CHAR_TO_LEVEL1_KEY[c2]
            if (lv1_1 != null) {
                altLetters.add(lv1_1 + lv1_1 + w2.take(2))
                if (w1.length >= 2) altLetters.add(lv1_1 + w1[1] + w2.take(2))
            }
            if (lv1_2 != null) {
                altLetters.add(w1.take(2) + lv1_2 + lv1_2)
                if (w2.length >= 2) altLetters.add(w1.take(2) + lv1_2 + w2[1])
            }
            // (b) 视觉直觉跳根拆法：首字取第1根+第3根（如左右结构右部上下拆字直觉取右下口/日/心/寸）
            if (w1.length >= 3 && w2.length >= 2) {
                altLetters.add("${w1[0]}${w1[2]}${w2[0]}${w2[1]}")
            }
            if (w1.length >= 2 && w2.length >= 3) {
                altLetters.add("${w1[0]}${w1[1]}${w2[0]}${w2[2]}")
            }
        } else if (word.length == 3) {
            // 三字词 2+1+1 顺手打法
            val w1 = codes[0]
            val w2 = codes[1]
            val w3 = codes[2]
            if (w1.length >= 2) {
                altLetters.add("${w1[0]}${w1[1]}${w2[0]}${w3[0]}")
            }
        }

        val res = ArrayList<String>(altLetters.size)
        for (al in altLetters) {
            val t14 = letterToT14Code(al)
            if (t14.length == 4 && t14 != primaryT14 && !res.contains(t14)) {
                res.add(t14)
            }
        }
        return res
    }

    private fun indexEntry(de: DictEntry) {
        val existingList = builtInWordMap.getOrPut(de.word) { ArrayList(2) }
        existingList.add(de)

        if (de.word.length == 4 && de.weight >= 7400 && isPureChinese(de.word)) {
            registerIdiomForSmartAssoc(de.word)
        }

        if (de.t14Wubi.isNotEmpty()) {
            val exactList = wubiExactIndex.getOrPut(de.t14Wubi) { ArrayList(12) }
            val prevIdx = exactList.indexOfFirst { it.word == de.word }
            if (prevIdx >= 0) {
                if (de.weight > exactList[prevIdx].weight) {
                    exactList[prevIdx] = de
                }
            } else if (exactList.size < 450) {
                exactList.add(de)
            }

            val maxPref = minOf(3, de.t14Wubi.length - 1)
            for (len in 1..maxPref) {
                val pref = de.t14Wubi.substring(0, len)
                val pList = wubiPrefixIndex.getOrPut(pref) { ArrayList(16) }
                val pPrev = pList.indexOfFirst { it.word == de.word }
                if (pPrev >= 0) {
                    if (de.weight > pList[pPrev].weight) {
                        pList[pPrev] = de
                    }
                } else if (pList.size < 450) {
                    pList.add(de)
                }
            }

            if (de.weight >= 6800 && de.word.length in 2..3) {
                val altCodes = generateFaultTolerantT14Codes(de.word, de.t14Wubi)
                for (altT14 in altCodes) {
                    val ftList = wubiFaultTolerantIndex.getOrPut(altT14) { ArrayList(6) }
                    if (ftList.size < 120 && ftList.none { it.word == de.word }) {
                        ftList.add(de)
                    }
                }
            }
        }

        if (de.t14Pinyin.isNotEmpty()) {
            val pyExact = pinyinExactIndex.getOrPut(de.t14Pinyin) { ArrayList(8) }
            if (pyExact.size < 120) pyExact.add(de)

            if (de.word.length == 1 && pyExact.size <= 12) {
                val scList = t14SingleCharByPy.getOrPut(de.t14Pinyin) { ArrayList(6) }
                if (scList.size < 10) scList.add(de)
            }

            val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
            for (len in 1..maxPyPref) {
                val pref = de.t14Pinyin.substring(0, len)
                val pList = pinyinPrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 160) pList.add(de)
            }
        }

        if (de.t14PyAbbr.length in 2..6) {
            val aList = pinyinAbbrIndex.getOrPut(de.t14PyAbbr) { ArrayList(8) }
            if (aList.size < 80) aList.add(de)
        }
    }

    fun reloadUserDict(context: Context) {
        reloadUserDict(ImeDatabaseHelper(context.applicationContext))
    }

    /**
     * 刷新用户个人词库与外部导入词库 (user_dict)：
     * - 采用独立的 UserDictIndex 容器，桶容量扩大至 300/350，绝不被内置词库截断；
     * - 按「手动添加/自动组词 -> 导入词库 -> weight DESC -> id DESC」排序；
     * - 若导入词条缺失五笔码或拼音码，自动根据 8105 单字表实时补全！
     */
    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        val nextIdx = UserDictIndex()
        try {
            dbHelper.readableDatabase.rawQuery(
                """
                SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight, source_name
                FROM user_dict
                ORDER BY CASE WHEN source_name IN ('手动添加', '自动组词') THEN 0 ELSE 1 END ASC, weight DESC, id DESC
                """.trimIndent(),
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val w = (c.getString(0) ?: "").trim()
                    if (w.isEmpty()) continue
                    var wc = (c.getString(1) ?: "").trim().lowercase()
                    if (wc == "__en__" || (w.length >= 2 && w.all { it in 'a'..'z' || it in 'A'..'Z' || it == '-' || it == '\'' })) {
                        val lower = w.lowercase()
                        val wt = c.getInt(5).coerceAtLeast(90000)
                        val maxP = minOf(8, lower.length)
                        for (len in 1..maxP) {
                            val pref = lower.substring(0, len)
                            val list = nextIdx.englishPrefix.getOrPut(pref) { ArrayList(12) }
                            if (list.size < 250) list.add(w to wt)
                        }
                        continue
                    }
                    var py = (c.getString(2) ?: "").trim().lowercase()
                    var t14W = (c.getString(3) ?: "").trim()
                    var t14P = (c.getString(4) ?: "").trim()
                    val rawWt = c.getInt(5)
                    val srcName = c.getString(6) ?: "手动添加"

                    if (wc.isEmpty()) {
                        wc = generateWubi86CodeForWord(w)
                        t14W = letterToT14Code(wc)
                    } else if (t14W.isEmpty()) {
                        t14W = letterToT14Code(wc)
                    }

                    if (py.isEmpty()) {
                        py = generateSegmentedPinyinForWord(w)
                        t14P = letterToT14Code(py.replace("'", ""))
                    } else if (t14P.isEmpty()) {
                        t14P = letterToT14Code(py.replace("'", ""))
                    }

                    val calibratedWt = when (srcName) {
                        "手动添加" -> maxOf(rawWt, 9200)
                        "自动组词" -> maxOf(rawWt, 9100)
                        else -> maxOf(rawWt, 7200)
                    }

                    val de = DictEntry(
                        word = w,
                        wubiCode = wc,
                        segmentedPinyin = py,
                        t14Wubi = t14W,
                        t14Pinyin = t14P,
                        t14PyAbbr = extractPyAbbrT14(py),
                        weight = calibratedWt
                    )
                    if (de.t14Wubi.isNotEmpty()) {
                        val exList = nextIdx.wubiExact.getOrPut(de.t14Wubi) { ArrayList(8) }
                        if (exList.size < 300) exList.add(de)
                        val maxPref = minOf(3, de.t14Wubi.length - 1)
                        for (len in 1..maxPref) {
                            val pref = de.t14Wubi.substring(0, len)
                            val pList = nextIdx.wubiPrefix.getOrPut(pref) { ArrayList(12) }
                            if (pList.size < 350) pList.add(de)
                        }
                    }
                    if (de.t14Pinyin.isNotEmpty()) {
                        val pyEx = nextIdx.pinyinExact.getOrPut(de.t14Pinyin) { ArrayList(8) }
                        if (pyEx.size < 300) pyEx.add(de)
                        val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
                        for (len in 2..maxPyPref) {
                            val pref = de.t14Pinyin.substring(0, len)
                            val pList = nextIdx.pinyinPrefix.getOrPut(pref) { ArrayList(10) }
                            if (pList.size < 300) pList.add(de)
                        }
                    }
                    if (de.t14PyAbbr.length in 2..6) {
                        val aList = nextIdx.pinyinAbbr.getOrPut(de.t14PyAbbr) { ArrayList(8) }
                        if (aList.size < 250) aList.add(de)
                    }
                }
            }
            userDictIndex = nextIdx
            userDictDirty.set(false)
            invalidateQueryCache()
        } catch (_: Exception) {}
    }

    /**
     * 内存增量注入新习得或新添加的个人词条（O(1) 毫秒级生效，避免重刷整张 user_dict 表引发卡顿）
     */
    fun injectLearnedUserPhraseInMemory(
        word: String,
        wubiCode: String,
        pinyinCode: String,
        weight: Int = 9100,
        timestamp: Long = System.currentTimeMillis()
    ) {
        val w = word.trim()
        if (w.isEmpty()) return
        val wc = wubiCode.trim().lowercase().ifEmpty { generateWubi86CodeForWord(w) }
        val py = pinyinCode.trim().lowercase().ifEmpty { generateSegmentedPinyinForWord(w) }
        val t14W = if (wc.isNotEmpty()) letterToT14Code(wc) else ""
        val t14P = if (py.isNotEmpty()) letterToT14Code(py.replace("'", "")) else ""
        val de = DictEntry(
            word = w,
            wubiCode = wc,
            segmentedPinyin = py,
            t14Wubi = t14W,
            t14Pinyin = t14P,
            t14PyAbbr = extractPyAbbrT14(py),
            weight = weight
        )
        val curIdx = userDictIndex
        synchronized(this) {
            if (de.t14Wubi.isNotEmpty()) {
                val exList = curIdx.wubiExact.getOrPut(de.t14Wubi) { ArrayList(8) }
                exList.removeAll { it.word == w }
                exList.add(0, de)
                val maxPref = minOf(3, de.t14Wubi.length - 1)
                for (len in 1..maxPref) {
                    val pref = de.t14Wubi.substring(0, len)
                    val pList = curIdx.wubiPrefix.getOrPut(pref) { ArrayList(12) }
                    pList.removeAll { it.word == w }
                    pList.add(0, de)
                }
                val prevStat = userCodeSelByCode[de.t14Wubi]?.get(w)
                val nextCnt = maxOf(prevStat?.count ?: 0, 2)
                putCodeSelStat(de.t14Wubi, w, CodeSelectionStat(nextCnt, maxOf(timestamp, mruSequenceCounter)))
            }
            if (de.t14Pinyin.isNotEmpty()) {
                val pyEx = curIdx.pinyinExact.getOrPut(de.t14Pinyin) { ArrayList(8) }
                pyEx.removeAll { it.word == w }
                pyEx.add(0, de)
                val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
                for (len in 2..maxPyPref) {
                    val pref = de.t14Pinyin.substring(0, len)
                    val pList = curIdx.pinyinPrefix.getOrPut(pref) { ArrayList(10) }
                    pList.removeAll { it.word == w }
                    pList.add(0, de)
                }
            }
            if (de.t14PyAbbr.length in 2..6) {
                val aList = curIdx.pinyinAbbr.getOrPut(de.t14PyAbbr) { ArrayList(8) }
                aList.removeAll { it.word == w }
                aList.add(0, de)
            }
        }
        invalidateQueryCache()
    }

    fun resetUserFrequency(dbHelper: ImeDatabaseHelper) {
        userFreqMap.clear()
        userCodeSelMap.clear()
        userCodeSelByCode.clear()
        userBigramMap.clear()
        synchronized(recentCharWindow) {
            recentCharWindow.clear()
        }
        invalidateQueryCache()
        dbHelper.resetUserFrequencySorting()
    }

    /**
     * 记录用户实际上屏的字词：
     * 1. 更新内存与 SQLite 中的 user_freq、user_code_mru（含同编码下竞争候选自动衰减 -1）和 user_bigram；
     * 2. 自动组词检测：当用户连续单字输入某个词汇（如先打「吐」再打「槽」组成「吐槽」）达到设定次数（默认 5 次）时，
     *    自动合成其 86 五笔码与拼音收录进 user_dict 并回调通知！
     */
    fun onWordCommitted(
        word: String,
        prevWord: String?,
        dbHelper: ImeDatabaseHelper,
        usedT14Code: String = "",
        context: Context? = null,
        onAutoPhraseLearned: ((String, String, String) -> Unit)? = null
    ) {
        if (word.isEmpty()) return
        userFreqMap[word] = ((userFreqMap[word] ?: 0) + 1).coerceAtMost(5000)
        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)

        if (usedT14Code.isNotEmpty()) {
            val codeBucket = userCodeSelByCode.getOrPut(usedT14Code) { ConcurrentHashMap() }
            val prevStat = codeBucket[word]
            val nextCnt = ((prevStat?.count ?: 0) + 1).coerceAtMost(50)
            putCodeSelStat(usedT14Code, word, CodeSelectionStat(nextCnt, mruSequenceCounter))

            // 同编码下未选中的其他历史候选温和衰减 -1；
            // 关键升级：一旦当前主动选中的字/词达到 2 次及以上（确认个人习惯），立即将同编码旧竞争词的计数压到 nextCnt - 1，
            // 彻底解决之前「你」「他」选了很多次却因为旧词历史累计计数更高而卡在第 2 名的问题！
            val wordsToRemove = ArrayList<String>(2)
            for ((otherWord, stat) in codeBucket.entries) {
                if (otherWord != word) {
                    val rawDecayed = stat.count - 1
                    val decayed = if (nextCnt >= 2) minOf(rawDecayed, nextCnt - 1) else rawDecayed
                    if (decayed <= 0) {
                        wordsToRemove.add(otherWord)
                    } else {
                        putCodeSelStat(usedT14Code, otherWord, CodeSelectionStat(decayed, stat.lastUsed))
                    }
                }
            }
            for (rw in wordsToRemove) {
                removeCodeSelStat(usedT14Code, rw)
            }
        }
        invalidateQueryCache()

        if (!prevWord.isNullOrEmpty() && prevWord != word) {
            val list = userBigramMap.getOrPut(prevWord) { CopyOnWriteArrayList() }
            list.remove(word)
            list.add(0, word)
            if (list.size > 12) list.removeAt(list.lastIndex)
        }
        dbHelper.recordWordUsageAsync(word, prevWord, usedT14Code, mruSequenceCounter)

        if (context != null) {
            checkConsecutiveSingleCharAutoPhrase(context, word, dbHelper, onAutoPhraseLearned)
        }
    }

    private fun isPureChinese(s: String): Boolean {
        if (s.isEmpty()) return false
        for (ch in s) {
            if (ch.code !in 0x4E00..0x9FA5) return false
        }
        return true
    }

    private fun checkConsecutiveSingleCharAutoPhrase(
        context: Context,
        committedWord: String,
        dbHelper: ImeDatabaseHelper,
        onAutoPhraseLearned: ((String, String, String) -> Unit)?
    ) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("auto_phrase_learn_enabled", true)) return
        val threshold = prefs.getInt("auto_phrase_threshold", 5).coerceIn(2, 20)

        val now = System.currentTimeMillis()
        if (committedWord.length != 1 || !isPureChinese(committedWord)) {
            synchronized(recentCharWindow) {
                recentCharWindow.clear()
            }
            return
        }

        val ch = committedWord[0]
        if (ch in AUTO_PHRASE_STOP_CHARS) {
            synchronized(recentCharWindow) {
                recentCharWindow.clear()
            }
            return
        }

        val candidatesToRecord = ArrayList<String>(2)
        synchronized(recentCharWindow) {
            if (recentCharWindow.isNotEmpty() && now - recentCharWindow.last().timestamp > 15000L) {
                recentCharWindow.clear()
            }
            recentCharWindow.add(RecentCharCommit(committedWord, now))
            while (recentCharWindow.size > 4) {
                recentCharWindow.removeAt(0)
            }
            val n = recentCharWindow.size
            if (n >= 2) {
                val c1 = recentCharWindow[n - 2].text
                val c2 = recentCharWindow[n - 1].text
                if (c1 != c2) {
                    candidatesToRecord.add(c1 + c2)
                }
            }
            if (n >= 3) {
                val c1 = recentCharWindow[n - 3].text
                val c2 = recentCharWindow[n - 2].text
                val c3 = recentCharWindow[n - 1].text
                if (!(c1 == c2 && c2 == c3)) {
                    candidatesToRecord.add(c1 + c2 + c3)
                }
            }
        }

        for (phrase in candidatesToRecord) {
            val wubiCode = generateWubi86CodeForWord(phrase)
            val pinyinCode = generateSegmentedPinyinForWord(phrase)
            if (wubiCode.isNotEmpty() || pinyinCode.isNotEmpty()) {
                dbHelper.recordAutoPhraseHitAndPromoteAsync(
                    context = context,
                    phrase = phrase,
                    wubiCode = wubiCode,
                    pinyinCode = pinyinCode,
                    threshold = threshold,
                    onAutoPromotedMainThread = onAutoPhraseLearned
                )
            }
        }
    }

    private val contextualIdiomAndChatTriggers = mapOf(
        "真是" to listOf("哭笑不得", "莫名其妙", "绝了", "服了", "太好了", "心疼", "无语了"),
        "简直" to listOf("匪夷所思", "难以置信", "一模一样", "太绝了", "完美", "不要太爽"),
        "令人" to listOf("哭笑不得", "匪夷所思", "难以置信", "头秃", "心旷神怡", "赏心悦目"),
        "让人" to listOf("哭笑不得", "心疼", "眼前一亮", "欲罢不能", "爱不释手"),
        "觉得" to listOf("莫名其妙", "不可思议", "挺好的", "没必要", "可以", "很舒服"),
        "感觉" to listOf("莫名其妙", "精疲力尽", "挺好的", "还可以", "怪怪的"),
        "完全" to listOf("不知所措", "没问题", "绷不住了", "一模一样", "可以"),
        "果然" to listOf("名不虚传", "不出所料", "一语成谶", "是这样", "还得是你"),
        "实在" to listOf("无可奈何", "哭笑不得", "太难了", "不好意思", "受不了"),
        "特别" to listOf("喜欢", "好看", "舒服", "开心", "赏心悦目", "爱不释手"),
        "非常" to listOf("感谢", "喜欢", "满意", "抱歉", "开心", "完美"),
        "祝你" to listOf("心想事成", "万事如意", "一帆风顺", "天天开心", "好运连连"),
        "希望" to listOf("一切顺利", "得偿所愿", "心想事成", "越来越好")
    )

    fun getAssociations(committedWord: String, limit: Int = 28): List<String> {
        if (committedWord.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        // 1. 用户个人真实接龙记忆 (Bigram)
        userBigramMap[committedWord]?.forEach { nextW ->
            if (seen.add(nextW) && result.size < limit) result.add(nextW)
        }

        // 2. 智能成语半截补全（如打完「莫名」立出「其妙」，打完「迫不」立出「及待」，打完「一模」立出「一样」）
        idiomCompletionMap[committedWord]?.forEach { suffix ->
            if (seen.add(suffix) && result.size < limit) result.add(suffix)
        }
        if (committedWord.length >= 2) {
            val tail2 = committedWord.takeLast(2)
            idiomCompletionMap[tail2]?.forEach { suffix ->
                if (seen.add(suffix) && result.size < limit) result.add(suffix)
            }
        }

        // 3. 语境触发词 -> 智能成语与日常金句联想（如打完「真是」「简直」「令人」）
        contextualIdiomAndChatTriggers[committedWord]?.forEach { nextPhrase ->
            if (seen.add(nextPhrase) && result.size < limit) result.add(nextPhrase)
        }

        // 4. 内置词库高频接龙表（自动过滤冷门新闻/工业后缀）
        builtInAssocMap[committedWord]?.forEach { suffix ->
            if (!isJargonOrNewsWord(committedWord + suffix) && seen.add(suffix) && result.size < limit) {
                result.add(suffix)
            }
        }

        val lastCharStr = committedWord.takeLast(1)
        userBigramMap[lastCharStr]?.forEach { nextW ->
            if (seen.add(nextW) && result.size < limit) result.add(nextW)
        }
        if (committedWord.length >= 2) {
            builtInAssocMap[lastCharStr]?.forEach { suffix ->
                if (!isJargonOrNewsWord(lastCharStr + suffix) && seen.add(suffix) && result.size < limit) {
                    result.add(suffix)
                }
            }
        }

        for (cw in defaultCommonAssoc) {
            if (cw != committedWord && seen.add(cw) && result.size < limit) {
                result.add(cw)
            }
        }
        return result
    }

    /**
     * 记录用户在 26 键英文模式下选定或输入的英文单词
     */
    fun onEnglishWordCommitted(word: String, rawPrefix: String, dbHelper: ImeDatabaseHelper) {
        val clean = word.trim()
        if (clean.length < 2) return
        val lower = clean.lowercase()
        val prefLower = rawPrefix.trim().lowercase()

        val freqKey = "en_freq|$lower"
        val newFreq = (userFreqMap[freqKey] ?: 0) + 1
        userFreqMap[freqKey] = newFreq

        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (prefLower.isNotEmpty()) {
            val k = "en_mru:$prefLower|$lower"
            val prev = userCodeSelMap[k]
            userCodeSelMap[k] = CodeSelectionStat(((prev?.count ?: 0) + 1).coerceAtMost(50), mruSequenceCounter)
        }
        val maxP = minOf(8, lower.length)
        for (len in 1..maxP) {
            val p = lower.substring(0, len)
            val ak = "en_any:$p|$lower"
            val prev = userCodeSelMap[ak]
            userCodeSelMap[ak] = CodeSelectionStat(((prev?.count ?: 0) + 1).coerceAtMost(50), mruSequenceCounter)
            val list = englishPrefixIndex.getOrPut(p) { ArrayList(16) }
            if (list.none { it.first.equals(clean, ignoreCase = true) }) {
                list.add(0, clean to 92000)
            }
        }
        englishExactSet.add(lower)
        dbHelper.recordWordUsageAsync(freqKey, null, if (prefLower.isNotEmpty()) "en_mru:$prefLower" else "", mruSequenceCounter)
    }

    fun queryEnglishCandidates(rawInput: String, limit: Int = 28): List<String> {
        if (rawInput.isEmpty()) return emptyList()
        val lower = rawInput.lowercase()
        val isAllUpper = rawInput.length >= 2 && rawInput.all { it.isUpperCase() }
        val isCapitalized = rawInput[0].isUpperCase() && !isAllUpper
        val prefKey = lower.take(8)

        val candidatesMap = LinkedHashMap<String, Pair<String, Int>>()
        userDictIndex.englishPrefix[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                if (!candidatesMap.containsKey(key)) {
                    candidatesMap[key] = w to (wt + 60000)
                }
            }
        }
        englishPrefixIndex[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                val existing = candidatesMap[key]
                if (existing == null || wt > existing.second) {
                    candidatesMap[key] = w to wt
                }
            }
        }

        class ScoredEng(
            val displayWord: String,
            val lowerWord: String,
            val exactMru: Long,
            val userFreq: Int,
            val anyMru: Long,
            val baseWeight: Int
        )

        val scoredList = ArrayList<ScoredEng>(candidatesMap.size)
        for ((wLower, pair) in candidatesMap) {
            val rawW = pair.first
            val baseWt = pair.second
            val formatted = when {
                isAllUpper -> rawW.uppercase()
                isCapitalized -> rawW.replaceFirstChar { it.uppercaseChar() }
                else -> rawW
            }
            val exMru = userCodeSelMap["en_mru:$lower|$wLower"]?.lastUsed ?: 0L
            val uFreq = userFreqMap["en_freq|$wLower"] ?: 0
            val anyMru = userCodeSelMap["en_any:$lower|$wLower"]?.lastUsed ?: 0L
            val lenPenalty = (wLower.length - lower.length).coerceAtLeast(0) * 180
            scoredList.add(ScoredEng(formatted, wLower, exMru, uFreq, anyMru, baseWt - lenPenalty))
        }

        scoredList.sortWith { a, b ->
            when {
                a.exactMru != b.exactMru -> b.exactMru.compareTo(a.exactMru)
                a.userFreq != b.userFreq -> b.userFreq.compareTo(a.userFreq)
                a.anyMru != b.anyMru -> b.anyMru.compareTo(a.anyMru)
                else -> b.baseWeight.compareTo(a.baseWeight)
            }
        }

        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        val topCand = scoredList.firstOrNull { !it.displayWord.equals(rawInput, ignoreCase = false) }
        val promoteTopToFirst = topCand != null && (
            topCand.exactMru > 0L ||
            topCand.userFreq >= 2 ||
            (lower.length >= 3 && !englishExactSet.contains(lower))
        )

        if (promoteTopToFirst && topCand != null) {
            if (seen.add(topCand.displayWord)) result.add(topCand.displayWord)
            if (seen.add(rawInput)) result.add(rawInput)
        } else {
            if (seen.add(rawInput)) result.add(rawInput)
            if (topCand != null && seen.add(topCand.displayWord)) result.add(topCand.displayWord)
        }

        for (item in scoredList) {
            if (seen.add(item.displayWord)) {
                result.add(item.displayWord)
                if (result.size >= limit) break
            }
        }
        return result
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code ->
            t14SyllableMap[code] ?: code.map { ch -> T14_CODE_TO_LETTER[ch] ?: ch.toString() }.joinToString("")
        }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    /**
     * 核心候选词查询与智能排序：
     * 1. 建立按「当前编码 t14Input + 候选文本 word」区分的个人选择计数 (codeSelCount) 与最近时间 (codeSelLastUsed)：
     *    - 单次点击/误选 (sel_count == 1)：仅给予 +1800 同级温和加分，绝不直接跨级或覆写高权重首选字（彻底杜绝一次误选永久改变首选！）；
     *    - 连续主动选择 (sel_count >= 2，单键一级简码下 >= 3)：触发同层级习惯晋升，按 (sel_count DESC, last_used DESC) 排到该层级前列；
     * 2. 全局词频 userFreqMap 仅提供最多 +800 的温和微调，绝不让刚输入的字跨编码霸占其他编码第 1 位；
     * 3. 严格保留五笔原有的「精确五笔 -> 五笔简码前缀 -> 精确拼音 -> 简拼 -> 拼音前缀」层级优先级，禁止低层级前缀候选越级覆盖五笔精确匹配。
     */
    fun queryCandidates(t14Input: String, rawFallback: String, limit: Int = 90): List<Candidate> {
        if (t14Input.isEmpty() || !isLoaded.get()) return emptyList()

        val curMru = mruSequenceCounter
        val cacheKey = "$t14Input|$limit"
        if (cacheKey == lastCachedQueryKey && curMru == lastCachedQueryMru) {
            val cached = lastCachedQueryResult
            if (cached.isNotEmpty()) return cached
        }

        val exactWubi = ArrayList<Candidate>(40)
        val prefixWubi = ArrayList<Candidate>(56)
        val exactPinyin = ArrayList<Candidate>(48)
        val abbrPinyin = ArrayList<Candidate>(32)
        val prefixPinyin = ArrayList<Candidate>(40)
        val seen = HashSet<String>(160)

        val isLongPinyinMode = t14Input.length > 4
        val segmentedDisplay = segmentT14ToPinyinDisplay(t14Input, rawFallback)

        // 一次性取出当前编码桶的个人习惯统计表（避免在循环与排序比较器中产生成千上万次字符串拼接与哈希查找！）
        val codeBucket = userCodeSelByCode[t14Input]
        val promThreshold = if (t14Input.length == 1) 3 else 2

        fun userBoost(word: String): Int {
            val globalFreq = userFreqMap[word] ?: 0
            val globalTieBonus = minOf(globalFreq * 40, 800)
            val selCnt = codeBucket?.get(word)?.count ?: 0
            val codeBonus = when {
                selCnt <= 0 -> 0
                selCnt == 1 -> 1800
                else -> 4200 + minOf(selCnt, 20) * 550
            }
            return globalTieBonus + codeBonus
        }

        fun makeCand(
            e: DictEntry,
            wubiHint: String?,
            displayCode: String,
            isWubiMatch: Boolean,
            extraBonus: Int = 0
        ): Candidate {
            val globalFreq = userFreqMap[e.word] ?: 0
            val globalTieBonus = minOf(globalFreq * 40, 800)
            val stat = codeBucket?.get(e.word)
            val selCnt = stat?.count ?: 0
            val selLu = stat?.lastUsed ?: 0L
            val codeBonus = when {
                selCnt <= 0 -> 0
                selCnt == 1 -> 1800
                else -> 4200 + minOf(selCnt, 20) * 550
            }
            return Candidate(
                word = e.word,
                wubiHint = wubiHint,
                displayCode = displayCode,
                weight = e.weight + globalTieBonus + codeBonus + extraBonus,
                isWubiMatch = isWubiMatch,
                selCount = selCnt,
                selLastUsed = selLu
            )
        }

        // 同层级零分配智能排序比较器：
        // 当候选已达到习惯晋升阈值 (selCount >= promThreshold，即主动选择满 2 次) 时，优先按最近一次选择时间 (selLastUsed DESC) 排第 1，
        // 确保用户主动连选 2 次「你」「他」或任何字词时，立即超越旧首选登顶第 1！
        val smartTierComparator = Comparator<Candidate> { a, b ->
            val promA = a.selCount >= promThreshold
            val promB = b.selCount >= promThreshold
            if (promA != promB) {
                return@Comparator if (promA) -1 else 1
            }
            if (promA) {
                val luCmp = b.selLastUsed.compareTo(a.selLastUsed)
                if (luCmp != 0) return@Comparator luCmp
                val cntCmp = b.selCount.compareTo(a.selCount)
                if (cntCmp != 0) return@Comparator cntCmp
            }
            b.weight.compareTo(a.weight)
        }

        // 计算 4 码与 2~3 码输入时的「常用单字默认第 1 + 日常 2 字词紧随其后 + 专业公文词降权」黄金梯度：
        // 1. 4 码输入时：常用单字（如「忙」「你」「他」「看」「想」等，weight >= 5600）获得 +1850 置顶加权，默认排在最前面！
        // 2. 日常 2 字词（如「或许」「括号」）获得 +650 加权，紧随常用单字之后（若该 4 码无同码常用单字则直接排第 1），并远超 3/4 字工业公文词！
        // 3. 罕用生僻单字（如「脧」，weight < 4500）扣除 -2200，绝不挡在常用词前面！
        fun wubiLengthAndStyleAdjust(e: DictEntry, inputLen: Int): Int {
            var adj = 0
            if (isJargonOrNewsWord(e.word)) {
                adj -= 2800
            }
            if (inputLen == 4) {
                when (e.word.length) {
                    1 -> {
                        if (e.word in CORE_SINGLE_CHAR_SET || e.weight >= 5600) {
                            adj += 1850
                        } else if (e.weight < 4500) {
                            adj -= 2200
                        }
                    }
                    2 -> if (!isJargonOrNewsWord(e.word)) adj += 650
                    3 -> adj -= 750
                    4 -> adj -= if (isJargonOrNewsWord(e.word)) 1600 else 950
                    else -> if (e.word.length >= 5) adj -= 3500
                }
            } else if (inputLen in 2..3) {
                when {
                    e.word.length == 1 && (e.word in CORE_SINGLE_CHAR_SET || e.weight >= 5800) -> adj += 950
                    e.word.length == 1 && e.weight < 4500 -> adj -= 1600
                    e.word.length >= 5 -> adj -= 2400
                }
            }
            return adj
        }

        // 收集同一匹配桶内的用户词条与系统词条（若同名则取更高权重）
        val uIdx = userDictIndex
        if (!isLongPinyinMode) {
            uIdx.wubiExact[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(makeCand(e, null, e.wubiCode, true, wubiLengthAndStyleAdjust(e, t14Input.length)))
                }
            }
            wubiExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(makeCand(e, null, e.wubiCode, true, wubiLengthAndStyleAdjust(e, t14Input.length)))
                }
            }

            // 4 码「只看字根不看字母」盲打容错召回层：
            // (1) 一级简码双轨组词、二字词跳根拆法、三字词 2+1+1 打法
            // (2) 单字前 3 根完全匹配、仅第 4 码（末笔交叉识别码）按偏的高频单字
            // (3) 首尾两码一致、中间第 2/3 码顺手颠倒的高频二字词/单字
            if (t14Input.length == 4) {
                wubiFaultTolerantIndex[t14Input]?.forEach { e ->
                    if (seen.add(e.word)) {
                        val tolBonus = wubiLengthAndStyleAdjust(e, 4) - 550
                        exactWubi.add(makeCand(e, e.wubiCode, e.wubiCode, true, tolBonus))
                    }
                }
                val pref3 = t14Input.substring(0, 3)
                wubiPrefixIndex[pref3]?.forEach { e ->
                    if (e.word.length == 1 && e.weight >= 6500 && seen.add(e.word)) {
                        exactWubi.add(makeCand(e, e.wubiCode, e.wubiCode, true, -900))
                    }
                }
                if (t14Input[1] != t14Input[2]) {
                    val swappedT14 = "${t14Input[0]}${t14Input[2]}${t14Input[1]}${t14Input[3]}"
                    wubiExactIndex[swappedT14]?.forEach { e ->
                        if (e.word.length <= 2 && e.weight >= 7800 && !isJargonOrNewsWord(e.word) && seen.add(e.word)) {
                            val swapBonus = wubiLengthAndStyleAdjust(e, 4) - 1100
                            exactWubi.add(makeCand(e, e.wubiCode, e.wubiCode, true, swapBonus))
                        }
                    }
                }
            }

            uIdx.wubiPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val shortBonus = (if (e.t14Wubi.length - t14Input.length <= 1) 900 else 0) + wubiLengthAndStyleAdjust(e, t14Input.length)
                    prefixWubi.add(makeCand(e, null, e.wubiCode.take(t14Input.length), true, shortBonus))
                }
            }
            wubiPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val shortBonus = (if (e.t14Wubi.length - t14Input.length <= 1) 900 else 0) + wubiLengthAndStyleAdjust(e, t14Input.length)
                    prefixWubi.add(makeCand(e, null, e.wubiCode.take(t14Input.length), true, shortBonus))
                }
            }
        }

        val needPinyinTiers = isLongPinyinMode || (exactWubi.size + prefixWubi.size < limit)
        if (needPinyinTiers) {
            uIdx.pinyinExact[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactPinyin.add(
                        makeCand(
                            e,
                            e.wubiCode,
                            e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            false,
                            minOf(e.word.length, 4) * 600
                        )
                    )
                }
            }
            pinyinExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactPinyin.add(
                        makeCand(
                            e,
                            e.wubiCode,
                            e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            false,
                            minOf(e.word.length, 4) * 600
                        )
                    )
                }
            }

            if (t14Input.length in 2..6 && (exactWubi.size + prefixWubi.size + exactPinyin.size < limit)) {
                uIdx.pinyinAbbr[t14Input]?.forEach { e ->
                    if (seen.add(e.word)) {
                        abbrPinyin.add(makeCand(e, e.wubiCode, e.segmentedPinyin.ifEmpty { segmentedDisplay }, false))
                    }
                }
                pinyinAbbrIndex[t14Input]?.forEach { e ->
                    if (seen.add(e.word)) {
                        abbrPinyin.add(makeCand(e, e.wubiCode, e.segmentedPinyin.ifEmpty { segmentedDisplay }, false))
                    }
                }
            }

            if (exactWubi.size + prefixWubi.size + exactPinyin.size + abbrPinyin.size < limit) {
                if (t14Input.length in 2..14) {
                    uIdx.pinyinPrefix[t14Input]?.forEach { e ->
                        if (seen.add(e.word)) {
                            prefixPinyin.add(makeCand(e, e.wubiCode, segmentedDisplay, false))
                        }
                    }
                }
                if (t14Input.length <= 14) {
                    pinyinPrefixIndex[t14Input]?.forEach { e ->
                        if (seen.add(e.word)) {
                            prefixPinyin.add(makeCand(e, e.wubiCode, segmentedDisplay, false))
                        }
                    }
                }
            }
        }

        // 叠字连打快捷识别（如连敲 GH 打 hhhhh 自动出 哈哈哈哈哈）
        val repeatCandidatesTop = ArrayList<Candidate>(4)
        if (t14Input.length >= 3 && t14Input.all { it == t14Input[0] }) {
            val n = t14Input.length
            val repeatPresets = when (t14Input[0]) {
                '8' -> listOf("哈" to "h", "嘿" to "h", "哼" to "h")
                '6' -> listOf("啊" to "a", "呀" to "a")
                '1' -> listOf("呜" to "w", "哇" to "w")
                'a' -> listOf("嘻" to "x")
                '5' -> listOf("哦" to "o", "噢" to "o")
                '0' -> listOf("啦" to "l", "略" to "l")
                'd' -> listOf("么" to "m", "喵" to "m")
                else -> emptyList()
            }
            if (repeatPresets.isNotEmpty()) {
                for ((idx, pair) in repeatPresets.withIndex()) {
                    val (chStr, codeCh) = pair
                    val repWord = chStr.repeat(n)
                    abbrPinyin.removeAll { it.word == repWord }
                    prefixPinyin.removeAll { it.word == repWord }
                    exactPinyin.removeAll { it.word == repWord }
                    seen.add(repWord)
                    if (n > 4) {
                        repeatCandidatesTop.add(Candidate(repWord, null, codeCh.repeat(n), 9999999 - idx * 100 + userBoost(repWord), false))
                    } else if (exactWubi.none { it.word == repWord }) {
                        exactWubi.add(Candidate(repWord, null, codeCh.repeat(n), 6500 - idx * 100 + userBoost(repWord), false))
                    }
                }
                if (repeatCandidatesTop.size > 1) {
                    repeatCandidatesTop.sortWith(smartTierComparator)
                }
            }
        }

        if (exactWubi.size > 1) exactWubi.sortWith(smartTierComparator)
        if (prefixWubi.size > 1) prefixWubi.sortWith(smartTierComparator)
        if (exactPinyin.size > 1) exactPinyin.sortWith(smartTierComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(smartTierComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(smartTierComparator)

        val result = ArrayList<Candidate>(limit)
        for (rc in repeatCandidatesTop) {
            result.add(rc)
        }

        if (!isLongPinyinMode) {
            // 跨桶习惯置顶：只要用户在当前按键序列下主动选过某候选满 promThreshold 次（>=2次），
            // 无论它来自精确五笔、五笔简码前缀还是精确同音字，一律按最近选择时间直接升至整个候选栏第 1 位！
            val promotedTop = ArrayList<Candidate>(6)
            for (c in exactWubi) {
                if (c.selCount >= promThreshold) promotedTop.add(c)
            }
            for (c in prefixWubi) {
                if (c.selCount >= promThreshold) promotedTop.add(c)
            }
            for (c in exactPinyin) {
                if (c.selCount >= promThreshold) promotedTop.add(c)
            }
            if (promotedTop.size > 1) {
                promotedTop.sortWith(smartTierComparator)
            }
            val addedResultWords = HashSet<String>(limit)
            for (c in promotedTop) {
                if (result.size < limit && addedResultWords.add(c.word)) {
                    result.add(c)
                }
            }
            for (c in exactWubi) {
                if (result.size < limit && addedResultWords.add(c.word)) result.add(c)
            }
            for (c in prefixWubi) {
                if (result.size < limit && addedResultWords.add(c.word)) result.add(c)
            }
            for (c in exactPinyin) {
                if (result.size < limit && addedResultWords.add(c.word)) result.add(c)
            }
            for (c in abbrPinyin) {
                if (result.size < limit && addedResultWords.add(c.word)) result.add(c)
            }
            for (c in prefixPinyin) {
                if (result.size < limit && addedResultWords.add(c.word)) result.add(c)
            }
        } else {
            for (c in exactPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in abbrPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in prefixPinyin) {
                if (result.size < limit) result.add(c)
            }
        }

        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight + userBoost(it.word) }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val wHint = generateWubi86CodeForWord(synthWord)
                    val insertPos = if (isLongPinyinMode) exactPinyin.size.coerceAtMost(result.size) else result.size
                    result.add(
                        insertPos,
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = fc.wubiCode,
                            displayCode = segmentedDisplay,
                            weight = fc.weight + userBoost(fc.word),
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        lastCachedQueryKey = cacheKey
        lastCachedQueryMru = curMru
        lastCachedQueryResult = result
        return result
    }

    /**
     * 词条与五笔编码全链路诊断器（用于设置页第 7 节「🔍 词条与五笔编码诊断/查询」）：
     * 精确区分：
     * 1) 词库里根本没有这个词；
     * 2) 词库里有词，但缺少五笔编码或编码不匹配；
     * 3) 词条和编码都存在，并展示其在对应 14 键编码下的实时候选排名与个人学习权重。
     */
    fun formatT14KeyLabels(t14Code: String): String {
        if (t14Code.isEmpty()) return "-"
        return t14Code.map { ch -> T14_CODE_TO_KEY_LABEL[ch] ?: ch.toString() }.joinToString(" · ")
    }

    fun recordTypingDiagLog(t14Code: String, candidates: List<Candidate>, committedWord: String) {
        if (t14Code.isEmpty()) return
        val sdf = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
        val timeStr = sdf.format(java.util.Date())
        val keyLabels = formatT14KeyLabels(t14Code)
        val top5 = if (candidates.isEmpty()) "无候选" else candidates.take(5).mapIndexed { i, c -> "${i + 1}.${c.word}(${c.displayCode})" }.joinToString(" ")
        val rec = TypingDiagRecord(
            timeStr = timeStr,
            t14Code = t14Code,
            keyLabels = keyLabels,
            topCandidates = top5,
            committedWord = committedWord
        )
        synchronized(recentTypingLogs) {
            recentTypingLogs.add(0, rec)
            while (recentTypingLogs.size > 15) {
                recentTypingLogs.removeAt(recentTypingLogs.lastIndex)
            }
        }
    }

    fun getRecentTypingDiagReport(): String {
        synchronized(recentTypingLogs) {
            if (recentTypingLogs.isEmpty()) {
                return "暂无打字按键记录。你可以在任意聊天框或上方输入框试打几个五笔词，回来点「🔄 刷新最近按键记录」即可查看每次敲击的 4 个键位和当时的前 5 候选！"
            }
            val sb = StringBuilder()
            sb.append("📋 最近 ").append(recentTypingLogs.size).append(" 次五笔按键与候选轨迹：\n")
            for ((idx, r) in recentTypingLogs.withIndex()) {
                sb.append(idx + 1).append(". [").append(r.timeStr).append("] 按键: ").append(r.keyLabels)
                    .append(" (码:").append(r.t14Code).append(")\n")
                sb.append("   ➔ 上屏:「").append(r.committedWord).append("」 | 当时前5: ").append(r.topCandidates).append("\n")
            }
            return sb.toString().trimEnd()
        }
    }

    /**
     * 一键将指定词条绑定到指定五笔码（或您习惯的4个按键）并置顶为第 1 首选！
     */
    fun pinWordToTopForCode(
        word: String,
        rawCustomCode: String,
        dbHelper: ImeDatabaseHelper
    ): String {
        val cleanWord = word.trim()
        if (cleanWord.isEmpty()) return "请先输入要置顶的字或词"
        val cleanCode = rawCustomCode.trim().lowercase()
        val wcode = if (cleanCode.isNotEmpty() && cleanCode.all { it in 'a'..'z' }) {
            cleanCode
        } else {
            generateWubi86CodeForWord(cleanWord)
        }
        val py = generateSegmentedPinyinForWord(cleanWord)
        val t14Code = if (cleanCode.isNotEmpty() && cleanCode.all { it in "1234567890abcd" }) {
            cleanCode
        } else {
            letterToT14Code(wcode)
        }
        if (t14Code.isEmpty()) {
            return "无法生成有效五笔码，请在第二个框填写您习惯按的 4 个字母（如 akyt）"
        }
        dbHelper.insertUserWord(cleanWord, wcode.ifEmpty { t14Code }, py, 9950, "手动添加")
        injectLearnedUserPhraseInMemory(cleanWord, wcode.ifEmpty { t14Code }, py, 9950)
        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        putCodeSelStat(t14Code, cleanWord, CodeSelectionStat(25, mruSequenceCounter))
        for (i in 1..6) {
            dbHelper.recordWordUsageAsync(cleanWord, null, t14Code, mruSequenceCounter + i)
        }
        invalidateQueryCache()
        return "✅ 已将「$cleanWord」在按键【${formatT14KeyLabels(t14Code)}】(五笔码: $wcode) 下永久置顶为第 1 首选！"
    }

    fun diagnoseWordInEngine(context: Context, dbHelper: ImeDatabaseHelper, rawQuery: String): String {
        val word = rawQuery.trim()
        if (word.isEmpty()) return "请输入要诊断查询的字或词（如：吐槽）"

        val autoWubi = generateWubi86CodeForWord(word)
        val autoPy = generateSegmentedPinyinForWord(word)
        val autoT14Wubi = letterToT14Code(autoWubi)
        val autoT14Py = letterToT14Code(autoPy.replace("'", ""))

        val charBreakdown = word.map { ch ->
            val cw = singleCharWubi[ch] ?: "未收录"
            val cp = singleCharPinyin[ch] ?: "?"
            "$ch(五笔:$cw, 拼音:$cp)"
        }.joinToString(" + ")

        val builtInMatches = builtInWordMap[word] ?: emptyList()
        val userRows = dbHelper.queryUserDictRowsByWord(word)
        val globalFreq = userFreqMap[word] ?: 0

        val sb = StringBuilder()
        sb.append("【诊断词条】「").append(word).append("」\n")
        sb.append("• 单字拆解：").append(charBreakdown).append("\n")
        sb.append("• 86五笔标准取码：").append(autoWubi.ifEmpty { "无法自动合成(缺单字码)" })
            .append("  → 对应14键编码：").append(autoT14Wubi.ifEmpty { "-" }).append("\n")
        sb.append("• 标准拼音：").append(autoPy.ifEmpty { "-" })
            .append("  → 对应14键编码：").append(autoT14Py.ifEmpty { "-" }).append("\n")

        when {
            builtInMatches.isEmpty() && userRows.isEmpty() -> {
                sb.append("• 诊断结论：【第 1 类：词库缺词】当前内置词库与个人词库中均未收录「").append(word).append("」。\n")
                sb.append("• 解决方案：点击下方「➕ 一键收录此词到个人词库」，或连续单字输入满设定次数由系统自动组词收录！")
            }
            builtInMatches.none { it.wubiCode.isNotEmpty() } && userRows.none { it.wubiCode.isNotEmpty() } -> {
                sb.append("• 诊断结论：【第 2 类：有词但缺五笔码】词库中存在该词，但缺少五笔编码字段（仅含拼音）。\n")
                sb.append("• 解决方案：点击下方「➕ 一键收录/补齐编码」即可写入标准五笔码 (").append(autoWubi).append(")！")
            }
            else -> {
                sb.append("• 内置词库记录：")
                if (builtInMatches.isEmpty()) {
                    sb.append("无\n")
                } else {
                    sb.append(builtInMatches.joinToString("；") { "五笔=${it.wubiCode}, 拼音=${it.segmentedPinyin}, 权重=${it.weight}" }).append("\n")
                }
                sb.append("• 个人/导入词库记录：")
                if (userRows.isEmpty()) {
                    sb.append("无\n")
                } else {
                    sb.append(userRows.joinToString("；") { "[${it.sourceName}] 五笔=${it.wubiCode}, 权重=${it.weight}" }).append("\n")
                }
                val checkCode = userRows.firstOrNull { it.t14Wubi.isNotEmpty() }?.t14Wubi
                    ?: builtInMatches.firstOrNull { it.t14Wubi.isNotEmpty() }?.t14Wubi
                    ?: autoT14Wubi
                if (checkCode.isNotEmpty()) {
                    val cands = queryCandidates(checkCode, "", 90)
                    val rankIdx = cands.indexOfFirst { it.word == word }
                    val selStat = userCodeSelMap["$checkCode|$word"]
                    sb.append("• 个人学习记录：全局使用 ").append(globalFreq).append(" 次；编码[").append(checkCode).append("]下专属选中 ")
                        .append(selStat?.count ?: 0).append(" 次\n")
                    val keyPathStr = formatT14KeyLabels(checkCode)
                    val top8Preview = cands.take(8).mapIndexed { i, c -> "${i + 1}.${c.word}(${c.weight})" }.joinToString("  ")
                    sb.append("• 对应键盘按键：").append(keyPathStr).append("\n")
                    sb.append("• 该键位前8候选：").append(top8Preview).append("\n")
                    if (rankIdx >= 0) {
                        sb.append("• 诊断结论：【第 3 类：正常可查】按「").append(keyPathStr).append("」时，「").append(word).append("」当前位于【第 ")
                            .append(rankIdx + 1).append(" 候选】！（若想让它固定排第1，点下方「📌 一键置顶为第1首选」即可）")
                    } else {
                        sb.append("• 诊断结论：词条已存在，但当前编码桶候选较多未进前90，点击「📌 一键置顶为第1首选」可立即升至第 1 位！")
                    }
                }
            }
        }
        return sb.toString()
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()

        fun parseAtOffset(startPos: Int): List<String> {
            val words = ArrayList<String>()
            try {
                val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var pos = startPos
                while (pos + 4 < bytes.size) {
                    val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                    val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                    pos += 4 + pyIdxBytesLen
                    if (samePyCount <= 0 || samePyCount > 2500 || pyIdxBytesLen > 256 || pos >= bytes.size) break
                    for (i in 0 until samePyCount) {
                        if (pos + 2 >= bytes.size) break
                        val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2
                        if (wordByteLen <= 0 || wordByteLen > 128 || pos + wordByteLen > bytes.size) break
                        val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                        pos += wordByteLen
                        if (pos + 2 > bytes.size) break
                        val extLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2 + extLen
                        if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 1..16) {
                            words.add(word)
                        }
                    }
                }
            } catch (_: Exception) {}
            return words
        }

        val primaryOffset = if ((bytes[4].toInt() and 0xFF) == 0x45) 0x26C4 else 0x2628
        val primaryWords = parseAtOffset(primaryOffset)
        if (primaryWords.size >= 5) return primaryWords.distinct()
        val fallbackOffset = if (primaryOffset == 0x2628) 0x26C4 else 0x2628
        val fallbackWords = if (bytes.size > fallbackOffset) parseAtOffset(fallbackOffset) else emptyList()
        return (if (fallbackWords.size > primaryWords.size) fallbackWords else primaryWords).distinct()
    }
}
