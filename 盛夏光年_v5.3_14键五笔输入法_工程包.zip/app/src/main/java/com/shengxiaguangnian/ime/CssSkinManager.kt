package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class SkinConfig(
    // 默认即为示例图 (1000127657_9f2a64.jpg) 的「默认极简灰白」配色与无边框纯净质感
    val kbBgTop: Int = Color.parseColor("#E6E7EB"),
    val kbBgBottom: Int = Color.parseColor("#E6E7EB"),

    val topBarBgTop: Int = Color.parseColor("#F3F4F6"),
    val topBarBgBottom: Int = Color.parseColor("#F3F4F6"),
    val topBarBorder: Int = Color.parseColor("#F3F4F6"),
    val topBarBorderWidthDp: Int = 0,
    val topBarText: Int = Color.parseColor("#33363C"),
    val topBarDivider: Int = Color.parseColor("#D5D8E0"),
    val showTopDivider: Boolean = false,
    val topBarRadiusDp: Int = 16,

    val keyBgTop: Int = Color.parseColor("#FFFFFF"),
    val keyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val keyPressedBg: Int = Color.parseColor("#ECEEF2"),
    val keyBorder: Int = Color.parseColor("#FFFFFF"),
    val keyBorderWidthDp: Int = 0,
    val keyText: Int = Color.parseColor("#222428"),
    val keyHint: Int = Color.parseColor("#B0B4BE"),
    val keyRadiusDp: Int = 12,
    val keyGapDp: Int = 3,
    val keyElevationDp: Int = 1,
    val cssFontScale: Float? = null,

    val funcKeyBgTop: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBgBottom: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBorder: Int = Color.parseColor("#F5F6F8"),
    val funcKeyText: Int = Color.parseColor("#33363C"),

    val punctKeyBgTop: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBorder: Int = Color.parseColor("#FFFFFF"),

    val candidateText: Int = Color.parseColor("#1E2024"),
    val candidateHighlight: Int = Color.parseColor("#D94336"),

    val spaceText: String = "空格",
    val enterText: String = "盛夏\n光年"
)

object CssSkinManager {

    const val DEFAULT_GRAY_CSS = """/* 盛夏光年 · 默认极简灰皮肤（清空 CSS 或点恢复默认即为此皮肤） */
.keyboard-bg {
  background: #E6E7EB;
}

.top-bar {
  background: #F3F4F6;
  border-width: 0px;
  border-radius: 16px;
  color: #33363C;
  divider: none;
}

.key {
  background: #FFFFFF;
  pressed-background: #ECEEF2;
  border-width: 0px;
  border-radius: 12px;
  key-gap: 3px;
  elevation: 1px;
  color: #222428;
  hint-color: #B0B4BE;
  space-text: 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #F5F6F8;
  color: #33363C;
}

.key-punct {
  background: #FFFFFF;
  border-width: 0px;
}

.candidate-bar {
  color: #1E2024;
  highlight-color: #D94336;
}"""

    const val LAVENDER_CSS = """/* 盛夏光年 · 薰衣草雾透皮肤 */
.keyboard-bg {
  background: linear-gradient(#DCE0F0, #E6E9F6);
}

.top-bar {
  background: linear-gradient(#F4F6FD, #E8ECF9);
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 22px;
  color: #454C66;
  divider: show;
  divider-color: #CBD2EA;
}

.key {
  background: linear-gradient(#FAFBFF, #EAEFF9);
  pressed-background: #DCE2F4;
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 15px;
  key-gap: 3px;
  elevation: 1px;
  color: #2A3042;
  hint-color: #7E87A6;
  space-text: 🌿 空格;
  enter-text: 盛夏\n光年✦;
}

.key-func {
  background: linear-gradient(#F1F4FC, #E2E7F5);
  border-color: #F8FAFF;
  color: #454C66;
}

.key-punct {
  background: linear-gradient(#F6F4FF, #E8E4FA);
  border-color: #DCD4F8;
}

.candidate-bar {
  color: #2A3042;
  highlight-color: #6C5CE7;
}"""

    const val SAKURA_PINK_CSS = """/* 盛夏光年 · 奶油樱花粉皮肤 */
.keyboard-bg {
  background: linear-gradient(#F9E8EE, #FCEFF3);
}

.top-bar {
  background: #FFF8FA;
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 20px;
  color: #6D4C56;
  divider: none;
}

.key {
  background: #FFFFFF;
  pressed-background: #F5DCE4;
  border-color: #FFEBF0;
  border-width: 1px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #4A323A;
  hint-color: #C49AA7;
  space-text: 🌸 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #FDF2F5;
  color: #6D4C56;
}

.key-punct {
  background: #FFF5F8;
  border-color: #F8D0DC;
}

.candidate-bar {
  color: #4A323A;
  highlight-color: #E84393;
}"""

    const val DARK_MODE_CSS = """/* 盛夏光年 · 暗夜极客黑皮肤 */
.keyboard-bg {
  background: #18191C;
}

.top-bar {
  background: #23252A;
  border-width: 0px;
  border-radius: 16px;
  color: #D8DAE0;
  divider: none;
}

.key {
  background: #2C2E35;
  pressed-background: #3E414B;
  border-width: 0px;
  border-radius: 11px;
  key-gap: 3px;
  elevation: 0px;
  color: #ECEEF4;
  hint-color: #767B89;
  space-text: 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #22242A;
  color: #B4B8C5;
}

.key-punct {
  background: #2C2E35;
  border-width: 0px;
}

.candidate-bar {
  color: #ECEEF4;
  highlight-color: #FF6B6B;
}"""

    private var cachedSkin: SkinConfig? = null

    fun getSkin(context: Context): SkinConfig {
        cachedSkin?.let { return it }
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val css = prefs.getString("custom_skin_css", "") ?: ""
        // 当 CSS 为空或被删除时，100% 恢复为示例图的「默认极简灰白」皮肤！
        val skin = if (css.isBlank()) SkinConfig() else parseCss(css)
        cachedSkin = skin
        return skin
    }

    fun saveCustomCss(context: Context, css: String) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val trimmed = css.trim()
        prefs.edit().putString("custom_skin_css", trimmed).apply()
        val parsed = if (trimmed.isBlank()) SkinConfig() else parseCss(trimmed)
        parsed.cssFontScale?.let { scale ->
            prefs.edit().putFloat("key_font_scale", scale.coerceIn(0.45f, 1.5f)).apply()
        }
        cachedSkin = null
    }

    fun resetToDefaultSkin(context: Context) {
        saveCustomCss(context, "")
    }

    fun getSavedCss(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_skin_css", "") ?: ""
        return saved.ifBlank { DEFAULT_GRAY_CSS }
    }

    private fun parseColorSafe(raw: String, fallback: Int): Int {
        return try {
            val clean = raw.trim().removeSuffix(";").trim()
            Color.parseColor(clean)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun parsePxInt(raw: String, minVal: Int, maxVal: Int): Int? {
        val n = raw.lowercase().removeSuffix("px").removeSuffix("dp").trim().toIntOrNull()
        return n?.coerceIn(minVal, maxVal)
    }

    private fun parseGradientOrSolid(raw: String, defaultTop: Int, defaultBottom: Int): Pair<Int, Int> {
        val clean = raw.trim().removeSuffix(";").trim()
        if (clean.startsWith("linear-gradient", ignoreCase = true)) {
            val inside = clean.substringAfter("(").substringBeforeLast(")")
            val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
            if (hexes.size >= 2) {
                return parseColorSafe(hexes[0], defaultTop) to parseColorSafe(hexes[1], defaultBottom)
            } else if (hexes.size == 1) {
                val c = parseColorSafe(hexes[0], defaultTop)
                return c to c
            }
        }
        val hexMatch = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value
        if (hexMatch != null) {
            val c = parseColorSafe(hexMatch, defaultTop)
            return c to c
        }
        return defaultTop to defaultBottom
    }

    fun parseCss(css: String): SkinConfig {
        var cfg = SkinConfig()
        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("([.\\w-]+)\\s*\\{([^}]*)\\}")
        for (match in blockRegex.findAll(noComments)) {
            val selector = match.groupValues[1].trim().lowercase()
            val body = match.groupValues[2]
            val props = HashMap<String, String>()
            body.split(";").forEach { line ->
                val colon = line.indexOf(':')
                if (colon > 0) {
                    val k = line.substring(0, colon).trim().lowercase()
                    val v = line.substring(colon + 1).trim()
                    if (k.isNotEmpty() && v.isNotEmpty()) props[k] = v
                }
            }

            when (selector) {
                ".keyboard-bg", "body" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.kbBgTop, cfg.kbBgBottom)
                        cfg = cfg.copy(kbBgTop = t, kbBgBottom = b)
                    }
                }
                ".top-bar" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.topBarBgTop, cfg.topBarBgBottom)
                        cfg = cfg.copy(topBarBgTop = t, topBarBgBottom = b)
                    }
                    props["border-color"]?.let {
                        cfg = cfg.copy(topBarBorder = parseColorSafe(it, cfg.topBarBorder), topBarBorderWidthDp = 1)
                    }
                    props["border-width"]?.let {
                        parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(topBarBorderWidthDp = w) }
                    }
                    props["color"]?.let { cfg = cfg.copy(topBarText = parseColorSafe(it, cfg.topBarText)) }
                    props["divider-color"]?.let { cfg = cfg.copy(topBarDivider = parseColorSafe(it, cfg.topBarDivider)) }
                    props["divider"]?.let {
                        cfg = cfg.copy(showTopDivider = !it.equals("none", ignoreCase = true))
                    }
                    props["border-radius"]?.let {
                        parsePxInt(it, 0, 32)?.let { r -> cfg = cfg.copy(topBarRadiusDp = r) }
                    }
                }
                ".key" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.keyBgTop, cfg.keyBgBottom)
                        cfg = cfg.copy(keyBgTop = t, keyBgBottom = b)
                    }
                    props["pressed-background"]?.let { cfg = cfg.copy(keyPressedBg = parseColorSafe(it, cfg.keyPressedBg)) }
                    props["border-color"]?.let {
                        cfg = cfg.copy(keyBorder = parseColorSafe(it, cfg.keyBorder), keyBorderWidthDp = 1)
                    }
                    props["border-width"]?.let {
                        parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(keyBorderWidthDp = w) }
                    }
                    props["color"]?.let { cfg = cfg.copy(keyText = parseColorSafe(it, cfg.keyText)) }
                    props["hint-color"]?.let { cfg = cfg.copy(keyHint = parseColorSafe(it, cfg.keyHint)) }
                    props["border-radius"]?.let {
                        parsePxInt(it, 0, 28)?.let { r -> cfg = cfg.copy(keyRadiusDp = r) }
                    }
                    props["key-gap"]?.let {
                        parsePxInt(it, 1, 10)?.let { g -> cfg = cfg.copy(keyGapDp = g) }
                    }
                    props["elevation"]?.let {
                        parsePxInt(it, 0, 8)?.let { el -> cfg = cfg.copy(keyElevationDp = el) }
                    }
                    props["font-scale"]?.let {
                        val pct = it.removeSuffix("%").trim().toFloatOrNull()
                        if (pct != null) {
                            val sc = if (pct > 3f) pct / 100f else pct
                            cfg = cfg.copy(cssFontScale = sc.coerceIn(0.45f, 1.5f))
                        }
                    }
                    props["space-text"]?.let { cfg = cfg.copy(spaceText = it.replace("\\n", "\n")) }
                    props["enter-text"]?.let { cfg = cfg.copy(enterText = it.replace("\\n", "\n")) }
                }
                ".key-func" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.funcKeyBgTop, cfg.funcKeyBgBottom)
                        cfg = cfg.copy(funcKeyBgTop = t, funcKeyBgBottom = b)
                    }
                    props["border-color"]?.let { cfg = cfg.copy(funcKeyBorder = parseColorSafe(it, cfg.funcKeyBorder)) }
                    props["color"]?.let { cfg = cfg.copy(funcKeyText = parseColorSafe(it, cfg.funcKeyText)) }
                }
                ".key-punct" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.punctKeyBgTop, cfg.punctKeyBgBottom)
                        cfg = cfg.copy(punctKeyBgTop = t, punctKeyBgBottom = b)
                    }
                    props["border-color"]?.let { cfg = cfg.copy(punctKeyBorder = parseColorSafe(it, cfg.punctKeyBorder)) }
                }
                ".candidate-bar" -> {
                    props["color"]?.let { cfg = cfg.copy(candidateText = parseColorSafe(it, cfg.candidateText)) }
                    props["highlight-color"]?.let { cfg = cfg.copy(candidateHighlight = parseColorSafe(it, cfg.candidateHighlight)) }
                }
            }
        }
        return cfg
    }

    fun makeGradientDrawable(
        topColor: Int,
        bottomColor: Int,
        radiusPx: Int,
        strokeColor: Int? = null,
        strokeWidthPx: Int = 0
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topColor, bottomColor)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            if (strokeColor != null && strokeWidthPx > 0) {
                setStroke(strokeWidthPx, strokeColor)
            }
        }
    }
}
