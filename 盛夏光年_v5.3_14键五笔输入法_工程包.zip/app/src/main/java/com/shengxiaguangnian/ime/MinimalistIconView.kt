package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.TypedValue
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.36f

        when (iconType) {
            TYPE_SETTINGS -> {
                // 极简几何圆环齿轮（6 齿微圆角 + 中心圆孔，纯单色极简线条）
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                // 极简线条笑脸（无彩色，纯单色极简几何线条）
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                // 极简圆角卡片笔记图标（纯单色线条，告别棕色剪贴板 emoji）
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                // 极简收起键盘折线箭头（向下 V 字折线 + 底部细短横线）
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
