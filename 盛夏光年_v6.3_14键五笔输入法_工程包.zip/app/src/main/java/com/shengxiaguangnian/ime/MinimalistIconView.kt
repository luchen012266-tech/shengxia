package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.util.TypedValue
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 莫奈油画睡莲键帽 + 微光背光（外发光）渲染视图：
 * - 支持绘制柔和的多层外发光光晕（Outer Backlight Glow）与珠光内高光边缘，按住按键时背光柔和绽放
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.WHITE
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                invalidate()
            }
        }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val pressOverlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(36, 30, 40, 60)
    }
    private val outerGlowPaint1 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(4.2f)
    }
    private val outerGlowPaint2 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(2.2f)
    }
    private val rimHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.1f)
    }
    private val srcRect = Rect()
    private val dstRectF = RectF()
    private val glowRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        dstRectF.set(0f, 0f, w, h)

        // 1. 绘制微光背光外发光（多级柔光光晕 + 珠光呼吸描边，按住时背光增强）
        if (enableGlow) {
            val rCol = Color.red(glowColor)
            val gCol = Color.green(glowColor)
            val bCol = Color.blue(glowColor)
            val alpha1 = if (isKeyPressedState) 115 else 68
            val alpha2 = if (isKeyPressedState) 185 else 120
            val alphaRim = if (isKeyPressedState) 245 else 185

            outerGlowPaint1.color = Color.argb(alpha1, rCol, gCol, bCol)
            outerGlowPaint2.color = Color.argb(alpha2, rCol, gCol, bCol)
            rimHighlightPaint.color = Color.argb(alphaRim, 255, 255, 255)

            val out1 = dpF(1.8f)
            glowRectF.set(-out1, -out1, w + out1, h + out1)
            canvas.drawRoundRect(glowRectF, cornerRadiusPx + out1, cornerRadiusPx + out1, outerGlowPaint1)

            val out2 = dpF(0.6f)
            glowRectF.set(-out2, -out2, w + out2, h + out2)
            canvas.drawRoundRect(glowRectF, cornerRadiusPx + out2, cornerRadiusPx + out2, outerGlowPaint2)
        }

        // 2. 绘制油画睡莲键帽纹理
        if (bitmap != null) {
            clipPath.reset()
            clipPath.addRoundRect(dstRectF, cornerRadiusPx, cornerRadiusPx, Path.Direction.CW)
            val saveCount = canvas.save()
            canvas.clipPath(clipPath)
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, dstRectF, bmpPaint)
            if (isKeyPressedState) {
                canvas.drawRoundRect(dstRectF, cornerRadiusPx, cornerRadiusPx, pressOverlayPaint)
            }
            canvas.restoreToCount(saveCount)
        }

        // 3. 绘制键帽内侧微光琉璃高光圈
        if (enableGlow) {
            val inset = dpF(0.6f)
            glowRectF.set(inset, inset, w - inset, h - inset)
            canvas.drawRoundRect(glowRectF, cornerRadiusPx, cornerRadiusPx, rimHighlightPaint)
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.36f

        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
