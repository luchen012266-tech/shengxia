package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class SavedCssSkinItem(
    val name: String,
    val css: String,
    val updatedAt: Long = System.currentTimeMillis()
)

data class KeyStyleOverride(
    val bgTop: Int? = null,
    val bgBottom: Int? = null,
    val pressedBg: Int? = null,
    val borderColor: Int? = null,
    val borderWidthDp: Int? = null,
    val textColor: Int? = null,
    val hintColor: Int? = null
) {
    fun mergeWith(higher: KeyStyleOverride?): KeyStyleOverride {
        if (higher == null) return this
        return KeyStyleOverride(
            bgTop = higher.bgTop ?: this.bgTop,
            bgBottom = higher.bgBottom ?: this.bgBottom,
            pressedBg = higher.pressedBg ?: this.pressedBg,
            borderColor = higher.borderColor ?: this.borderColor,
            borderWidthDp = higher.borderWidthDp ?: this.borderWidthDp,
            textColor = higher.textColor ?: this.textColor,
            hintColor = higher.hintColor ?: this.hintColor
        )
    }
}

data class SkinConfig(
    // 默认即为示例图 (1000127657_9f2a64.jpg) 的「默认极简灰白」配色与无边框纯净质感
    val kbBgTop: Int = Color.parseColor("#E6E7EB"),
    val kbBgBottom: Int = Color.parseColor("#E6E7EB"),

    val topBarBgTop: Int = Color.parseColor("#F3F4F6"),
    val topBarBgBottom: Int = Color.parseColor("#F3F4F6"),
    val topBarBorder: Int = Color.parseColor("#F3F4F6"),
    val topBarBorderWidthDp: Int = 0,
    val topBarText: Int = Color.parseColor("#33363C"),
    val topBarDivider: Int = Color.parseColor("#D5D8E0"),
    val showTopDivider: Boolean = false,
    val topBarRadiusDp: Int = 16,

    val keyBgTop: Int = Color.parseColor("#FFFFFF"),
    val keyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val keyPressedBg: Int = Color.parseColor("#ECEEF2"),
    val keyBorder: Int = Color.parseColor("#FFFFFF"),
    val keyBorderWidthDp: Int = 0,
    val keyText: Int = Color.parseColor("#222428"),
    val keyHint: Int = Color.parseColor("#B0B4BE"),
    val keyRadiusDp: Int = 12,
    val keyGapDp: Int = 3,
    val keyElevationDp: Int = 1,
    val cssFontScale: Float? = null,
    val funcFontScale: Float = 1.15f,
    val keyAlign: String = "center",

    val funcKeyBgTop: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBgBottom: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBorder: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBorderWidthDp: Int? = null,
    val funcKeyText: Int = Color.parseColor("#33363C"),

    val punctKeyBgTop: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBorder: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBorderWidthDp: Int? = null,
    val punctKeyText: Int? = null,
    val punctKeyHint: Int? = null,

    val candidateText: Int = Color.parseColor("#1E2024"),
    val candidateHighlight: Int = Color.parseColor("#D94336"),

    val spaceText: String = "空格",
    val enterText: String = "盛夏\n光年",
    val waterLilyDecor: Boolean = false,
    val topLilyAlpha: Int = 108,
    val keyGlowEnabled: Boolean = true,
    val keyGlowColor: Int? = null,

    // 按排独立配色 (1=第一排, 2=第二排, 3=第三排, 4=第四排)
    val rowOverrides: Map<Int, KeyStyleOverride> = emptyMap(),
    // 按单个按键或分组独立配色 (如 "qw", "er", "q", "vowel", "space", "enter", "comma", "period", "backspace", "wildcard", "sym", "num", "lang")
    val keyOverrides: Map<String, KeyStyleOverride> = emptyMap()
) {
    fun resolveKeyStyle(
        rowIndex: Int,
        keyId: String,
        isFuncKey: Boolean = false,
        isPunctKey: Boolean = false,
        lettersOnKey: String = ""
    ): KeyStyleOverride {
        val base = when {
            isPunctKey -> KeyStyleOverride(
                bgTop = punctKeyBgTop,
                bgBottom = punctKeyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = punctKeyBorder,
                borderWidthDp = punctKeyBorderWidthDp ?: keyBorderWidthDp,
                textColor = punctKeyText ?: keyText,
                hintColor = punctKeyHint ?: punctKeyText ?: keyHint
            )
            isFuncKey -> KeyStyleOverride(
                bgTop = funcKeyBgTop,
                bgBottom = funcKeyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = funcKeyBorder,
                borderWidthDp = funcKeyBorderWidthDp ?: keyBorderWidthDp,
                textColor = funcKeyText,
                hintColor = keyHint
            )
            else -> KeyStyleOverride(
                bgTop = keyBgTop,
                bgBottom = keyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = keyBorder,
                borderWidthDp = keyBorderWidthDp,
                textColor = keyText,
                hintColor = keyHint
            )
        }

        // 1. 先叠加「按排配色」（默认作用于字母键，或者第4排未单独指定的功能键）
        var resolved = if (!isFuncKey && !isPunctKey) {
            base.mergeWith(rowOverrides[rowIndex])
        } else {
            base
        }

        // 2. 如果配置了 .key-vowel（元音键 A/E/I/O/U），且该按键包含元音字母，则叠加元音样式
        val lowerLetters = lettersOnKey.lowercase()
        if (lowerLetters.any { it in "aeiou" }) {
            resolved = resolved.mergeWith(keyOverrides["vowel"])
        }

        // 3. 如果在 26 键模式下按键是单字母（如 t 或 y），自动关联对应 14 键双字母组的配色（如 .key-ty -> t, y；.key-bn -> b, n）
        val cleanId = keyId.lowercase()
        if (cleanId.length == 1) {
            val parentDual = when (cleanId) {
                "q", "w" -> "qw"
                "e", "r" -> "er"
                "t", "y" -> "ty"
                "u", "i" -> "ui"
                "o", "p" -> "op"
                "a", "s" -> "as"
                "d", "f" -> "df"
                "g", "h" -> "gh"
                "j", "k" -> "jk"
                "z", "x" -> "zx"
                "c", "v" -> "cv"
                "b", "n" -> "bn"
                else -> null
            }
            if (parentDual != null) {
                resolved = resolved.mergeWith(keyOverrides[parentDual])
            }
        }

        // 4. 如果配置了单字母选择器（如 .key-q 或 [data-key="Q"]），匹配包含该字母的按键
        for (ch in lowerLetters) {
            resolved = resolved.mergeWith(keyOverrides[ch.toString()])
        }

        // 5. 最后叠加精确按键 ID 选择器（如 .key-qw、[data-key="QW"]、.key-space、.key-enter 等，优先级最高！）
        resolved = resolved.mergeWith(keyOverrides[cleanId])

        return resolved
    }
}

object CssSkinManager {

    const val SAMPLE_COMMENTED_CSS = """/* =========================================================
 * 盛夏光年 · 双层架构 + OKLCH 智能背光 CSS 皮肤完整示例模板
 * 说明：
 * 1. 背光采用 OKLCH 感知色彩空间自动根据每个按键最终底色计算，
 *    深浅自适应、不荧光不发灰，无需手动调光晕色！
 * 2. 开启「随机跳色」后，系统会自动在 24 字母键中随机挑 1~3 个键
 *    进行和谐撞色点缀，也可随时点击「换跳色」重新洗牌位置。
 * ========================================================= */

/* 1. 键盘整体底板颜色 */
.keyboard-bg {
  background: #F4F0EA;
}

/* 2. 顶部状态栏与候选词栏 */
.top-bar {
  background: #DCE8F5;
  border-width: 0px;
  border-radius: 18px;
  color: #2B4263;
  divider: show;
  divider-color: #B8CBE0;
}

/* 3. 普通字母按键基础样式（支持 Flexbox 5 位置对齐与底部功能键独立字号！） */
.key {
  background: #A9DEC9;
  border-width: 0px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #1E3A4C;
  hint-color: #4A6E7D;

  /* 底部功能键独立字号倍率（默认 1.15，可设为 1.25 或 130% 放大底部按键文字）： */
  --func-font-scale: 1.20;

  /* 按键字母 5 位置对齐（通过 justify-content 控制左右，align-items 控制上下）：
   * - 居中：justify-content: center;     align-items: center;
   * - 左上：justify-content: flex-start; align-items: flex-start;
   * - 右上：justify-content: flex-end;   align-items: flex-start;
   * - 左下：justify-content: flex-start; align-items: flex-end;
   * - 右下：justify-content: flex-end;   align-items: flex-end;
   */
  justify-content: center;
  align-items: center;
}

/* 4. 第一、二、三排分层配色（自由搭配每一排的色调） */
.chat-keyboard-row:nth-child(1) .key {
  background: #A9DEC9 !important;
  color: #1E3A4C !important;
}
.chat-keyboard-row:nth-child(2) .key {
  background: #2FB5B8 !important;
  color: #FFFFFF !important;
  hint-color: #D8F5F5 !important;
}
.chat-keyboard-row:nth-child(3) .key {
  background: #1C7FA6 !important;
  color: #FFFFFF !important;
  hint-color: #CBE8F5 !important;
}

/* 5. 功能键样式（通配、退格、符、123、中/英、回车） */
.key-func {
  background: #14497A;
  color: #FFFFFF;
}

/* 6. 底部逗号与句号键样式 */
.key-punct {
  background: #B8C9E6;
  color: #1E3A4C;
}

/* 7. 空格键点睛色（开启随机跳色时也会自动借用此点睛色！） */
.key-space {
  background: #F4CE85 !important;
  color: #3B2E1A !important;
}

/* 8. 候选词文字与首选高亮色 */
.candidate-bar {
  color: #1E3A4C;
  highlight-color: #14497A;
}"""

    const val DEFAULT_GRAY_CSS = """/* 盛夏光年 · 薄荷奶黄撞色皮肤（复刻灵感配色图1：薄荷绿 + 湖水青 + 深海蓝 + 奶黄跳色） */
.keyboard-bg {
  background: #F5F1EB;
}

.top-bar {
  background: #BDCDED;
  border-width: 0px;
  border-radius: 18px;
  color: #1D3B66;
  divider: none;
}

.key {
  background: #A5DEC8;
  border-width: 0px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #1A3A52;
  hint-color: #4E7688;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #A5DEC8 !important;
  color: #1A3A52 !important;
  hint-color: #4E7688 !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #2CB3B6 !important;
  color: #FFFFFF !important;
  hint-color: #D6F5F5 !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #187BA3 !important;
  color: #FFFFFF !important;
  hint-color: #C8E6F2 !important;
}

.key-func {
  background: #124578;
  color: #FFFFFF;
}

.key-punct {
  background: #B8C9E8;
  color: #1D3B66;
  hint-color: #4A658C;
}

.key-space {
  background: #F4CE85 !important;
  color: #2B2418 !important;
}

.candidate-bar {
  color: #1D3B66;
  highlight-color: #187BA3;
}"""

    const val MONET_WATER_LILY_CSS = """/* 盛夏光年 · 莫奈花园油画高定皮肤（唯一自带油画睡莲键帽贴图的特殊皮肤） */
.keyboard-bg {
  background: #E4EDF7;
  decor: water-lily;
}

.top-bar {
  background: #F2F5FB;
  border-width: 1px;
  border-color: #FFFFFF;
  border-radius: 22px;
  color: #4D5E7C;
  divider: show;
  divider-color: #B6C6DC;
  lily-opacity: 42%;
}

.key {
  background: #9DB5E4;
  pressed-background: #88A2D6;
  border-width: 1px;
  border-color: #F4F8FF;
  border-radius: 15px;
  key-gap: 3px;
  elevation: 1px;
  color: #4D5E7C;
  hint-color: #F0F5FF;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #9DB5E4 !important;
  color: #FFFFFF !important;
  hint-color: #F0F5FF !important;
}
.key-ty, .key-t, .key-y {
  background: #EAD4DC !important;
  color: #4D5E7C !important;
  hint-color: #6B7E9E !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #A9C09A !important;
  color: #FFFFFF !important;
  hint-color: #F2F8EE !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #92ADE0 !important;
  color: #FFFFFF !important;
  hint-color: #EEF4FF !important;
}
.key-bn {
  background: #6D8A70 !important;
  color: #FFFFFF !important;
}

.key-func {
  background: #6D8A70;
  color: #FFFFFF;
}

.key-punct {
  background: #9EAEE0;
  color: #FFFFFF;
  hint-color: #EEF4FF;
}

.key-space {
  background: #EAD4DC !important;
  color: #4D5E7C !important;
}

.candidate-bar {
  color: #3E4E68;
  highlight-color: #687FD4;
}"""

    const val LATTE_MAILLARD_CSS = """/* 盛夏光年 · 焦糖拿铁分层混搭皮肤 */
.keyboard-bg {
  background: #F5EFEA;
}

.top-bar {
  background: #EDE0D4;
  border-width: 0px;
  border-radius: 18px;
  color: #4A3525;
  divider: none;
}

.key {
  background: #EFE3D5;
  border-width: 0px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #4A3328;
  hint-color: #9C7E68;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #F4E9DC !important;
  color: #5C4033 !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #E5D0BE !important;
  color: #4A3328 !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #D6B89D !important;
  color: #3A2318 !important;
}

.key-func {
  background: #9E6B4B;
  color: #FFFFFF;
}

.key-punct {
  background: #5C4033;
  color: #FFFFFF;
  hint-color: #E5D0BE;
}

.key-space {
  background: #F2CCA0 !important;
  color: #4A3328 !important;
}

.candidate-bar {
  color: #3A2E26;
  highlight-color: #B85D3B;
}"""

    const val LAVENDER_CSS = """/* 盛夏光年 · 薰衣草紫藤撞色皮肤（复刻灵感配色图3：天蓝 + 丁香紫 + 鸢尾紫 + 樱粉点睛） */
.keyboard-bg {
  background: #F7EFEA;
}

.top-bar {
  background: #F7C8D4;
  border-width: 0px;
  border-radius: 18px;
  color: #3B2854;
  divider: none;
}

.key {
  background: #A9CEFA;
  border-width: 0px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #2B234A;
  hint-color: #63689E;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #A9CEFA !important;
  color: #2B234A !important;
  hint-color: #5A709E !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #B49CE2 !important;
  color: #FFFFFF !important;
  hint-color: #EBE4FA !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #8B6FC9 !important;
  color: #FFFFFF !important;
  hint-color: #E2D8F8 !important;
}

.key-func {
  background: #3E2A6E;
  color: #FFFFFF;
}

.key-punct {
  background: #F7C8D4;
  color: #3B2854;
  hint-color: #7A5870;
}

.key-space {
  background: #FDE2E8 !important;
  color: #3B2854 !important;
}

.candidate-bar {
  color: #2B234A;
  highlight-color: #6C4AB6;
}"""

    const val SAKURA_PINK_CSS = """/* =========================================================
 * 盛夏光年 · 豆沙玫瑰 / 夜樱初绽 (Dusty Rose) 默认樱花粉皮肤（1:1 复刻图4）
 * ========================================================= */
.keyboard-bg {
  background: #FAF2F3;
}

.top-bar {
  background: #FFFFFF;
  border-width: 1px;
  border-color: #EFE2E4;
  border-radius: 22px;
  color: #824955;
  divider: show;
  divider-color: #EBDAD8;
}

.key {
  background: #FAEEF0;
  border-width: 0px;
  border-radius: 16px;
  key-gap: 4px;
  elevation: 1px;
  color: #5A3940;
  hint-color: #A87A84;
  enter-text: 夜樱\n初绽;
  justify-content: flex-start;
  align-items: flex-start;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #FAEEF0 !important;
  color: #5A3940 !important;
  hint-color: #A87A84 !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #F6E8E8 !important;
  color: #5A3940 !important;
  hint-color: #A87A84 !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #E8C4C8 !important;
  color: #5A3940 !important;
  hint-color: #8C5864 !important;
}

.key-func {
  background: #CE7A87;
  color: #FFFFFF;
}

.key-punct {
  background: #8C4E5B;
  color: #FFFFFF;
  hint-color: #F6E8E8;
}

.key-space {
  background: #F9ECEF !important;
  color: #5A3940 !important;
}

/* 图4 专属豆沙玫瑰层次跳色键（QW 深酒红玫瑰、UI 树莓红、GH/M 豆沙粉、ZX 浅花瓣粉） */
.key-qw {
  background: #8B4F5B !important;
  color: #FFFFFF !important;
  hint-color: #F6E8E8 !important;
}

.key-ui {
  background: #C55669 !important;
  color: #FFFFFF !important;
  hint-color: #FAEEF0 !important;
}

.key-gh, .key-m {
  background: #CE7A87 !important;
  color: #FFFFFF !important;
  hint-color: #FAEEF0 !important;
}

.key-zx {
  background: #FAEEF0 !important;
  color: #5A3940 !important;
  hint-color: #8C5864 !important;
}

.candidate-bar {
  color: #5A3940;
  highlight-color: #C55669;
}"""

    const val DARK_MODE_CSS = """/* 盛夏光年 · 暗夜黑金月相高定皮肤（复刻灵感皮肤图1：曜石黑底 + 暖杏仁白字键 + 暗金功能键 + 香槟金流光） */
.keyboard-bg {
  background: #14161D;
}

.top-bar {
  background: #1D202A;
  border-width: 1px;
  border-color: #3D3528;
  border-radius: 18px;
  color: #E6C187;
  divider: none;
}

.key {
  background: #FAF3E6;
  border-width: 0px;
  border-radius: 13px;
  key-gap: 3px;
  elevation: 1px;
  color: #23252E;
  hint-color: #9E9484;
}

.chat-keyboard-row:nth-child(1) .key {
  background: #FAF3E6 !important;
  color: #23252E !important;
}

.chat-keyboard-row:nth-child(2) .key {
  background: #F5ECE0 !important;
  color: #23252E !important;
}

.chat-keyboard-row:nth-child(3) .key {
  background: #EFE4D4 !important;
  color: #23252E !important;
}

.key-func {
  background: #232733;
  border-width: 1px;
  border-color: #3A3328;
  color: #E6C187;
}

.key-punct {
  background: #232733;
  color: #E6C187;
  hint-color: #9E865E;
}

.key-space {
  background: #FAF3E6 !important;
  color: #23252E !important;
}

.candidate-bar {
  color: #E6C187;
  highlight-color: #F2CD88;
}"""

    private var cachedSkin: SkinConfig? = null

    fun getSkin(context: Context): SkinConfig {
        cachedSkin?.let { return it }
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val css = prefs.getString("custom_skin_css", "") ?: ""
        val skin = if (css.isBlank()) parseCss(SAKURA_PINK_CSS) else parseCss(css)
        cachedSkin = skin
        return skin
    }

    fun saveCustomCss(context: Context, css: String) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val trimmed = css.trim()
        prefs.edit().putString("custom_skin_css", trimmed).apply()
        val parsed = if (trimmed.isBlank()) SkinConfig() else parseCss(trimmed)
        parsed.cssFontScale?.let { scale ->
            prefs.edit().putFloat("key_font_scale", scale.coerceIn(0.45f, 1.5f)).apply()
        }
        cachedSkin = null
    }

    fun resetToDefaultSkin(context: Context) {
        saveCustomCss(context, "")
    }

    fun getSavedCss(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_skin_css", "") ?: ""
        return saved.ifBlank { SAKURA_PINK_CSS }
    }

    private const val PREF_SAVED_SKINS_JSON = "saved_custom_css_skins_json"

    fun getSavedSkinList(context: Context): List<SavedCssSkinItem> {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val raw = prefs.getString(PREF_SAVED_SKINS_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        val result = ArrayList<SavedCssSkinItem>()
        try {
            val arr = org.json.JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val n = obj.optString("name", "").trim()
                val c = obj.optString("css", "").trim()
                val ts = obj.optLong("updatedAt", 0L)
                if (n.isNotEmpty() && c.isNotEmpty()) {
                    result.add(SavedCssSkinItem(n, c, ts))
                }
            }
        } catch (_: Exception) {}
        return result
    }

    fun saveNamedSkin(context: Context, name: String, css: String) {
        val cleanName = name.trim()
        val cleanCss = css.trim()
        if (cleanName.isEmpty() || cleanCss.isEmpty()) return
        val existing = getSavedSkinList(context).toMutableList()
        existing.removeAll { it.name == cleanName }
        existing.add(0, SavedCssSkinItem(cleanName, cleanCss, System.currentTimeMillis()))
        writeSavedSkinList(context, existing)
    }

    fun deleteNamedSkin(context: Context, name: String) {
        val existing = getSavedSkinList(context).filter { it.name != name }
        writeSavedSkinList(context, existing)
    }

    private fun writeSavedSkinList(context: Context, list: List<SavedCssSkinItem>) {
        val arr = org.json.JSONArray()
        for (item in list) {
            val obj = org.json.JSONObject()
            obj.put("name", item.name)
            obj.put("css", item.css)
            obj.put("updatedAt", item.updatedAt)
            arr.put(obj)
        }
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString(PREF_SAVED_SKINS_JSON, arr.toString())
            .apply()
    }

    private fun stripImportant(raw: String): String {
        return raw.replace(Regex("!\\s*important", RegexOption.IGNORE_CASE), "")
            .trim()
            .removeSuffix(";")
            .trim()
    }

    private fun parseColorSafe(raw: String, fallback: Int): Int {
        return try {
            val clean = stripImportant(raw)
            val hex = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value ?: clean
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun parseColorNullable(raw: String): Int? {
        return try {
            val clean = stripImportant(raw)
            val hex = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value ?: clean
            Color.parseColor(hex)
        } catch (_: Exception) {
            null
        }
    }

    private fun parsePxInt(raw: String, minVal: Int, maxVal: Int): Int? {
        val clean = stripImportant(raw).lowercase().removeSuffix("px").removeSuffix("dp").trim()
        val n = clean.toIntOrNull()
        return n?.coerceIn(minVal, maxVal)
    }

    private fun parseGradientOrSolid(raw: String, defaultTop: Int, defaultBottom: Int): Pair<Int, Int> {
        val clean = stripImportant(raw)
        if (clean.startsWith("linear-gradient", ignoreCase = true)) {
            val inside = clean.substringAfter("(").substringBeforeLast(")")
            val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
            if (hexes.size >= 2) {
                return parseColorSafe(hexes[0], defaultTop) to parseColorSafe(hexes[1], defaultBottom)
            } else if (hexes.size == 1) {
                val c = parseColorSafe(hexes[0], defaultTop)
                return c to c
            }
        }
        val hexMatch = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value
        if (hexMatch != null) {
            val c = parseColorSafe(hexMatch, defaultTop)
            return c to c
        }
        return defaultTop to defaultBottom
    }

    private fun parseKeyStyleOverride(props: Map<String, String>, existing: KeyStyleOverride?): KeyStyleOverride {
        var bgT: Int? = existing?.bgTop
        var bgB: Int? = existing?.bgBottom
        props["background"]?.let { raw ->
            val clean = stripImportant(raw)
            if (clean.startsWith("linear-gradient", ignoreCase = true)) {
                val inside = clean.substringAfter("(").substringBeforeLast(")")
                val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
                if (hexes.size >= 2) {
                    bgT = parseColorNullable(hexes[0]) ?: bgT
                    bgB = parseColorNullable(hexes[1]) ?: bgB
                } else if (hexes.size == 1) {
                    val c = parseColorNullable(hexes[0])
                    if (c != null) { bgT = c; bgB = c }
                }
            } else {
                val c = parseColorNullable(clean)
                if (c != null) { bgT = c; bgB = c }
            }
        }
        props["background-color"]?.let { raw ->
            val c = parseColorNullable(raw)
            if (c != null) { bgT = c; bgB = c }
        }
        val pBg = props["pressed-background"]?.let { parseColorNullable(it) } ?: existing?.pressedBg
        val bCol = props["border-color"]?.let { parseColorNullable(it) } ?: existing?.borderColor
        val bWidth = props["border-width"]?.let { parsePxInt(it, 0, 6) }
            ?: (if (props.containsKey("border-color") && existing?.borderWidthDp == null) 1 else existing?.borderWidthDp)
        val tCol = props["color"]?.let { parseColorNullable(it) } ?: existing?.textColor
        val hCol = props["hint-color"]?.let { parseColorNullable(it) } ?: existing?.hintColor

        return KeyStyleOverride(
            bgTop = bgT,
            bgBottom = bgB,
            pressedBg = pBg,
            borderColor = bCol,
            borderWidthDp = bWidth,
            textColor = tCol,
            hintColor = hCol
        )
    }

    private fun normalizeKeyAlias(rawKey: String): String {
        return when (rawKey.trim().lowercase()) {
            "通配", "wildcard" -> "wildcard"
            "退格", "删除", "⌫", "backspace", "del", "delete" -> "backspace"
            "符", "符号", "sym", "symbol", "symbols" -> "sym"
            "123", "num", "number" -> "num"
            "，", ",", "comma", "逗号" -> "comma"
            "空格", "space", "spacebar" -> "space"
            "。", ".", "period", "dot", "句号" -> "period"
            "中/英", "英/中", "lang", "mode", "switch" -> "lang"
            "回车", "发送", "盛夏光年", "enter", "return" -> "enter"
            "vowel", "vowels", "元音" -> "vowel"
            else -> rawKey.trim().lowercase().replace(" ", "")
        }
    }

    fun parseCss(css: String): SkinConfig {
        var cfg = SkinConfig()
        val rowMap = HashMap<Int, KeyStyleOverride>()
        val keyMap = HashMap<String, KeyStyleOverride>()

        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("([^{]+)\\{([^}]*)\\}")

        for (match in blockRegex.findAll(noComments)) {
            val rawSelectorGroup = match.groupValues[1].trim()
            val body = match.groupValues[2]
            val props = HashMap<String, String>()
            body.split(";").forEach { line ->
                val colon = line.indexOf(':')
                if (colon > 0) {
                    val k = line.substring(0, colon).trim().lowercase()
                    val v = line.substring(colon + 1).trim()
                    if (k.isNotEmpty() && v.isNotEmpty()) props[k] = v
                }
            }
            if (props.isEmpty()) continue

            // 支持逗号分隔并列选择器（如 .key-qw, .key-er, [data-key="TY"] { ... }）
            val selectors = rawSelectorGroup.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (sel in selectors) {
                val lowerSel = sel.lowercase()

                // 1. 检查是否为「按排选择器」：
                // 支持 .row-1 / .row-1 .key / .chat-keyboard-row:nth-child(1) .key / .keyboard-row:nth-child(1) / [data-row="1"]
                val nthMatch = Regex("nth-child\\(\\s*(\\d+)\\s*\\)").find(lowerSel)
                val dataRowMatch = Regex("data-row\\s*=\\s*['\"]?(\\d+)['\"]?").find(lowerSel)
                val dotRowMatch = Regex("\\.row-(\\d+)").find(lowerSel)
                val rowNum = (nthMatch?.groupValues?.get(1)
                    ?: dataRowMatch?.groupValues?.get(1)
                    ?: dotRowMatch?.groupValues?.get(1))?.toIntOrNull()

                if (rowNum != null && rowNum in 1..4) {
                    rowMap[rowNum] = parseKeyStyleOverride(props, rowMap[rowNum])
                    continue
                }

                // 2. 检查是否为「data-key 属性选择器」：如 [data-key="QW"] 或 .key[data-key="Q"]
                val dataKeyMatch = Regex("data-key\\s*=\\s*['\"]?([^'\"\\]]+)['\"]?").find(sel)
                if (dataKeyMatch != null) {
                    val kId = normalizeKeyAlias(dataKeyMatch.groupValues[1])
                    keyMap[kId] = parseKeyStyleOverride(props, keyMap[kId])
                    continue
                }

                // 3. 标准基础选择器与 .key-xxx 单键选择器
                // 全局检查 --func-font-scale / func-font-scale
                (props["--func-font-scale"] ?: props["func-font-scale"])?.let { rawScale ->
                    val pct = stripImportant(rawScale).removeSuffix("%").trim().toFloatOrNull()
                    if (pct != null) {
                        val sc = if (pct > 3.5f) pct / 100f else pct
                        cfg = cfg.copy(funcFontScale = sc.coerceIn(0.6f, 2.0f))
                    }
                }

                when (lowerSel) {
                    ":root", ".keyboard-bg", "body", ".keyboard" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.kbBgTop, cfg.kbBgBottom)
                            cfg = cfg.copy(kbBgTop = t, kbBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.kbBgTop)
                            cfg = cfg.copy(kbBgTop = c, kbBgBottom = c)
                        }
                    }
                    ".top-bar" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.topBarBgTop, cfg.topBarBgBottom)
                            cfg = cfg.copy(topBarBgTop = t, topBarBgBottom = b)
                        }
                        props["border-color"]?.let {
                            cfg = cfg.copy(topBarBorder = parseColorSafe(it, cfg.topBarBorder), topBarBorderWidthDp = 1)
                        }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(topBarBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(topBarText = parseColorSafe(it, cfg.topBarText)) }
                        props["divider-color"]?.let { cfg = cfg.copy(topBarDivider = parseColorSafe(it, cfg.topBarDivider)) }
                        props["divider"]?.let {
                            cfg = cfg.copy(showTopDivider = !stripImportant(it).equals("none", ignoreCase = true))
                        }
                        props["border-radius"]?.let {
                            parsePxInt(it, 0, 32)?.let { r -> cfg = cfg.copy(topBarRadiusDp = r) }
                        }
                    (props["lily-opacity"] ?: props["opacity"])?.let {
                        val pct = stripImportant(it).removeSuffix("%").trim().toFloatOrNull()
                        if (pct != null) {
                            val ratio = if (pct > 1.0f) (pct / 100f) else pct
                            cfg = cfg.copy(topLilyAlpha = (ratio * 255f).toInt().coerceIn(20, 255))
                        }
                    }
                    }
                    ".key" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.keyBgTop, cfg.keyBgBottom)
                            cfg = cfg.copy(keyBgTop = t, keyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.keyBgTop)
                            cfg = cfg.copy(keyBgTop = c, keyBgBottom = c)
                        }
                        props["pressed-background"]?.let { cfg = cfg.copy(keyPressedBg = parseColorSafe(it, cfg.keyPressedBg)) }
                        props["border-color"]?.let {
                            cfg = cfg.copy(keyBorder = parseColorSafe(it, cfg.keyBorder), keyBorderWidthDp = 1)
                        }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(keyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(keyText = parseColorSafe(it, cfg.keyText)) }
                        props["hint-color"]?.let { cfg = cfg.copy(keyHint = parseColorSafe(it, cfg.keyHint)) }
                        props["border-radius"]?.let {
                            parsePxInt(it, 0, 28)?.let { r -> cfg = cfg.copy(keyRadiusDp = r) }
                        }
                        props["key-gap"]?.let {
                            parsePxInt(it, 1, 10)?.let { g -> cfg = cfg.copy(keyGapDp = g) }
                        }
                        props["elevation"]?.let {
                            parsePxInt(it, 0, 8)?.let { el -> cfg = cfg.copy(keyElevationDp = el) }
                        }
                        props["font-scale"]?.let {
                            val pct = stripImportant(it).removeSuffix("%").trim().toFloatOrNull()
                            if (pct != null) {
                                val sc = if (pct > 3f) pct / 100f else pct
                                cfg = cfg.copy(cssFontScale = sc.coerceIn(0.45f, 1.5f))
                            }
                        }
                        props["space-text"]?.let { cfg = cfg.copy(spaceText = stripImportant(it).replace("\\n", "\n")) }
                        props["enter-text"]?.let { cfg = cfg.copy(enterText = stripImportant(it).replace("\\n", "\n")) }
                        props["glow"]?.let {
                            cfg = cfg.copy(keyGlowEnabled = !stripImportant(it).equals("none", ignoreCase = true))
                        }
                        props["glow-color"]?.let {
                            cfg = cfg.copy(keyGlowColor = parseColorNullable(it))
                        }
                        // 解析按键字母 5 位置对齐：支持 Flexbox (justify-content + align-items) 或简写 key-align
                        val rawJustify = props["justify-content"]?.let { stripImportant(it).lowercase() }
                        val rawAlign = props["align-items"]?.let { stripImportant(it).lowercase() }
                        val rawKeyAlign = (props["key-align"] ?: props["text-align"])?.let { stripImportant(it).lowercase() }
                        if (rawJustify != null || rawAlign != null) {
                            val isLeft = rawJustify in setOf("flex-start", "start", "left")
                            val isRight = rawJustify in setOf("flex-end", "end", "right")
                            val isTop = rawAlign in setOf("flex-start", "start", "top")
                            val isBottom = rawAlign in setOf("flex-end", "end", "bottom")
                            val resolvedAlign = when {
                                isTop && isLeft -> "top-left"
                                isTop && isRight -> "top-right"
                                isBottom && isLeft -> "bottom-left"
                                isBottom && isRight -> "bottom-right"
                                isLeft -> "top-left"
                                isRight -> "top-right"
                                else -> "center"
                            }
                            cfg = cfg.copy(keyAlign = resolvedAlign)
                        } else if (rawKeyAlign != null) {
                            val resolvedAlign = when (rawKeyAlign) {
                                "top-left", "left-top", "左上", "start" -> "top-left"
                                "top-right", "right-top", "右上" -> "top-right"
                                "bottom-left", "left-bottom", "左下" -> "bottom-left"
                                "bottom-right", "right-bottom", "右下" -> "bottom-right"
                                else -> "center"
                            }
                            cfg = cfg.copy(keyAlign = resolvedAlign)
                        }
                    }
                    ".key-func" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.funcKeyBgTop, cfg.funcKeyBgBottom)
                            cfg = cfg.copy(funcKeyBgTop = t, funcKeyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.funcKeyBgTop)
                            cfg = cfg.copy(funcKeyBgTop = c, funcKeyBgBottom = c)
                        }
                        props["border-color"]?.let { cfg = cfg.copy(funcKeyBorder = parseColorSafe(it, cfg.funcKeyBorder)) }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(funcKeyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(funcKeyText = parseColorSafe(it, cfg.funcKeyText)) }
                    }
                    ".key-punct" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.punctKeyBgTop, cfg.punctKeyBgBottom)
                            cfg = cfg.copy(punctKeyBgTop = t, punctKeyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.punctKeyBgTop)
                            cfg = cfg.copy(punctKeyBgTop = c, punctKeyBgBottom = c)
                        }
                        props["border-color"]?.let { cfg = cfg.copy(punctKeyBorder = parseColorSafe(it, cfg.punctKeyBorder)) }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(punctKeyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(punctKeyText = parseColorSafe(it, cfg.keyText)) }
                        props["hint-color"]?.let { cfg = cfg.copy(punctKeyHint = parseColorSafe(it, cfg.keyHint)) }
                    }
                    ".candidate-bar" -> {
                        props["color"]?.let { cfg = cfg.copy(candidateText = parseColorSafe(it, cfg.candidateText)) }
                        props["highlight-color"]?.let { cfg = cfg.copy(candidateHighlight = parseColorSafe(it, cfg.candidateHighlight)) }
                    }
                    else -> {
                        // 匹配 .key-xxx 或 #key-xxx 单键选择器（如 .key-qw, .key-q, .key-space, .key-enter, .key-vowel 等）
                        val keyClassMatch = Regex("[.#]key-([a-zA-Z0-9_\\u4e00-\\u9fa5]+)").find(lowerSel)
                        if (keyClassMatch != null) {
                            val kId = normalizeKeyAlias(keyClassMatch.groupValues[1])
                            keyMap[kId] = parseKeyStyleOverride(props, keyMap[kId])
                        }
                    }
                }
            }
        }
        val lowerAll = noComments.lowercase()
        val hasWaterLilySignal = lowerAll.contains("water-lily") ||
            lowerAll.contains("lotus") ||
            lowerAll.contains("睡莲") ||
            (lowerAll.contains("#e2c9cd") && lowerAll.contains("#a6bf86")) ||
            (lowerAll.contains("#a4b9e6") && lowerAll.contains("#a6bf86"))
        return cfg.copy(
            waterLilyDecor = cfg.waterLilyDecor || hasWaterLilySignal,
            rowOverrides = rowMap,
            keyOverrides = keyMap
        )
    }

    fun makeGradientDrawable(
        topColor: Int,
        bottomColor: Int,
        radiusPx: Int,
        strokeColor: Int? = null,
        strokeWidthPx: Int = 0
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topColor, bottomColor)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            if (strokeColor != null && strokeWidthPx > 0) {
                setStroke(strokeWidthPx, strokeColor)
            }
        }
    }
}
