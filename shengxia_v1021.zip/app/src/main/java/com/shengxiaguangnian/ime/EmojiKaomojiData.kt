package com.shengxiaguangnian.ime

data class SymbolEntry(
    val text: String,
    val isEnglish: Boolean = false
)

object EmojiKaomojiData {

    val SYMBOL_CATEGORIES = linkedMapOf(
        "最近" to listOf(
            SymbolEntry("✦"), SymbolEntry("✧"), SymbolEntry("～"), SymbolEntry("【】"), SymbolEntry("♡"),
            SymbolEntry("“”"), SymbolEntry("（）"), SymbolEntry("「」"), SymbolEntry("『』"), SymbolEntry("《》"),
            SymbolEntry("✨"), SymbolEntry("❤️"), SymbolEntry("🎀"), SymbolEntry("🌸"), SymbolEntry("🌙"),
            SymbolEntry("，"), SymbolEntry("。"), SymbolEntry("？"), SymbolEntry("！"), SymbolEntry("、"),
            SymbolEntry("："), SymbolEntry("；"), SymbolEntry("…"), SymbolEntry("——"), SymbolEntry("·"),
            SymbolEntry("+", true), SymbolEntry("-", true), SymbolEntry("*", true), SymbolEntry("/", true), SymbolEntry("=", true)
        ),

        "中文" to listOf(
            SymbolEntry("，"), SymbolEntry("。"), SymbolEntry("？"), SymbolEntry("！"), SymbolEntry("、"),
            SymbolEntry("："), SymbolEntry("；"), SymbolEntry("“”"), SymbolEntry("‘’"), SymbolEntry("（）"),
            SymbolEntry("【】"), SymbolEntry("《》"), SymbolEntry("「」"), SymbolEntry("『』"), SymbolEntry("〔〕"),
            SymbolEntry("〖〗"), SymbolEntry("〈〉"), SymbolEntry("…"), SymbolEntry("……"), SymbolEntry("——"),
            SymbolEntry("—"), SymbolEntry("～"), SymbolEntry("·"), SymbolEntry("•"), SymbolEntry("｜"),
            SymbolEntry("“"), SymbolEntry("”"), SymbolEntry("‘"), SymbolEntry("’"), SymbolEntry("（"),
            SymbolEntry("）"), SymbolEntry("【"), SymbolEntry("】"), SymbolEntry("《"), SymbolEntry("》"),
            SymbolEntry("「"), SymbolEntry("」"), SymbolEntry("『"), SymbolEntry("』"), SymbolEntry("﹏"),
            SymbolEntry("〰"), SymbolEntry("￥"), SymbolEntry("‰"), SymbolEntry("‱"), SymbolEntry("§"),
            SymbolEntry("※"), SymbolEntry("〇"), SymbolEntry("〃"), SymbolEntry("々"), SymbolEntry("ˉ"),
            SymbolEntry("ˇ"), SymbolEntry("¨"), SymbolEntry("！？"), SymbolEntry("？！"), SymbolEntry("～✦")
        ),

        "英文" to listOf(
            SymbolEntry(",", true), SymbolEntry(".", true), SymbolEntry("?", true), SymbolEntry("!", true), SymbolEntry(":", true),
            SymbolEntry(";", true), SymbolEntry("\"", true), SymbolEntry("'", true), SymbolEntry("()", true), SymbolEntry("[]", true),
            SymbolEntry("{}", true), SymbolEntry("<>", true), SymbolEntry("+", true), SymbolEntry("-", true), SymbolEntry("*", true),
            SymbolEntry("/", true), SymbolEntry("=", true), SymbolEntry("_", true), SymbolEntry("\\", true), SymbolEntry("|", true),
            SymbolEntry("@", true), SymbolEntry("#", true), SymbolEntry("$", true), SymbolEntry("%", true), SymbolEntry("^", true),
            SymbolEntry("&", true), SymbolEntry("~", true), SymbolEntry("`", true), SymbolEntry("(", true), SymbolEntry(")", true),
            SymbolEntry("[", true), SymbolEntry("]", true), SymbolEntry("{", true), SymbolEntry("}", true), SymbolEntry("<", true),
            SymbolEntry(">", true), SymbolEntry("€", true), SymbolEntry("£", true), SymbolEntry("¥", true), SymbolEntry("¢", true),
            SymbolEntry("©", true), SymbolEntry("®", true), SymbolEntry("™", true), SymbolEntry("°", true), SymbolEntry("±", true),
            SymbolEntry("×", true), SymbolEntry("÷", true), SymbolEntry("•", true), SymbolEntry("·", true), SymbolEntry("…", true),
            SymbolEntry("–", true), SymbolEntry("—", true), SymbolEntry("§", true), SymbolEntry("¶", true), SymbolEntry("†", true),
            SymbolEntry("‡", true), SymbolEntry("№", true), SymbolEntry("℗", true), SymbolEntry("℠", true), SymbolEntry("‰", true)
        ),

        "数学" to listOf(
            SymbolEntry("＋"), SymbolEntry("－"), SymbolEntry("×"), SymbolEntry("÷"), SymbolEntry("＝"),
            SymbolEntry("≠"), SymbolEntry("≈"), SymbolEntry("≡"), SymbolEntry("≤"), SymbolEntry("≥"),
            SymbolEntry("＜"), SymbolEntry("＞"), SymbolEntry("≪"), SymbolEntry("≫"), SymbolEntry("±"),
            SymbolEntry("∓"), SymbolEntry("√"), SymbolEntry("∛"), SymbolEntry("∜"), SymbolEntry("∞"),
            SymbolEntry("∝"), SymbolEntry("∵"), SymbolEntry("∴"), SymbolEntry("⊥"), SymbolEntry("∥"),
            SymbolEntry("∠"), SymbolEntry("∟"), SymbolEntry("°"), SymbolEntry("′"), SymbolEntry("″"),
            SymbolEntry("％"), SymbolEntry("‰"), SymbolEntry("‱"), SymbolEntry("∪"), SymbolEntry("∩"),
            SymbolEntry("∈"), SymbolEntry("∉"), SymbolEntry("⊂"), SymbolEntry("⊃"), SymbolEntry("⊆"),
            SymbolEntry("⊇"), SymbolEntry("⊄"), SymbolEntry("⊅"), SymbolEntry("∅"), SymbolEntry("∀"),
            SymbolEntry("∃"), SymbolEntry("¬"), SymbolEntry("∧"), SymbolEntry("∨"), SymbolEntry("⊕"),
            SymbolEntry("⊙"), SymbolEntry("∑"), SymbolEntry("∏"), SymbolEntry("∫"), SymbolEntry("∮"),
            SymbolEntry("∂"), SymbolEntry("∇"), SymbolEntry("∆"), SymbolEntry("π"), SymbolEntry("¹"),
            SymbolEntry("²"), SymbolEntry("³"), SymbolEntry("⁴"), SymbolEntry("⁵"), SymbolEntry("⁶"),
            SymbolEntry("⁷"), SymbolEntry("⁸"), SymbolEntry("⁹"), SymbolEntry("⁰"), SymbolEntry("½"),
            SymbolEntry("⅓"), SymbolEntry("⅔"), SymbolEntry("¼"), SymbolEntry("¾"), SymbolEntry("℃"),
            SymbolEntry("℉"), SymbolEntry("㎎"), SymbolEntry("㎏"), SymbolEntry("㎜"), SymbolEntry("㎝"),
            SymbolEntry("㎞"), SymbolEntry("㎡"), SymbolEntry("㏄"), SymbolEntry("㏕"), SymbolEntry("Ω")
        ),

        "序号" to listOf(
            SymbolEntry("①"), SymbolEntry("②"), SymbolEntry("③"), SymbolEntry("④"), SymbolEntry("⑤"),
            SymbolEntry("⑥"), SymbolEntry("⑦"), SymbolEntry("⑧"), SymbolEntry("⑨"), SymbolEntry("⑩"),
            SymbolEntry("⑪"), SymbolEntry("⑫"), SymbolEntry("⑬"), SymbolEntry("⑭"), SymbolEntry("⑮"),
            SymbolEntry("⑯"), SymbolEntry("⑰"), SymbolEntry("⑱"), SymbolEntry("⑲"), SymbolEntry("⑳"),
            SymbolEntry("❶"), SymbolEntry("❷"), SymbolEntry("❸"), SymbolEntry("❹"), SymbolEntry("❺"),
            SymbolEntry("❻"), SymbolEntry("❼"), SymbolEntry("❽"), SymbolEntry("❾"), SymbolEntry("❿"),
            SymbolEntry("⑴"), SymbolEntry("⑵"), SymbolEntry("⑶"), SymbolEntry("⑷"), SymbolEntry("⑸"),
            SymbolEntry("⑹"), SymbolEntry("⑺"), SymbolEntry("⑻"), SymbolEntry("⑼"), SymbolEntry("⑽"),
            SymbolEntry("一、"), SymbolEntry("二、"), SymbolEntry("三、"), SymbolEntry("四、"), SymbolEntry("五、"),
            SymbolEntry("六、"), SymbolEntry("七、"), SymbolEntry("八、"), SymbolEntry("九、"), SymbolEntry("十、"),
            SymbolEntry("（一）"), SymbolEntry("（二）"), SymbolEntry("（三）"), SymbolEntry("（四）"), SymbolEntry("（五）"),
            SymbolEntry("1."), SymbolEntry("2."), SymbolEntry("3."), SymbolEntry("4."), SymbolEntry("5."),
            SymbolEntry("6."), SymbolEntry("7."), SymbolEntry("8."), SymbolEntry("9."), SymbolEntry("10."),
            SymbolEntry("Ⅰ"), SymbolEntry("Ⅱ"), SymbolEntry("Ⅲ"), SymbolEntry("Ⅳ"), SymbolEntry("Ⅴ"),
            SymbolEntry("Ⅵ"), SymbolEntry("Ⅶ"), SymbolEntry("Ⅷ"), SymbolEntry("Ⅸ"), SymbolEntry("Ⅹ"),
            SymbolEntry("Ⅺ"), SymbolEntry("Ⅻ"), SymbolEntry("ⅰ"), SymbolEntry("ⅱ"), SymbolEntry("ⅲ"),
            SymbolEntry("ⓐ"), SymbolEntry("ⓑ"), SymbolEntry("ⓒ"), SymbolEntry("ⓓ"), SymbolEntry("ⓔ"),
            SymbolEntry("ⓕ"), SymbolEntry("ⓖ"), SymbolEntry("ⓗ"), SymbolEntry("ⓘ"), SymbolEntry("ⓙ")
        ),

        "括号" to listOf(
            SymbolEntry("【】"), SymbolEntry("〖〗"), SymbolEntry("〔〕"), SymbolEntry("〘〙"), SymbolEntry("〚〛"),
            SymbolEntry("「」"), SymbolEntry("『』"), SymbolEntry("《》"), SymbolEntry("〈〉"), SymbolEntry("（）"),
            SymbolEntry("“”"), SymbolEntry("‘’"), SymbolEntry("()", true), SymbolEntry("[]", true), SymbolEntry("{}", true),
            SymbolEntry("<>", true), SymbolEntry("‹›"), SymbolEntry("«»"), SymbolEntry("꒰꒱"), SymbolEntry("ʚɞ"),
            SymbolEntry("༺༻"), SymbolEntry("╭╮"), SymbolEntry("╰╯"), SymbolEntry("︵︶"), SymbolEntry("︷︸"),
            SymbolEntry("︹︺"), SymbolEntry("︻︼"), SymbolEntry("︽︾"), SymbolEntry("︿﹀"), SymbolEntry("﹁﹂"),
            SymbolEntry("﹃﹄"), SymbolEntry("（"), SymbolEntry("）"), SymbolEntry("【"), SymbolEntry("】"),
            SymbolEntry("〖"), SymbolEntry("〗"), SymbolEntry("〔"), SymbolEntry("〕"), SymbolEntry("「"),
            SymbolEntry("」"), SymbolEntry("『"), SymbolEntry("』"), SymbolEntry("《"), SymbolEntry("》"),
            SymbolEntry("〈"), SymbolEntry("〉"), SymbolEntry("“"), SymbolEntry("”"), SymbolEntry("‘"),
            SymbolEntry("’"), SymbolEntry("꒰"), SymbolEntry("꒱"), SymbolEntry("ʚ"), SymbolEntry("ɞ"),
            SymbolEntry("༺"), SymbolEntry("༻"), SymbolEntry("«"), SymbolEntry("»"), SymbolEntry("‹"),
            SymbolEntry("›"), SymbolEntry("(", true), SymbolEntry(")", true), SymbolEntry("[", true), SymbolEntry("]", true),
            SymbolEntry("{", true), SymbolEntry("}", true), SymbolEntry("<", true), SymbolEntry(">", true), SymbolEntry("\"", true)
        ),

        "星芒" to listOf(
            SymbolEntry("✦"), SymbolEntry("✧"), SymbolEntry("★"), SymbolEntry("☆"), SymbolEntry("✩"),
            SymbolEntry("✪"), SymbolEntry("✫"), SymbolEntry("✬"), SymbolEntry("✭"), SymbolEntry("✮"),
            SymbolEntry("✯"), SymbolEntry("✰"), SymbolEntry("✴"), SymbolEntry("✵"), SymbolEntry("✶"),
            SymbolEntry("✷"), SymbolEntry("✸"), SymbolEntry("✹"), SymbolEntry("✺"), SymbolEntry("✻"),
            SymbolEntry("✼"), SymbolEntry("✽"), SymbolEntry("✾"), SymbolEntry("✿"), SymbolEntry("❀"),
            SymbolEntry("❁"), SymbolEntry("❂"), SymbolEntry("❃"), SymbolEntry("❄"), SymbolEntry("❅"),
            SymbolEntry("❆"), SymbolEntry("❇"), SymbolEntry("❈"), SymbolEntry("❉"), SymbolEntry("❊"),
            SymbolEntry("❋"), SymbolEntry("⁎"), SymbolEntry("⁑"), SymbolEntry("⁂"), SymbolEntry("⁜"),
            SymbolEntry("☾"), SymbolEntry("☽"), SymbolEntry("☼"), SymbolEntry("☀"), SymbolEntry("☁"),
            SymbolEntry("☂"), SymbolEntry("☃"), SymbolEntry("☄"), SymbolEntry("⚜"), SymbolEntry("⚘"),
            SymbolEntry("☘"), SymbolEntry("🫧"), SymbolEntry("✨"), SymbolEntry("🌟"), SymbolEntry("💫"),
            SymbolEntry("🌙"), SymbolEntry("🪐"), SymbolEntry("👑"), SymbolEntry("💎"), SymbolEntry("🪄"),
            SymbolEntry("🎀"), SymbolEntry("🌸"), SymbolEntry("🌷"), SymbolEntry("🌹"), SymbolEntry("🌺"),
            SymbolEntry("🌻"), SymbolEntry("🌼"), SymbolEntry("🍀"), SymbolEntry("🦋"), SymbolEntry("🕊️")
        ),

        "爱心" to listOf(
            SymbolEntry("♡"), SymbolEntry("♥"), SymbolEntry("❤"), SymbolEntry("❥"), SymbolEntry("❣"),
            SymbolEntry("❦"), SymbolEntry("❧"), SymbolEntry("🩷"), SymbolEntry("❤️"), SymbolEntry("🧡"),
            SymbolEntry("💛"), SymbolEntry("💚"), SymbolEntry("🩵"), SymbolEntry("💙"), SymbolEntry("💜"),
            SymbolEntry("🤍"), SymbolEntry("🖤"), SymbolEntry("🤎"), SymbolEntry("💕"), SymbolEntry("💞"),
            SymbolEntry("💓"), SymbolEntry("💗"), SymbolEntry("💖"), SymbolEntry("💘"), SymbolEntry("💝"),
            SymbolEntry("💟"), SymbolEntry("💌"), SymbolEntry("♪"), SymbolEntry("♫"), SymbolEntry("♬"),
            SymbolEntry("♭"), SymbolEntry("♮"), SymbolEntry("♯"), SymbolEntry("♤"), SymbolEntry("♠"),
            SymbolEntry("♢"), SymbolEntry("♦"), SymbolEntry("♧"), SymbolEntry("♣"), SymbolEntry("☺"),
            SymbolEntry("☻"), SymbolEntry("♨"), SymbolEntry("☎"), SymbolEntry("☏"), SymbolEntry("✉"),
            SymbolEntry("✎"), SymbolEntry("✏"), SymbolEntry("✒"), SymbolEntry("✂"), SymbolEntry("✓"),
            SymbolEntry("✔"), SymbolEntry("✕"), SymbolEntry("✖"), SymbolEntry("✗"), SymbolEntry("✘"),
            SymbolEntry("⊕"), SymbolEntry("⊗"), SymbolEntry("⊙"), SymbolEntry("⊚"), SymbolEntry("⊛")
        ),

        "箭头" to listOf(
            SymbolEntry("→"), SymbolEntry("←"), SymbolEntry("↑"), SymbolEntry("↓"), SymbolEntry("↔"),
            SymbolEntry("↕"), SymbolEntry("↖"), SymbolEntry("↗"), SymbolEntry("↘"), SymbolEntry("↙"),
            SymbolEntry("⇒"), SymbolEntry("⇐"), SymbolEntry("⇑"), SymbolEntry("⇓"), SymbolEntry("⇔"),
            SymbolEntry("⇕"), SymbolEntry("➔"), SymbolEntry("➜"), SymbolEntry("➝"), SymbolEntry("➞"),
            SymbolEntry("➟"), SymbolEntry("➠"), SymbolEntry("➡"), SymbolEntry("➢"), SymbolEntry("➣"),
            SymbolEntry("➤"), SymbolEntry("➥"), SymbolEntry("➦"), SymbolEntry("➧"), SymbolEntry("➨"),
            SymbolEntry("↻"), SymbolEntry("↺"), SymbolEntry("⇄"), SymbolEntry("⇅"), SymbolEntry("⇆"),
            SymbolEntry("⇇"), SymbolEntry("⇈"), SymbolEntry("⇉"), SymbolEntry("⇊"), SymbolEntry("↠"),
            SymbolEntry("↞"), SymbolEntry("↟"), SymbolEntry("↡"), SymbolEntry("↣"), SymbolEntry("↢"),
            SymbolEntry("↦"), SymbolEntry("↤"), SymbolEntry("⇀"), SymbolEntry("↽"), SymbolEntry("●"),
            SymbolEntry("○"), SymbolEntry("◎"), SymbolEntry("◉"), SymbolEntry("◌"), SymbolEntry("◍"),
            SymbolEntry("◐"), SymbolEntry("◑"), SymbolEntry("◒"), SymbolEntry("◓"), SymbolEntry("◆"),
            SymbolEntry("◇"), SymbolEntry("◈"), SymbolEntry("■"), SymbolEntry("□"), SymbolEntry("▢"),
            SymbolEntry("▣"), SymbolEntry("▲"), SymbolEntry("△"), SymbolEntry("▶"), SymbolEntry("▷"),
            SymbolEntry("▼"), SymbolEntry("▽"), SymbolEntry("◀"), SymbolEntry("◁"), SymbolEntry("⬟")
        ),

        "线条" to listOf(
            SymbolEntry("～"), SymbolEntry("〰"), SymbolEntry("﹏"), SymbolEntry("━"), SymbolEntry("─"),
            SymbolEntry("═"), SymbolEntry("┄"), SymbolEntry("┈"), SymbolEntry("┅"), SymbolEntry("┉"),
            SymbolEntry("│"), SymbolEntry("┃"), SymbolEntry("║"), SymbolEntry("┆"), SymbolEntry("┊"),
            SymbolEntry("┌"), SymbolEntry("┏"), SymbolEntry("┐"), SymbolEntry("┓"), SymbolEntry("└"),
            SymbolEntry("┗"), SymbolEntry("┘"), SymbolEntry("┛"), SymbolEntry("├"), SymbolEntry("┣"),
            SymbolEntry("┤"), SymbolEntry("┫"), SymbolEntry("┬"), SymbolEntry("┳"), SymbolEntry("┴"),
            SymbolEntry("┻"), SymbolEntry("┼"), SymbolEntry("╋"), SymbolEntry("╔"), SymbolEntry("╗"),
            SymbolEntry("╚"), SymbolEntry("╝"), SymbolEntry("╠"), SymbolEntry("╣"), SymbolEntry("╦"),
            SymbolEntry("╩"), SymbolEntry("╬"), SymbolEntry("╭"), SymbolEntry("╮"), SymbolEntry("╯"),
            SymbolEntry("╰"), SymbolEntry("╱"), SymbolEntry("╲"), SymbolEntry("╳"), SymbolEntry("♈"),
            SymbolEntry("♉"), SymbolEntry("♊"), SymbolEntry("♋"), SymbolEntry("♌"), SymbolEntry("♍"),
            SymbolEntry("♎"), SymbolEntry("♏"), SymbolEntry("♐"), SymbolEntry("♑"), SymbolEntry("♒"),
            SymbolEntry("♓"), SymbolEntry("♔"), SymbolEntry("♕"), SymbolEntry("♖"), SymbolEntry("♗"),
            SymbolEntry("♘"), SymbolEntry("♙"), SymbolEntry("♚"), SymbolEntry("♛"), SymbolEntry("♜")
        ),

        "外文" to listOf(
            SymbolEntry("α"), SymbolEntry("β"), SymbolEntry("γ"), SymbolEntry("δ"), SymbolEntry("ε"),
            SymbolEntry("ζ"), SymbolEntry("η"), SymbolEntry("θ"), SymbolEntry("ι"), SymbolEntry("κ"),
            SymbolEntry("λ"), SymbolEntry("μ"), SymbolEntry("ν"), SymbolEntry("ξ"), SymbolEntry("ο"),
            SymbolEntry("π"), SymbolEntry("ρ"), SymbolEntry("σ"), SymbolEntry("τ"), SymbolEntry("υ"),
            SymbolEntry("φ"), SymbolEntry("χ"), SymbolEntry("ψ"), SymbolEntry("ω"), SymbolEntry("Α"),
            SymbolEntry("Β"), SymbolEntry("Γ"), SymbolEntry("Δ"), SymbolEntry("Ε"), SymbolEntry("Θ"),
            SymbolEntry("Λ"), SymbolEntry("Ξ"), SymbolEntry("Π"), SymbolEntry("Σ"), SymbolEntry("Φ"),
            SymbolEntry("Ψ"), SymbolEntry("Ω"), SymbolEntry("あ"), SymbolEntry("い"), SymbolEntry("う"),
            SymbolEntry("え"), SymbolEntry("お"), SymbolEntry("か"), SymbolEntry("き"), SymbolEntry("く"),
            SymbolEntry("け"), SymbolEntry("こ"), SymbolEntry("さ"), SymbolEntry("し"), SymbolEntry("す"),
            SymbolEntry("せ"), SymbolEntry("そ"), SymbolEntry("た"), SymbolEntry("ち"), SymbolEntry("つ"),
            SymbolEntry("て"), SymbolEntry("と"), SymbolEntry("な"), SymbolEntry("に"), SymbolEntry("ぬ"),
            SymbolEntry("ね"), SymbolEntry("の"), SymbolEntry("は"), SymbolEntry("ひ"), SymbolEntry("ふ"),
            SymbolEntry("へ"), SymbolEntry("ほ"), SymbolEntry("ま"), SymbolEntry("み"), SymbolEntry("む"),
            SymbolEntry("め"), SymbolEntry("も"), SymbolEntry("や"), SymbolEntry("ゆ"), SymbolEntry("よ"),
            SymbolEntry("ら"), SymbolEntry("り"), SymbolEntry("る"), SymbolEntry("れ"), SymbolEntry("ろ"),
            SymbolEntry("わ"), SymbolEntry("を"), SymbolEntry("ん"), SymbolEntry("ツ"), SymbolEntry("シ")
        ),

        "网络" to listOf(
            SymbolEntry("### "), SymbolEntry("**"), SymbolEntry("```"), SymbolEntry("> "), SymbolEntry("- [ ] "),
            SymbolEntry("http://", true), SymbolEntry("https://", true), SymbolEntry("www.", true), SymbolEntry(".com", true), SymbolEntry(".cn", true),
            SymbolEntry("@", true), SymbolEntry("#", true), SymbolEntry("✦•┈๑⋅⋯"), SymbolEntry("⋯⋅๑┈•✦"), SymbolEntry("─── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ───"),
            SymbolEntry("*:ஐ(●˘͈ ᵕ˘͈)人(˘͈ᵕ ˘͈●)ஐ:*"), SymbolEntry("⋆｡ﾟ☁︎｡⋆｡ ﾟ☾ ﾟ｡⋆"), SymbolEntry("✧*｡٩(ˊᗜˋ*)و✧*｡"), SymbolEntry("♡₊˚ 🦢・₊✧"), SymbolEntry("‧₊˚ ⋅* ‧₊"),
            SymbolEntry("┌─── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ───┐"), SymbolEntry("└─── ･ ｡ﾟ☆: *.☽ .* :☆ﾟ. ───┘"), SymbolEntry("°˖✧◝(⁰▿⁰)◜✧˖°"), SymbolEntry("꒰ঌ ໒꒱"), SymbolEntry("ʚ♡ɞ")
        ),

        "表情" to listOf(
            SymbolEntry("❤️"), SymbolEntry("✨"), SymbolEntry("🔥"), SymbolEntry("⭐"), SymbolEntry("🎉"),
            SymbolEntry("🌹"), SymbolEntry("☀️"), SymbolEntry("🌙"), SymbolEntry("💧"), SymbolEntry("⚡"),
            SymbolEntry("(T^T)"), SymbolEntry("(￣.￣)"), SymbolEntry("→_→"), SymbolEntry("\\^O^/"), SymbolEntry("つ♡⊂"),
            SymbolEntry("(｡•̀ᴗ-)✧"), SymbolEntry("ෆ( ˶'ᵕ'˶)ෆ"), SymbolEntry("૮ ・ﻌ・ ა"), SymbolEntry("(,,>᎑<,,)"), SymbolEntry("(๑•̀ㅂ•́)و✧"),
            SymbolEntry("☺"), SymbolEntry("☻"), SymbolEntry("♡"), SymbolEntry("♥"), SymbolEntry("♤"),
            SymbolEntry("♠"), SymbolEntry("♢"), SymbolEntry("♦"), SymbolEntry("♧"), SymbolEntry("♣"),
            SymbolEntry("♪"), SymbolEntry("♫"), SymbolEntry("♬"), SymbolEntry("♭"), SymbolEntry("♮")
        )
    )

    val EMOJI_CATEGORIES = linkedMapOf(
        "笑脸" to listOf(
            "🤣", "🤔", "😘", "😂", "🥺", "🥳", "😭", "😝",
            "👌", "😠", "😋", "🤨", "✌️", "❤️", "😅", "😆",
            "🌹", "😢", "😉", "🥰", "🍠", "☺️", "😄", "😊",
            "🌞", "😤", "🙁", "🙃", "🍓", "🍒", "😌", "⭐",
            "😍", "🤩", "😎", "🥳", "😏", "😒", "😞", "😔",
            "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩",
            "🥱", "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢",
            "🤭", "🤫", "🤥", "🫠", "🫡", "🫢", "🫣", "🫤"
        ),
        "动物" to listOf(
            "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼",
            "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐔",
            "🐧", "🐦", "🐤", "🦆", "🦅", "🦉", "🦇", "🐺",
            "🦄", "🐝", "🦋", "🐌", "🐞", "🐢", "🐍", "🐙",
            "🪼", "🐬", "🐳", "🦢", "🦩", "🦚", "🦜", "🐾"
        ),
        "象形" to listOf(
            "❤️", "🩷", "🧡", "💛", "💚", "🩵", "💙", "💜",
            "🖤", "🤍", "🤎", "💔", "❣️", "💕", "💞", "💓",
            "💗", "💖", "💘", "💝", "💟", "✨", "🌟", "💫",
            "💥", "💢", "💦", "💧", "💤", "🔥", "🌈", "☀️",
            "🌙", "⭐", "☁️", "❄️", "⚡", "🫧", "🎀", "👑"
        ),
        "食物" to listOf(
            "🍓", "🍒", "🍎", "🍉", "🍑", "🍊", "🍋", "🍌",
            "🍍", "🥭", "🍇", "🍈", "🍐", "🥝", "🍅", "🥑",
            "🍠", "🥐", "🍞", "🥖", "🧀", "🥚", "🍳", "🥞",
            "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🍜", "🍣",
            "🍦", "🍰", "🎂", "🧁", "🍫", "🍬", "🧋", "☕"
        ),
        "活动" to listOf(
            "🎉", "🎊", "🎈", "🎁", "🎀", "🏆", "🏅", "🥇",
            "⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🎮", "🎲",
            "🎵", "🎶", "🎤", "🎧", "🎸", "🎹", "🎨", "🎬",
            "🪄", "🔮", "🧸", "🪩", "💎", "💍", "💄", "💅"
        ),
        "旅行" to listOf(
            "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑",
            "🚲", "🛵", "🏍️", "🚄", "✈️", "🚀", "🛸", "⛵",
            "🏠", "🏡", "🏢", "🏰", "🎡", "🎢", "🏖️", "🏔️"
        )
    )

    val KAOMOJI_CATEGORIES = linkedMapOf(
        "经典" to listOf(
            "(T^T)", "<(｀^´)>", "(￣.￣)", "→_→",
            "^v^♡^v^", "(♡>𖥦<)/♥", "つ♡⊂", "૮ ・ﻌ・ ა",
            "\\^O^/", "(^˶•ω•˶^)୨", "ෆ( ˶'ᵕ'˶)ෆ", "(* ´ ︶ ` *)",
            "(,,>᎑<,,)", "(｡•̀ᴗ-)✧", "(๑•̀ㅂ•́)و✧", "✧(≖ ◡ ≖✿)",
            "(¬_¬)", "(°ー°〃)", "(￣▽￣)", "╮(╯▽╰)╭",
            "✧*｡٩(ˊᗜˋ*)و✧*｡", "°˖✧◝(⁰▿⁰)◜✧˖°", "( ´͈ ᵕ `͈ )◞♡", "(⁎⁍̴̛ᴗ⁍̴̛⁎)"
        ),
        "卖萌" to listOf(
            "૮ ・ﻌ・ ა", "(^˶•ω•˶^)୨", "ෆ( ˶'ᵕ'˶)ෆ", "(,,>᎑<,,)",
            "(๑>؂<๑）", "(｡･ω･｡)ﾉ♡", "(◍•ᴗ•◍)", "ฅ՞•ﻌ•՞ฅ",
            "(づ｡◕‿‿◕｡)づ", "ヾ(◍°∇°◍)ﾉﾞ", "(๑• . •๑)", "૮₍ ˶•⤙•˶ ₎ა",
            "૮₍ ˶• ༝ •˶ ₎ა", "₍ᐢ..ᐢ₎♡", "(っ˘ω˘ς )", "૮꒰ ˶• ༝ •˶꒱ა"
        ),
        "爱心" to listOf(
            "^v^♡^v^", "(♡>𖥦<)/♥", "つ♡⊂", "(｡･ω･｡)ﾉ♡",
            "(´▽`ʃ♡ƪ)", "(✿◡‿◡)", "(♥ω♥*)", "♡(˃͈ દ ˂͈ ༶ )",
            "(ɔˆ ³(ˆ⌣ˆc)", "(*♡∀♡)", "(๑′ᴗ‵๑)Ｉ Lᵒᵛᵉᵧₒᵤ❤", "( ˘ ³˘)♥"
        ),
        "伤心" to listOf(
            "(T^T)", "(；′⌒`)", "(｡•́︿•̀｡)", "(>_<)",
            "(╥﹏╥)", "(´;ω;`)", "o(╥﹏╥)o", "( ´•̥̥̥ω•̥̥̥` )",
            "/(ㄒoㄒ)/~~", "(｡ŏ_ŏ)", "(´-ω-`)", "૮₍ ´• ˕ •` ₎ა"
        )
    )
}
