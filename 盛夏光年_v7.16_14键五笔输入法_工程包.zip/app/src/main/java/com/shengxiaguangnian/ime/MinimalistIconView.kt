package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import java.io.File
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt



/**
 * 三大字体模块独立导入与缓存管理器：
 * 1. SLOT_ENG ("font_eng.ttf")：按键英文字母与数字字体
 * 2. SLOT_CAND ("font_cand.ttf")：中文候选词与状态栏字体
 * 3. SLOT_ENTER ("font_enter.ttf")：右下角自定义文字（如“盛夏光年”）专属字体
 */
object CustomFontManager {
    const val SLOT_ENG = "eng"
    const val SLOT_CAND = "cand"
    const val SLOT_ENTER = "enter"

    private var cachedEngTs: Long = -1L
    private var cachedCandTs: Long = -1L
    private var cachedEnterTs: Long = -1L

    private var engTypeface: Typeface? = null
    private var candTypeface: Typeface? = null
    private var enterTypeface: Typeface? = null

    fun getFontFile(context: Context, slot: String): File {
        return File(context.filesDir, "custom_font_$slot.ttf")
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_eng", 0L) xor
            (prefs.getLong("font_ts_cand", 0L) shl 1) xor
            (prefs.getLong("font_ts_enter", 0L) shl 2)
    }

    fun hasCustomFont(context: Context, slot: String): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_$slot", 0L) > 0L && getFontFile(context, slot).exists()
    }

    fun getCustomFontName(context: Context, slot: String): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("font_name_$slot", "未导入（使用系统默认）") ?: "未导入（使用系统默认）"
    }

    fun clearCustomFont(context: Context, slot: String) {
        try {
            getFontFile(context, slot).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("font_ts_$slot", 0L)
            .remove("font_name_$slot")
            .apply()
        synchronized(this) {
            when (slot) {
                SLOT_ENG -> { cachedEngTs = 0L; engTypeface = null }
                SLOT_CAND -> { cachedCandTs = 0L; candTypeface = null }
                SLOT_ENTER -> { cachedEnterTs = 0L; enterTypeface = null }
            }
        }
    }

    fun getEngKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_eng", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedEngTs && engTypeface != null) return engTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENG)
            if (f.exists()) {
                try {
                    engTypeface = Typeface.createFromFile(f)
                    cachedEngTs = ts
                    return engTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getCandidateTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_cand", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedCandTs && candTypeface != null) return candTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_CAND)
            if (f.exists()) {
                try {
                    candTypeface = Typeface.createFromFile(f)
                    cachedCandTs = ts
                    return candTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getEnterKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_enter", 0L)
        if (ts <= 0L) return getCandidateTypeface(context)
        if (ts == cachedEnterTs && enterTypeface != null) return enterTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENTER)
            if (f.exists()) {
                try {
                    enterTypeface = Typeface.createFromFile(f)
                    cachedEnterTs = ts
                    return enterTypeface!!
                } catch (_: Exception) {}
            }
            return getCandidateTypeface(context)
        }
    }
}


/**
 * 基于 OKLCH 感知均匀色彩空间的按键背光自动取色器：
 * - 完全独立于现有的 KeyboardBacklightOverlayView 光晕动画与双层渐变绘制；
 * - 直接根据单键最终生效的背景色（含按排配色、单键独立配色、随机跳色）计算背光色；
 * - 不设死板的统一饱和度下限，采用「比例温和增益 + 软上限压缩（Soft-Knee）」，保留浅色系的呼吸层次感；
 * - 针对人眼最敏感的绿/黄绿波段（Hue 100°~165°）施加平滑色度阻尼，根治荧光绿，同时绝不压低明度 L 导致浅粉/焦糖变灰；
 * - 自动区分浅色皮肤与深色皮肤（如暗夜黑金）：当检测到深色按键或深黑底板时，自动开启「暗底逆向提亮 + 暖珀流金」模式。
 */
object OklchBacklightExtractor {

    fun extractGlowColor(
        finalKeyBgColor: Int,
        kbBgColor: Int = Color.WHITE,
        themeTintColor: Int = Color.WHITE,
        explicitCssGlowColor: Int? = null
    ): Int {
        explicitCssGlowColor?.let { return it }

        val r = Color.red(finalKeyBgColor) / 255.0
        val g = Color.green(finalKeyBgColor) / 255.0
        val b = Color.blue(finalKeyBgColor) / 255.0

        val tr = Color.red(themeTintColor) / 255.0
        val tg = Color.green(themeTintColor) / 255.0
        val tb = Color.blue(themeTintColor) / 255.0

        val (l, c, hDeg) = srgbToOklch(r, g, b)
        val (_, themeC, themeHDeg) = srgbToOklch(tr, tg, tb)

        // 1. 深色按键 (L < 0.45，如黑粉皮肤的第3排深紫灰键、黑色功能键，或黑金皮肤的深黑功能键)：
        //    彻底移除写死的金色！若深色键自身色度较低 (c < 0.032)，自动借用当前皮肤的主色调色相 themeHDeg
        //    （黑粉皮肤自动发柔和樱花粉光晕，黑金皮肤自动发香槟金光晕，绝不串色！）
        if (l < 0.45) {
            val effectiveHue = when {
                c < 0.026 && themeC >= 0.014 -> themeHDeg
                c < 0.038 && themeC >= 0.018 -> blendHueDegrees(hDeg, themeHDeg, 0.55)
                else -> hDeg
            }
            val liftedL = (l + 0.42).coerceIn(0.76, 0.83)
            val baseC = max(c, themeC * 0.85)
            val liftedC = (baseC * 1.45 + 0.032).coerceIn(0.072, 0.110)
            return oklchToSrgbColor(liftedL, liftedC, effectiveHue)
        }

        // 2. 极低色度纯白/纯灰键 (C < 0.012)：若当前皮肤有明确主题色相则轻柔借用主题色相，否则给出清透冰蓝微光
        if (c < 0.012) {
            if (themeC >= 0.015) {
                val borrowedC = (themeC * 1.35 + 0.025).coerceIn(0.055, 0.088)
                return oklchToSrgbColor(0.84, borrowedC, themeHDeg)
            }
            return Color.parseColor("#B6CDF2")
        }

        // 3. 计算绿/黄绿敏感色相区的柔性色度上限（Hue 在 105°~165° 之间时人眼对绿光最敏感，软上限收敛防荧光）
        val greenSensitivity = when {
            hDeg in 105.0..165.0 -> {
                val distFromPeak = kotlin.math.abs(hDeg - 135.0) / 30.0
                1.0 - 0.28 * (1.0 - distFromPeak.coerceIn(0.0, 1.0))
            }
            else -> 1.0
        }

        val maxChromaCap = 0.128 * greenSensitivity

        // 4. 比例柔性色度增益（彻底移除 isDarkTheme 写死金色逻辑！让黑粉皮肤第1排浅粉键 #F0D8E5 忠实绽放樱花粉光晕，
        //    黑金皮肤暖杏仁白键 #FAF3E6 忠实绽放暖金光晕）
        val boostedC = if (l >= 0.80) {
            val rawC = c * 1.95 + 0.036
            softKneeCompress(rawC, maxChromaCap * 0.88, maxChromaCap)
        } else {
            val rawC = c * 1.22 + 0.020
            softKneeCompress(rawC, maxChromaCap * 0.85, maxChromaCap)
        }

        // 5. 感知明度 L 校正：绝不把浅色压暗成水泥灰！
        val targetL = when {
            l >= 0.85 -> (l * 0.93).coerceIn(0.82, 0.89)
            l >= 0.65 -> (l * 1.04).coerceIn(0.76, 0.86)
            else -> (l + 0.14).coerceIn(0.70, 0.80)
        }

        return oklchToSrgbColor(targetL, boostedC, hDeg)
    }

    private fun blendHueDegrees(h1: Double, h2: Double, ratioH2: Double): Double {
        val r1 = Math.toRadians(h1)
        val r2 = Math.toRadians(h2)
        val x = (1.0 - ratioH2) * cos(r1) + ratioH2 * cos(r2)
        val y = (1.0 - ratioH2) * sin(r1) + ratioH2 * sin(r2)
        var deg = Math.toDegrees(atan2(y, x))
        if (deg < 0.0) deg += 360.0
        return deg
    }

    private fun softKneeCompress(x: Double, knee: Double, maxVal: Double): Double {
        if (x <= knee) return x
        val excess = x - knee
        val span = (maxVal - knee).coerceAtLeast(0.005)
        return knee + span * (excess / (excess + span))
    }

    private fun srgbToLinear(v: Double): Double {
        return if (v <= 0.04045) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun linearToSrgb(v: Double): Double {
        val clamped = v.coerceIn(0.0, 1.0)
        return if (clamped <= 0.0031308) 12.92 * clamped else 1.055 * clamped.pow(1.0 / 2.4) - 0.055
    }

    private fun srgbToOklch(r: Double, g: Double, b: Double): Triple<Double, Double, Double> {
        val lr = srgbToLinear(r)
        val lg = srgbToLinear(g)
        val lb = srgbToLinear(b)

        val l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb)
        val m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb)
        val s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb)

        val okL = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
        val okA = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
        val okB = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s

        val c = hypot(okA, okB)
        var h = Math.toDegrees(atan2(okB, okA))
        if (h < 0.0) h += 360.0
        return Triple(okL, c, h)
    }

    private fun oklchToSrgbColor(l: Double, c: Double, hDeg: Double): Int {
        val hRad = Math.toRadians(hDeg)
        val okA = c * cos(hRad)
        val okB = c * sin(hRad)

        val l_ = l + 0.3963377774 * okA + 0.2158037573 * okB
        val m_ = l - 0.1055613458 * okA - 0.0638541728 * okB
        val s_ = l - 0.0894841775 * okA - 1.2914855480 * okB

        val lCube = l_ * l_ * l_
        val mCube = m_ * m_ * m_
        val sCube = s_ * s_ * s_

        val lr = +4.0767416621 * lCube - 3.3077115913 * mCube + 0.2309699292 * sCube
        val lg = -1.2684380046 * lCube + 2.6097574011 * mCube - 0.3413193965 * sCube
        val lb = -0.0041960863 * lCube - 0.7034186147 * mCube + 1.7076147010 * sCube

        val sr = (linearToSrgb(lr) * 255.0).toInt().coerceIn(0, 255)
        val sg = (linearToSrgb(lg) * 255.0).toInt().coerceIn(0, 255)
        val sb = (linearToSrgb(lb) * 255.0).toInt().coerceIn(0, 255)
        return Color.rgb(sr, sg, sb)
    }
}


/**
 * 零延迟按键敲击音效管理器（内置用户提供的清脆敲击音 key_click.wav，支持设置页 Switch 自由开关）
 */
object KeySoundManager {
    private const val CUSTOM_SOUND_FILE = "custom_key_sound.dat"
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    private var loaded = false
    private var loadedSoundTs: Long = -1L

    fun getCustomSoundFile(context: Context): File = File(context.filesDir, CUSTOM_SOUND_FILE)

    fun hasCustomSound(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_sound_ts", 0L) > 0L && getCustomSoundFile(context).exists()
    }

    fun getCustomSoundName(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("custom_sound_name", "自定义音效") ?: "自定义音效"
    }

    fun clearCustomSound(context: Context) {
        try {
            getCustomSoundFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_sound_ts", 0L)
            .remove("custom_sound_name")
            .apply()
        reloadSound(context)
    }

    fun reloadSound(context: Context) {
        synchronized(this) {
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            soundPool = null
            clickSoundId = 0
            loaded = false
            loadedSoundTs = -1L
            ensureInitialized(context)
        }
    }

    fun ensureInitialized(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val curTs = prefs.getLong("custom_sound_ts", 0L)
        if (soundPool != null && curTs == loadedSoundTs) return
        synchronized(this) {
            if (soundPool != null && curTs == loadedSoundTs) return
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            loaded = false
            clickSoundId = 0
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val sp = SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(attrs)
                    .build()
                sp.setOnLoadCompleteListener { pool, sampleId, status ->
                    if (status == 0 && sampleId == clickSoundId) {
                        loaded = true
                        if (pendingPreviewPlay) {
                            pendingPreviewPlay = false
                            pool.play(clickSoundId, 0.90f, 0.90f, 1, 0, 1.0f)
                        }
                    }
                }
                val customFile = getCustomSoundFile(context)
                clickSoundId = if (curTs > 0L && customFile.exists()) {
                    sp.load(customFile.absolutePath, 1)
                } else {
                    context.assets.openFd("key_click.wav").use { afd ->
                        sp.load(afd, 1)
                    }
                }
                soundPool = sp
                loadedSoundTs = curTs
            } catch (_: Exception) {}
        }
    }

    @Volatile
    private var pendingPreviewPlay = false

    fun playClick(context: Context, forcePreview: Boolean = false) {
        try {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            if (!forcePreview && !prefs.getBoolean("key_sound_enabled", true)) return
            ensureInitialized(context)
            val sp = soundPool ?: return
            if (loaded && clickSoundId != 0) {
                sp.play(clickSoundId, 0.88f, 0.88f, 1, 0, 1.0f)
            } else if (forcePreview) {
                pendingPreviewPlay = true
            }
        } catch (_: Exception) {}
    }
}

/**
 * 纯色框架下的「自定义键盘背景图 + 实时高斯模糊底图采样」管理器：
 * - 当用户从相册上传背景图后，自动按 background-size: cover 铺满键盘底板；
 * - 同时预计算高平滑度高斯模糊底图 (blurredBitmap)，供所有半透明毛玻璃按键与顶栏实时读取并模糊对应坐标处的底图！
 */
object CustomBgManager {
    private const val FILE_NAME = "custom_kb_bg.png"
    private var cachedTimestamp: Long = -1L
    private var rawBitmap: Bitmap? = null
    private var blurredBitmap: Bitmap? = null

    fun getBgFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun hasCustomBg(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        return ts > 0L && getBgFile(context).exists()
    }

    fun clearCustomBg(context: Context) {
        try {
            getBgFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_bg_ts", 0L)
            .apply()
        synchronized(this) {
            cachedTimestamp = 0L
            rawBitmap = null
            blurredBitmap = null
        }
    }

    private fun ensureLoaded(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        if (ts <= 0L) {
            rawBitmap = null
            blurredBitmap = null
            cachedTimestamp = 0L
            return
        }
        if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
        synchronized(this) {
            if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
            val file = getBgFile(context)
            if (!file.exists()) {
                rawBitmap = null
                blurredBitmap = null
                cachedTimestamp = 0L
                return
            }
            try {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) {
                    rawBitmap = bmp
                    blurredBitmap = createGaussianBlurredBitmap(bmp)
                    cachedTimestamp = ts
                }
            } catch (_: Exception) {}
        }
    }

    fun getRawBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return rawBitmap
    }

    fun getBlurredBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return blurredBitmap
    }

    /**
     * 通过 1/4 下采样 + 3 遍可分离均值滤波（中心极限定理等效高半径高斯模糊）生成柔焦毛玻璃底图
     */
    private fun createGaussianBlurredBitmap(src: Bitmap): Bitmap {
        val sw = (src.width / 4).coerceAtLeast(64)
        val sh = (src.height / 4).coerceAtLeast(48)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        val tmp = IntArray(sw * sh)
        val radius = 6

        repeat(3) {
            // Horizontal pass
            for (y in 0 until sh) {
                val rowOff = y * sw
                for (x in 0 until sw) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val x0 = max(0, x - radius)
                    val x1 = min(sw - 1, x + radius)
                    for (ix in x0..x1) {
                        val c = pixels[rowOff + ix]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    tmp[rowOff + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
            // Vertical pass
            for (x in 0 until sw) {
                for (y in 0 until sh) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val y0 = max(0, y - radius)
                    val y1 = min(sh - 1, y + radius)
                    for (iy in y0..y1) {
                        val c = tmp[iy * sw + x]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    pixels[y * sw + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
        }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        return out
    }
}

/**
 * 自定义背景图的 background-size: cover + 可调节（0~100）背景毛玻璃程度渲染 Drawable：
 * - blurLevel = 0 时：100% 清晰显示用户上传的原图；
 * - blurLevel = 1..100 时：按比例平滑混合高清原图与柔焦高斯模糊底图，并叠加清透毛玻璃雾面光泽！
 */
class CustomCoverBgDrawable(
    private val rawBitmap: Bitmap,
    private val blurredBitmap: Bitmap?,
    var blurLevel: Int = 25
) : Drawable() {
    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val frostVeilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val matrix = Matrix()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val bw = b.width().toFloat()
        val bh = b.height().toFloat()
        if (bw <= 0f || bh <= 0f || rawBitmap.width <= 0 || rawBitmap.height <= 0) return

        val lv = blurLevel.coerceIn(0, 100)
        val save = canvas.save()
        canvas.clipRect(b)

        // 1. 绘制原图（当 blurLevel < 100 时作为清晰基底）
        if (lv < 100 || blurredBitmap == null) {
            val scale = max(bw / rawBitmap.width.toFloat(), bh / rawBitmap.height.toFloat())
            val dx = b.left + (bw - rawBitmap.width * scale) * 0.5f
            val dy = b.top + (bh - rawBitmap.height * scale) * 0.5f
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(dx, dy)
            canvas.drawBitmap(rawBitmap, matrix, rawPaint)
        }

        // 2. 按 0~100 程度叠加背景毛玻璃模糊层与轻柔雾面光泽
        if (lv > 0 && blurredBitmap != null && blurredBitmap.width > 0 && blurredBitmap.height > 0) {
            val bScale = max(bw / blurredBitmap.width.toFloat(), bh / blurredBitmap.height.toFloat())
            val bDx = b.left + (bw - blurredBitmap.width * bScale) * 0.5f
            val bDy = b.top + (bh - blurredBitmap.height * bScale) * 0.5f
            matrix.reset()
            matrix.setScale(bScale, bScale)
            matrix.postTranslate(bDx, bDy)
            blurPaint.alpha = (lv * 2.55f).toInt().coerceIn(0, 255)
            canvas.drawBitmap(blurredBitmap, matrix, blurPaint)

            // 随毛玻璃程度增加一点点清透雾白柔光感（最高约 22% 雾面感，不遮挡画面色彩）
            val veilAlpha = (lv * 0.56f).toInt().coerceIn(0, 56)
            if (veilAlpha > 0) {
                frostVeilPaint.color = Color.argb(veilAlpha, 255, 255, 255)
                canvas.drawRect(b, frostVeilPaint)
            }
        }
        canvas.restoreToCount(save)
    }

    private val paint = rawPaint

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 位于键盘最底层的「中心浓郁加深、四周柔和减淡」双层半透明背光层：
 * - 彻底摒弃刺眼的荧光亮色；
 * - 内层核心（innerGrad）自动比外层柔雾（outerGrad）再加深 22%，让按键中心位置呈现出浓郁温润的深睡莲绿/同色系深色核心，
 *   越往周围扩散越浅、越半透明，与莫奈花园及所有纯色皮肤完美融合。
 */
class KeyboardBacklightOverlayView(context: Context) : View(context) {

    private class SpotlightOrb(
        val sourceView: View,
        val keyRect: RectF,
        val glowColor: Int,
        var releaseTime: Long = 0L
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val shaderMatrix = Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    fun triggerKeyDown(keyView: View, @Suppress("UNUSED_PARAMETER") cornerRadius: Float, glowColor: Int) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + keyView.width
        val bottom = top + keyView.height

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(
            SpotlightOrb(
                sourceView = keyView,
                keyRect = RectF(left, top, right, bottom),
                glowColor = glowColor,
                releaseTime = 0L
            )
        )
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val holdMs = 150f
        val fadeMs = 640f
        val totalMs = holdMs + fadeMs
        val outerSpread = dpF(40f)
        val innerSpread = dpF(20f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.06f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.94f * (1f - t) * (1f - t)
                }
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val rGlow = Color.red(orb.glowColor)
            val gGlow = Color.green(orb.glowColor)
            val bGlow = Color.blue(orb.glowColor)

            // 保持灵动清透的纯正粉彩 RGB（绝不乘黑变灰！），通过内外两层半透明 Alpha 叠加自然实现「中间浓郁、四周渐浅」
            // 第一层：外层朦胧扩散柔雾（spread = 40dp）
            val rxOut = (orb.keyRect.width() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
            val ryOut = (orb.keyRect.height() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
            val outerGrad = RadialGradient(
                0f,
                0f,
                baseRadius,
                intArrayOf(
                    Color.argb((185 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((160 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((110 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((56 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((18 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                ),
                floatArrayOf(0f, 0.34f, 0.54f, 0.72f, 0.86f, 1.0f),
                Shader.TileMode.CLAMP
            )
            shaderMatrix.reset()
            shaderMatrix.setScale(rxOut / baseRadius, ryOut / baseRadius)
            shaderMatrix.postTranslate(cx, cy)
            outerGrad.setLocalMatrix(shaderMatrix)
            orbPaint.shader = outerGrad
            tmpRectF.set(cx - rxOut, cy - ryOut, cx + rxOut, cy + ryOut)
            canvas.drawOval(tmpRectF, orbPaint)

            // 第二层：中间聚光核心层（spread = 20dp，同色系叠加提升中心浓度，不压暗明度、不发灰）
            val rxIn = (orb.keyRect.width() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
            val ryIn = (orb.keyRect.height() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
            val innerGrad = RadialGradient(
                0f,
                0f,
                baseRadius,
                intArrayOf(
                    Color.argb((215 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((185 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((118 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((40 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                ),
                floatArrayOf(0f, 0.42f, 0.65f, 0.85f, 1.0f),
                Shader.TileMode.CLAMP
            )
            shaderMatrix.reset()
            shaderMatrix.setScale(rxIn / baseRadius, ryIn / baseRadius)
            shaderMatrix.postTranslate(cx, cy)
            innerGrad.setLocalMatrix(shaderMatrix)
            orbPaint.shader = innerGrad
            tmpRectF.set(cx - rxIn, cy - ryIn, cx + rxIn, cy + ryIn)
            canvas.drawOval(tmpRectF, orbPaint)
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 统一按键与顶栏背景视图（支持三大渲染模式）：
 * 1. 莫奈花园模式 (bitmap != null)：渲染 1:1 油画睡莲键帽贴图；
 * 2. 纯色框架 + 已上传自定义背景图模式 (useFrostedCustomBg = true)：
 *    自动定位当前按键在键盘中的坐标，实时读取并模糊对应位置的底图 (CustomBgManager.getBlurredBitmap)，
 *    再叠加半透明毛玻璃键帽底色与细腻磨砂白边；
 * 3. 纯色框架默认模式：渲染干净的纯色键帽，按下时自动呈现加深 25% 的同色系反馈。
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#528262"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT,
    private val useFrostedCustomBg: Boolean = false
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    KeySoundManager.playClick(context)
                }
                if (enableGlow) {
                    val overlay = findBacklightOverlay()
                    if (value) {
                        overlay?.triggerKeyDown(this, cornerRadiusPx, glowColor)
                    } else {
                        overlay?.triggerKeyUp(this)
                    }
                }
                invalidate()
            }
        }

    private fun findBacklightOverlay(): KeyboardBacklightOverlayView? {
        var p = parent
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    return child
                }
            }
            p = p.parent
        }
        return null
    }

    private fun findRootKbContainer(): View? {
        var cur: View? = this
        var last: View? = null
        while (cur != null) {
            last = cur
            val np = cur.parent
            cur = if (np is View) np else null
        }
        return last
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val frostBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.0f, resources.displayMetrics)
        color = Color.argb(135, 255, 255, 255)
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()
    private val blurMatrix = Matrix()
    private val selfLoc = IntArray(2)
    private val rootLoc = IntArray(2)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        val blurredBg = if (useFrostedCustomBg) CustomBgManager.getBlurredBitmap(context) else null

        if (bitmap != null) {
            // 模式 1：莫奈花园专属油画键帽贴图
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (blurredBg != null) {
            // 模式 2：纯色框架下已上传自定义背景图 -> 实时读取并模糊对应坐标处的底图 + 半透明毛玻璃键帽层
            val rootV = findRootKbContainer()
            val rw = (rootV?.width ?: width).toFloat().coerceAtLeast(1f)
            val rh = (rootV?.height ?: height).toFloat().coerceAtLeast(1f)
            getLocationInWindow(selfLoc)
            rootV?.getLocationInWindow(rootLoc)
            val relX = (selfLoc[0] - rootLoc[0]).toFloat()
            val relY = (selfLoc[1] - rootLoc[1]).toFloat()

            val scale = max(rw / blurredBg.width.toFloat(), rh / blurredBg.height.toFloat())
            val dx = (rw - blurredBg.width * scale) * 0.5f - relX
            val dy = (rh - blurredBg.height * scale) * 0.5f - relY
            blurMatrix.reset()
            blurMatrix.setScale(scale, scale)
            blurMatrix.postTranslate(dx, dy)
            canvas.drawBitmap(blurredBg, blurMatrix, bmpPaint)

            // 叠加半透明毛玻璃键帽色（按下时向灵动光晕色轻柔过渡 22%，绝不压暗变灰！）
            val baseCol = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else Color.WHITE
            val tintCol = if (isKeyPressedState) blendLivelyPressColor(baseCol, glowColor) else baseCol
            val frostAlpha = if (isKeyPressedState) 138 else 110
            fallbackFillPaint.color = Color.argb(
                frostAlpha,
                Color.red(tintCol),
                Color.green(tintCol),
                Color.blue(tintCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        } else if (fallbackBgTop != Color.TRANSPARENT) {
            // 模式 3：纯色框架默认模式（未上传背景图）-> 实心纯色键帽，按下时向同色系灵动粉彩轻柔过渡，绝不变灰！
            val drawCol = if (isKeyPressedState) blendLivelyPressColor(fallbackBgTop, glowColor) else fallbackBgTop
            fallbackFillPaint.color = Color.argb(
                255,
                Color.red(drawCol),
                Color.green(drawCol),
                Color.blue(drawCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)

        if (blurredBg != null && bitmap == null) {
            val half = frostBorderPaint.strokeWidth * 0.5f
            keyRectF.set(half, half, w - half, h - half)
            canvas.drawRoundRect(keyRectF, r, r, frostBorderPaint)
        }
    }

    private fun blendLivelyPressColor(baseColor: Int, livelyGlowColor: Int): Int {
        val r = (Color.red(baseColor) * 0.72f + Color.red(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val g = (Color.green(baseColor) * 0.72f + Color.green(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val b = (Color.blue(baseColor) * 0.72f + Color.blue(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }
}

/**
 * 现代圆角极简风「顶部状态栏 4 图标视图」（复刻参考图 1000128623.jpg & 1000128608.jpg）：
 * - 与圆角按键风格高度统一，采用圆角方糖（Squircle）微填充底衬 + 圆润胶囊线条：
 *   0 (设置)：现代圆角四宫格控制中心图标（3 枚圆角方格 + 右上角点睛圆点）
 *   1 (表情)：圆角方糖微填充萌系笑脸图标（圆润胶囊眼 + 柔和微笑弧）
 *   2 (常用)：圆角书签卡片图标（圆角外框 + 双胶囊横线 + 右上角小折角）
 *   3 (收起)：圆角胶囊下折图标（柔和圆角底衬 + 宽角圆头下折箭头 + 底部短横）
 * - 在莫奈花园模式下支持渲染水彩睡莲图标。
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = false
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0   // 小猫头（设置）
        const val TYPE_EMOJI = 1      // 猫脚印（表情/颜文字）
        const val TYPE_PHRASE = 2     // 镂空小星星（收藏/常用语）
        const val TYPE_FAVORITE = 2   // 镂空小星星（收藏/常用语）
        const val TYPE_COLLAPSE = 3   // 五瓣小樱花（收起键盘）
        const val TYPE_CLIPBOARD = 4  // 镂空小鱼（剪贴板）
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    // 100% 纯镂空线条画笔（彻底取消一切半透明灰色底衬填充，在浅色/深色顶栏上都干净通透！）
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.50f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(2.2f))
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fineStrokePaint.color = newColor
        starStrokePaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.38f
        drawCuteHollowIcon(canvas, cx, cy, r)
    }

    private fun drawCuteHollowIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                // 1. 设置：100% 纯镂空可爱小猫头（圆润猫耳 + 苹果脸颊 + 弯弯笑眼 + ω 猫咪嘴）
                val cyCat = cy + r * 0.05f
                path.reset()
                path.moveTo(cx - r * 0.35f, cyCat - r * 0.46f)
                // 额头微弧 -> 右耳内侧 -> 右耳尖 -> 右耳外侧
                path.quadTo(cx, cyCat - r * 0.50f, cx + r * 0.35f, cyCat - r * 0.46f)
                path.quadTo(cx + r * 0.58f, cyCat - r * 0.88f, cx + r * 0.78f, cyCat - r * 0.92f)
                path.quadTo(cx + r * 0.92f, cyCat - r * 0.58f, cx + r * 0.88f, cyCat - r * 0.16f)
                // 右侧圆润脸颊 -> 下巴 -> 左侧圆润脸颊
                path.cubicTo(
                    cx + r * 1.04f, cyCat + r * 0.40f,
                    cx + r * 0.56f, cyCat + r * 0.82f,
                    cx, cyCat + r * 0.82f
                )
                path.cubicTo(
                    cx - r * 0.56f, cyCat + r * 0.82f,
                    cx - r * 1.04f, cyCat + r * 0.40f,
                    cx - r * 0.88f, cyCat - r * 0.16f
                )
                // 左耳外侧 -> 左耳尖 -> 左耳内侧
                path.quadTo(cx - r * 0.92f, cyCat - r * 0.58f, cx - r * 0.78f, cyCat - r * 0.92f)
                path.quadTo(cx - r * 0.58f, cyCat - r * 0.88f, cx - r * 0.35f, cyCat - r * 0.46f)
                path.close()
                canvas.drawPath(path, strokePaint)

                // 弯弯笑眼
                path.reset()
                path.moveTo(cx - r * 0.46f, cyCat + r * 0.04f)
                path.quadTo(cx - r * 0.31f, cyCat - r * 0.15f, cx - r * 0.16f, cyCat + r * 0.04f)
                path.moveTo(cx + r * 0.16f, cyCat + r * 0.04f)
                path.quadTo(cx + r * 0.31f, cyCat - r * 0.15f, cx + r * 0.46f, cyCat + r * 0.04f)
                // 可爱猫咪 ω 嘴
                path.moveTo(cx - r * 0.22f, cyCat + r * 0.28f)
                path.quadTo(cx - r * 0.11f, cyCat + r * 0.43f, cx, cyCat + r * 0.26f)
                path.quadTo(cx + r * 0.11f, cyCat + r * 0.43f, cx + r * 0.22f, cyCat + r * 0.28f)
                canvas.drawPath(path, fineStrokePaint)
            }

            TYPE_EMOJI -> {
                // 2. 表情：100% 纯镂空可爱猫脚印（心形掌心大肉垫 + 4 颗扇形排列镂空小肉垫）
                val cyPaw = cy + r * 0.05f
                path.reset()
                path.moveTo(cx, cyPaw - r * 0.04f)
                path.cubicTo(
                    cx + r * 0.34f, cyPaw - r * 0.04f,
                    cx + r * 0.58f, cyPaw + r * 0.16f,
                    cx + r * 0.54f, cyPaw + r * 0.44f
                )
                path.cubicTo(
                    cx + r * 0.52f, cyPaw + r * 0.78f,
                    cx + r * 0.22f, cyPaw + r * 0.84f,
                    cx, cyPaw + r * 0.72f
                )
                path.cubicTo(
                    cx - r * 0.22f, cyPaw + r * 0.84f,
                    cx - r * 0.52f, cyPaw + r * 0.78f,
                    cx - r * 0.54f, cyPaw + r * 0.44f
                )
                path.cubicTo(
                    cx - r * 0.58f, cyPaw + r * 0.16f,
                    cx - r * 0.34f, cyPaw - r * 0.04f,
                    cx, cyPaw - r * 0.04f
                )
                path.close()
                canvas.drawPath(path, strokePaint)

                fun drawHollowToeBean(tcx: Float, tcy: Float, rx: Float, ry: Float, deg: Float) {
                    val save = canvas.save()
                    canvas.rotate(deg, tcx, tcy)
                    rectF.set(tcx - rx, tcy - ry, tcx + rx, tcy + ry)
                    canvas.drawOval(rectF, fineStrokePaint)
                    canvas.restoreToCount(save)
                }
                drawHollowToeBean(cx - r * 0.74f, cyPaw - r * 0.18f, r * 0.16f, r * 0.23f, -28f)
                drawHollowToeBean(cx - r * 0.28f, cyPaw - r * 0.56f, r * 0.16f, r * 0.24f, -10f)
                drawHollowToeBean(cx + r * 0.28f, cyPaw - r * 0.56f, r * 0.16f, r * 0.24f, 10f)
                drawHollowToeBean(cx + r * 0.74f, cyPaw - r * 0.18f, r * 0.16f, r * 0.23f, 28f)
            }

            TYPE_CLIPBOARD -> {
                // 3. 剪贴板：100% 纯镂空灵动小鱼（流线型圆润鱼身 + 分叉小鱼尾 + 鳃弧线 + 镂空小鱼眼）
                path.reset()
                path.moveTo(cx - r * 0.94f, cy)
                // 鱼背弧线 -> 鱼尾上腰
                path.cubicTo(
                    cx - r * 0.52f, cy - r * 0.74f,
                    cx + r * 0.04f, cy - r * 0.62f,
                    cx + r * 0.34f, cy - r * 0.13f
                )
                // 分叉鱼尾上叶 -> 尾尖分叉口 -> 鱼尾下叶 -> 鱼尾下腰
                path.quadTo(cx + r * 0.64f, cy - r * 0.44f, cx + r * 0.92f, cy - r * 0.52f)
                path.quadTo(cx + r * 0.80f, cy - r * 0.18f, cx + r * 0.66f, cy)
                path.quadTo(cx + r * 0.80f, cy + r * 0.18f, cx + r * 0.92f, cy + r * 0.52f)
                path.quadTo(cx + r * 0.64f, cy + r * 0.44f, cx + r * 0.34f, cy + r * 0.13f)
                // 鱼腹弧线回到鱼嘴
                path.cubicTo(
                    cx + r * 0.04f, cy + r * 0.62f,
                    cx - r * 0.52f, cy + r * 0.74f,
                    cx - r * 0.94f, cy
                )
                path.close()
                canvas.drawPath(path, strokePaint)

                // 鱼鳃柔弧与小圆眼
                path.reset()
                path.moveTo(cx - r * 0.30f, cy - r * 0.32f)
                path.quadTo(cx - r * 0.15f, cy, cx - r * 0.30f, cy + r * 0.32f)
                canvas.drawPath(path, fineStrokePaint)
                canvas.drawCircle(cx - r * 0.54f, cy - r * 0.10f, r * 0.08f, fineStrokePaint)
            }

            TYPE_PHRASE -> {
                // 4. 收藏（常用语）：100% 纯镂空圆润五角小星星
                val outerR = r * 0.96f
                val innerR = r * 0.46f
                path.reset()
                for (i in 0 until 10) {
                    val ang = Math.toRadians((-90.0 + i * 36.0))
                    val rad = if (i % 2 == 0) outerR else innerR
                    val px = cx + (rad * cos(ang)).toFloat()
                    val py = cy + (rad * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, starStrokePaint)
            }

            TYPE_COLLAPSE -> {
                // 5. 收起键盘：100% 纯镂空五瓣小樱花（每片花瓣尖端带标志性樱花小缺口 + 镂空小花心）
                val baseR = r * 0.34f
                val tipR = r * 0.95f
                val notchR = r * 0.76f
                val ctrlR = r * 0.96f
                path.reset()
                for (i in 0 until 5) {
                    val baseDeg = -90.0 + i * 72.0
                    val aStart = Math.toRadians(baseDeg - 36.0)
                    val aCtrlL = Math.toRadians(baseDeg - 28.0)
                    val aTipL = Math.toRadians(baseDeg - 10.0)
                    val aMid = Math.toRadians(baseDeg)
                    val aTipR = Math.toRadians(baseDeg + 10.0)
                    val aCtrlR = Math.toRadians(baseDeg + 28.0)
                    val aEnd = Math.toRadians(baseDeg + 36.0)

                    val sx = cx + (baseR * cos(aStart)).toFloat()
                    val sy = cy + (baseR * sin(aStart)).toFloat()
                    if (i == 0) path.moveTo(sx, sy) else path.lineTo(sx, sy)

                    path.quadTo(
                        cx + (ctrlR * cos(aCtrlL)).toFloat(),
                        cy + (ctrlR * sin(aCtrlL)).toFloat(),
                        cx + (tipR * cos(aTipL)).toFloat(),
                        cy + (tipR * sin(aTipL)).toFloat()
                    )
                    path.lineTo(
                        cx + (notchR * cos(aMid)).toFloat(),
                        cy + (notchR * sin(aMid)).toFloat()
                    )
                    path.lineTo(
                        cx + (tipR * cos(aTipR)).toFloat(),
                        cy + (tipR * sin(aTipR)).toFloat()
                    )
                    path.quadTo(
                        cx + (ctrlR * cos(aCtrlR)).toFloat(),
                        cy + (ctrlR * sin(aCtrlR)).toFloat(),
                        cx + (baseR * cos(aEnd)).toFloat(),
                        cy + (baseR * sin(aEnd)).toFloat()
                    )
                }
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawCircle(cx, cy, r * 0.13f, fineStrokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 现代圆角极简风「退格删除键图标视图」（取代生硬的系统 ⌫ 字符，与圆角键帽风格统一）：
 * - 采用 CornerPathEffect 绘制圆润左尖角胶囊轮廓 + 微透明柔光填充 + 居中圆头 × 号。
 */
class BackspaceIconView(
    context: Context,
    private val iconColor: Int
) : View(context) {

    private val tagPath = Path()
    private val cornerEffect = CornerPathEffect(dpF(3.8f))

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(36, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor))
        pathEffect = cornerEffect
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
        pathEffect = cornerEffect
    }

    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        color = iconColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val halfW = dpF(10.5f)
        val halfH = dpF(7.2f)
        val noseX = cx - halfW
        val bodyLeft = cx - halfW * 0.38f
        val rightX = cx + halfW

        tagPath.reset()
        tagPath.moveTo(noseX, cy)
        tagPath.lineTo(bodyLeft, cy - halfH)
        tagPath.lineTo(rightX, cy - halfH)
        tagPath.lineTo(rightX, cy + halfH)
        tagPath.lineTo(bodyLeft, cy + halfH)
        tagPath.close()

        // 100% 纯镂空退格键图标（去除半透明灰色内填充）
        canvas.drawPath(tagPath, strokePaint)

        // 内部居中偏右一点的圆头 × 号
        val xCenter = (bodyLeft + rightX) * 0.5f + dpF(0.6f)
        val xSpan = dpF(2.7f)
        canvas.drawLine(xCenter - xSpan, cy - xSpan, xCenter + xSpan, cy + xSpan, crossPaint)
        canvas.drawLine(xCenter + xSpan, cy - xSpan, xCenter - xSpan, cy + xSpan, crossPaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
