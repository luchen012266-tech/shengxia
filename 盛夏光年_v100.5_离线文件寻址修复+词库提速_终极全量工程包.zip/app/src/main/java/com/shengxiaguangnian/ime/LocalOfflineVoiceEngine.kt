package com.shengxiaguangnian.ime

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.io.FileOutputStream

object LocalOfflineVoiceEngine {

    private const val TAG = "LocalVoiceEngine"
    private var recognizer: OnlineRecognizer? = null
    @Volatile
    private var isModelInitialized = false
    @Volatile
    private var isInitializing = false

    private var audioRecord: AudioRecord? = null
    @Volatile
    private var isRecording = false
    private var recordingThread: Thread? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    interface VoiceCallback {
        fun onReady()
        fun onRmsChanged(rmsdB: Float)
        fun onPartialResult(text: String)
        fun onFinalResult(text: String)
        fun onError(errorMsg: String)
        fun onStopped()
    }

    private fun copyAssetFileIfNotExists(context: Context, assetPath: String, outFile: File) {
        if (outFile.exists() && outFile.length() > 0) return
        outFile.parentFile?.mkdirs()
        try {
            context.assets.open(assetPath).use { input ->
                FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy asset $assetPath to ${outFile.absolutePath}", e)
        }
    }

    fun ensureModelInitialized(context: Context, onReady: (() -> Unit)? = null) {
        if (isModelInitialized && recognizer != null) {
            onReady?.let { mainHandler.post(it) }
            return
        }
        if (isInitializing) return
        isInitializing = true

        Thread {
            try {
                val appCtx = context.applicationContext
                val modelDir = File(appCtx.filesDir, "sherpa_model")
                if (!modelDir.exists()) modelDir.mkdirs()

                val encoderFile = File(modelDir, "encoder.onnx")
                val decoderFile = File(modelDir, "decoder.onnx")
                val joinerFile = File(modelDir, "joiner.onnx")
                val tokensFile = File(modelDir, "tokens.txt")

                copyAssetFileIfNotExists(appCtx, "sherpa_model/encoder.onnx", encoderFile)
                copyAssetFileIfNotExists(appCtx, "sherpa_model/decoder.onnx", decoderFile)
                copyAssetFileIfNotExists(appCtx, "sherpa_model/joiner.onnx", joinerFile)
                copyAssetFileIfNotExists(appCtx, "sherpa_model/tokens.txt", tokensFile)

                val transducerConfig = OnlineTransducerModelConfig(
                    encoder = encoderFile.absolutePath,
                    decoder = decoderFile.absolutePath,
                    joiner = joinerFile.absolutePath
                )

                val modelConfig = OnlineModelConfig(
                    transducer = transducerConfig,
                    tokens = tokensFile.absolutePath,
                    numThreads = 2,
                    provider = "cpu",
                    modelType = "zipformer2"
                )

                val endpointConfig = EndpointConfig(
                    rule1 = EndpointRule(mustContainNonSilence = false, minTrailingSilence = 2.4f, minUtteranceLength = 0.0f),
                    rule2 = EndpointRule(mustContainNonSilence = true, minTrailingSilence = 1.2f, minUtteranceLength = 0.0f),
                    rule3 = EndpointRule(mustContainNonSilence = false, minTrailingSilence = 0.0f, minUtteranceLength = 30.0f)
                )

                val config = OnlineRecognizerConfig(
                    modelConfig = modelConfig,
                    endpointConfig = endpointConfig,
                    enableEndpoint = true,
                    decodingMethod = "greedy_search"
                )

                recognizer = OnlineRecognizer(config = config)
                isModelInitialized = true
                isInitializing = false
                Log.i(TAG, "Sherpa-ONNX model loaded successfully from file path!")
                onReady?.let { mainHandler.post(it) }
            } catch (e: Throwable) {
                isInitializing = false
                Log.e(TAG, "Model initialization failed", e)
            }
        }.start()
    }

    fun startListening(context: Context, callback: VoiceCallback) {
        if (isRecording) {
            stopListening()
        }

        ensureModelInitialized(context) {
            startAudioRecordPipeline(callback)
        }
    }

    private fun startAudioRecordPipeline(callback: VoiceCallback) {
        val rec = recognizer ?: run {
            callback.onError("离线模型加载中，请稍候再试")
            return
        }

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = maxOf(minBufferSize, sampleRate * 2)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                callback.onError("无法启动麦克风录音权限")
                return
            }

            audioRecord?.startRecording()
            isRecording = true
            callback.onReady()

            recordingThread = Thread {
                val stream = rec.createStream()
                val readBuffer = ShortArray(1600)
                val floatBuffer = FloatArray(1600)
                var lastResultText = ""

                try {
                    while (isRecording) {
                        val readCount = audioRecord?.read(readBuffer, 0, readBuffer.size) ?: -1
                        if (readCount > 0) {
                            var sumSquares = 0.0
                            for (i in 0 until readCount) {
                                val s = readBuffer[i].toFloat()
                                floatBuffer[i] = s / 32768.0f
                                sumSquares += (s * s).toDouble()
                            }
                            val mean = sumSquares / readCount
                            val rms = Math.sqrt(mean)
                            val rmsDb = if (rms > 1.0) (20 * Math.log10(rms)).toFloat() else 0f
                            mainHandler.post { callback.onRmsChanged(rmsDb) }

                            val samples = if (readCount == floatBuffer.size) floatBuffer else floatBuffer.copyOf(readCount)
                            stream.acceptWaveform(samples, sampleRate)
                            while (rec.isReady(stream)) {
                                rec.decode(stream)
                            }

                            val curText = rec.getResult(stream).text.trim()
                            if (curText.isNotEmpty() && curText != lastResultText) {
                                lastResultText = curText
                                mainHandler.post { callback.onPartialResult(curText) }
                            }
                        }
                    }

                    val finalText = rec.getResult(stream).text.trim()
                    mainHandler.post {
                        callback.onFinalResult(finalText)
                        callback.onStopped()
                    }
                } catch (t: Throwable) {
                    mainHandler.post {
                        callback.onError(t.message ?: "识别异常")
                        callback.onStopped()
                    }
                } finally {
                    try {
                        stream.release()
                    } catch (_: Throwable) {}
                }
            }.apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
        } catch (e: Throwable) {
            callback.onError("启动录音失败: ${e.message}")
        }
    }

    fun stopListening() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Throwable) {}
        audioRecord = null
    }

    fun release() {
        stopListening()
        try {
            recognizer?.release()
        } catch (_: Throwable) {}
        recognizer = null
        isModelInitialized = false
    }
}
