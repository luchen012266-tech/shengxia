package com.shengxiaguangnian.ime

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.os.SystemClock
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.widget.FrameLayout
import android.view.View
import org.json.JSONObject
import java.io.File

/**
 * 按键效果（KeyFx）—— 可导入 / 可删除的按键按下反馈。
 *
 * 一个效果文件就是一个 JSON（扩展名 .keyfx 或 .json）：
 * {
 *   "name": "涟漪静湖",
 *   "scale": 0.93,           // 按下时键帽缩到多少（0.7 ~ 1.0）
 *   "downMs": 65,            // 按下去用多久
 *   "upMs": 150,             // 弹回来用多久
 *   "translateYdp": 2,       // 按下时往下沉几 dp
 *   "layers": [              // 可以叠很多层，按顺序画
 *     { "type": "ripple",  "color": "#3D2A3042", "durationMs": 260, "radiusPct": 1.0, "auto": true },
 *     { "type": "flash",   "color": "#22FFFFFF", "durationMs": 120 },
 *     { "type": "glow",    "color": "#554A6BD8", "durationMs": 240, "widthDp": 3 },
 *     { "type": "outline", "color": "#FF7A9B",   "durationMs": 200, "widthDp": 2 }
 *   ]
 * }
 *
 * color 支持 #RRGGBB 或 #AARRGGBB；auto=true 表示跟随浅色/深色皮肤自动选墨色或白色。
 */
data class KeyFxLayer(
    val type: String = "flash",
    val color: Int = 0x332A3042,
    val delayMs: Int = 0,
    val durationMs: Int = 220,
    val radiusPct: Float = 1.0f,
    val widthDp: Float = 2.5f,
    val auto: Boolean = false
)

data class KeyFx(
    val id: String,
    val name: String,
    val scale: Float = 0.93f,
    val downMs: Int = 65,
    val upMs: Int = 150,
    val translateYdp: Float = 2f,
    val layers: List<KeyFxLayer> = emptyList(),
    val builtin: Boolean = false
) {
    /** auto 颜色的层，按当前皮肤明暗换成墨色或微白 */
    fun withAdaptiveColors(isLightSkin: Boolean): KeyFx {
        if (layers.none { it.auto }) return this
        val c = if (isLightSkin) 0x3D2A3042 else 0x33FFFFFF
        return copy(layers = layers.map { if (it.auto) it.copy(color = c) else it })
    }
}

object KeyFxManager {
    const val PREFS_NAME = "shengxia_prefs"
    const val KEY_ACTIVE = "keyfx_active_id"
    const val ID_DEFAULT = "builtin_ripple"
    const val ID_SOFT = "builtin_soft"
    const val ID_PLAIN = "builtin_plain"

    fun builtins(): List<KeyFx> = listOf(
        KeyFx(
            id = ID_DEFAULT, name = "涟漪静湖（默认）",
            scale = 0.928f, downMs = 65, upMs = 150, translateYdp = 2f,
            layers = listOf(KeyFxLayer("ripple", 0x3D2A3042, 0, 260, 1.0f, 0f, true)),
            builtin = true
        ),
        KeyFx(
            id = ID_SOFT, name = "柔光轻闪",
            scale = 0.95f, downMs = 50, upMs = 160, translateYdp = 1f,
            layers = listOf(
                KeyFxLayer("flash", 0x22FFFFFF, 0, 120, 1f, 0f, true),
                KeyFxLayer("glow", 0x664A6BD8, 0, 240, 1f, 3f, false)
            ),
            builtin = true
        ),
        KeyFx(
            id = ID_PLAIN, name = "仅下沉（无光效）",
            scale = 0.95f, downMs = 55, upMs = 140, translateYdp = 2f,
            layers = emptyList(),
            builtin = true
        )
    )

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "keyfx")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun imported(ctx: Context): List<KeyFx> {
        val out = ArrayList<KeyFx>()
        val files = dir(ctx).listFiles() ?: return out
        for (f in files) {
            if (!f.isFile) continue
            val n = f.name.lowercase()
            if (!(n.endsWith(".keyfx") || n.endsWith(".json") || n.endsWith(".txt"))) continue
            try {
                val fx = parse(f.readText(), f.nameWithoutExtension)
                if (fx != null) out.add(fx)
            } catch (_: Throwable) {
            }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    fun listAll(ctx: Context): List<KeyFx> = builtins() + imported(ctx)

    fun activeId(ctx: Context): String =
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE, ID_DEFAULT) ?: ID_DEFAULT

    fun setActive(ctx: Context, id: String) {
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_ACTIVE, id).apply()
    }

    fun load(ctx: Context, id: String): KeyFx? {
        builtins().firstOrNull { it.id == id }?.let { return it }
        for (ext in arrayOf(".keyfx", ".json", ".txt")) {
            val f = File(dir(ctx), id + ext)
            if (f.exists()) {
                parse(f.readText(), id)?.let { return it }
            }
        }
        imported(ctx).firstOrNull { it.id == id }?.let { return it }
        return builtins().first()
    }

    fun delete(ctx: Context, fx: KeyFx): Boolean {
        if (fx.builtin) return false
        var ok = false
        for (ext in arrayOf(".keyfx", ".json", ".txt")) {
            val f = File(dir(ctx), fx.id + ext)
            if (f.exists() && f.delete()) ok = true
        }
        return ok
    }

    fun parseAndSave(ctx: Context, text: String, fileName: String): KeyFx? {
        val base = fileName.substringBeforeLast('.').trim().ifEmpty { "effect" }
        val safe = base.replace(Regex("[^\\p{L}\\p{N}_\\-]"), "_").take(40)
        val fx = parse(text, safe) ?: return null
        File(dir(ctx), safe + ".keyfx").writeText(text)
        return fx
    }

    fun parse(text: String, id: String): KeyFx? {
        return try {
            val clean = text.trim().removePrefix("\uFEFF")
            if (!clean.startsWith("{")) return null
            val o = JSONObject(clean)
            val layersJson = o.optJSONArray("layers")
            val layers = ArrayList<KeyFxLayer>()
            if (layersJson != null) {
                for (i in 0 until layersJson.length()) {
                    val lo = layersJson.optJSONObject(i) ?: continue
                    val type = lo.optString("type", "flash").lowercase()
                    if (type != "ripple" && type != "flash" && type != "glow" && type != "outline") continue
                    layers.add(
                        KeyFxLayer(
                            type = type,
                            color = parseColor(lo.optString("color", "#332A3042")),
                            delayMs = lo.optInt("delayMs", lo.optInt("delay", 0)).coerceIn(0, 2000),
                            durationMs = lo.optInt("durationMs", lo.optInt("duration", 220)).coerceIn(30, 2000),
                            radiusPct = lo.optDouble("radiusPct", 1.0).toFloat().coerceIn(0.3f, 2.5f),
                            widthDp = lo.optDouble("widthDp", 2.5).toFloat().coerceIn(0.5f, 8f),
                            auto = lo.optBoolean("auto", false)
                        )
                    )
                }
            }
            KeyFx(
                id = id,
                name = o.optString("name", id).take(24),
                scale = o.optDouble("scale", 0.93).toFloat().coerceIn(0.7f, 1.0f),
                downMs = o.optInt("downMs", 65).coerceIn(0, 400),
                upMs = o.optInt("upMs", 150).coerceIn(0, 800),
                translateYdp = o.optDouble("translateYdp", 2.0).toFloat().coerceIn(0f, 8f),
                layers = layers,
                builtin = false
            )
        } catch (_: Throwable) {
            null
        }
    }

    fun parseColor(s: String): Int {
        return try {
            Color.parseColor(s.trim())
        } catch (_: Throwable) {
            0x332A3042
        }
    }
}

/**
 * 效果绘制层：铺在键盘根容器最上层，按键被重建也不会消失。
 * 一次按键只用一个实例，动画结束自动隐藏。
 */
class KeyFxOverlayView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private var fx: KeyFx? = null
    private var cornerPx = 0f
    private var padPx = 0f
    private var elapsed = 0f
    private var animator: ValueAnimator? = null
    private var drawCount = 0
    private var onFinished: (() -> Unit)? = null

    init {
        setWillNotDraw(false)
        isClickable = false
        isFocusable = false
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun play(target: KeyFx, corner: Float, pad: Float, onDone: () -> Unit) {
        drawCount = 0
        fx = target
        cornerPx = corner
        padPx = pad
        elapsed = 0f
        // ★ 关键：先把上一轮动画的监听摘掉再 cancel。
        //   否则 cancel 会立刻触发上一轮的 onAnimationEnd，把这一轮刚点亮的效果瞬间 alpha=0 关掉，
        //   表现就是"只有第一下看得见，之后每次只闪一帧"。
        animator?.let { old ->
            old.removeAllUpdateListeners()
            old.removeAllListeners()
            old.cancel()
        }
        onFinished = onDone
        val total = (target.layers.maxOfOrNull { it.delayMs + it.durationMs } ?: 0).coerceAtLeast(60)
        animator = ValueAnimator.ofFloat(0f, total.toFloat()).apply {
            duration = total.toLong()
            addUpdateListener { a ->
                elapsed = (a.animatedValue as Float)
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onFinished?.invoke()
                }
            })
            start()
        }
    }

    fun stop() {
        animator?.let { old ->
            old.removeAllUpdateListeners()
            old.removeAllListeners()
            old.cancel()
        }
        animator = null
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        return Color.argb(
            alpha.coerceIn(0, 255),
            Color.red(color), Color.green(color), Color.blue(color)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCount++
        PressDiag.lastOverlayDraws = drawCount
        val f = fx ?: return
        if (f.layers.isEmpty()) return
        val inner = RectF(padPx, padPx, width - padPx, height - padPx)
        for (layer in f.layers) {
            if (elapsed < layer.delayMs) continue
            val dur = layer.durationMs.coerceAtLeast(1).toFloat()
            val local = ((elapsed - layer.delayMs) / dur).coerceIn(0f, 1f)
            val baseAlpha = Color.alpha(layer.color)
            val fade = 1f - local
            when (layer.type) {
                "ripple" -> {
                    val eased = 1f - (1f - local) * (1f - local) * (1f - local)
                    val maxR = inner.height() / 2f * layer.radiusPct
                    val r = (maxR * eased).coerceAtLeast(1f)
                    paint.style = Paint.Style.FILL
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawCircle(inner.centerX(), inner.centerY(), r, paint)
                }
                "flash" -> {
                    paint.style = Paint.Style.FILL
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawRoundRect(inner, cornerPx, cornerPx, paint)
                }
                "outline" -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = layer.widthDp * density
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawRoundRect(inner, cornerPx, cornerPx, paint)
                }
                "glow" -> {
                    paint.style = Paint.Style.STROKE
                    val step = layer.widthDp * density
                    for (k in 0 until 3) {
                        val grow = step * (k + 1) * 0.8f
                        val rr = RectF(inner)
                        rr.inset(-grow, -grow)
                        paint.strokeWidth = step
                        val a = (baseAlpha * fade * (0.55f - k * 0.15f)).toInt()
                        paint.color = withAlpha(layer.color, a)
                        canvas.drawRoundRect(rr, cornerPx + grow, cornerPx + grow, paint)
                    }
                }
            }
        }
    }
}


/**
 * 只是替身 FrameLayout：在事件发给按键之前先看一眼 ACTION_DOWN。
 * 用来保证"按下去一定有反馈"，不受任何按键自身的滑动手势判定影响。
 */
class TouchSpyFrameLayout(ctx: Context) : FrameLayout(ctx) {
    var onTouchDown: ((Float, Float) -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            try {
                onTouchDown?.invoke(ev.x, ev.y)
            } catch (_: Throwable) {
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}


/** 极轻量的按键反馈诊断记录（存在内存里，设置页可以直接读） */
object PressDiag {
    private val buf = ArrayList<String>()

    fun add(msg: String) {
        try {
            synchronized(buf) {
                buf.add("${SystemClock.elapsedRealtime() % 1000000}  $msg")
                if (buf.size > 200) buf.removeAt(0)
            }
        } catch (_: Throwable) {
        }
    }

    @Volatile
    var lastOverlayDraws = 0

    fun dump(): String = synchronized(buf) {
        if (buf.isEmpty()) "（还没有记录，先回键盘按几下再来）" else buf.joinToString("\n")
    }

    fun clear() {
        synchronized(buf) { buf.clear() }
    }
}
