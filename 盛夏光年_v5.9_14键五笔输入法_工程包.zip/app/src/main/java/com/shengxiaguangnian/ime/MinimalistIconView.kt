package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.TypedValue
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.36f

        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 莫奈《睡莲》印象派点题矢量装饰层：
 * - ART_KEY_LOTUS (0): 在粉色按键（如 TY）左下/右下角绘制盛开的睡莲花瓣 + 浮叶托盘
 * - ART_SPACE_LOTUS (1): 在空格键左右两侧对称绘制莫奈睡莲花朵 + 缺口圆荷叶 + 池水微澜
 * - ART_LILY_PAD (2): 在绿色荷叶按键（如 AS / GH / L / BN）右下角绘制缺口圆荷叶与叶脉
 * - ART_WATER_RIPPLE (3): 在蓝色池水按键（如 QW / OP / ZX / M）底部绘制柔光水波纹与小花苞
 */
class WaterLilyDecorView(
    context: Context,
    private val artType: Int
) : View(context) {

    companion object {
        const val ART_KEY_LOTUS = 0
        const val ART_SPACE_LOTUS = 1
        const val ART_LILY_PAD = 2
        const val ART_WATER_RIPPLE = 3
    }

    private val petalOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(145, 255, 246, 249) // 半透明柔白粉花瓣
    }
    private val petalInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(155, 218, 152, 168) // 莫奈深玫瑰粉内瓣
    }
    private val petalStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.0f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(135, 138, 86, 102)
    }
    private val stamenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(190, 242, 206, 116) // 暖金睡莲花蕊
    }
    private val padFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(95, 118, 152, 104) // 印象派浮水荷叶绿
    }
    private val padLightStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.1f)
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(115, 255, 255, 255)
    }
    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.1f)
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(105, 255, 255, 255)
    }

    private val path = Path()
    private val rectF = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        when (artType) {
            ART_KEY_LOTUS -> {
                // 在 TY 键右下角与左下角绘制莫奈睡莲与微澜
                drawWaterLilyFlower(canvas, w * 0.78f, h * 0.78f, minOf(w, h) * 0.25f)
                rectF.set(w * 0.08f, h * 0.76f, w * 0.52f, h * 0.90f)
                canvas.drawArc(rectF, 15f, 150f, false, ripplePaint)
            }
            ART_SPACE_LOTUS -> {
                // 在空格键左侧绘制盛开睡莲 + 水波，右侧绘制缺口荷叶 + 小睡莲苞
                val flowerScale = minOf(w, h) * 0.27f
                drawWaterLilyFlower(canvas, w * 0.19f, h * 0.56f, flowerScale)
                drawNotchedLilyPad(canvas, w * 0.82f, h * 0.58f, flowerScale * 0.88f, 35f)
                drawWaterLilyBud(canvas, w * 0.75f, h * 0.44f, flowerScale * 0.58f)
            }
            ART_LILY_PAD -> {
                // 在绿色按键右下角绘制莫奈缺口圆荷叶与叶脉
                val r = minOf(w, h) * 0.24f
                drawNotchedLilyPad(canvas, w * 0.79f, h * 0.77f, r, 25f)
            }
            ART_WATER_RIPPLE -> {
                // 在蓝色池水键底部绘制莫奈池水涟漪弧线
                rectF.set(w * 0.15f, h * 0.74f, w * 0.85f, h * 0.92f)
                canvas.drawArc(rectF, 12f, 156f, false, ripplePaint)
                rectF.set(w * 0.30f, h * 0.80f, w * 0.70f, h * 0.94f)
                canvas.drawArc(rectF, 18f, 144f, false, ripplePaint)
            }
        }
    }

    private fun drawNotchedLilyPad(canvas: Canvas, cx: Float, cy: Float, radius: Float, notchAngleDeg: Float) {
        rectF.set(cx - radius, cy - radius * 0.68f, cx + radius, cy + radius * 0.68f)
        path.reset()
        path.moveTo(cx, cy)
        path.arcTo(rectF, notchAngleDeg, 312f, false)
        path.close()
        canvas.drawPath(path, padFillPaint)
        canvas.drawPath(path, padLightStrokePaint)
        // 放射状荷叶脉络
        for (a in listOf(110.0, 185.0, 260.0)) {
            val rad = Math.toRadians(a)
            val ex = cx + radius * 0.68f * cos(rad).toFloat()
            val ey = cy + radius * 0.45f * sin(rad).toFloat()
            canvas.drawLine(cx, cy, ex, ey, padLightStrokePaint)
        }
    }

    private fun drawWaterLilyFlower(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        // 1. 底部托叶椭圆
        rectF.set(cx - size * 1.15f, cy - size * 0.15f, cx + size * 1.15f, cy + size * 0.58f)
        path.reset()
        path.moveTo(cx, cy + size * 0.2f)
        path.arcTo(rectF, 15f, 320f, false)
        path.close()
        canvas.drawPath(path, padFillPaint)

        // 2. 外层舒展五片睡莲花瓣 (-56°, -28°, 0°, 28°, 56°)
        val outerAngles = listOf(-58f, -29f, 0f, 29f, 58f)
        for (deg in outerAngles) {
            canvas.save()
            canvas.translate(cx, cy + size * 0.15f)
            canvas.rotate(deg)
            path.reset()
            path.moveTo(0f, 0f)
            path.quadTo(-size * 0.36f, -size * 0.55f, 0f, -size * 1.05f)
            path.quadTo(size * 0.36f, -size * 0.55f, 0f, 0f)
            path.close()
            canvas.drawPath(path, petalOuterPaint)
            canvas.drawPath(path, petalStrokePaint)
            canvas.restore()
        }

        // 3. 内层深粉三片睡莲花瓣 (-22°, 0°, 22°)
        val innerAngles = listOf(-22f, 0f, 22f)
        for (deg in innerAngles) {
            canvas.save()
            canvas.translate(cx, cy + size * 0.16f)
            canvas.rotate(deg)
            path.reset()
            path.moveTo(0f, 0f)
            path.quadTo(-size * 0.26f, -size * 0.42f, 0f, -size * 0.80f)
            path.quadTo(size * 0.26f, -size * 0.42f, 0f, 0f)
            path.close()
            canvas.drawPath(path, petalInnerPaint)
            canvas.drawPath(path, petalStrokePaint)
            canvas.restore()
        }

        // 4. 暖金色睡莲花心
        canvas.drawCircle(cx, cy + size * 0.04f, size * 0.16f, stamenPaint)
    }

    private fun drawWaterLilyBud(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val budAngles = listOf(-18f, 0f, 18f)
        for (deg in budAngles) {
            canvas.save()
            canvas.translate(cx, cy + size * 0.15f)
            canvas.rotate(deg)
            path.reset()
            path.moveTo(0f, 0f)
            path.quadTo(-size * 0.28f, -size * 0.45f, 0f, -size * 0.88f)
            path.quadTo(size * 0.28f, -size * 0.45f, 0f, 0f)
            path.close()
            canvas.drawPath(path, petalOuterPaint)
            canvas.drawPath(path, petalStrokePaint)
            canvas.restore()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
