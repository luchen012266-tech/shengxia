package com.shengxiaguangnian.ime

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

data class ClipItem(
    val id: Long,
    val content: String,
    val isPinned: Boolean,
    val timestamp: Long
)

data class PhraseItem(
    val id: Long,
    val category: String,
    val content: String,
    val isStarred: Boolean,
    val lastUsed: Long
)

data class ImportedDictPack(
    val packName: String,
    val wordCount: Int,
    val importedAt: Long
)

class ImeDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "shengxia_ime.db", null, 7) {

    companion object {
        const val MAX_CLIPBOARD_ITEMS = 300
        val DEFAULT_CATEGORIES = listOf("收藏", "最近", "邮", "号", "叮", "演", "扮", "模块", "api")
        private val dbExecutor = Executors.newSingleThreadExecutor()

        private val URL_REGEX = Regex(
            "(?:https?://|www\\.)[a-zA-Z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]+|(?:[a-zA-Z0-9\\-]+\\.)+(?:com|cn|net|org|io|cc|tv|me|xyz|top|vip|co|ai|app|dev|gg|hk|tw|jp|uk|us)(?:/[a-zA-Z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]*)?",
            RegexOption.IGNORE_CASE
        )

        /**
         * 从任意剪贴板或常用语文本中智能提取纯网址（自动剥离末尾粘连的标点符号）
         */
        fun extractUrls(text: String): List<String> {
            if (text.isBlank()) return emptyList()
            val result = ArrayList<String>()
            val trimChars = charArrayOf('.', ',', ';', ':', '!', '?', ')', ']', '>', '\'', '"', '，', '。', '！', '？', '；', '：', '）', '】', '》', '”', '’')
            for (match in URL_REGEX.findAll(text)) {
                val cleaned = match.value.trimEnd(*trimChars).trim()
                if (cleaned.length >= 4 && !result.contains(cleaned)) {
                    result.add(cleaned)
                }
            }
            return result
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS clipboard_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL UNIQUE ON CONFLICT REPLACE,
                is_pinned INTEGER DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrase_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                sort_order INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                is_starred INTEGER DEFAULT 0,
                last_used INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_dict (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                wubi_code TEXT NOT NULL,
                pinyin_code TEXT NOT NULL,
                t14_wubi TEXT NOT NULL,
                t14_pinyin TEXT NOT NULL,
                weight INTEGER DEFAULT 5000,
                source_name TEXT NOT NULL DEFAULT '手动添加'
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_source ON user_dict(source_name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_wubi ON user_dict(t14_wubi)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_pinyin ON user_dict(t14_pinyin)")

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())

        createV3Tables(db)

        DEFAULT_CATEGORIES.forEachIndexed { idx, name ->
            val cv = ContentValues().apply {
                put("name", name)
                put("sort_order", idx)
            }
            db.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }

        val samplePhrases = listOf(
            Triple("演", "### 角色扮演规则指令：《盛夏光年》 **【核心世界观】** 这是一个支持无限字数、零截断的专属常用语模板，点击卡片直接全文上屏，点击右侧箭头可展开或编辑。", 1),
            Triple("模块", "【模块指令模板】可在此分类下存放常用的系统提示词模块与世界观插件，不限字数。", 1),
            Triple("api", "【API 快捷配置】可在此处存放常用的接口地址、模型名称或参数片段。", 0)
        )
        samplePhrases.forEach { (cat, text, starred) ->
            val cv = ContentValues().apply {
                put("category", cat)
                put("content", text)
                put("is_starred", starred)
                put("last_used", System.currentTimeMillis())
            }
            db.insert("phrases", null, cv)
        }
    }

    private fun createV3Tables(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_freq (
                word TEXT PRIMARY KEY,
                freq INTEGER NOT NULL DEFAULT 1,
                last_used INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_code_mru (
                t14_code TEXT NOT NULL,
                word TEXT NOT NULL,
                last_used INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (t14_code, word)
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_bigram (
                prev_word TEXT NOT NULL,
                next_word TEXT NOT NULL,
                freq INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (prev_word, next_word)
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS imported_dict_packs (
                pack_name TEXT PRIMARY KEY,
                word_count INTEGER NOT NULL DEFAULT 0,
                imported_at INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        createV3Tables(db)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())
        try {
            db.execSQL("ALTER TABLE user_dict ADD COLUMN source_name TEXT NOT NULL DEFAULT '手动添加'")
        } catch (_: Exception) {}
        try {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_source ON user_dict(source_name)")
        } catch (_: Exception) {}
        // 将旧版本已导入的词库词条（weight=5000）自动归档为可见词库包，方便用户查看与一键删除
        try {
            db.execSQL("UPDATE user_dict SET source_name = '此前已导入词库汇总' WHERE weight = 5000 AND source_name = '手动添加'")
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = '此前已导入词库汇总'", null).use { c ->
                if (c.moveToFirst()) {
                    val cnt = c.getInt(0)
                    if (cnt > 0) {
                        val cv = ContentValues().apply {
                            put("pack_name", "此前已导入词库汇总")
                            put("word_count", cnt)
                            put("imported_at", System.currentTimeMillis())
                        }
                        db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                    }
                }
            }
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = '手动添加'", null).use { c ->
                if (c.moveToFirst()) {
                    val cnt = c.getInt(0)
                    if (cnt > 0) {
                        val cv = ContentValues().apply {
                            put("pack_name", "手动添加")
                            put("word_count", cnt)
                            put("imported_at", System.currentTimeMillis())
                        }
                        db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    fun recordWordUsageAsync(word: String, prevWord: String?, t14Code: String = "", mruSeq: Long = 0L) {
        dbExecutor.execute {
            try {
                val now = if (mruSeq > 0L) mruSeq else System.currentTimeMillis()
                val db = writableDatabase
                db.execSQL(
                    "INSERT INTO user_freq(word, freq, last_used) VALUES(?, 1, ?) ON CONFLICT(word) DO UPDATE SET freq = freq + 1, last_used = ?",
                    arrayOf<Any>(word, now, now)
                )
                if (t14Code.isNotEmpty()) {
                    db.execSQL(
                        "INSERT INTO user_code_mru(t14_code, word, last_used) VALUES(?, ?, ?) ON CONFLICT(t14_code, word) DO UPDATE SET last_used = ?",
                        arrayOf<Any>(t14Code, word, now, now)
                    )
                }
                if (!prevWord.isNullOrEmpty() && prevWord != word) {
                    db.execSQL(
                        "INSERT INTO user_bigram(prev_word, next_word, freq) VALUES(?, ?, 1) ON CONFLICT(prev_word, next_word) DO UPDATE SET freq = freq + 1",
                        arrayOf<Any>(prevWord, word)
                    )
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * 一键重置个人高频字词排序为默认出厂排序
     */
    fun resetUserFrequencySorting() {
        try {
            val db = writableDatabase
            db.delete("user_freq", null, null)
            db.delete("user_code_mru", null, null)
            db.delete("user_bigram", null, null)
        } catch (_: Exception) {}
    }

    fun loadUserFreqMap(): HashMap<String, Int> {
        val map = HashMap<String, Int>()
        try {
            readableDatabase.rawQuery("SELECT word, freq FROM user_freq", null).use { c ->
                while (c.moveToNext()) {
                    map[c.getString(0)] = c.getInt(1)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserCodeMruMap(): HashMap<String, Long> {
        val map = HashMap<String, Long>()
        try {
            readableDatabase.rawQuery("SELECT t14_code, word, last_used FROM user_code_mru WHERE last_used > 0", null).use { c ->
                while (c.moveToNext()) {
                    val code = c.getString(0)
                    val w = c.getString(1)
                    val lu = c.getLong(2)
                    if (code.isNotEmpty() && w.isNotEmpty()) {
                        map["$code|$w"] = lu
                    }
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserBigramMap(): HashMap<String, MutableList<String>> {
        val map = HashMap<String, MutableList<String>>()
        try {
            readableDatabase.rawQuery(
                "SELECT prev_word, next_word FROM user_bigram ORDER BY freq DESC LIMIT 2000",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0)
                    val n = c.getString(1)
                    val list = map.getOrPut(p) { ArrayList() }
                    if (list.size < 10) list.add(n)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    // --- 自定义表情与颜文字增删查 ---
    fun addCustomExpression(typeCategory: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val cv = ContentValues().apply {
            put("category", typeCategory)
            put("text", clean)
        }
        writableDatabase.insertWithOnConflict("custom_kaomoji", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getCustomExpressions(typeCategory: String): List<String> {
        val list = ArrayList<String>()
        try {
            readableDatabase.rawQuery(
                "SELECT text FROM custom_kaomoji WHERE category = ? ORDER BY id DESC",
                arrayOf(typeCategory)
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(c.getString(0))
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteCustomExpression(text: String) {
        writableDatabase.delete("custom_kaomoji", "text = ?", arrayOf(text))
    }

    // --- 剪贴板与常用语一键导出 / 导入备份 (JSON) ---
    fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("app", "盛夏光年")
        root.put("version", 5)

        val catsArr = JSONArray()
        getCategories().forEach { catsArr.put(it) }
        root.put("categories", catsArr)

        val phrasesArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, content, is_starred, last_used FROM phrases ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("content", c.getString(1))
                    put("is_starred", c.getInt(2))
                    put("last_used", c.getLong(3))
                }
                phrasesArr.put(obj)
            }
        }
        root.put("phrases", phrasesArr)

        val clipsArr = JSONArray()
        readableDatabase.rawQuery("SELECT content, is_pinned, created_at FROM clipboard_history ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("content", c.getString(0))
                    put("is_pinned", c.getInt(1))
                    put("created_at", c.getLong(2))
                }
                clipsArr.put(obj)
            }
        }
        root.put("clipboard", clipsArr)

        val kaomojiArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, text FROM custom_kaomoji ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("text", c.getString(1))
                }
                kaomojiArr.put(obj)
            }
        }
        root.put("custom_expressions", kaomojiArr)

        return root.toString(2)
    }

    fun importBackupJson(jsonStr: String): Pair<Int, Int> {
        val root = JSONObject(jsonStr)
        var phraseCount = 0
        var clipCount = 0
        val db = writableDatabase
        db.beginTransaction()
        try {
            root.optJSONArray("categories")?.let { arr ->
                for (i in 0 until arr.length()) {
                    addCategory(arr.getString(i))
                }
            }
            root.optJSONArray("phrases")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val cat = obj.optString("category", "演")
                    val content = obj.optString("content", "")
                    val starred = obj.optInt("is_starred", 0) == 1
                    if (content.isNotBlank()) {
                        addCategory(cat)
                        addOrUpdatePhrase(null, cat, content, starred)
                        phraseCount++
                    }
                }
            }
            root.optJSONArray("clipboard")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val content = obj.optString("content", "")
                    val pinned = obj.optInt("is_pinned", 0)
                    val createdAt = obj.optLong("created_at", System.currentTimeMillis())
                    if (content.isNotBlank()) {
                        val cv = ContentValues().apply {
                            put("content", content)
                            put("is_pinned", pinned)
                            put("created_at", createdAt)
                        }
                        db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                        clipCount++
                    }
                }
            }
            root.optJSONArray("custom_expressions")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    addCustomExpression(obj.optString("category", "kaomoji"), obj.optString("text", ""))
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return phraseCount to clipCount
    }

    fun addClip(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        dbExecutor.execute {
            try {
                val db = writableDatabase
                db.beginTransaction()
                try {
                    var pinned = 0
                    // 自动识别一模一样的文字（含首尾空白一致的记录）：不重复新增，保留原置顶属性并直接调到最上面！
                    db.rawQuery(
                        "SELECT is_pinned FROM clipboard_history WHERE content = ? OR TRIM(content) = ?",
                        arrayOf(text, trimmed)
                    ).use { c ->
                        while (c.moveToNext()) {
                            if (c.getInt(0) == 1) pinned = 1
                        }
                    }
                    db.delete(
                        "clipboard_history",
                        "content = ? OR TRIM(content) = ?",
                        arrayOf(text, trimmed)
                    )
                    val cv = ContentValues().apply {
                        put("content", text)
                        put("is_pinned", pinned)
                        put("created_at", System.currentTimeMillis())
                    }
                    db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

                    db.execSQL("""
                        DELETE FROM clipboard_history
                        WHERE is_pinned = 0 AND id NOT IN (
                            SELECT id FROM clipboard_history
                            ORDER BY is_pinned DESC, created_at DESC
                            LIMIT $MAX_CLIPBOARD_ITEMS
                        )
                    """.trimIndent())
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            } catch (_: Exception) {}
        }
    }

    fun getClips(): List<ClipItem> {
        val list = mutableListOf<ClipItem>()
        val seen = HashSet<String>()
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history ORDER BY is_pinned DESC, created_at DESC LIMIT $MAX_CLIPBOARD_ITEMS",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val content = c.getString(1)
                val norm = content.trim()
                if (seen.add(norm)) {
                    list.add(ClipItem(id, content, c.getInt(2) == 1, c.getLong(3)))
                }
            }
        }
        return list
    }

    fun toggleClipPin(id: Long, currentPinned: Boolean) {
        val cv = ContentValues().apply { put("is_pinned", if (currentPinned) 0 else 1) }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
    }

    fun updateClipContent(id: Long, newContent: String) {
        val trimmed = newContent.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("content", newContent)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
    }

    fun getClipById(id: Long): ClipItem? {
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history WHERE id = ?",
            arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                return ClipItem(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getLong(3))
            }
        }
        return null
    }

    fun deleteClip(id: Long) {
        writableDatabase.delete("clipboard_history", "id = ?", arrayOf(id.toString()))
    }

    fun clearUnpinnedClips() {
        writableDatabase.delete("clipboard_history", "is_pinned = 0", null)
    }

    fun getCategories(): List<String> {
        val list = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM phrase_categories ORDER BY sort_order ASC, id ASC", null).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        if (!list.contains("收藏")) list.add(0, "收藏")
        if (!list.contains("最近")) list.add(1, "最近")
        return list.distinct()
    }

    fun getAssignableCategories(): List<String> {
        val all = getCategories().filter { it != "最近" }
        return if (all.isEmpty()) listOf("收藏", "邮", "号", "叮", "演", "扮", "模块", "api") else all
    }

    fun addCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("name", trimmed)
            put("sort_order", 99)
        }
        writableDatabase.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun renameCategory(oldName: String, newName: String): Boolean {
        val cleanOld = oldName.trim()
        val cleanNew = newName.trim()
        if (cleanOld.isEmpty() || cleanNew.isEmpty() || cleanOld == "收藏" || cleanOld == "最近" || cleanNew == "最近") return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            addCategory(cleanNew)
            val cv = ContentValues().apply { put("category", cleanNew) }
            db.update("phrases", cv, "category = ?", arrayOf(cleanOld))
            if (cleanOld != cleanNew) {
                db.delete("phrase_categories", "name = ?", arrayOf(cleanOld))
            }
            db.setTransactionSuccessful()
            return true
        } catch (_: Exception) {
            return false
        } finally {
            db.endTransaction()
        }
    }

    fun deleteCategory(name: String) {
        if (name == "收藏" || name == "最近") return
        writableDatabase.delete("phrase_categories", "name = ?", arrayOf(name))
        writableDatabase.delete("phrases", "category = ?", arrayOf(name))
    }

    fun getPhrasesByCategory(category: String): List<PhraseItem> {
        val list = mutableListOf<PhraseItem>()
        val query = when (category) {
            "全部" -> "SELECT id, category, content, is_starred, last_used FROM phrases ORDER BY is_starred DESC, id DESC"
            "收藏" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE is_starred = 1 OR category = '收藏' ORDER BY id DESC"
            "最近" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE last_used > 0 ORDER BY last_used DESC LIMIT 50"
            else -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE category = ? ORDER BY is_starred DESC, id DESC"
        }
        val args = if (category == "全部" || category == "收藏" || category == "最近") null else arrayOf(category)
        readableDatabase.rawQuery(query, args).use { c ->
            while (c.moveToNext()) {
                list.add(PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4)))
            }
        }
        return list
    }

    fun getPhraseById(id: Long): PhraseItem? {
        readableDatabase.rawQuery(
            "SELECT id, category, content, is_starred, last_used FROM phrases WHERE id = ?",
            arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                return PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4))
            }
        }
        return null
    }

    fun movePhraseToCategory(id: Long, newCategory: String) {
        val cleanCat = newCategory.trim().ifEmpty { "收藏" }
        if (cleanCat != "最近") addCategory(cleanCat)
        val cv = ContentValues().apply {
            put("category", cleanCat)
            if (cleanCat == "收藏") {
                put("is_starred", 1)
            }
        }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun addOrUpdatePhrase(id: Long?, category: String, content: String, isStarred: Boolean) {
        if (content.isBlank()) return
        val targetCat = if (category == "最近" || category.isBlank()) "收藏" else category.trim()
        if (targetCat != "收藏" && targetCat != "最近") {
            addCategory(targetCat)
        }
        val cv = ContentValues().apply {
            put("category", targetCat)
            put("content", content)
            put("is_starred", if (isStarred || targetCat == "收藏") 1 else 0)
            put("last_used", System.currentTimeMillis())
        }
        if (id == null || id <= 0L) {
            writableDatabase.insert("phrases", null, cv)
        } else {
            writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
        }
    }

    fun togglePhraseStar(id: Long, currentStarred: Boolean) {
        val cv = ContentValues().apply { put("is_starred", if (currentStarred) 0 else 1) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun markPhraseUsed(id: Long) {
        val cv = ContentValues().apply { put("last_used", System.currentTimeMillis()) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deletePhrase(id: Long) {
        writableDatabase.delete("phrases", "id = ?", arrayOf(id.toString()))
    }

    fun insertUserWord(word: String, wubiCode: String, pinyinCode: String, weight: Int = 6000, sourceName: String = "手动添加") {
        val cleanPy = pinyinCode.replace("'", "")
        val t14Wubi = T14WubiEngine.letterToT14Code(wubiCode)
        val t14Pinyin = T14WubiEngine.letterToT14Code(cleanPy)
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("word", word)
            put("wubi_code", wubiCode)
            put("pinyin_code", pinyinCode)
            put("t14_wubi", t14Wubi)
            put("t14_pinyin", t14Pinyin)
            put("weight", weight)
            put("source_name", sourceName)
        }
        db.insert("user_dict", null, cv)
        refreshPackCount(db, sourceName)
        T14WubiEngine.markUserDictDirty()
    }

    fun importDictionaryBatch(packName: String, wordsWithCodes: List<Triple<String, String, String>>, weight: Int = 5000): Int {
        if (wordsWithCodes.isEmpty()) return 0
        val cleanPack = packName.trim().ifEmpty { "导入词库.scel" }
        val db = writableDatabase
        var inserted = 0
        db.beginTransaction()
        try {
            // 若同名词库包重新导入，先清理该包旧记录避免重复膨胀
            db.delete("user_dict", "source_name = ?", arrayOf(cleanPack))
            val stmt = db.compileStatement(
                "INSERT INTO user_dict(word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight, source_name) VALUES(?, ?, ?, ?, ?, ?, ?)"
            )
            for ((w, wcode, py) in wordsWithCodes) {
                val cleanPy = py.replace("'", "")
                val t14W = T14WubiEngine.letterToT14Code(wcode)
                val t14P = T14WubiEngine.letterToT14Code(cleanPy)
                stmt.clearBindings()
                stmt.bindString(1, w)
                stmt.bindString(2, wcode)
                stmt.bindString(3, py)
                stmt.bindString(4, t14W)
                stmt.bindString(5, t14P)
                stmt.bindLong(6, weight.toLong())
                stmt.bindString(7, cleanPack)
                stmt.executeInsert()
                inserted++
            }
            val cv = ContentValues().apply {
                put("pack_name", cleanPack)
                put("word_count", inserted)
                put("imported_at", System.currentTimeMillis())
            }
            db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        T14WubiEngine.markUserDictDirty()
        return inserted
    }

    private fun refreshPackCount(db: SQLiteDatabase, packName: String) {
        try {
            var cnt = 0
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = ?", arrayOf(packName)).use { c ->
                if (c.moveToFirst()) cnt = c.getInt(0)
            }
            if (cnt > 0) {
                val cv = ContentValues().apply {
                    put("pack_name", packName)
                    put("word_count", cnt)
                    put("imported_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            } else {
                db.delete("imported_dict_packs", "pack_name = ?", arrayOf(packName))
            }
        } catch (_: Exception) {}
    }

    fun getImportedDictPacks(): List<ImportedDictPack> {
        val list = ArrayList<ImportedDictPack>()
        try {
            val db = readableDatabase
            db.rawQuery(
                "SELECT source_name, COUNT(*) as cnt, MAX(id) FROM user_dict GROUP BY source_name ORDER BY MAX(id) DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: "导入词库"
                    val count = c.getInt(1)
                    if (count > 0) {
                        var ts = 0L
                        db.rawQuery("SELECT imported_at FROM imported_dict_packs WHERE pack_name = ?", arrayOf(name)).use { tc ->
                            if (tc.moveToFirst()) ts = tc.getLong(0)
                        }
                        list.add(ImportedDictPack(name, count, ts))
                    }
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteDictionaryPack(packName: String): Int {
        val db = writableDatabase
        val deleted = db.delete("user_dict", "source_name = ?", arrayOf(packName))
        db.delete("imported_dict_packs", "pack_name = ?", arrayOf(packName))
        T14WubiEngine.markUserDictDirty()
        return deleted
    }

    fun clearAllUserDict(): Int {
        val db = writableDatabase
        val deleted = db.delete("user_dict", null, null)
        db.delete("imported_dict_packs", null, null)
        T14WubiEngine.markUserDictDirty()
        return deleted
    }
}
