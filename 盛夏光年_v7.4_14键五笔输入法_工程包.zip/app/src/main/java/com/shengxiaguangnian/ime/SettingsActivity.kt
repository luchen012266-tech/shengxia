package com.shengxiaguangnian.ime

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import java.io.FileOutputStream
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class SettingsActivity : AppCompatActivity() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private lateinit var cssInputBox: EditText
    private lateinit var importedDictListContainer: LinearLayout
    private lateinit var importDictStatusTv: TextView

    private val REQ_IMPORT_DICT = 1001
    private val REQ_EXPORT_BACKUP = 1002
    private val REQ_IMPORT_BACKUP = 1003
    private val REQ_IMPORT_CSS = 1004
    private val REQ_PICK_BG_IMAGE = 1005
    private lateinit var customBgStatusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = ImeDatabaseHelper(this)
        val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        T14WubiEngine.ensureInitializedAsync(this, dbHelper)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EEF0F8"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(36))
        }

        val titleTv = TextView(this).apply {
            text = "盛夏光年 v7.4 · 莫奈睡莲琥珀流光版"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2A3042"))
        }
        root.addView(titleTv)

        val subTv = TextView(this).apply {
            text = "🔒 零联网权限纯单机 · 哈希秒查词库管理 · 几码归几码智能排序 · CSS皮肤"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#5A627A"))
            setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(subTv)

        // 1. 启用与切换输入法
        val stepCard = makeCard("1. 启用与切换「盛夏光年」")
        stepCard.addView(Button(this).apply {
            text = "在系统设置中勾选「盛夏光年」"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        stepCard.addView(Button(this).apply {
            text = "切换当前输入法为「盛夏光年」"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        root.addView(stepCard)

        // 1.2 键盘敲击音效开关（Switch）
        val soundCard = makeCard("键盘敲击音效与反馈设置")
        val soundSwitch = Switch(this).apply {
            text = "开启按键敲击音效（清脆机械/水滴敲击音）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setTextColor(Color.parseColor("#2A3042"))
            isChecked = prefs.getBoolean("key_sound_enabled", true)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean("key_sound_enabled", isChecked).apply()
                if (isChecked) {
                    KeySoundManager.playClick(this@SettingsActivity)
                }
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启按键敲击音效" else "已关闭按键敲击音效",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        soundCard.addView(soundSwitch)
        root.addView(soundCard)

        // 1.5 自定义键盘右下角文字（原「盛夏光年」按键）
        val enterTextCard = makeCard("✨ 自定义键盘右下角文字（默认：盛夏光年）")
        val enterTextDesc = TextView(this).apply {
            text = "随时修改键盘右下角回车键显示的文字（4个字会自动排成精致的上下两行，也可以用 / 手动分行，如：盛夏/光年、暴富/暴美、biu~）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(6))
        }
        val enterTextInput = EditText(this).apply {
            setText(prefs.getString("custom_enter_text", "") ?: "")
            hint = "默认显示：盛夏光年（直接输入你想换的字）"
            setSingleLine(true)
        }
        val enterBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val saveEnterTextBtn = Button(this).apply {
            text = "💾 保存右下角文字"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val newText = enterTextInput.text.toString().trim()
                if (newText.isEmpty()) {
                    prefs.edit().remove("custom_enter_text").apply()
                    Toast.makeText(this@SettingsActivity, "已恢复默认「盛夏光年」！弹出键盘即可看到", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString("custom_enter_text", newText).apply()
                    Toast.makeText(this@SettingsActivity, "右下角文字已更新为「$newText」！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val resetEnterTextBtn = Button(this).apply {
            text = "↺ 恢复「盛夏光年」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                enterTextInput.setText("")
                prefs.edit().remove("custom_enter_text").apply()
                Toast.makeText(this@SettingsActivity, "已恢复默认「盛夏光年」！", Toast.LENGTH_SHORT).show()
            }
        }
        enterBtnRow.addView(saveEnterTextBtn)
        enterBtnRow.addView(resetEnterTextBtn)
        enterTextCard.addView(enterTextDesc)
        enterTextCard.addView(enterTextInput)
        enterTextCard.addView(enterBtnRow)
        root.addView(enterTextCard)

        // 2. 剪贴板与常用语导出 / 导入备份 (.json)
        val backupCard = makeCard("2. 剪贴板与常用语导出 / 导入备份")
        val backupDesc = TextView(this).apply {
            text = "可将全部 300 条剪贴板、自定义常用语分类与万字指令、自定义颜文字一键打包导出为 .json 文件，换机或重装随时恢复："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        backupCard.addView(backupDesc)

        val backupBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val exportBtn = Button(this).apply {
            text = "📤 导出备份 (.json)"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "盛夏光年_常用语与剪贴板备份.json")
                }
                startActivityForResult(intent, REQ_EXPORT_BACKUP)
            }
        }
        val importBackupBtn = Button(this).apply {
            text = "📥 导入恢复 (.json)"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择备份 .json 文件"), REQ_IMPORT_BACKUP)
            }
        }
        backupBtnRow.addView(exportBtn)
        backupBtnRow.addView(importBackupBtn)
        backupCard.addView(backupBtnRow)
        root.addView(backupCard)

        // 3. 添加自定义表情与颜文字
        val kaomojiCard = makeCard("3. 添加自定义表情与颜文字（长按键盘内自定义项可删除）")
        val customExpInput = EditText(this).apply {
            hint = "输入你想添加的颜文字或表情组合，如：(๑•̀ㅂ•́)و✧ 或 🐱✨"
        }
        val expBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addToKaomojiBtn = Button(this).apply {
            text = "＋加入「颜文字」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val t = customExpInput.text.toString().trim()
                if (t.isNotEmpty()) {
                    dbHelper.addCustomExpression("kaomoji", t)
                    customExpInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已加入颜文字「经典」分类首位！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val addToEmojiBtn = Button(this).apply {
            text = "＋加入「Emoji」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val t = customExpInput.text.toString().trim()
                if (t.isNotEmpty()) {
                    dbHelper.addCustomExpression("emoji", t)
                    customExpInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已加入 Emoji「笑脸」分类首位！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        expBtnRow.addView(addToKaomojiBtn)
        expBtnRow.addView(addToEmojiBtn)
        kaomojiCard.addView(customExpInput)
        kaomojiCard.addView(expBtnRow)
        root.addView(kaomojiCard)

        // 4. 高频字词自动排序说明与一键重置
        val freqCard = makeCard("4. 个人高频字词自动排序与重置")
        val freqDesc = TextView(this).apply {
            text = "工作原理（几码归几码精准记忆）：系统严格按你当时输入的码数（1码、2码、3码、4码各管各的）记录你最后选过的字/词，下次打相同编码时直接排第 1 位，绝不会出现长编码词语越级抢占 1 码单字的情况。若想恢复初始词库顺序，可点击下方重置："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        val resetFreqBtn = Button(this).apply {
            text = "🔄 一键重置文字默认排序（清空个人高频记忆）"
            setOnClickListener {
                T14WubiEngine.resetUserFrequency(dbHelper)
                Toast.makeText(this@SettingsActivity, "已重置所有字词为默认排序！", Toast.LENGTH_SHORT).show()
            }
        }
        freqCard.addView(freqDesc)
        freqCard.addView(resetFreqBtn)
        root.addView(freqCard)

        // 5. 双层架构皮肤设置（莫奈花园特殊皮肤 + 纯色/自定义背景图毛玻璃框架 + CSS 编辑器）
        val skinCard = makeCard("5. 皮肤设置与 CSS 编辑器（支持上传自定义背景图）")

        val bgArchNote = TextView(this).apply {
            text = "架构说明：「莫奈花园」为唯一自带油画贴图的特殊皮肤；其余皮肤均采用「纯色框架」。在纯色框架下上传自定义背景图后，底图会自动以 cover 模式铺满键盘，所有按键自动开启半透明毛玻璃效果并实时模糊底图；不上传则默认使用纯色背景。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        skinCard.addView(bgArchNote)

        customBgStatusTv = TextView(this).apply {
            val hasBg = CustomBgManager.hasCustomBg(this@SettingsActivity)
            text = if (hasBg) "当前底图状态：已启用自定义背景图（纯色框架下按键已开启半透明毛玻璃）" else "当前底图状态：未上传自定义背景图（默认使用纯色背景）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#3B5998"))
            setPadding(0, 0, 0, dp(6))
        }
        skinCard.addView(customBgStatusTv)

        val customBgBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val uploadBgBtn = Button(this).apply {
            text = "上传自定义背景图"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(Intent.createChooser(intent, "从相册选择键盘背景图"), REQ_PICK_BG_IMAGE)
            }
        }
        val clearBgBtn = Button(this).apply {
            text = "清除自定义背景图"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                CustomBgManager.clearCustomBg(this@SettingsActivity)
                customBgStatusTv.text = "当前底图状态：未上传自定义背景图（默认使用纯色背景）"
                Toast.makeText(this@SettingsActivity, "已清除自定义背景图，恢复纯色背景！", Toast.LENGTH_SHORT).show()
            }
        }
        customBgBtnRow.addView(uploadBgBtn)
        customBgBtnRow.addView(clearBgBtn)
        skinCard.addView(customBgBtnRow)

        cssInputBox = EditText(this).apply {
            setText(CssSkinManager.getSavedCss(this@SettingsActivity))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            minLines = 8
            maxLines = 14
            gravity = Gravity.TOP or Gravity.START
            setBackgroundColor(Color.parseColor("#F7F8FC"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        // 代码辅助按钮行：清除代码 | 示例代码（带完整中文注释框架）
        val codeHelperRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val clearCodeBtn = Button(this).apply {
            text = "清除代码"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                cssInputBox.setText("")
                Toast.makeText(this@SettingsActivity, "已清空代码编辑框，可直接粘贴或编写新代码", Toast.LENGTH_SHORT).show()
            }
        }
        val sampleCodeBtn = Button(this).apply {
            text = "示例代码"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                cssInputBox.setText(CssSkinManager.SAMPLE_COMMENTED_CSS)
                Toast.makeText(this@SettingsActivity, "已载入带完整中文注释的 CSS 示例代码！修改颜色后点「应用上方 CSS 皮肤」即可", Toast.LENGTH_LONG).show()
            }
        }
        codeHelperRow.addView(clearCodeBtn)
        codeHelperRow.addView(sampleCodeBtn)

        // 应用与导入按钮行（去掉破坏排版的小图标）
        val skinBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val applyCssBtn = Button(this).apply {
            text = "应用上方 CSS 皮肤"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                CssSkinManager.saveCustomCss(this@SettingsActivity, cssInputBox.text.toString())
                Toast.makeText(this@SettingsActivity, "CSS 皮肤已生效！弹出键盘即可查看", Toast.LENGTH_SHORT).show()
            }
        }
        val importCssFileBtn = Button(this).apply {
            text = "导入 .CSS 文件"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择 .css 皮肤文件"), REQ_IMPORT_CSS)
            }
        }
        skinBtnRow.addView(applyCssBtn)
        skinBtnRow.addView(importCssFileBtn)

        // 预设皮肤切换行（全部移除多余图标，统一 4 字工整排版，杜绝高低错位）
        val presetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun makePresetBtn(label: String, onClick: () -> Unit): Button {
            return Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setPadding(dp(2), dp(8), dp(2), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { onClick() }
            }
        }
        presetRow.addView(makePresetBtn("默认灰") {
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.DEFAULT_GRAY_CSS)
            cssInputBox.setText(CssSkinManager.DEFAULT_GRAY_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为默认灰（纯色框架）！", Toast.LENGTH_SHORT).show()
        })
        presetRow.addView(makePresetBtn("莫奈花园") {
            cssInputBox.setText(CssSkinManager.MONET_WATER_LILY_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.MONET_WATER_LILY_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为莫奈花园专属皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow.addView(makePresetBtn("焦糖拿铁") {
            cssInputBox.setText(CssSkinManager.LATTE_MAILLARD_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.LATTE_MAILLARD_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为焦糖拿铁（纯色框架）！", Toast.LENGTH_SHORT).show()
        })
        presetRow.addView(makePresetBtn("薰衣草紫") {
            cssInputBox.setText(CssSkinManager.LAVENDER_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.LAVENDER_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为薰衣草紫（纯色框架）！", Toast.LENGTH_SHORT).show()
        })
        presetRow.addView(makePresetBtn("樱花粉") {
            cssInputBox.setText(CssSkinManager.SAKURA_PINK_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.SAKURA_PINK_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为樱花粉（纯色框架）！", Toast.LENGTH_SHORT).show()
        })
        presetRow.addView(makePresetBtn("暗夜黑") {
            cssInputBox.setText(CssSkinManager.DARK_MODE_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.DARK_MODE_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为暗夜黑（纯色框架）！", Toast.LENGTH_SHORT).show()
        })

        skinCard.addView(cssInputBox)
        skinCard.addView(codeHelperRow)
        skinCard.addView(skinBtnRow)
        skinCard.addView(presetRow)
        root.addView(skinCard)

        // 6. 常用语管理（无字数限制）
        val phraseCard = makeCard("6. 常用语与分类标签管理（无字数限制）")
        val categorySpinner = Spinner(this)
        fun refreshSpinner() {
            val cats = dbHelper.getCategories().filter { it != "最近" }
            categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
            val defaultCat = intent.getStringExtra("default_category")
            if (defaultCat != null) {
                val idx = cats.indexOf(defaultCat)
                if (idx >= 0) categorySpinner.setSelection(idx)
            }
        }
        refreshSpinner()
        phraseCard.addView(categorySpinner)

        val newCatInput = EditText(this).apply {
            hint = "输入新分类名（如：咒语 / 设定 / 常用）"
        }
        val catBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addCatBtn = Button(this).apply {
            text = "＋新增分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val name = newCatInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    dbHelper.addCategory(name)
                    newCatInput.setText("")
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已添加分类：$name", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val delCatBtn = Button(this).apply {
            text = "删除选中分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val sel = categorySpinner.selectedItem?.toString() ?: return@setOnClickListener
                if (sel == "收藏" || sel == "最近") {
                    Toast.makeText(this@SettingsActivity, "基础分类不可删除", Toast.LENGTH_SHORT).show()
                } else {
                    dbHelper.deleteCategory(sel)
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已删除分类：$sel", Toast.LENGTH_SHORT).show()
                }
            }
        }
        catBtnRow.addView(addCatBtn)
        catBtnRow.addView(delCatBtn)
        phraseCard.addView(newCatInput)
        phraseCard.addView(catBtnRow)

        val phraseInput = EditText(this).apply {
            hint = "在此粘贴或输入长篇常用语（无字数上限，支持 10000+ 字）..."
            minLines = 4
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
        }
        val starCheck = CheckBox(this).apply {
            text = "同时加入「收藏」星标置顶"
            isChecked = true
        }
        val savePhraseBtn = Button(this).apply {
            text = "保存常用语到选中分类"
            setOnClickListener {
                val cat = categorySpinner.selectedItem?.toString() ?: "演"
                val content = phraseInput.text.toString()
                if (content.isNotBlank()) {
                    dbHelper.addOrUpdatePhrase(null, cat, content, starCheck.isChecked)
                    phraseInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已保存至「$cat」（共 ${content.length} 字）", Toast.LENGTH_SHORT).show()
                }
            }
        }
        phraseCard.addView(phraseInput)
        phraseCard.addView(starCheck)
        phraseCard.addView(savePhraseBtn)
        root.addView(phraseCard)

        // 7. 词库扩展与已导入词库管理 (.scel / .txt)
        val dictCard = makeCard("7. 词库扩展与已导入词库管理（O(1) 哈希索引 · 导入再多也不卡）")
        val dictPerfNote = TextView(this).apply {
            text = "💡 速度与安全说明：所有导入的词库均在内存建立 O(1) 哈希表索引，导入数万词条耗时同样低于 0.1 毫秒，绝不拖慢打字速度；且本输入法在系统底层未申请任何联网权限（无 INTERNET 权限），所有词库与剪贴板 100% 物理隔离保存在手机本地。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#4B5563"))
            setPadding(0, 0, 0, dp(8))
        }
        dictCard.addView(dictPerfNote)

        val wordInput = EditText(this).apply {
            hint = "输入你想添加的新词（如：薅羊毛 / 芙莉莲 / 周杰伦）"
        }
        val codeInput = EditText(this).apply {
            hint = "86五笔编码（留空即可！系统会自动按 2+2 / 1+1+2 / 1+1+1+末1 规则生成）"
        }
        val addWordBtn = Button(this).apply {
            text = "＋添加到我的五笔词库"
            setOnClickListener {
                val w = wordInput.text.toString().trim()
                if (w.isEmpty()) return@setOnClickListener
                var wcode = codeInput.text.toString().trim().lowercase()
                if (wcode.isEmpty()) {
                    wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                }
                val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                if (wcode.isEmpty() && py.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请填写该词的五笔编码", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                dbHelper.insertUserWord(w, wcode, py, 8000, "手动添加")
                T14WubiEngine.reloadUserDict(dbHelper)
                wordInput.setText("")
                codeInput.setText("")
                refreshImportedDictListUI()
                Toast.makeText(this@SettingsActivity, "已添加词组「$w」(五笔码: $wcode)", Toast.LENGTH_SHORT).show()
            }
        }

        val importScelBtn = Button(this).apply {
            text = "📂 选择手机中的 .scel (搜狗细胞词库) 或 .txt 词表批量导入"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(intent, "选择 .scel 或 .txt 词库文件"), REQ_IMPORT_DICT)
            }
        }

        importDictStatusTv = TextView(this).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#D94336"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            visibility = android.view.View.GONE
        }

        val packListHeader = TextView(this).apply {
            text = "📚 已导入的词库与自定义词条记录（可随时单独删除）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(12), 0, dp(6))
        }

        importedDictListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        dictCard.addView(wordInput)
        dictCard.addView(codeInput)
        dictCard.addView(addWordBtn)
        dictCard.addView(importScelBtn)
        dictCard.addView(importDictStatusTv)
        dictCard.addView(packListHeader)
        dictCard.addView(importedDictListContainer)
        root.addView(dictCard)
        refreshImportedDictListUI()

        scroll.addView(root)
        setContentView(scroll)
        if (intent.getStringExtra("open_tab") == "enter_text") {
            enterTextInput.requestFocus()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return

        when (requestCode) {
            REQ_EXPORT_BACKUP -> {
                Thread {
                    try {
                        val json = dbHelper.exportBackupJson()
                        contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray(Charsets.UTF_8))
                        }
                        runOnUiThread {
                            Toast.makeText(this, "✅ 导出备份成功！", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_BACKUP -> {
                Thread {
                    try {
                        val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                        val (pCount, cCount) = dbHelper.importBackupJson(json)
                        runOnUiThread {
                            Toast.makeText(this, "✅ 成功导入 $pCount 条常用语与 $cCount 条剪贴板记录！", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导入失败：文件格式不正确", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_CSS -> {
                try {
                    val css = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                    if (css.isNotBlank()) {
                        cssInputBox.setText(css)
                        CssSkinManager.saveCustomCss(this, css)
                        Toast.makeText(this, "已成功导入并应用 .css 皮肤文件！", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "读取 CSS 文件失败", Toast.LENGTH_SHORT).show()
                }
            }
            REQ_PICK_BG_IMAGE -> {
                Thread {
                    try {
                        val rawBmp = contentResolver.openInputStream(uri)?.use { ins ->
                            BitmapFactory.decodeStream(ins)
                        }
                        if (rawBmp != null) {
                            val maxDim = 1280
                            val w = rawBmp.width
                            val h = rawBmp.height
                            val scaledBmp = if (w > maxDim || h > maxDim) {
                                val ratio = minOf(maxDim.toFloat() / w.toFloat(), maxDim.toFloat() / h.toFloat())
                                Bitmap.createScaledBitmap(
                                    rawBmp,
                                    (w * ratio).toInt().coerceAtLeast(1),
                                    (h * ratio).toInt().coerceAtLeast(1),
                                    true
                                )
                            } else {
                                rawBmp
                            }
                            val outFile = CustomBgManager.getBgFile(this)
                            FileOutputStream(outFile).use { fos ->
                                scaledBmp.compress(Bitmap.CompressFormat.PNG, 95, fos)
                            }
                            val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putLong("custom_bg_ts", System.currentTimeMillis()).apply()

                            // 若当前处于莫奈花园特殊皮肤，自动切换到纯色/自定义底图框架，使上传的背景图与毛玻璃按键立即生效
                            val curSkin = CssSkinManager.getSkin(this)
                            val switchedFromMonet = curSkin.waterLilyDecor
                            if (switchedFromMonet) {
                                CssSkinManager.saveCustomCss(this, CssSkinManager.SAMPLE_COMMENTED_CSS)
                            }

                            runOnUiThread {
                                if (switchedFromMonet) {
                                    cssInputBox.setText(CssSkinManager.SAMPLE_COMMENTED_CSS)
                                }
                                customBgStatusTv.text = "当前底图状态：已启用自定义背景图（纯色框架下按键已开启半透明毛玻璃）"
                                Toast.makeText(
                                    this,
                                    "自定义背景图已上传生效！已自动应用 cover 铺满并开启按键毛玻璃效果",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            runOnUiThread {
                                Toast.makeText(this, "无法解析所选图片，请换一张图片重试", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "上传背景图失败：${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_DICT -> {
                val fileName = resolveFileName(uri)
                importDictStatusTv.visibility = android.view.View.VISIBLE
                importDictStatusTv.text = "⏳ 正在解析「$fileName」并生成 86 五笔哈希索引，请稍候..."
                Thread {
                    var importedCount = 0
                    try {
                        val lowerName = fileName.lowercase()
                        val path = uri.toString().lowercase()
                        val isScel = lowerName.endsWith(".scel") || path.endsWith(".scel")
                        val batchList = ArrayList<Triple<String, String, String>>(4096)
                        contentResolver.openInputStream(uri)?.use { ins ->
                            if (isScel) {
                                val words = T14WubiEngine.parseSogouScel(ins)
                                for (w in words) {
                                    val wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                                    val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                                    if (wcode.isNotEmpty() || py.isNotEmpty()) {
                                        batchList.add(Triple(w, wcode, py))
                                    }
                                }
                            } else {
                                val reader = BufferedReader(InputStreamReader(ins, Charsets.UTF_8))
                                val seenInFile = HashSet<String>()
                                reader.forEachLine { line ->
                                    val clean = line.trim()
                                    if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                                    val parts = clean.split(Regex("[\\s,]+"))
                                    val w = parts[0]
                                    if (w.isNotEmpty() && seenInFile.add(w)) {
                                        val wcode = if (parts.size >= 2 && parts[1].all { it.isLetter() }) {
                                            parts[1].lowercase()
                                        } else {
                                            T14WubiEngine.generateWubi86CodeForWord(w)
                                        }
                                        val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                                        if (wcode.isNotEmpty() || py.isNotEmpty()) {
                                            batchList.add(Triple(w, wcode, py))
                                        }
                                    }
                                }
                            }
                        }
                        if (batchList.isNotEmpty()) {
                            importedCount = dbHelper.importDictionaryBatch(fileName, batchList, 5000)
                            T14WubiEngine.reloadUserDict(dbHelper)
                        }
                    } catch (_: Exception) {}
                    runOnUiThread {
                        if (importedCount > 0) {
                            importDictStatusTv.text = "✅ 已成功导入「$fileName」($importedCount 词)，已加入下方列表！"
                            Toast.makeText(this, "成功导入「$fileName」共 $importedCount 条词组！", Toast.LENGTH_LONG).show()
                        } else {
                            importDictStatusTv.text = "⚠️ 未能从「$fileName」解析出词条，请确认文件为未加密的搜狗 .scel 或 UTF-8 .txt 格式"
                            Toast.makeText(this, "未解析出有效词条，请检查文件格式", Toast.LENGTH_LONG).show()
                        }
                        refreshImportedDictListUI()
                    }
                }.start()
            }
        }
    }

    private fun resolveFileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) {
                    val name = c.getString(idx)?.trim()
                    if (!name.isNullOrEmpty()) return name
                }
            }
        } catch (_: Exception) {}
        val seg = uri.lastPathSegment ?: "导入词库.scel"
        return seg.substringAfterLast('/').substringAfterLast(':').ifEmpty { "导入词库.scel" }
    }

    private fun refreshImportedDictListUI() {
        if (!::importedDictListContainer.isInitialized) return
        importedDictListContainer.removeAllViews()
        val packs = dbHelper.getImportedDictPacks()
        if (packs.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "当前暂无已导入的外部词库（在上方选择 .scel 或 .txt 导入后，会在此处显示词库名、词条数量与删除按钮）"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setTextColor(Color.parseColor("#888888"))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.parseColor("#F7F8FC"))
            }
            importedDictListContainer.addView(emptyTv)
            return
        }

        val totalWords = packs.sumOf { it.wordCount }
        val summaryTv = TextView(this).apply {
            text = "目前已挂载 ${packs.size} 个扩展词库来源，共 $totalWords 条词组（已建立 O(1) 内存哈希索引）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#4B5563"))
            setPadding(0, 0, 0, dp(6))
        }
        importedDictListContainer.addView(summaryTv)

        val sdf = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        for (pack in packs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#F3F4F8"))
                setPadding(dp(12), dp(8), dp(10), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(6)
                layoutParams = lp
            }

            val timeStr = if (pack.importedAt > 0L) " · ${sdf.format(Date(pack.importedAt))}" else ""
            val infoTv = TextView(this).apply {
                text = "📦 ${pack.packName}\n共 ${pack.wordCount} 词$timeStr"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(Color.parseColor("#222428"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val delBtn = Button(this).apply {
                text = "🗑 删除"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Color.parseColor("#D94336"))
                setOnClickListener {
                    val removed = dbHelper.deleteDictionaryPack(pack.packName)
                    Thread { T14WubiEngine.reloadUserDict(dbHelper) }.start()
                    Toast.makeText(this@SettingsActivity, "已删除「${pack.packName}」（共移除 $removed 词）！", Toast.LENGTH_SHORT).show()
                    refreshImportedDictListUI()
                }
            }

            row.addView(infoTv)
            row.addView(delBtn)
            importedDictListContainer.addView(row)
        }

        if (packs.size >= 2 || totalWords > 100) {
            val clearAllBtn = Button(this).apply {
                text = "🗑 一键清空全部已导入扩展词库（不影响内置 86 五笔词库）"
                setTextColor(Color.parseColor("#D94336"))
                setOnClickListener {
                    val removed = dbHelper.clearAllUserDict()
                    Thread { T14WubiEngine.reloadUserDict(dbHelper) }.start()
                    Toast.makeText(this@SettingsActivity, "已清空全部扩展词库（共移除 $removed 词）！", Toast.LENGTH_SHORT).show()
                    refreshImportedDictListUI()
                }
            }
            importedDictListContainer.addView(clearAllBtn)
        }
    }

    private fun makeCard(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(16)
            layoutParams = lp

            val tv = TextView(this@SettingsActivity).apply {
                text = title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#2A3042"))
                setPadding(0, 0, 0, dp(10))
            }
            addView(tv)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
