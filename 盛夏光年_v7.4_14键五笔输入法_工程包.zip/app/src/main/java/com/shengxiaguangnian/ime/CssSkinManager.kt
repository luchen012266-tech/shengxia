package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class KeyStyleOverride(
    val bgTop: Int? = null,
    val bgBottom: Int? = null,
    val pressedBg: Int? = null,
    val borderColor: Int? = null,
    val borderWidthDp: Int? = null,
    val textColor: Int? = null,
    val hintColor: Int? = null
) {
    fun mergeWith(higher: KeyStyleOverride?): KeyStyleOverride {
        if (higher == null) return this
        return KeyStyleOverride(
            bgTop = higher.bgTop ?: this.bgTop,
            bgBottom = higher.bgBottom ?: this.bgBottom,
            pressedBg = higher.pressedBg ?: this.pressedBg,
            borderColor = higher.borderColor ?: this.borderColor,
            borderWidthDp = higher.borderWidthDp ?: this.borderWidthDp,
            textColor = higher.textColor ?: this.textColor,
            hintColor = higher.hintColor ?: this.hintColor
        )
    }
}

data class SkinConfig(
    // 默认即为示例图 (1000127657_9f2a64.jpg) 的「默认极简灰白」配色与无边框纯净质感
    val kbBgTop: Int = Color.parseColor("#E6E7EB"),
    val kbBgBottom: Int = Color.parseColor("#E6E7EB"),

    val topBarBgTop: Int = Color.parseColor("#F3F4F6"),
    val topBarBgBottom: Int = Color.parseColor("#F3F4F6"),
    val topBarBorder: Int = Color.parseColor("#F3F4F6"),
    val topBarBorderWidthDp: Int = 0,
    val topBarText: Int = Color.parseColor("#33363C"),
    val topBarDivider: Int = Color.parseColor("#D5D8E0"),
    val showTopDivider: Boolean = false,
    val topBarRadiusDp: Int = 16,

    val keyBgTop: Int = Color.parseColor("#FFFFFF"),
    val keyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val keyPressedBg: Int = Color.parseColor("#ECEEF2"),
    val keyBorder: Int = Color.parseColor("#FFFFFF"),
    val keyBorderWidthDp: Int = 0,
    val keyText: Int = Color.parseColor("#222428"),
    val keyHint: Int = Color.parseColor("#B0B4BE"),
    val keyRadiusDp: Int = 12,
    val keyGapDp: Int = 3,
    val keyElevationDp: Int = 1,
    val cssFontScale: Float? = null,

    val funcKeyBgTop: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBgBottom: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBorder: Int = Color.parseColor("#F5F6F8"),
    val funcKeyBorderWidthDp: Int? = null,
    val funcKeyText: Int = Color.parseColor("#33363C"),

    val punctKeyBgTop: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBgBottom: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBorder: Int = Color.parseColor("#FFFFFF"),
    val punctKeyBorderWidthDp: Int? = null,
    val punctKeyText: Int? = null,
    val punctKeyHint: Int? = null,

    val candidateText: Int = Color.parseColor("#1E2024"),
    val candidateHighlight: Int = Color.parseColor("#D94336"),

    val spaceText: String = "空格",
    val enterText: String = "盛夏\n光年",
    val waterLilyDecor: Boolean = false,
    val topLilyAlpha: Int = 108,
    val keyGlowEnabled: Boolean = true,
    val keyGlowColor: Int? = null,

    // 按排独立配色 (1=第一排, 2=第二排, 3=第三排, 4=第四排)
    val rowOverrides: Map<Int, KeyStyleOverride> = emptyMap(),
    // 按单个按键或分组独立配色 (如 "qw", "er", "q", "vowel", "space", "enter", "comma", "period", "backspace", "wildcard", "sym", "num", "lang")
    val keyOverrides: Map<String, KeyStyleOverride> = emptyMap()
) {
    fun resolveKeyStyle(
        rowIndex: Int,
        keyId: String,
        isFuncKey: Boolean = false,
        isPunctKey: Boolean = false,
        lettersOnKey: String = ""
    ): KeyStyleOverride {
        val base = when {
            isPunctKey -> KeyStyleOverride(
                bgTop = punctKeyBgTop,
                bgBottom = punctKeyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = punctKeyBorder,
                borderWidthDp = punctKeyBorderWidthDp ?: keyBorderWidthDp,
                textColor = punctKeyText ?: keyText,
                hintColor = punctKeyHint ?: punctKeyText ?: keyHint
            )
            isFuncKey -> KeyStyleOverride(
                bgTop = funcKeyBgTop,
                bgBottom = funcKeyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = funcKeyBorder,
                borderWidthDp = funcKeyBorderWidthDp ?: keyBorderWidthDp,
                textColor = funcKeyText,
                hintColor = keyHint
            )
            else -> KeyStyleOverride(
                bgTop = keyBgTop,
                bgBottom = keyBgBottom,
                pressedBg = keyPressedBg,
                borderColor = keyBorder,
                borderWidthDp = keyBorderWidthDp,
                textColor = keyText,
                hintColor = keyHint
            )
        }

        // 1. 先叠加「按排配色」（默认作用于字母键，或者第4排未单独指定的功能键）
        var resolved = if (!isFuncKey && !isPunctKey) {
            base.mergeWith(rowOverrides[rowIndex])
        } else {
            base
        }

        // 2. 如果配置了 .key-vowel（元音键 A/E/I/O/U），且该按键包含元音字母，则叠加元音样式
        val lowerLetters = lettersOnKey.lowercase()
        if (lowerLetters.any { it in "aeiou" }) {
            resolved = resolved.mergeWith(keyOverrides["vowel"])
        }

        // 3. 如果在 26 键模式下按键是单字母（如 t 或 y），自动关联对应 14 键双字母组的配色（如 .key-ty -> t, y；.key-bn -> b, n）
        val cleanId = keyId.lowercase()
        if (cleanId.length == 1) {
            val parentDual = when (cleanId) {
                "q", "w" -> "qw"
                "e", "r" -> "er"
                "t", "y" -> "ty"
                "u", "i" -> "ui"
                "o", "p" -> "op"
                "a", "s" -> "as"
                "d", "f" -> "df"
                "g", "h" -> "gh"
                "j", "k" -> "jk"
                "z", "x" -> "zx"
                "c", "v" -> "cv"
                "b", "n" -> "bn"
                else -> null
            }
            if (parentDual != null) {
                resolved = resolved.mergeWith(keyOverrides[parentDual])
            }
        }

        // 4. 如果配置了单字母选择器（如 .key-q 或 [data-key="Q"]），匹配包含该字母的按键
        for (ch in lowerLetters) {
            resolved = resolved.mergeWith(keyOverrides[ch.toString()])
        }

        // 5. 最后叠加精确按键 ID 选择器（如 .key-qw、[data-key="QW"]、.key-space、.key-enter 等，优先级最高！）
        resolved = resolved.mergeWith(keyOverrides[cleanId])

        return resolved
    }
}

object CssSkinManager {

    const val SAMPLE_COMMENTED_CSS = """/* =========================================================
 * 盛夏光年 · 纯色与自定义底图毛玻璃 CSS 皮肤完整示例模板
 * 使用说明：直接修改下方的 #颜色代码，点击「应用上方 CSS 皮肤」即可生效！
 * 若在上方上传了自定义背景图，按键会自动变成半透明毛玻璃并模糊底图。
 * ========================================================= */

/* 1. 键盘整体背景（若已上传自定义背景图，则自动以 cover 模式铺满底图） */
.keyboard-bg {
  background: #EAECEF;
}

/* 2. 顶部状态栏与候选词栏 */
.top-bar {
  background: #F7F8FA;      /* 顶栏背景色 */
  border-width: 1px;        /* 顶栏边框粗细 */
  border-color: #FFFFFF;    /* 顶栏边框颜色 */
  border-radius: 20px;      /* 顶栏圆角大小 */
  color: #3A4659;           /* 顶栏图标与状态文字颜色 */
  divider: show;            /* 是否显示分隔竖线：show 或 none */
  divider-color: #D0D7E2;   /* 分隔竖线颜色 */
}

/* 3. 普通字母按键默认样式（光晕会自动取按键底色并加深 20%-30%） */
.key {
  background: #FFFFFF;      /* 按键默认底色 */
  border-width: 1px;        /* 按键边框粗细 */
  border-color: #F0F2F5;    /* 按键边框颜色 */
  border-radius: 14px;      /* 按键圆角大小 */
  key-gap: 3px;             /* 按键之间的间距 */
  elevation: 1px;           /* 按键阴影高度 */
  color: #2C3545;           /* 按键主字母颜色 */
  hint-color: #9AA5B8;      /* 按键右上角符号/数字颜色 */
}

/* 4. 按键按下与背光光晕设置（不填 glow-color 时自动按底色加深 25%） */
.key:active {
  glow: on;                 /* 开启背光光晕：on 或 off */
}

/* 5. 按行独立配色示例（可按需修改第 1、2、3 排按键底色） */
.chat-keyboard-row:nth-child(1) .key {
  background: #DCE6F7;
  color: #2C3A52;
}
.chat-keyboard-row:nth-child(2) .key {
  background: #DFECE2;
  color: #2B3E30;
}
.chat-keyboard-row:nth-child(3) .key {
  background: #E8E2F4;
  color: #382E4E;
}

/* 6. 功能键样式（通配、退格、符、123、中/英、回车键） */
.key-func {
  background: #CFD8E6;
  color: #2C3A52;
}

/* 7. 底部逗号与句号键样式 */
.key-punct {
  background: #DCE6F7;
  color: #2C3A52;
}

/* 8. 指定单键独立配色示例（如 TY 键、空格键） */
.key-ty, .key-space {
  background: #F5DCE4 !important;
  color: #4A323B !important;
}

/* 9. 候选词文字颜色与第 1 候选词高亮色 */
.candidate-bar {
  color: #2C3545;           /* 普通候选词颜色 */
  highlight-color: #4A6FE3; /* 首选 1 号词高亮颜色 */
}"""

    const val DEFAULT_GRAY_CSS = """/* 盛夏光年 · 默认极简灰皮肤（清空 CSS 或点恢复默认即为此皮肤） */
.keyboard-bg {
  background: #E6E7EB;
}

.top-bar {
  background: #F3F4F6;
  border-width: 0px;
  border-radius: 16px;
  color: #33363C;
  divider: none;
}

.key {
  background: #FFFFFF;
  pressed-background: #ECEEF2;
  border-width: 0px;
  border-radius: 12px;
  key-gap: 3px;
  elevation: 1px;
  color: #222428;
  hint-color: #B0B4BE;
  space-text: 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #F5F6F8;
  color: #33363C;
}

.key-punct {
  background: #FFFFFF;
  border-width: 0px;
}

.candidate-bar {
  color: #1E2024;
  highlight-color: #D94336;
}"""

    const val MONET_WATER_LILY_CSS = """/* 盛夏光年 · 莫奈睡莲油画高定皮肤（1:1 还原效果图油画睡莲键帽纹理！） */
.keyboard-bg {
  background: #E4EDF7;
  decor: water-lily;
}

.top-bar {
  background: #F2F5FB;
  border-width: 1px;
  border-color: #FFFFFF;
  border-radius: 22px;
  color: #4D5E7C;
  divider: show;
  divider-color: #B6C6DC;
  lily-opacity: 42%;
}

.key {
  background: #9DB5E4;
  pressed-background: #88A2D6;
  border-width: 1px;
  border-color: #F4F8FF;
  border-radius: 15px;
  key-gap: 3px;
  elevation: 1px;
  color: #4D5E7C;
  hint-color: #F0F5FF;
}

/* 第一排：池水油画蓝（白字）+ TY 键睡莲花瓣粉（深蓝灰字） */
.chat-keyboard-row:nth-child(1) .key {
  background: #9DB5E4 !important;
  color: #FFFFFF !important;
  hint-color: #F0F5FF !important;
}
.key-ty, .key-t, .key-y {
  background: #EAD4DC !important;
  color: #4D5E7C !important;
  hint-color: #6B7E9E !important;
}

/* 第二排：莫奈浮水嫩荷叶油画绿（白字） */
.chat-keyboard-row:nth-child(2) .key {
  background: #A9C09A !important;
  color: #FFFFFF !important;
  hint-color: #F2F8EE !important;
}

/* 第三排：深池水油画蓝 + BN 键深苔藓荷叶绿 */
.chat-keyboard-row:nth-child(3) .key {
  background: #92ADE0 !important;
  color: #FFFFFF !important;
  hint-color: #EEF4FF !important;
}
.key-bn {
  background: #6D8A70 !important;
  color: #FFFFFF !important;
}

/* 功能键：深苔藓油画荷叶绿 */
.key-func {
  background: #6D8A70;
  color: #FFFFFF;
}

/* 逗号与句号：莫奈薰衣草池水蓝 + 白字 */
.key-punct {
  background: #9EAEE0;
  color: #FFFFFF;
  hint-color: #EEF4FF;
}

/* 空格键：盛开睡莲柔粉 + 油画小莲花图标 */
.key-space {
  background: #EAD4DC !important;
  color: #4D5E7C !important;
}

.candidate-bar {
  color: #3E4E68;
  highlight-color: #687FD4;
}"""

    const val LATTE_MAILLARD_CSS = """/* 盛夏光年 · 焦糖拿铁分层与单键混搭皮肤（支持按排、按元音、按单键独立上色！） */
.keyboard-bg {
  background: #F5EFEA;
}

.top-bar {
  background: #FDFBF9;
  border-width: 0px;
  border-radius: 18px;
  color: #4A3525;
  divider: none;
}

.key {
  background: #EFE3D5;
  pressed-background: #DEC8B0;
  border-width: 0px;
  border-radius: 13px;
  key-gap: 3px;
  elevation: 1px;
  color: #4A3328;
  hint-color: #9C7E68;
}

/* 第一排 (QW ER TY UI OP)：浅燕麦奶泡色 */
.chat-keyboard-row:nth-child(1) .key {
  background: #F4E9DC !important;
  color: #5C4033 !important;
}

/* 第二排 (AS DF GH JK L)：中等拿铁色 */
.chat-keyboard-row:nth-child(2) .key {
  background: #E5D0BE !important;
  color: #4A3328 !important;
}

/* 第三排 (ZX CV BN M)：醇厚焦糖色 */
.chat-keyboard-row:nth-child(3) .key {
  background: #D6B89D !important;
  color: #3A2318 !important;
}

/* 功能键：烤榛果暖棕 */
.key-func {
  background: #9E6B4B;
  color: #FFFFFF;
}

/* 逗号与句号键：深巧克力色 + 纯白符号文字 */
.key-punct {
  background: #5C4033;
  color: #FFFFFF;
  hint-color: #E5D0BE;
  border-width: 0px;
}

/* 空格键单独配色 */
.key-space {
  background: #E5D0BE !important;
  color: #4A3328 !important;
}

/* 候选词栏高亮色 */
.candidate-bar {
  color: #3A2E26;
  highlight-color: #D96C4A;
}

/* 💡 单键独立配色示例：想给任意单个键换色，直接写 .key-qw 或 [data-key="QW"] 即可！
.key-qw { background: #E8C5B0; color: #3A2318; }
.key-ui { background: #D96C4A; color: #FFFFFF; }
.key-vowel { background: #EDD5C5; }
*/"""

    const val LAVENDER_CSS = """/* 盛夏光年 · 薰衣草雾透皮肤 */
.keyboard-bg {
  background: linear-gradient(#DCE0F0, #E6E9F6);
}

.top-bar {
  background: linear-gradient(#F4F6FD, #E8ECF9);
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 22px;
  color: #454C66;
  divider: show;
  divider-color: #CBD2EA;
}

.key {
  background: linear-gradient(#FAFBFF, #EAEFF9);
  pressed-background: #DCE2F4;
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 15px;
  key-gap: 3px;
  elevation: 1px;
  color: #2A3042;
  hint-color: #7E87A6;
  space-text: 🌿 空格;
  enter-text: 盛夏\n光年✦;
}

.key-func {
  background: linear-gradient(#F1F4FC, #E2E7F5);
  border-color: #F8FAFF;
  color: #454C66;
}

.key-punct {
  background: linear-gradient(#F6F4FF, #E8E4FA);
  border-color: #DCD4F8;
}

.candidate-bar {
  color: #2A3042;
  highlight-color: #6C5CE7;
}"""

    const val SAKURA_PINK_CSS = """/* 盛夏光年 · 奶油樱花粉皮肤 */
.keyboard-bg {
  background: linear-gradient(#F9E8EE, #FCEFF3);
}

.top-bar {
  background: #FFF8FA;
  border-color: #FFFFFF;
  border-width: 1px;
  border-radius: 20px;
  color: #6D4C56;
  divider: none;
}

.key {
  background: #FFFFFF;
  pressed-background: #F5DCE4;
  border-color: #FFEBF0;
  border-width: 1px;
  border-radius: 14px;
  key-gap: 3px;
  elevation: 1px;
  color: #4A323A;
  hint-color: #C49AA7;
  space-text: 🌸 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #FDF2F5;
  color: #6D4C56;
}

.key-punct {
  background: #FFF5F8;
  border-color: #F8D0DC;
}

.candidate-bar {
  color: #4A323A;
  highlight-color: #E84393;
}"""

    const val DARK_MODE_CSS = """/* 盛夏光年 · 暗夜极客黑皮肤 */
.keyboard-bg {
  background: #18191C;
}

.top-bar {
  background: #23252A;
  border-width: 0px;
  border-radius: 16px;
  color: #D8DAE0;
  divider: none;
}

.key {
  background: #2C2E35;
  pressed-background: #3E414B;
  border-width: 0px;
  border-radius: 11px;
  key-gap: 3px;
  elevation: 0px;
  color: #ECEEF4;
  hint-color: #767B89;
  space-text: 空格;
  enter-text: 盛夏\n光年;
}

.key-func {
  background: #22242A;
  color: #B4B8C5;
}

.key-punct {
  background: #2C2E35;
  border-width: 0px;
}

.candidate-bar {
  color: #ECEEF4;
  highlight-color: #FF6B6B;
}"""

    private var cachedSkin: SkinConfig? = null

    fun getSkin(context: Context): SkinConfig {
        cachedSkin?.let { return it }
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val css = prefs.getString("custom_skin_css", "") ?: ""
        val skin = if (css.isBlank()) SkinConfig() else parseCss(css)
        cachedSkin = skin
        return skin
    }

    fun saveCustomCss(context: Context, css: String) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val trimmed = css.trim()
        prefs.edit().putString("custom_skin_css", trimmed).apply()
        val parsed = if (trimmed.isBlank()) SkinConfig() else parseCss(trimmed)
        parsed.cssFontScale?.let { scale ->
            prefs.edit().putFloat("key_font_scale", scale.coerceIn(0.45f, 1.5f)).apply()
        }
        cachedSkin = null
    }

    fun resetToDefaultSkin(context: Context) {
        saveCustomCss(context, "")
    }

    fun getSavedCss(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_skin_css", "") ?: ""
        return saved.ifBlank { DEFAULT_GRAY_CSS }
    }

    private fun stripImportant(raw: String): String {
        return raw.replace(Regex("!\\s*important", RegexOption.IGNORE_CASE), "")
            .trim()
            .removeSuffix(";")
            .trim()
    }

    private fun parseColorSafe(raw: String, fallback: Int): Int {
        return try {
            val clean = stripImportant(raw)
            val hex = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value ?: clean
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun parseColorNullable(raw: String): Int? {
        return try {
            val clean = stripImportant(raw)
            val hex = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value ?: clean
            Color.parseColor(hex)
        } catch (_: Exception) {
            null
        }
    }

    private fun parsePxInt(raw: String, minVal: Int, maxVal: Int): Int? {
        val clean = stripImportant(raw).lowercase().removeSuffix("px").removeSuffix("dp").trim()
        val n = clean.toIntOrNull()
        return n?.coerceIn(minVal, maxVal)
    }

    private fun parseGradientOrSolid(raw: String, defaultTop: Int, defaultBottom: Int): Pair<Int, Int> {
        val clean = stripImportant(raw)
        if (clean.startsWith("linear-gradient", ignoreCase = true)) {
            val inside = clean.substringAfter("(").substringBeforeLast(")")
            val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
            if (hexes.size >= 2) {
                return parseColorSafe(hexes[0], defaultTop) to parseColorSafe(hexes[1], defaultBottom)
            } else if (hexes.size == 1) {
                val c = parseColorSafe(hexes[0], defaultTop)
                return c to c
            }
        }
        val hexMatch = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value
        if (hexMatch != null) {
            val c = parseColorSafe(hexMatch, defaultTop)
            return c to c
        }
        return defaultTop to defaultBottom
    }

    private fun parseKeyStyleOverride(props: Map<String, String>, existing: KeyStyleOverride?): KeyStyleOverride {
        var bgT: Int? = existing?.bgTop
        var bgB: Int? = existing?.bgBottom
        props["background"]?.let { raw ->
            val clean = stripImportant(raw)
            if (clean.startsWith("linear-gradient", ignoreCase = true)) {
                val inside = clean.substringAfter("(").substringBeforeLast(")")
                val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
                if (hexes.size >= 2) {
                    bgT = parseColorNullable(hexes[0]) ?: bgT
                    bgB = parseColorNullable(hexes[1]) ?: bgB
                } else if (hexes.size == 1) {
                    val c = parseColorNullable(hexes[0])
                    if (c != null) { bgT = c; bgB = c }
                }
            } else {
                val c = parseColorNullable(clean)
                if (c != null) { bgT = c; bgB = c }
            }
        }
        props["background-color"]?.let { raw ->
            val c = parseColorNullable(raw)
            if (c != null) { bgT = c; bgB = c }
        }
        val pBg = props["pressed-background"]?.let { parseColorNullable(it) } ?: existing?.pressedBg
        val bCol = props["border-color"]?.let { parseColorNullable(it) } ?: existing?.borderColor
        val bWidth = props["border-width"]?.let { parsePxInt(it, 0, 6) }
            ?: (if (props.containsKey("border-color") && existing?.borderWidthDp == null) 1 else existing?.borderWidthDp)
        val tCol = props["color"]?.let { parseColorNullable(it) } ?: existing?.textColor
        val hCol = props["hint-color"]?.let { parseColorNullable(it) } ?: existing?.hintColor

        return KeyStyleOverride(
            bgTop = bgT,
            bgBottom = bgB,
            pressedBg = pBg,
            borderColor = bCol,
            borderWidthDp = bWidth,
            textColor = tCol,
            hintColor = hCol
        )
    }

    private fun normalizeKeyAlias(rawKey: String): String {
        return when (rawKey.trim().lowercase()) {
            "通配", "wildcard" -> "wildcard"
            "退格", "删除", "⌫", "backspace", "del", "delete" -> "backspace"
            "符", "符号", "sym", "symbol", "symbols" -> "sym"
            "123", "num", "number" -> "num"
            "，", ",", "comma", "逗号" -> "comma"
            "空格", "space", "spacebar" -> "space"
            "。", ".", "period", "dot", "句号" -> "period"
            "中/英", "英/中", "lang", "mode", "switch" -> "lang"
            "回车", "发送", "盛夏光年", "enter", "return" -> "enter"
            "vowel", "vowels", "元音" -> "vowel"
            else -> rawKey.trim().lowercase().replace(" ", "")
        }
    }

    fun parseCss(css: String): SkinConfig {
        var cfg = SkinConfig()
        val rowMap = HashMap<Int, KeyStyleOverride>()
        val keyMap = HashMap<String, KeyStyleOverride>()

        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("([^{]+)\\{([^}]*)\\}")

        for (match in blockRegex.findAll(noComments)) {
            val rawSelectorGroup = match.groupValues[1].trim()
            val body = match.groupValues[2]
            val props = HashMap<String, String>()
            body.split(";").forEach { line ->
                val colon = line.indexOf(':')
                if (colon > 0) {
                    val k = line.substring(0, colon).trim().lowercase()
                    val v = line.substring(colon + 1).trim()
                    if (k.isNotEmpty() && v.isNotEmpty()) props[k] = v
                }
            }
            if (props.isEmpty()) continue

            // 支持逗号分隔并列选择器（如 .key-qw, .key-er, [data-key="TY"] { ... }）
            val selectors = rawSelectorGroup.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            for (sel in selectors) {
                val lowerSel = sel.lowercase()

                // 1. 检查是否为「按排选择器」：
                // 支持 .row-1 / .row-1 .key / .chat-keyboard-row:nth-child(1) .key / .keyboard-row:nth-child(1) / [data-row="1"]
                val nthMatch = Regex("nth-child\\(\\s*(\\d+)\\s*\\)").find(lowerSel)
                val dataRowMatch = Regex("data-row\\s*=\\s*['\"]?(\\d+)['\"]?").find(lowerSel)
                val dotRowMatch = Regex("\\.row-(\\d+)").find(lowerSel)
                val rowNum = (nthMatch?.groupValues?.get(1)
                    ?: dataRowMatch?.groupValues?.get(1)
                    ?: dotRowMatch?.groupValues?.get(1))?.toIntOrNull()

                if (rowNum != null && rowNum in 1..4) {
                    rowMap[rowNum] = parseKeyStyleOverride(props, rowMap[rowNum])
                    continue
                }

                // 2. 检查是否为「data-key 属性选择器」：如 [data-key="QW"] 或 .key[data-key="Q"]
                val dataKeyMatch = Regex("data-key\\s*=\\s*['\"]?([^'\"\\]]+)['\"]?").find(sel)
                if (dataKeyMatch != null) {
                    val kId = normalizeKeyAlias(dataKeyMatch.groupValues[1])
                    keyMap[kId] = parseKeyStyleOverride(props, keyMap[kId])
                    continue
                }

                // 3. 标准基础选择器与 .key-xxx 单键选择器
                when (lowerSel) {
                    ".keyboard-bg", "body", ".keyboard" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.kbBgTop, cfg.kbBgBottom)
                            cfg = cfg.copy(kbBgTop = t, kbBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.kbBgTop)
                            cfg = cfg.copy(kbBgTop = c, kbBgBottom = c)
                        }
                    }
                    ".top-bar" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.topBarBgTop, cfg.topBarBgBottom)
                            cfg = cfg.copy(topBarBgTop = t, topBarBgBottom = b)
                        }
                        props["border-color"]?.let {
                            cfg = cfg.copy(topBarBorder = parseColorSafe(it, cfg.topBarBorder), topBarBorderWidthDp = 1)
                        }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(topBarBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(topBarText = parseColorSafe(it, cfg.topBarText)) }
                        props["divider-color"]?.let { cfg = cfg.copy(topBarDivider = parseColorSafe(it, cfg.topBarDivider)) }
                        props["divider"]?.let {
                            cfg = cfg.copy(showTopDivider = !stripImportant(it).equals("none", ignoreCase = true))
                        }
                        props["border-radius"]?.let {
                            parsePxInt(it, 0, 32)?.let { r -> cfg = cfg.copy(topBarRadiusDp = r) }
                        }
                    (props["lily-opacity"] ?: props["opacity"])?.let {
                        val pct = stripImportant(it).removeSuffix("%").trim().toFloatOrNull()
                        if (pct != null) {
                            val ratio = if (pct > 1.0f) (pct / 100f) else pct
                            cfg = cfg.copy(topLilyAlpha = (ratio * 255f).toInt().coerceIn(20, 255))
                        }
                    }
                    }
                    ".key" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.keyBgTop, cfg.keyBgBottom)
                            cfg = cfg.copy(keyBgTop = t, keyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.keyBgTop)
                            cfg = cfg.copy(keyBgTop = c, keyBgBottom = c)
                        }
                        props["pressed-background"]?.let { cfg = cfg.copy(keyPressedBg = parseColorSafe(it, cfg.keyPressedBg)) }
                        props["border-color"]?.let {
                            cfg = cfg.copy(keyBorder = parseColorSafe(it, cfg.keyBorder), keyBorderWidthDp = 1)
                        }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(keyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(keyText = parseColorSafe(it, cfg.keyText)) }
                        props["hint-color"]?.let { cfg = cfg.copy(keyHint = parseColorSafe(it, cfg.keyHint)) }
                        props["border-radius"]?.let {
                            parsePxInt(it, 0, 28)?.let { r -> cfg = cfg.copy(keyRadiusDp = r) }
                        }
                        props["key-gap"]?.let {
                            parsePxInt(it, 1, 10)?.let { g -> cfg = cfg.copy(keyGapDp = g) }
                        }
                        props["elevation"]?.let {
                            parsePxInt(it, 0, 8)?.let { el -> cfg = cfg.copy(keyElevationDp = el) }
                        }
                        props["font-scale"]?.let {
                            val pct = stripImportant(it).removeSuffix("%").trim().toFloatOrNull()
                            if (pct != null) {
                                val sc = if (pct > 3f) pct / 100f else pct
                                cfg = cfg.copy(cssFontScale = sc.coerceIn(0.45f, 1.5f))
                            }
                        }
                        props["space-text"]?.let { cfg = cfg.copy(spaceText = stripImportant(it).replace("\\n", "\n")) }
                        props["enter-text"]?.let { cfg = cfg.copy(enterText = stripImportant(it).replace("\\n", "\n")) }
                        props["glow"]?.let {
                            cfg = cfg.copy(keyGlowEnabled = !stripImportant(it).equals("none", ignoreCase = true))
                        }
                        props["glow-color"]?.let {
                            cfg = cfg.copy(keyGlowColor = parseColorNullable(it))
                        }
                    }
                    ".key-func" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.funcKeyBgTop, cfg.funcKeyBgBottom)
                            cfg = cfg.copy(funcKeyBgTop = t, funcKeyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.funcKeyBgTop)
                            cfg = cfg.copy(funcKeyBgTop = c, funcKeyBgBottom = c)
                        }
                        props["border-color"]?.let { cfg = cfg.copy(funcKeyBorder = parseColorSafe(it, cfg.funcKeyBorder)) }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(funcKeyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(funcKeyText = parseColorSafe(it, cfg.funcKeyText)) }
                    }
                    ".key-punct" -> {
                        props["background"]?.let {
                            val (t, b) = parseGradientOrSolid(it, cfg.punctKeyBgTop, cfg.punctKeyBgBottom)
                            cfg = cfg.copy(punctKeyBgTop = t, punctKeyBgBottom = b)
                        }
                        props["background-color"]?.let {
                            val c = parseColorSafe(it, cfg.punctKeyBgTop)
                            cfg = cfg.copy(punctKeyBgTop = c, punctKeyBgBottom = c)
                        }
                        props["border-color"]?.let { cfg = cfg.copy(punctKeyBorder = parseColorSafe(it, cfg.punctKeyBorder)) }
                        props["border-width"]?.let {
                            parsePxInt(it, 0, 6)?.let { w -> cfg = cfg.copy(punctKeyBorderWidthDp = w) }
                        }
                        props["color"]?.let { cfg = cfg.copy(punctKeyText = parseColorSafe(it, cfg.keyText)) }
                        props["hint-color"]?.let { cfg = cfg.copy(punctKeyHint = parseColorSafe(it, cfg.keyHint)) }
                    }
                    ".candidate-bar" -> {
                        props["color"]?.let { cfg = cfg.copy(candidateText = parseColorSafe(it, cfg.candidateText)) }
                        props["highlight-color"]?.let { cfg = cfg.copy(candidateHighlight = parseColorSafe(it, cfg.candidateHighlight)) }
                    }
                    else -> {
                        // 匹配 .key-xxx 或 #key-xxx 单键选择器（如 .key-qw, .key-q, .key-space, .key-enter, .key-vowel 等）
                        val keyClassMatch = Regex("[.#]key-([a-zA-Z0-9_\\u4e00-\\u9fa5]+)").find(lowerSel)
                        if (keyClassMatch != null) {
                            val kId = normalizeKeyAlias(keyClassMatch.groupValues[1])
                            keyMap[kId] = parseKeyStyleOverride(props, keyMap[kId])
                        }
                    }
                }
            }
        }
        val lowerAll = noComments.lowercase()
        val hasWaterLilySignal = lowerAll.contains("water-lily") ||
            lowerAll.contains("lotus") ||
            lowerAll.contains("睡莲") ||
            (lowerAll.contains("#e2c9cd") && lowerAll.contains("#a6bf86")) ||
            (lowerAll.contains("#a4b9e6") && lowerAll.contains("#a6bf86"))
        return cfg.copy(
            waterLilyDecor = cfg.waterLilyDecor || hasWaterLilySignal,
            rowOverrides = rowMap,
            keyOverrides = keyMap
        )
    }

    fun makeGradientDrawable(
        topColor: Int,
        bottomColor: Int,
        radiusPx: Int,
        strokeColor: Int? = null,
        strokeWidthPx: Int = 0
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topColor, bottomColor)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            if (strokeColor != null && strokeWidthPx > 0) {
                setStroke(strokeWidthPx, strokeColor)
            }
        }
    }
}
