package com.shengxiaguangnian.ime

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicInteger
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

data class Candidate(
    val word: String,
    val wubiHint: String?,
    val displayCode: String,
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val t14PyAbbr: String,
    val weight: Int,
    val cleanPinyin: String = segmentedPinyin.replace("'", "").lowercase(),
    val py26Abbr: String = "",
    val t9Pinyin: String = "",
    val t9PyAbbr: String = ""
)

data class StrokePoint(val x: Float, val y: Float, val t: Long = 0L)

object T14WubiEngine {
    // 中文键盘样式枚举常量（9键拼音 / 14键拼音 / 26键拼音 / 独立星光手写板 / 键盘内嵌按住说话语音 / 14键五笔混输）
    const val LAYOUT_PINYIN_9 = "pinyin_9"
    const val LAYOUT_PINYIN_14 = "pinyin_14"
    const val LAYOUT_PINYIN_26 = "pinyin_26"
    const val LAYOUT_HANDWRITING = "handwriting"
    const val LAYOUT_VOICE = "voice"
    const val LAYOUT_WUBI_14 = "wubi_14"

    fun getChineseLayoutMode(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("cn_keyboard_layout_mode", LAYOUT_PINYIN_9) ?: LAYOUT_PINYIN_9
    }

    fun setChineseLayoutMode(context: Context, mode: String) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val prevNonVoice = prefs.getString("cn_keyboard_layout_mode", LAYOUT_PINYIN_9) ?: LAYOUT_PINYIN_9
        val editor = prefs.edit().putString("cn_keyboard_layout_mode", mode)
        if (mode != LAYOUT_VOICE) {
            editor.putString("cn_last_non_voice_layout", mode)
        } else if (prevNonVoice != LAYOUT_VOICE) {
            editor.putString("cn_last_non_voice_layout", prevNonVoice)
        }
        editor.apply()
    }

    fun getLastNonVoiceLayoutMode(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val last = prefs.getString("cn_last_non_voice_layout", LAYOUT_PINYIN_9) ?: LAYOUT_PINYIN_9
        return if (last == LAYOUT_VOICE) LAYOUT_PINYIN_9 else last
    }

    fun getLayoutShortBadge(mode: String): String {
        return when (mode) {
            LAYOUT_PINYIN_9 -> "9键"
            LAYOUT_PINYIN_14 -> "14键"
            LAYOUT_PINYIN_26 -> "26键"
            LAYOUT_HANDWRITING -> "手写"
            LAYOUT_VOICE -> "语音"
            LAYOUT_WUBI_14 -> "五笔"
            else -> "9键"
        }
    }

    fun getLayoutDisplayName(mode: String): String {
        return when (mode) {
            LAYOUT_PINYIN_9 -> "9键拼音（T9九宫格）"
            LAYOUT_PINYIN_14 -> "14键拼音（双字母布局）"
            LAYOUT_PINYIN_26 -> "26键拼音（全键盘）"
            LAYOUT_HANDWRITING -> "星光手写板"
            LAYOUT_VOICE -> "按住说话语音"
            LAYOUT_WUBI_14 -> "14键五笔拼音混输"
            else -> "9键拼音"
        }
    }

    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    private val CHAR_TO_T9 = mapOf(
        'a' to '2', 'b' to '2', 'c' to '2',
        'd' to '3', 'e' to '3', 'f' to '3',
        'g' to '4', 'h' to '4', 'i' to '4',
        'j' to '5', 'k' to '5', 'l' to '5',
        'm' to '6', 'n' to '6', 'o' to '6',
        'p' to '7', 'q' to '7', 'r' to '7', 's' to '7',
        't' to '8', 'u' to '8', 'v' to '8',
        'w' to '9', 'x' to '9', 'y' to '9', 'z' to '9'
    )

    private val T9_CODE_TO_LETTER = mapOf(
        '2' to "a", '3' to "d", '4' to "g", '5' to "j",
        '6' to "m", '7' to "p", '8' to "t", '9' to "w"
    )

    // 将内部 14 键编码还原为纯字母（彻底杜绝 8'7'nv 或 9 等数字出现在左上角浮窗！）
    private val T14_CODE_TO_LETTER = mapOf(
        '1' to "q", '2' to "e", '3' to "t", '4' to "u", '5' to "o",
        '6' to "a", '7' to "d", '8' to "g", '9' to "j", '0' to "l",
        'a' to "z", 'b' to "c", 'c' to "n", 'd' to "m"
    )

    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "dun", "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )
    private val VALID_SYLLABLE_SET = VALID_SYLLABLES.toHashSet()

    private val wubiExactIndex = HashMap<String, MutableList<DictEntry>>(20000)
    private val wubiPrefixIndex = HashMap<String, MutableList<DictEntry>>(8000)
    private val pinyinExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val pinyinPrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val pinyinAbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)

    // 26 键中文拼音专属哈希索引（全拼精确、全拼前缀、简拼首字母、单字音节表）
    private val py26ExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val py26PrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val py26AbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)
    private val py26SingleCharBySyl = HashMap<String, MutableList<DictEntry>>(450)

    // 9 键 T9 拼音专属哈希索引（T9全拼精确、T9前缀、T9简拼、T9音节映射表）
    private val t9ExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val t9PrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val t9AbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)
    private val t9SyllableListMap = LinkedHashMap<String, MutableList<String>>()
    private val t9SingleCharByCode = HashMap<String, MutableList<DictEntry>>(450)

    // 26 键英文单词前缀索引（支持词频权重与个人高频动态提权，容量扩大至每前缀 250 词）
    private val englishPrefixIndex = HashMap<String, MutableList<Pair<String, Int>>>(12000)
    private val englishExactSet = HashSet<String>(25000)

    private val t14SyllableMap = LinkedHashMap<String, String>()
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)

    // 离线手写特征库（支持 3793+ 至 8105+ 汉字的 8x8 空间密度 + 4x4x4 方向场 + 笔画数/起止方向特征）
    private class HwTemplate(
        val ch: String,
        val weight: Int,
        val aspectCode: Int,
        val complexity: Int,
        val density64: FloatArray,
        val orient64: FloatArray,
        val strokeCount: Int = 0,
        val strokeDirs: String = ""
    )
    private val hwTemplates = ArrayList<HwTemplate>(4200)

    // gugray/hanzi_lookup (MakeMeAHanzi) 3-Byte 子笔画特征结构: (dir 0..255, len 0..255, centerXY (cx<<4)|cy)
    private class SubstrokeItem(
        val dirRad: Float,
        val normLen: Float,
        val cxNorm: Float,
        val cyNorm: Float
    )
    private class MmahSubstrokeTemplate(
        val ch: String,
        val strokeCount: Int,
        val substrokes: Array<SubstrokeItem>
    )
    private val mmahSubstrokeMap = HashMap<String, MmahSubstrokeTemplate>(9600)

    // 用户导入词库专用 O(1) 哈希索引（同时支持 9键/14键/26键中文词库与英文 .txt 词库！）
    private class UserDictIndex(
        val wubiExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val wubiPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinAbbr: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val py26Exact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val py26Prefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val py26Abbr: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val t9Exact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val t9Prefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val t9Abbr: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val englishPrefix: HashMap<String, MutableList<Pair<String, Int>>> = HashMap()
    )
    @Volatile
    private var userDictIndex = UserDictIndex()

    private val userFreqMap = HashMap<String, Int>()
    private val userCodeMruMap = HashMap<String, Long>()
    private var mruSequenceCounter = System.currentTimeMillis()
    private val userBigramMap = HashMap<String, MutableList<String>>()
    private val builtInAssocMap = HashMap<String, List<String>>(15000)
    private val defaultCommonAssoc = listOf("的", "了", "是", "在", "我", "有", "和", "就", "不", "都", "也", "很", "可以", "什么", "自己", "知道", "觉得", "现在")

    private val isLoaded = AtomicBoolean(false)
    private val isLoading = AtomicBoolean(false)
    private val userDictDirty = AtomicBoolean(false)

    fun markUserDictDirty() {
        userDictDirty.set(true)
    }

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    fun letterToT9Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T9[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbr26(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val c = part[0].lowercaseChar()
                if (c in 'a'..'z') sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    fun ensureInitializedAsync(context: Context, dbHelper: ImeDatabaseHelper) {
        if (isLoaded.get()) {
            if (userDictDirty.compareAndSet(true, false)) {
                Thread { reloadUserDict(dbHelper) }.start()
            }
            return
        }
        if (!isLoading.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        Thread {
            loadAllInternal(appCtx, dbHelper)
            isLoaded.set(true)
            isLoading.set(false)
        }.start()
    }

    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        ensureInitializedAsync(context, dbHelper)
    }

    private fun decodeHex64ToFloatArray(hex: String): FloatArray {
        val out = FloatArray(64)
        val n = minOf(32, hex.length / 2)
        var maxV = 0f
        for (i in 0 until n) {
            val b = hex.substring(i * 2, i * 2 + 2).toIntOrNull(16) ?: 0
            val hi = ((b ushr 4) and 0x0F).toFloat() / 15f
            val lo = (b and 0x0F).toFloat() / 15f
            out[i * 2] = hi
            out[i * 2 + 1] = lo
            if (hi > maxV) maxV = hi
            if (lo > maxV) maxV = lo
        }
        if (maxV > 1e-4f) {
            for (i in 0 until 64) out[i] /= maxV
        }
        return out
    }

    private fun loadAllInternal(context: Context, dbHelper: ImeDatabaseHelper) {
        for (syl in VALID_SYLLABLES) {
            val code14 = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code14)) {
                t14SyllableMap[code14] = syl
            }
            val code9 = letterToT9Code(syl)
            if (code9.isNotEmpty()) {
                val list9 = t9SyllableListMap.getOrPut(code9) { ArrayList(4) }
                if (!list9.contains(syl)) list9.add(syl)
            }
        }

        // 1. 加载内置高频英文日常与 AI 词库 (en_daily_words.txt) + 主英文词典 (english_words.tsv)
        val seenEngLoaded = HashSet<String>(30000)
        fun indexEnglishWord(word: String, weight: Int) {
            if (word.length < 2) return
            val lower = word.lowercase()
            englishExactSet.add(lower)
            if (!seenEngLoaded.add(lower)) return
            val maxP = minOf(8, lower.length)
            for (len in 1..maxP) {
                val pref = lower.substring(0, len)
                val list = englishPrefixIndex.getOrPut(pref) { ArrayList(16) }
                if (list.size < 250) list.add(word to weight)
            }
        }
        for (assetName in listOf("en_daily_words.txt", "english_words.tsv")) {
            try {
                context.assets.open(assetName).use { ins ->
                    var autoWt = 95000
                    BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                        val clean = line.trim()
                        if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                        val tab = clean.indexOf('\t')
                        val word = (if (tab > 0) clean.substring(0, tab) else clean).trim()
                        val wt = if (tab > 0) clean.substring(tab + 1).trim().toIntOrNull() ?: autoWt else autoWt
                        autoWt = maxOf(1000, autoWt - 5)
                        indexEnglishWord(word, wt)
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. 加载单字五笔与拼音码表
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载词语联想表
        try {
            context.assets.open("assoc_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) {
                        val prefix = line.substring(0, tab)
                        val suffixes = line.substring(tab + 1).split(',').filter { it.isNotEmpty() }
                        if (suffixes.isNotEmpty()) {
                            builtInAssocMap[prefix] = suffixes
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. 加载主词库并建立 9键/14键/26键 全量哈希索引
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 65536).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 4) {
                        val word = parts[0]
                        val wcode = parts[1]
                        val segPy = parts[2]
                        val t14W: String
                        val t14P: String
                        val t14A: String
                        val weight: Int
                        if (parts.size >= 7) {
                            t14W = parts[3]
                            t14P = parts[4]
                            t14A = parts[5]
                            weight = parts[6].toIntOrNull() ?: 500
                        } else {
                            t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                            t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                            t14A = extractPyAbbrT14(segPy)
                            weight = parts[3].toIntOrNull() ?: 500
                        }

                        if (word.isNotEmpty()) {
                            val cleanPy = segPy.replace("'", "").lowercase()
                            val abbr26 = extractPyAbbr26(segPy)
                            val t9P = if (cleanPy.isNotEmpty()) letterToT9Code(cleanPy) else ""
                            val t9A = if (abbr26.isNotEmpty()) letterToT9Code(abbr26) else ""
                            val de = DictEntry(word, wcode, segPy, t14W, t14P, t14A, weight, cleanPy, abbr26, t9P, t9A)
                            indexEntry(de)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 5. 运行时兜底加载内置「中文日常高频用语词库」(cn_daily_phrases.txt)
        try {
            context.assets.open("cn_daily_phrases.txt").use { ins ->
                var dailyWt = 9950
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val w = line.trim()
                    if (w.isEmpty() || w.startsWith("#")) return@forEachLine
                    val wcode = generateWubi86CodeForWord(w)
                    val segPy = generateSegmentedPinyinForWord(w)
                    val cleanPy = segPy.replace("'", "").lowercase()
                    val abbr26 = extractPyAbbr26(segPy)
                    val t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                    val t14P = if (cleanPy.isNotEmpty()) letterToT14Code(cleanPy) else ""
                    val t14A = extractPyAbbrT14(segPy)
                    val t9P = if (cleanPy.isNotEmpty()) letterToT9Code(cleanPy) else ""
                    val t9A = if (abbr26.isNotEmpty()) letterToT9Code(abbr26) else ""
                    if (t14W.isNotEmpty() || t14P.isNotEmpty()) {
                        indexEntry(DictEntry(w, wcode, segPy, t14W, t14P, t14A, dailyWt, cleanPy, abbr26, t9P, t9A))
                    }
                    dailyWt = maxOf(8800, dailyWt - 1)
                }
            }
        } catch (_: Exception) {}

        // 6. 将最常用的 AI 与日常英文词同步注入 9键/14键/26键 拼音索引
        val topCrossModeEng = listOf(
            "gemini", "Gemini", "deepseek", "DeepSeek", "chatgpt", "ChatGPT", "gpt", "GPT",
            "claude", "Claude", "grok", "Grok", "openai", "copilot", "github", "android",
            "apk", "css", "oklch", "rgb", "hsv", "hsl", "love", "hello", "baby", "okay"
        )
        for ((idx, ew) in topCrossModeEng.withIndex()) {
            val cleanPy = ew.lowercase()
            val t14P = letterToT14Code(ew)
            val t9P = letterToT9Code(ew)
            if (t14P.isNotEmpty()) {
                indexEntry(DictEntry(ew, "", cleanPy, "", t14P, "", 9600 - idx * 10, cleanPy, "", t9P, ""))
            }
        }

        // 7. 加载离线手写特征库 (handwriting_strokes.tsv)
        try {
            hwTemplates.clear()
            context.assets.open("handwriting_strokes.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 32768).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 6) {
                        val ch = parts[0]
                        val wt = parts[1].toIntOrNull() ?: 5000
                        val aspect = parts[2].toIntOrNull() ?: 100
                        val comp = parts[3].toIntOrNull() ?: 100
                        val dHex = parts[4]
                        val oHex = parts[5]
                        val sCount = if (parts.size >= 7) parts[6].toIntOrNull() ?: 0 else 0
                        val sDirs = if (parts.size >= 8) parts[7] else ""
                        if (ch.isNotEmpty() && dHex.length >= 64 && oHex.length >= 64) {
                            hwTemplates.add(
                                HwTemplate(
                                    ch = ch,
                                    weight = wt,
                                    aspectCode = aspect,
                                    complexity = comp,
                                    density64 = decodeHex64ToFloatArray(dHex),
                                    orient64 = decodeHex64ToFloatArray(oHex),
                                    strokeCount = sCount,
                                    strokeDirs = sDirs
                                )
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 7b. 加载 gugray/hanzi_lookup 子笔画特征库 (mmah_substrokes.tsv)
        try {
            mmahSubstrokeMap.clear()
            context.assets.open("mmah_substrokes.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 32768).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 3) {
                        val ch = parts[0]
                        val sc = parts[1].toIntOrNull() ?: 0
                        val hex = parts[2].trim()
                        val nSubs = hex.length / 6
                        if (ch.isNotEmpty() && nSubs > 0) {
                            val subs = Array(nSubs) { idx ->
                                val base = idx * 6
                                val dByte = hex.substring(base, base + 2).toIntOrNull(16) ?: 0
                                val lByte = hex.substring(base + 2, base + 4).toIntOrNull(16) ?: 64
                                val cByte = hex.substring(base + 4, base + 6).toIntOrNull(16) ?: 0x88
                                val cx = ((cByte ushr 4) and 0x0F).toFloat() / 15f
                                val cy = (cByte and 0x0F).toFloat() / 15f
                                SubstrokeItem(
                                    dirRad = (dByte.toFloat() / 255f) * (2f * Math.PI.toFloat()),
                                    normLen = (lByte.toFloat() / 255f).coerceIn(0.02f, 1f),
                                    cxNorm = cx,
                                    cyNorm = cy
                                )
                            }
                            mmahSubstrokeMap[ch] = MmahSubstrokeTemplate(ch, sc, subs)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 按每个拼音音节下最高频单字的真实词频对 T9 音节列表排序（如 64 优先 ni 而非 mi，426 优先 hao 而非 gan）
        for ((_, sylList) in t9SyllableListMap) {
            if (sylList.size > 1) {
                sylList.sortByDescending { syl ->
                    py26SingleCharBySyl[syl]?.maxByOrNull { it.weight }?.weight ?: 0
                }
            }
        }

        userFreqMap.putAll(dbHelper.loadUserFreqMap())
        userCodeMruMap.putAll(dbHelper.loadUserCodeMruMap())
        userBigramMap.putAll(dbHelper.loadUserBigramMap())
        reloadUserDict(dbHelper)
    }

    private fun indexEntry(de: DictEntry) {
        if (de.t14Wubi.isNotEmpty()) {
            val exactList = wubiExactIndex.getOrPut(de.t14Wubi) { ArrayList(6) }
            if (exactList.size < 80) exactList.add(de)

            val maxPref = minOf(3, de.t14Wubi.length - 1)
            for (len in 1..maxPref) {
                val pref = de.t14Wubi.substring(0, len)
                val pList = wubiPrefixIndex.getOrPut(pref) { ArrayList(12) }
                if (pList.size < 250) pList.add(de)
            }
        }

        if (de.t14Pinyin.isNotEmpty()) {
            val pyExact = pinyinExactIndex.getOrPut(de.t14Pinyin) { ArrayList(6) }
            if (pyExact.size < 60) pyExact.add(de)

            if (de.word.length == 1 && pyExact.size <= 8) {
                val scList = t14SingleCharByPy.getOrPut(de.t14Pinyin) { ArrayList(4) }
                if (scList.size < 8) scList.add(de)
            }

            val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
            for (len in 1..maxPyPref) {
                val pref = de.t14Pinyin.substring(0, len)
                val pList = pinyinPrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 120) pList.add(de)
            }
        }

        if (de.t14PyAbbr.length in 2..6) {
            val aList = pinyinAbbrIndex.getOrPut(de.t14PyAbbr) { ArrayList(6) }
            if (aList.size < 40) aList.add(de)
        }

        // 26 键拼音索引
        if (de.cleanPinyin.isNotEmpty()) {
            val ex26 = py26ExactIndex.getOrPut(de.cleanPinyin) { ArrayList(8) }
            if (ex26.size < 80) ex26.add(de)

            if (de.word.length == 1) {
                val sc26 = py26SingleCharBySyl.getOrPut(de.cleanPinyin) { ArrayList(8) }
                if (sc26.size < 16) sc26.add(de)
            }

            val maxP26 = minOf(12, de.cleanPinyin.length - 1)
            for (len in 1..maxP26) {
                val pref = de.cleanPinyin.substring(0, len)
                val pList = py26PrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 100) pList.add(de)
            }
        }
        if (de.py26Abbr.length in 2..6) {
            val ab26 = py26AbbrIndex.getOrPut(de.py26Abbr) { ArrayList(8) }
            if (ab26.size < 50) ab26.add(de)
        }

        // 9 键 T9 拼音索引
        if (de.t9Pinyin.isNotEmpty()) {
            val ex9 = t9ExactIndex.getOrPut(de.t9Pinyin) { ArrayList(8) }
            if (ex9.size < 80) ex9.add(de)

            if (de.word.length == 1) {
                val sc9 = t9SingleCharByCode.getOrPut(de.t9Pinyin) { ArrayList(8) }
                if (sc9.size < 14) sc9.add(de)
            }

            val maxP9 = minOf(12, de.t9Pinyin.length - 1)
            for (len in 1..maxP9) {
                val pref = de.t9Pinyin.substring(0, len)
                val pList = t9PrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 100) pList.add(de)
            }
        }
        if (de.t9PyAbbr.length in 2..6) {
            val ab9 = t9AbbrIndex.getOrPut(de.t9PyAbbr) { ArrayList(8) }
            if (ab9.size < 50) ab9.add(de)
        }
    }

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        val nextIdx = UserDictIndex()
        try {
            dbHelper.readableDatabase.rawQuery(
                "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val w = c.getString(0)
                    val wc = c.getString(1)
                    if (wc == "__en__" || (w.length >= 2 && w.all { it in 'a'..'z' || it in 'A'..'Z' || it == '-' || it == '\'' })) {
                        val lower = w.lowercase()
                        val wt = c.getInt(5).coerceAtLeast(90000)
                        val maxP = minOf(8, lower.length)
                        for (len in 1..maxP) {
                            val pref = lower.substring(0, len)
                            val list = nextIdx.englishPrefix.getOrPut(pref) { ArrayList(12) }
                            if (list.size < 200) list.add(w to wt)
                        }
                        continue
                    }
                    val py = c.getString(2).ifEmpty { generateSegmentedPinyinForWord(w) }
                    val cleanPy = py.replace("'", "").lowercase()
                    val abbr26 = extractPyAbbr26(py)
                    val t9P = if (cleanPy.isNotEmpty()) letterToT9Code(cleanPy) else ""
                    val t9A = if (abbr26.isNotEmpty()) letterToT9Code(abbr26) else ""
                    val de = DictEntry(
                        word = w,
                        wubiCode = wc,
                        segmentedPinyin = py,
                        t14Wubi = c.getString(3),
                        t14Pinyin = c.getString(4),
                        t14PyAbbr = extractPyAbbrT14(py),
                        weight = c.getInt(5),
                        cleanPinyin = cleanPy,
                        py26Abbr = abbr26,
                        t9Pinyin = t9P,
                        t9PyAbbr = t9A
                    )
                    if (de.t14Wubi.isNotEmpty()) {
                        val exList = nextIdx.wubiExact.getOrPut(de.t14Wubi) { ArrayList(4) }
                        if (exList.size < 60) exList.add(de)
                        val maxPref = minOf(3, de.t14Wubi.length - 1)
                        for (len in 1..maxPref) {
                            val pref = de.t14Wubi.substring(0, len)
                            val pList = nextIdx.wubiPrefix.getOrPut(pref) { ArrayList(8) }
                            if (pList.size < 80) pList.add(de)
                        }
                    }
                    if (de.t14Pinyin.isNotEmpty()) {
                        val pyEx = nextIdx.pinyinExact.getOrPut(de.t14Pinyin) { ArrayList(4) }
                        if (pyEx.size < 50) pyEx.add(de)
                        val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
                        for (len in 2..maxPyPref) {
                            val pref = de.t14Pinyin.substring(0, len)
                            val pList = nextIdx.pinyinPrefix.getOrPut(pref) { ArrayList(6) }
                            if (pList.size < 50) pList.add(de)
                        }
                    }
                    if (de.t14PyAbbr.length in 2..6) {
                        val aList = nextIdx.pinyinAbbr.getOrPut(de.t14PyAbbr) { ArrayList(4) }
                        if (aList.size < 40) aList.add(de)
                    }
                    if (de.cleanPinyin.isNotEmpty()) {
                        val ex26 = nextIdx.py26Exact.getOrPut(de.cleanPinyin) { ArrayList(4) }
                        if (ex26.size < 50) ex26.add(de)
                        val maxP26 = minOf(12, de.cleanPinyin.length - 1)
                        for (len in 2..maxP26) {
                            val pref = de.cleanPinyin.substring(0, len)
                            val pList = nextIdx.py26Prefix.getOrPut(pref) { ArrayList(6) }
                            if (pList.size < 50) pList.add(de)
                        }
                    }
                    if (de.py26Abbr.length in 2..6) {
                        val ab26 = nextIdx.py26Abbr.getOrPut(de.py26Abbr) { ArrayList(4) }
                        if (ab26.size < 40) ab26.add(de)
                    }
                    if (de.t9Pinyin.isNotEmpty()) {
                        val ex9 = nextIdx.t9Exact.getOrPut(de.t9Pinyin) { ArrayList(4) }
                        if (ex9.size < 50) ex9.add(de)
                        val maxP9 = minOf(12, de.t9Pinyin.length - 1)
                        for (len in 2..maxP9) {
                            val pref = de.t9Pinyin.substring(0, len)
                            val pList = nextIdx.t9Prefix.getOrPut(pref) { ArrayList(6) }
                            if (pList.size < 50) pList.add(de)
                        }
                    }
                    if (de.t9PyAbbr.length in 2..6) {
                        val ab9 = nextIdx.t9Abbr.getOrPut(de.t9PyAbbr) { ArrayList(4) }
                        if (ab9.size < 40) ab9.add(de)
                    }
                }
            }
            userDictIndex = nextIdx
        } catch (_: Exception) {}
    }

    fun resetUserFrequency(dbHelper: ImeDatabaseHelper) {
        userFreqMap.clear()
        userCodeMruMap.clear()
        userBigramMap.clear()
        dbHelper.resetUserFrequencySorting()
    }

    fun onWordCommitted(word: String, prevWord: String?, dbHelper: ImeDatabaseHelper, inputCode: String = "") {
        if (word.isEmpty()) return
        userFreqMap[word] = (userFreqMap[word] ?: 0) + 1
        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (inputCode.isNotEmpty()) {
            userCodeMruMap["$inputCode|$word"] = mruSequenceCounter
        }
        if (!prevWord.isNullOrEmpty() && prevWord != word) {
            val list = userBigramMap.getOrPut(prevWord) { ArrayList() }
            list.remove(word)
            list.add(0, word)
            if (list.size > 12) list.removeAt(list.lastIndex)
        }
        dbHelper.recordWordUsageAsync(word, prevWord, inputCode, mruSequenceCounter)
    }

    fun getAssociations(committedWord: String, limit: Int = 28): List<String> {
        if (committedWord.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        userBigramMap[committedWord]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }
        val lastCharStr = committedWord.takeLast(1)
        userBigramMap[lastCharStr]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }

        builtInAssocMap[committedWord]?.forEach { suffix ->
            if (seen.add(suffix) && result.size < limit) result.add(suffix)
        }
        if (committedWord.length >= 2) {
            builtInAssocMap[lastCharStr]?.forEach { suffix ->
                if (seen.add(suffix) && result.size < limit) result.add(suffix)
            }
        }

        for (cw in defaultCommonAssoc) {
            if (cw != committedWord && seen.add(cw) && result.size < limit) {
                result.add(cw)
            }
        }
        return result
    }

    fun onEnglishWordCommitted(word: String, rawPrefix: String, dbHelper: ImeDatabaseHelper) {
        val clean = word.trim()
        if (clean.length < 2) return
        val lower = clean.lowercase()
        val prefLower = rawPrefix.trim().lowercase()

        val freqKey = "en_freq|$lower"
        val newFreq = (userFreqMap[freqKey] ?: 0) + 1
        userFreqMap[freqKey] = newFreq

        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (prefLower.isNotEmpty()) {
            userCodeMruMap["en_mru:$prefLower|$lower"] = mruSequenceCounter
        }
        val maxP = minOf(8, lower.length)
        for (len in 1..maxP) {
            val p = lower.substring(0, len)
            userCodeMruMap["en_any:$p|$lower"] = mruSequenceCounter
            val list = englishPrefixIndex.getOrPut(p) { ArrayList(16) }
            if (list.none { it.first.equals(clean, ignoreCase = true) }) {
                list.add(0, clean to 92000)
            }
        }
        englishExactSet.add(lower)
        dbHelper.recordWordUsageAsync(freqKey, null, if (prefLower.isNotEmpty()) "en_mru:$prefLower" else "", mruSequenceCounter)
    }

    fun queryEnglishCandidates(rawInput: String, limit: Int = 28): List<String> {
        if (rawInput.isEmpty()) return emptyList()
        val lower = rawInput.lowercase()
        val isAllUpper = rawInput.length >= 2 && rawInput.all { it.isUpperCase() }
        val isCapitalized = rawInput[0].isUpperCase() && !isAllUpper
        val prefKey = lower.take(8)

        val candidatesMap = LinkedHashMap<String, Pair<String, Int>>()
        userDictIndex.englishPrefix[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                if (!candidatesMap.containsKey(key)) {
                    candidatesMap[key] = w to (wt + 60000)
                }
            }
        }
        englishPrefixIndex[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                val existing = candidatesMap[key]
                if (existing == null || wt > existing.second) {
                    candidatesMap[key] = w to wt
                }
            }
        }

        class ScoredEng(
            val displayWord: String,
            val lowerWord: String,
            val exactMru: Long,
            val userFreq: Int,
            val anyMru: Long,
            val baseWeight: Int
        )

        val scoredList = ArrayList<ScoredEng>(candidatesMap.size)
        for ((wLower, pair) in candidatesMap) {
            val rawW = pair.first
            val baseWt = pair.second
            val formatted = when {
                isAllUpper -> rawW.uppercase()
                isCapitalized -> rawW.replaceFirstChar { it.uppercaseChar() }
                else -> rawW
            }
            val exMru = userCodeMruMap["en_mru:$lower|$wLower"] ?: 0L
            val uFreq = userFreqMap["en_freq|$wLower"] ?: 0
            val anyMru = userCodeMruMap["en_any:$lower|$wLower"] ?: 0L
            val lenPenalty = (wLower.length - lower.length).coerceAtLeast(0) * 180
            scoredList.add(ScoredEng(formatted, wLower, exMru, uFreq, anyMru, baseWt - lenPenalty))
        }

        scoredList.sortWith { a, b ->
            when {
                a.exactMru != b.exactMru -> b.exactMru.compareTo(a.exactMru)
                a.userFreq != b.userFreq -> b.userFreq.compareTo(a.userFreq)
                a.anyMru != b.anyMru -> b.anyMru.compareTo(a.anyMru)
                else -> b.baseWeight.compareTo(a.baseWeight)
            }
        }

        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        val topCand = scoredList.firstOrNull { !it.displayWord.equals(rawInput, ignoreCase = false) }
        val promoteTopToFirst = topCand != null && (
            topCand.exactMru > 0L ||
            topCand.userFreq >= 2 ||
            (lower.length >= 3 && !englishExactSet.contains(lower))
        )

        if (promoteTopToFirst && topCand != null) {
            if (seen.add(topCand.displayWord)) result.add(topCand.displayWord)
            if (seen.add(rawInput)) result.add(rawInput)
        } else {
            if (seen.add(rawInput)) result.add(rawInput)
            if (topCand != null && seen.add(topCand.displayWord)) result.add(topCand.displayWord)
        }

        for (item in scoredList) {
            if (seen.add(item.displayWord)) {
                result.add(item.displayWord)
                if (result.size >= limit) break
            }
        }
        return result
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    // ==================== 26 键中文拼音分词与候选词引擎 ====================
    fun segment26Syllables(rawLetters: String): List<String> {
        val res = ArrayList<String>()
        val parts = rawLetters.lowercase().split('\'').filter { it.isNotEmpty() }
        for (part in parts) {
            var i = 0
            val n = part.length
            while (i < n) {
                var matchedLen = 0
                val maxLen = minOf(6, n - i)
                for (len in maxLen downTo 1) {
                    val sub = part.substring(i, i + len)
                    if (VALID_SYLLABLE_SET.contains(sub)) {
                        // Lookahead check: avoid greedy "fangan" -> "fan"+"gan" ambiguity issues when next char is vowel
                        matchedLen = len
                        res.add(sub)
                        break
                    }
                }
                if (matchedLen == 0) {
                    res.add(part.substring(i, i + 1))
                    i += 1
                } else {
                    i += matchedLen
                }
            }
        }
        return res
    }

    fun segment26ToPinyinDisplay(rawInput: String): String {
        val syls = segment26Syllables(rawInput)
        return if (syls.isEmpty()) rawInput else syls.joinToString("'")
    }

    fun queryPinyin26Candidates(rawInput: String, limit: Int = 90): List<Candidate> {
        val clean = rawInput.replace("'", "").lowercase()
        if (clean.isEmpty() || !isLoaded.get()) return emptyList()

        val exactPinyin = ArrayList<Candidate>(48)
        val abbrPinyin = ArrayList<Candidate>(32)
        val prefixPinyin = ArrayList<Candidate>(36)
        val seen = HashSet<String>(128)
        val segmentedDisplay = segment26ToPinyinDisplay(rawInput)

        val uIdx = userDictIndex
        uIdx.py26Exact[clean]?.forEach { e ->
            if (seen.add(e.word)) {
                exactPinyin.add(Candidate(e.word, null, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 50000, false))
            }
        }
        if (clean.length in 2..6) {
            uIdx.py26Abbr[clean]?.forEach { e ->
                if (seen.add(e.word)) {
                    abbrPinyin.add(Candidate(e.word, null, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 25000, false))
                }
            }
        }
        if (clean.length in 1..12) {
            uIdx.py26Prefix[clean]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixPinyin.add(Candidate(e.word, null, segmentedDisplay, e.weight + 12000, false))
                }
            }
        }

        py26ExactIndex[clean]?.forEach { e ->
            if (seen.add(e.word)) {
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = null,
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }
        if (clean.length in 2..6) {
            py26AbbrIndex[clean]?.forEach { e ->
                if (seen.add(e.word)) {
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight,
                            isWubiMatch = false
                        )
                    )
                }
            }
        }
        if (clean.length in 1..12) {
            py26PrefixIndex[clean]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = segmentedDisplay,
                            weight = e.weight,
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        fun codeMru(word: String): Long = userCodeMruMap["py26:$clean|$word"] ?: userCodeMruMap["$clean|$word"] ?: 0L
        val mruComparator = Comparator<Candidate> { a, b ->
            val luA = codeMru(a.word)
            val luB = codeMru(b.word)
            if (luA != luB) {
                luB.compareTo(luA)
            } else {
                val ufA = userFreqMap[a.word] ?: 0
                val ufB = userFreqMap[b.word] ?: 0
                if (ufA != ufB && (luA > 0L || luB > 0L || ufA >= 2 || ufB >= 2)) {
                    ufB.compareTo(ufA)
                } else {
                    b.weight.compareTo(a.weight)
                }
            }
        }

        // 叠字连打快捷识别（如 hhhhh -> 哈哈哈哈哈）
        val repeatCandidatesTop = ArrayList<Candidate>(4)
        if (clean.length >= 3 && clean.all { it == clean[0] }) {
            val n = clean.length
            val repeatPresets = when (clean[0]) {
                'h' -> listOf("哈", "嘿", "哼")
                'a' -> listOf("啊", "呀")
                'w' -> listOf("呜", "哇")
                'x' -> listOf("嘻")
                'o' -> listOf("哦", "噢")
                'l' -> listOf("啦", "略")
                'm' -> listOf("么", "喵")
                else -> emptyList()
            }
            for ((idx, chStr) in repeatPresets.withIndex()) {
                val repWord = chStr.repeat(n)
                abbrPinyin.removeAll { it.word == repWord }
                prefixPinyin.removeAll { it.word == repWord }
                exactPinyin.removeAll { it.word == repWord }
                seen.add(repWord)
                repeatCandidatesTop.add(Candidate(repWord, null, clean, 9999999 - idx * 100, false))
            }
        }

        if (exactPinyin.size > 1) exactPinyin.sortWith(mruComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(mruComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(mruComparator)

        val result = ArrayList<Candidate>(limit)
        result.addAll(repeatCandidatesTop)
        for (c in exactPinyin) if (result.size < limit) result.add(c)
        for (c in abbrPinyin) if (result.size < limit) result.add(c)
        for (c in prefixPinyin) if (result.size < limit) result.add(c)

        val syls = segment26Syllables(clean)
        if (syls.isNotEmpty()) {
            if (syls.size >= 2) {
                val sbWord = StringBuilder()
                for (s in syls) {
                    val topChar = py26SingleCharBySyl[s]?.maxByOrNull { it.weight + (userFreqMap[it.word] ?: 0) * 500 }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val insertPos = exactPinyin.size.coerceAtMost(result.size)
                    result.add(insertPos, Candidate(synthWord, null, segmentedDisplay, 12000, false))
                }
            }
            val firstSyl = syls[0]
            val firstChars = py26SingleCharBySyl[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = null,
                            displayCode = segmentedDisplay,
                            weight = fc.weight,
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        val promotedMru = result.filter { codeMru(it.word) > 0L }.sortedWith(mruComparator)
        if (promotedMru.isNotEmpty()) {
            val promotedSet = promotedMru.map { it.word }.toHashSet()
            val remaining = result.filterNot { it.word in promotedSet }
            result.clear()
            result.addAll(promotedMru)
            result.addAll(remaining)
        }
        return result
    }

    // ==================== 9 键 T9 拼音分词、左侧音节筛选与候选词引擎 ====================
    private fun segmentT9SyllableCodes(t9Input: String): List<String> {
        val res = ArrayList<String>()
        val parts = t9Input.split('\'').filter { it.isNotEmpty() }
        for (part in parts) {
            var i = 0
            val n = part.length
            while (i < n) {
                var matchedLen = 0
                val maxLen = minOf(6, n - i)
                for (len in maxLen downTo 1) {
                    val sub = part.substring(i, i + len)
                    if (t9SyllableListMap.containsKey(sub)) {
                        matchedLen = len
                        res.add(sub)
                        break
                    }
                }
                if (matchedLen == 0) {
                    res.add(part.substring(i, i + 1))
                    i += 1
                } else {
                    i += matchedLen
                }
            }
        }
        return res
    }

    fun segmentT9ToPinyinDisplay(t9Input: String, lockedFirstSyl: String? = null): String {
        val clean = t9Input.trim()
        if (clean.isEmpty()) return ""
        val sylCodes = segmentT9SyllableCodes(clean)
        if (sylCodes.isEmpty()) return clean
        return sylCodes.mapIndexed { idx, code ->
            if (idx == 0 && !lockedFirstSyl.isNullOrEmpty()) {
                lockedFirstSyl
            } else {
                t9SyllableListMap[code]?.firstOrNull()
                    ?: code.map { ch -> T9_CODE_TO_LETTER[ch] ?: ch.toString() }.joinToString("")
            }
        }.joinToString("'")
    }

    private val T9_DIGIT_TO_LETTERS = mapOf(
        '2' to listOf("a", "b", "c"),
        '3' to listOf("d", "e", "f"),
        '4' to listOf("g", "h", "i"),
        '5' to listOf("j", "k", "l"),
        '6' to listOf("m", "n", "o"),
        '7' to listOf("p", "q", "r", "s"),
        '8' to listOf("t", "u", "v"),
        '9' to listOf("w", "x", "y", "z")
    )

    /**
     * 获取 9 键 T9 当前输入对应的左侧候选拼音音节与单字母/数字列表（复刻图3栗子奶泡左侧竖向胶囊栏体验）
     */
    fun getT9MatchingSyllables(t9Input: String): List<String> {
        val clean = t9Input.replace("'", "")
        if (clean.isEmpty()) return emptyList()
        val result = ArrayList<String>(18)
        val seen = HashSet<String>()

        // 若刚按下单键（如按下 5 JKL），在胶囊栏顶部优先展示该键对应的单字母与数字（如 j / k / l / 5）及高频音节
        if (clean.length == 1) {
            val ch = clean[0]
            T9_DIGIT_TO_LETTERS[ch]?.forEach { letStr ->
                if (seen.add(letStr)) result.add(letStr)
            }
            if (seen.add(ch.toString())) result.add(ch.toString())
            for ((code, sylList) in t9SyllableListMap) {
                if (code.startsWith(clean)) {
                    for (syl in sylList) {
                        if (seen.add(syl) && result.size < 14) result.add(syl)
                    }
                }
            }
            return result
        }

        // 1. 多键输入时：优先加入第一分词音节码对应的全部精确音节（已按高频字权重排序）
        val firstSegCode = segmentT9SyllableCodes(t9Input).firstOrNull() ?: clean.take(6)
        t9SyllableListMap[firstSegCode]?.forEach { syl ->
            if (seen.add(syl)) result.add(syl)
        }

        // 2. 加入其他可能的长度（从 minOf(6, clean.length) 到 1）对应的有效音节
        val maxL = minOf(6, clean.length)
        for (len in maxL downTo 2) {
            val sub = clean.substring(0, len)
            t9SyllableListMap[sub]?.forEach { syl ->
                if (seen.add(syl)) result.add(syl)
            }
        }

        // 3. 若输入较短（2~3位），补充以此 T9 为前缀的高频音节
        if (clean.length <= 3 && result.size < 10) {
            for ((code, sylList) in t9SyllableListMap) {
                if (code.startsWith(clean)) {
                    for (syl in sylList) {
                        if (seen.add(syl) && result.size < 14) result.add(syl)
                    }
                }
            }
        }

        // 4. 底部附上首键对应的单字母筛选（如 j / k / l）
        T9_DIGIT_TO_LETTERS[clean[0]]?.forEach { letStr ->
            if (seen.add(letStr)) result.add(letStr)
        }
        return result
    }

    fun queryPinyin9Candidates(
        t9Input: String,
        lockedFirstSyl: String? = null,
        limit: Int = 90
    ): List<Candidate> {
        val clean = t9Input.replace("'", "")
        if (clean.isEmpty() || !isLoaded.get()) return emptyList()

        val exactPinyin = ArrayList<Candidate>(56)
        val abbrPinyin = ArrayList<Candidate>(36)
        val prefixPinyin = ArrayList<Candidate>(40)
        val seen = HashSet<String>(140)
        val segmentedDisplay = segmentT9ToPinyinDisplay(t9Input, lockedFirstSyl)

        fun matchesLockedSyl(de: DictEntry): Boolean {
            if (lockedFirstSyl.isNullOrEmpty()) return true
            val lockLow = lockedFirstSyl.lowercase()
            val firstWordSyl = de.segmentedPinyin.substringBefore('\'').lowercase()
            return if (lockLow.length == 1) {
                firstWordSyl.startsWith(lockLow) || de.cleanPinyin.startsWith(lockLow)
            } else {
                firstWordSyl == lockLow || de.cleanPinyin.startsWith(lockLow)
            }
        }

        val uIdx = userDictIndex
        uIdx.t9Exact[clean]?.forEach { e ->
            if (matchesLockedSyl(e) && seen.add(e.word)) {
                exactPinyin.add(Candidate(e.word, null, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 50000, false))
            }
        }
        if (clean.length in 2..6) {
            uIdx.t9Abbr[clean]?.forEach { e ->
                if (matchesLockedSyl(e) && seen.add(e.word)) {
                    abbrPinyin.add(Candidate(e.word, null, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 25000, false))
                }
            }
        }
        if (clean.length in 1..12) {
            uIdx.t9Prefix[clean]?.forEach { e ->
                if (matchesLockedSyl(e) && seen.add(e.word)) {
                    prefixPinyin.add(Candidate(e.word, null, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 12000, false))
                }
            }
        }

        t9ExactIndex[clean]?.forEach { e ->
            if (matchesLockedSyl(e) && seen.add(e.word)) {
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = null,
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }
        if (clean.length in 2..6) {
            t9AbbrIndex[clean]?.forEach { e ->
                if (matchesLockedSyl(e) && seen.add(e.word)) {
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight,
                            isWubiMatch = false
                        )
                    )
                }
            }
        }
        if (clean.length in 1..12) {
            t9PrefixIndex[clean]?.forEach { e ->
                if (matchesLockedSyl(e) && seen.add(e.word)) {
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight,
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        fun codeMru(word: String): Long = userCodeMruMap["t9:$clean|$word"] ?: userCodeMruMap["$clean|$word"] ?: 0L
        val mruComparator = Comparator<Candidate> { a, b ->
            val luA = codeMru(a.word)
            val luB = codeMru(b.word)
            if (luA != luB) {
                luB.compareTo(luA)
            } else {
                val ufA = userFreqMap[a.word] ?: 0
                val ufB = userFreqMap[b.word] ?: 0
                if (ufA != ufB && (luA > 0L || luB > 0L || ufA >= 2 || ufB >= 2)) {
                    ufB.compareTo(ufA)
                } else {
                    b.weight.compareTo(a.weight)
                }
            }
        }

        // 叠字连打快捷识别（如连敲 44444 -> 哈哈哈哈哈）
        val repeatCandidatesTop = ArrayList<Candidate>(4)
        if (clean.length >= 3 && clean.all { it == clean[0] }) {
            val n = clean.length
            val repeatPresets = when (clean[0]) {
                '4' -> listOf("哈", "嘿", "哼")
                '2' -> listOf("啊", "呀")
                '9' -> listOf("呜", "哇", "嘻")
                '6' -> listOf("哦", "么", "喵")
                '5' -> listOf("啦", "略")
                else -> emptyList()
            }
            for ((idx, chStr) in repeatPresets.withIndex()) {
                val repWord = chStr.repeat(n)
                abbrPinyin.removeAll { it.word == repWord }
                prefixPinyin.removeAll { it.word == repWord }
                exactPinyin.removeAll { it.word == repWord }
                seen.add(repWord)
                repeatCandidatesTop.add(Candidate(repWord, null, segmentedDisplay, 9999999 - idx * 100, false))
            }
        }

        if (exactPinyin.size > 1) exactPinyin.sortWith(mruComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(mruComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(mruComparator)

        val result = ArrayList<Candidate>(limit)
        result.addAll(repeatCandidatesTop)

        // 若用户在左侧胶囊栏锁定了某个音节（如 "ni"）或首字母（如 "j"），先把匹配词组与单字置顶
        if (!lockedFirstSyl.isNullOrEmpty()) {
            val lockLow = lockedFirstSyl.lowercase()
            for (c in exactPinyin) if (result.size < limit) result.add(c)
            if (lockLow.length == 1) {
                for (c in abbrPinyin) if (result.size < limit && !result.contains(c)) result.add(c)
                for (c in prefixPinyin) if (result.size < limit && !result.contains(c)) result.add(c)
            } else {
                py26SingleCharBySyl[lockLow]?.forEach { fc ->
                    if (seen.add(fc.word) && result.size < limit) {
                        result.add(
                            Candidate(
                                word = fc.word,
                                wubiHint = null,
                                displayCode = lockedFirstSyl,
                                weight = fc.weight + 15000,
                                isWubiMatch = false,
                                consumedKeys = lockedFirstSyl.length.coerceAtMost(clean.length)
                            )
                        )
                    }
                }
            }
        }

        for (c in exactPinyin) if (result.size < limit && !result.contains(c)) result.add(c)
        for (c in abbrPinyin) if (result.size < limit) result.add(c)
        for (c in prefixPinyin) if (result.size < limit) result.add(c)

        val sylCodes = segmentT9SyllableCodes(clean)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for ((idx, sc) in sylCodes.withIndex()) {
                    val topChar = if (idx == 0 && !lockedFirstSyl.isNullOrEmpty()) {
                        py26SingleCharBySyl[lockedFirstSyl.lowercase()]?.maxByOrNull { it.weight }?.word
                    } else {
                        t9SingleCharByCode[sc]?.maxByOrNull { it.weight }?.word
                    }
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val insertPos = exactPinyin.size.coerceAtMost(result.size)
                    result.add(insertPos, Candidate(synthWord, null, segmentedDisplay, 11000, false))
                }
            }
            val firstCode = sylCodes[0]
            val firstChars = if (!lockedFirstSyl.isNullOrEmpty()) {
                py26SingleCharBySyl[lockedFirstSyl.lowercase()] ?: emptyList()
            } else {
                t9SingleCharByCode[firstCode] ?: emptyList()
            }
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = null,
                            displayCode = segmentedDisplay,
                            weight = fc.weight,
                            isWubiMatch = false,
                            consumedKeys = firstCode.length
                        )
                    )
                }
            }
        }

        val promotedMru = result.filter { codeMru(it.word) > 0L }.sortedWith(mruComparator)
        if (promotedMru.isNotEmpty()) {
            val promotedSet = promotedMru.map { it.word }.toHashSet()
            val remaining = result.filterNot { it.word in promotedSet }
            result.clear()
            result.addAll(promotedMru)
            result.addAll(remaining)
        }
        return result
    }

    /**
     * 将 14 键编码转换为左上角浮窗显示的纯字母串（彻底杜绝 '8'、'7'、'9' 等内部数字编号出现！）
     */
    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code ->
            t14SyllableMap[code] ?: code.map { ch -> T14_CODE_TO_LETTER[ch] ?: ch.toString() }.joinToString("")
        }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    fun queryCandidates(
        t14Input: String,
        rawFallback: String,
        limit: Int = 90,
        includeWubi: Boolean = false,
        showWubiHint: Boolean = false
    ): List<Candidate> {
        if (t14Input.isEmpty() || !isLoaded.get()) return emptyList()

        val exactWubi = ArrayList<Candidate>(32)
        val prefixWubi = ArrayList<Candidate>(48)
        val exactPinyin = ArrayList<Candidate>(40)
        val abbrPinyin = ArrayList<Candidate>(24)
        val prefixPinyin = ArrayList<Candidate>(32)
        val seen = HashSet<String>(128)

        val isLongPinyinMode = !includeWubi || t14Input.length > 4
        val segmentedDisplay = segmentT14ToPinyinDisplay(t14Input, rawFallback)

        fun userBoost(@Suppress("UNUSED_PARAMETER") word: String): Int = 0
        fun optWubiHint(e: DictEntry): String? {
            if (!showWubiHint) return null
            return e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
        }

        val uIdx = userDictIndex
        if (!isLongPinyinMode) {
            uIdx.wubiExact[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(Candidate(e.word, null, e.wubiCode, e.weight + 50000, true))
                }
            }
            uIdx.wubiPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(Candidate(e.word, null, e.wubiCode.take(t14Input.length), e.weight + 20000, true))
                }
            }
        }
        uIdx.pinyinExact[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                exactPinyin.add(Candidate(e.word, optWubiHint(e), e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 50000, false))
            }
        }
        if (t14Input.length in 2..6) {
            uIdx.pinyinAbbr[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    abbrPinyin.add(Candidate(e.word, optWubiHint(e), e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 20000, false))
                }
            }
        }
        if (t14Input.length in 1..14) {
            uIdx.pinyinPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixPinyin.add(Candidate(e.word, optWubiHint(e), segmentedDisplay, e.weight + 10000, false))
                }
            }
        }

        if (!isLongPinyinMode) {
            wubiExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
            wubiPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode.take(t14Input.length),
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
        }

        pinyinExactIndex[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = optWubiHint(e),
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + userBoost(e.word) + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }

        if (t14Input.length in 2..6) {
            pinyinAbbrIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = optWubiHint(e),
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        if (t14Input.length <= 14) {
            pinyinPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = optWubiHint(e),
                            displayCode = segmentedDisplay,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        fun codeMru(word: String): Long = userCodeMruMap["$t14Input|$word"] ?: 0L

        val mruComparator = Comparator<Candidate> { a, b ->
            val luA = codeMru(a.word)
            val luB = codeMru(b.word)
            if (luA != luB) {
                luB.compareTo(luA)
            } else {
                val ufA = userFreqMap[a.word] ?: 0
                val ufB = userFreqMap[b.word] ?: 0
                if (ufA != ufB && (luA > 0L || luB > 0L)) {
                    ufB.compareTo(ufA)
                } else {
                    b.weight.compareTo(a.weight)
                }
            }
        }

        val repeatCandidatesTop = ArrayList<Candidate>(4)
        if (t14Input.length >= 3 && t14Input.all { it == t14Input[0] }) {
            val n = t14Input.length
            val repeatPresets = when (t14Input[0]) {
                '8' -> listOf("哈" to "h", "嘿" to "h", "哼" to "h")
                '6' -> listOf("啊" to "a", "呀" to "a")
                '1' -> listOf("呜" to "w", "哇" to "w")
                'a' -> listOf("嘻" to "x")
                '5' -> listOf("哦" to "o", "噢" to "o")
                '0' -> listOf("啦" to "l", "略" to "l")
                'd' -> listOf("么" to "m", "喵" to "m")
                else -> emptyList()
            }
            if (repeatPresets.isNotEmpty()) {
                for ((idx, pair) in repeatPresets.withIndex()) {
                    val (chStr, codeCh) = pair
                    val repWord = chStr.repeat(n)
                    abbrPinyin.removeAll { it.word == repWord }
                    prefixPinyin.removeAll { it.word == repWord }
                    exactPinyin.removeAll { it.word == repWord }
                    seen.add(repWord)
                    if (n > 4 || !includeWubi) {
                        repeatCandidatesTop.add(Candidate(repWord, null, codeCh.repeat(n), 9999999 - idx * 100, false))
                    } else if (exactWubi.none { it.word == repWord }) {
                        exactWubi.add(Candidate(repWord, null, codeCh.repeat(n), 50 - idx, false))
                    }
                }
                if (repeatCandidatesTop.size > 1) {
                    repeatCandidatesTop.sortWith(mruComparator)
                }
            }
        }

        if (exactWubi.size > 1) exactWubi.sortWith(mruComparator)
        if (prefixWubi.size > 1) prefixWubi.sortWith(mruComparator)
        if (exactPinyin.size > 1) exactPinyin.sortWith(mruComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(mruComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(mruComparator)

        val result = ArrayList<Candidate>(limit)
        for (rc in repeatCandidatesTop) {
            result.add(rc)
        }

        if (!isLongPinyinMode) {
            for (c in exactWubi) if (result.size < limit) result.add(c)
            for (c in prefixWubi) if (result.size < limit) result.add(c)
            for (c in exactPinyin) if (result.size < limit) result.add(c)
            for (c in abbrPinyin) if (result.size < limit) result.add(c)
            for (c in prefixPinyin) if (result.size < limit) result.add(c)
        } else {
            for (c in exactPinyin) if (result.size < limit) result.add(c)
            for (c in abbrPinyin) if (result.size < limit) result.add(c)
            for (c in prefixPinyin) if (result.size < limit) result.add(c)
        }

        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight + userBoost(it.word) }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val wHint = if (showWubiHint) generateWubi86CodeForWord(synthWord) else null
                    val insertPos = if (isLongPinyinMode) exactPinyin.size.coerceAtMost(result.size) else result.size
                    result.add(
                        insertPos,
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = if (showWubiHint) fc.wubiCode else null,
                            displayCode = segmentedDisplay,
                            weight = fc.weight + userBoost(fc.word),
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        val promotedMru = result.filter { codeMru(it.word) > 0L }.sortedWith(mruComparator)
        if (promotedMru.isNotEmpty()) {
            val promotedSet = promotedMru.map { it.word }.toHashSet()
            val remaining = result.filterNot { it.word in promotedSet }
            result.clear()
            result.addAll(promotedMru)
            result.addAll(remaining)
        }

        return result
    }

    // ==================== 100% 离线手写识别引擎（v8.4：转角向量检测 + 柔性DP子序列 + 32x32对齐归一化） ====================
    private fun classifySingleStrokeDir(pts: List<StrokePoint>): Char {
        if (pts.size < 2) return '4' // 点
        val first = pts.first()
        val last = pts.last()
        val dx = last.x - first.x
        val dy = last.y - first.y
        val chord = hypot(dx, dy)
        var pathLen = 0f
        for (i in 1 until pts.size) {
            pathLen += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
        }
        if (pathLen < 8f) return '4' // 短点

        // 1. 专门识别竖钩 (亅，如「你、小、可、水、丁」的竖钩)：主干垂直向下且笔直，仅末尾向左上方短促勾起
        if (pts.size >= 3) {
            var lowIdx = 0
            var maxY = pts[0].y
            for (i in 1 until pts.size) {
                if (pts[i].y >= maxY) {
                    maxY = pts[i].y
                    lowIdx = i
                }
            }
            if (lowIdx > 0 && lowIdx < pts.lastIndex) {
                val dxMain = pts[lowIdx].x - first.x
                val dyMain = pts[lowIdx].y - first.y
                if (dyMain > 12f && abs(dxMain) < dyMain * 0.24f) {
                    val stemChord = hypot(dxMain, dyMain).coerceAtLeast(1f)
                    val ux = dxMain / stemChord
                    val uy = dyMain / stemChord
                    var stemDev = 0f
                    for (i in 0..lowIdx) {
                        val perp = abs((pts[i].x - first.x) * uy - (pts[i].y - first.y) * ux)
                        if (perp > stemDev) stemDev = perp
                    }
                    var tailLen = 0f
                    for (i in (lowIdx + 1) until pts.size) {
                        tailLen += hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y)
                    }
                    // 竖钩尾端必在最低点左侧 (last.x < pts[lowIdx].x)，避免把竖弯钩(乚)误判为竖钩
                    if (stemDev < dyMain * 0.15f && tailLen < dyMain * 0.42f && last.x < pts[lowIdx].x) {
                        return '2' // 竖钩归入竖 (2)
                    }
                }
            }
        }

        // 2. 检测折画（含短钩横撇 乛、竖弯钩 乚、撇点 ㄑ、横折 𠃍）：
        // 综合路径弯曲比、法向最大偏离度与首末两段向量夹角，防止短钩折笔被误判为直横/直竖
        if (chord > 1f && pathLen / chord > 1.28f) {
            return '5'
        }
        var maxDeviation = 0f
        if (chord > 6f) {
            val ux = dx / chord
            val uy = dy / chord
            for (p in pts) {
                val vx = p.x - first.x
                val vy = p.y - first.y
                val perp = abs(vx * uy - vy * ux)
                if (perp > maxDeviation) maxDeviation = perp
            }
            if (maxDeviation / chord > 0.20f) return '5'
        }
        if (pts.size >= 3) {
            val mid = pts.size / 2
            val v1x = pts[mid].x - first.x
            val v1y = pts[mid].y - first.y
            val v2x = last.x - pts[mid].x
            val v2y = last.y - pts[mid].y
            val n1 = hypot(v1x, v1y)
            val n2 = hypot(v2x, v2y)
            if (n1 > 4f && n2 > 4f) {
                val cosA = (v1x * v2x + v1y * v2y) / (n1 * n2)
                if (cosA < 0.68f) return '5' // 转折角大于 ~47° 判定为折笔
            }
        }

        val absDx = abs(dx)
        val absDy = abs(dy)
        return when {
            dx < 0 && dy > 0 && absDx > absDy * 0.20f -> '3' // 撇 (丿)
            dy > 0 && absDy > absDx * 2.15f -> '2'           // 竖 (丨)
            dx > 0 && absDx > absDy * 1.35f -> '1'           // 横 (一)
            dx < 0 && dy >= -absDx * 0.25f -> '3'            // 平撇 (丿)
            dx >= 0 && dy >= 0 -> '4'                        // 捺 / 点 (丶)
            dy < 0 && dx > 0 -> '1'                          // 提 (㇀)
            else -> '5'
        }
    }

    /**
     * 笔画方向柔性亲和度（消除手写中折笔 '5' 与横 '1'、竖 '2'、撇 '3' 临界互转导致的断崖式扣分）
     */
    private fun charDirSim(a: Char, b: Char): Float {
        if (a == b) return 1.0f
        if ((a == '5' && (b == '1' || b == '2' || b == '3')) ||
            (b == '5' && (a == '1' || a == '2' || a == '3'))
        ) {
            return 0.65f
        }
        if (((a == '2' || a == '3') && (b == '2' || b == '3')) ||
            ((a == '1' || a == '4') && (b == '1' || b == '4'))
        ) {
            return 0.35f
        }
        return 0.0f
    }

    /**
     * 动态规划柔性子序列匹配度（容忍连笔、拆笔及单笔临界方向波动）
     */
    private fun softSubseqScore(pat: String, txt: String): Float {
        val n = pat.length
        val m = txt.length
        if (n == 0 || m == 0) return 0f
        val dp = FloatArray((n + 1) * (m + 1))
        val stride = m + 1
        for (i in 1..n) {
            val pc = pat[i - 1]
            for (j in 1..m) {
                val v1 = dp[(i - 1) * stride + j]
                val v2 = dp[i * stride + (j - 1)]
                val v3 = dp[(i - 1) * stride + (j - 1)] + charDirSim(pc, txt[j - 1])
                dp[i * stride + j] = max(v1, max(v2, v3))
            }
        }
        return dp[n * stride + m] / max(n, m).toFloat()
    }

    private val CORE_STROKE_DICT: Map<String, List<String>> = mapOf(
        "1" to listOf("一", "十", "大", "不", "下"),
        "2" to listOf("丨", "十", "上", "中", "口"),
        "3" to listOf("人", "你", "我", "的", "八", "千"),
        "4" to listOf("、", "。", "之", "这", "永"),
        "5" to listOf("了", "子", "女", "好", "也"),
        "11" to listOf("二", "十", "干", "于", "云", "天", "王"),
        "12" to listOf("十", "丁", "下", "七", "土", "干", "大"),
        "24" to listOf("卜", "上", "小"),
        "21" to listOf("上", "止", "卜"),
        "32" to listOf("你", "他", "们", "什", "仁", "化", "休", "体"),
        "34" to listOf("人", "八", "入", "个", "父", "又"),
        "53" to listOf("刀", "力", "乃", "又", "九", "女", "好"),
        "35" to listOf("儿", "几", "九", "七", "月", "用"),
        "52" to listOf("了", "子", "卫", "也"),
        "55" to listOf("了", "子", "女", "双", "比", "孔"),
        "13" to listOf("厂", "大", "七", "不", "在", "有"),
        "15" to listOf("七", "丁", "了", "力", "买"),
        "111" to listOf("三", "王", "丰", "干"),
        "112" to listOf("干", "于", "土", "王", "工"),
        "121" to listOf("工", "土", "士", "上", "下"),
        "211" to listOf("上", "止"),
        "124" to listOf("下", "寸", "大", "才"),
        "134" to listOf("大", "丈", "犬", "太", "木"),
        "251" to listOf("口", "日", "山", "中", "国"),
        "252" to listOf("山", "巾", "口", "中"),
        "322" to listOf("川", "州", "顺"),
        "332" to listOf("川", "彡", "彳", "行", "很"),
        "222" to listOf("川", "山"),
        "511" to listOf("子", "女", "己", "已", "巳", "弓"),
        "521" to listOf("子", "孔", "女", "也", "卫"),
        "551" to listOf("子", "孔", "女", "好", "已"),
        "531" to listOf("女", "好", "她", "妈", "如", "子"),
        "234" to listOf("小", "水", "少"),
        "312" to listOf("千", "禾", "牛", "生", "我"),
        "441" to listOf("水", "江", "河", "没", "海"),
        "1121" to listOf("王", "天", "开", "井", "丰", "云"),
        "1134" to listOf("天", "夫", "木", "无", "元", "云"),
        "1344" to listOf("太", "犬", "木", "火"),
        "1234" to listOf("木", "不", "本", "术", "米"),
        "1324" to listOf("不", "木", "大", "在"),
        "2511" to listOf("日", "曰", "目", "田", "是"),
        "3511" to listOf("月", "用", "丹", "风", "的"),
        "2534" to listOf("水", "少", "中"),
        "2512" to listOf("中", "申", "由", "甲", "田"),
        "4334" to listOf("火", "心", "米"),
        "4544" to listOf("心", "必", "火"),
        "3112" to listOf("手", "毛", "牛", "生", "我"),
        "3121" to listOf("牛", "生", "午", "手", "我"),
        "4134" to listOf("文", "方", "六", "火"),
        "5215" to listOf("孔", "比", "巴", "双", "忆", "子"),
        "5515" to listOf("孔", "比", "巴", "双", "忆", "子"),
        "1215" to listOf("孔", "切", "功", "五", "元"),
        "1515" to listOf("孔", "切", "元", "五", "互"),
        "531521" to listOf("好", "如", "她", "妈", "妇"),
        "531551" to listOf("好", "如", "她", "妈", "妇"),
        "3235234" to listOf("你", "他", "们", "体", "休"),
        "3235334" to listOf("你", "他", "们", "体", "休"),
        "323524" to listOf("你", "他", "休", "体", "们"),
        "3121534" to listOf("我", "找", "成", "代")
    )

    /**
     * gugray/hanzi_lookup 核心算法：Ramer-Douglas-Peucker 折点分解，将单笔连折拆解为精确子笔画序列
     */
    private fun rdpSimplifyPoints(pts: List<StrokePoint>, eps: Float): List<StrokePoint> {
        if (pts.size <= 2) return pts
        val first = pts.first()
        val last = pts.last()
        val dx = last.x - first.x
        val dy = last.y - first.y
        val chord = hypot(dx, dy)
        var maxDist = -1f
        var maxIdx = 0
        for (i in 1 until pts.lastIndex) {
            val p = pts[i]
            val dist = if (chord < 1e-3f) {
                hypot(p.x - first.x, p.y - first.y)
            } else {
                abs((p.x - first.x) * dy - (p.y - first.y) * dx) / chord
            }
            if (dist > maxDist) {
                maxDist = dist
                maxIdx = i
            }
        }
        if (maxDist > eps && maxIdx > 0 && maxIdx < pts.lastIndex) {
            val left = rdpSimplifyPoints(pts.subList(0, maxIdx + 1), eps)
            val right = rdpSimplifyPoints(pts.subList(maxIdx, pts.size), eps)
            val combined = ArrayList<StrokePoint>(left.size + right.size - 1)
            for (i in 0 until left.lastIndex) combined.add(left[i])
            combined.addAll(right)
            return combined
        }
        return listOf(first, last)
    }

    private fun extractUserGugraySubstrokes(
        strokes: List<List<StrokePoint>>,
        minX: Float,
        minY: Float,
        bw: Float,
        bh: Float
    ): List<SubstrokeItem> {
        val span = max(bw, bh).coerceAtLeast(1f)
        val eps = max(span * 0.052f, 4f)
        val twoPi = 2f * Math.PI.toFloat()
        val out = ArrayList<SubstrokeItem>(strokes.size * 2)
        for (stroke in strokes) {
            if (stroke.isEmpty()) continue
            if (stroke.size == 1) {
                val cx = ((stroke[0].x - minX) / bw).coerceIn(0f, 1f)
                val cy = ((stroke[0].y - minY) / bh).coerceIn(0f, 1f)
                out.add(SubstrokeItem(0.785f, 0.08f, cx, cy))
                continue
            }
            val pivots = rdpSimplifyPoints(stroke, eps)
            for (i in 0 until pivots.lastIndex) {
                val p0 = pivots[i]
                val p1 = pivots[i + 1]
                val dx = p1.x - p0.x
                val dy = p1.y - p0.y
                val segLen = hypot(dx, dy)
                if (segLen < span * 0.025f && pivots.size > 2) continue
                var ang = atan2(dy, dx)
                if (ang < 0f) ang += twoPi
                val nLen = (segLen / span).coerceIn(0.03f, 1f)
                val cx = (((p0.x + p1.x) * 0.5f - minX) / bw).coerceIn(0f, 1f)
                val cy = (((p0.y + p1.y) * 0.5f - minY) / bh).coerceIn(0f, 1f)
                out.add(SubstrokeItem(ang, nLen, cx, cy))
                if (out.size >= 40) break
            }
            if (out.size >= 40) break
        }
        return out
    }

    /**
     * gugray/hanzi_lookup 子笔画动态规划匹配打分：
     * 综合子笔画方向角余弦相似度、归一化相对长度比、中心点 (cx, cy) 空间位置权重
     */
    private fun computeGugraySubstrokeScore(
        userSubs: List<SubstrokeItem>,
        tplSubs: Array<SubstrokeItem>
    ): Float {
        val n = userSubs.size
        val m = tplSubs.size
        if (n == 0 || m == 0) return 0f
        if (abs(n - m) > max(4, max(n, m) / 2)) return 0f
        val stride = m + 1
        val dp = FloatArray((n + 1) * stride)
        for (i in 1..n) {
            val u = userSubs[i - 1]
            for (j in 1..m) {
                val t = tplSubs[j - 1]
                val dTheta = abs(u.dirRad - t.dirRad)
                val cosDir = cos(dTheta)
                // 方向分: [-1, 1] 映射到 [0, 1]，同向为 1.0，正交为 0.35，反向为 0
                val dirScore = ((cosDir + 0.55f) / 1.55f).coerceIn(0f, 1f)
                // 长度比相似度
                val lenRatio = min(u.normLen, t.normLen) / max(u.normLen, t.normLen).coerceAtLeast(0.02f)
                val lenScore = 0.65f + 0.35f * lenRatio
                // 中心点距离衰减 (gugray: a substroke that is in the wrong place counts for less)
                val posDist = hypot(u.cxNorm - t.cxNorm, u.cyNorm - t.cyNorm)
                val posWeight = (1.0f - posDist * 0.52f).coerceIn(0.25f, 1.0f)

                val matchGain = dirScore * lenScore * posWeight
                val vSkipU = dp[(i - 1) * stride + j]
                val vSkipT = dp[i * stride + (j - 1)]
                val vMatch = dp[(i - 1) * stride + (j - 1)] + matchGain
                dp[i * stride + j] = max(vMatch, max(vSkipU, vSkipT))
            }
        }
        val raw = dp[n * stride + m] / max(n, m).toFloat()
        val countRatio = min(n, m).toFloat() / max(n, m).toFloat()
        return raw * (0.78f + 0.22f * countRatio)
    }

    fun recognizeHandwriting(strokes: List<List<StrokePoint>>, limit: Int = 28): List<String> {
        if (strokes.isEmpty()) return emptyList()

        // 1. 提取笔画方向串与包围盒
        val dirSb = StringBuilder(strokes.size)
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        var totalPts = 0

        for (stroke in strokes) {
            if (stroke.isEmpty()) continue
            dirSb.append(classifySingleStrokeDir(stroke))
            for (p in stroke) {
                if (p.x < minX) minX = p.x
                if (p.x > maxX) maxX = p.x
                if (p.y < minY) minY = p.y
                if (p.y > maxY) maxY = p.y
                totalPts++
            }
        }
        if (totalPts == 0) return emptyList()

        val dirCode = dirSb.toString()
        val bw = max(1f, maxX - minX)
        val bh = max(1f, maxY - minY)
        val userAspect = ((bw / bh) * 100f).roundToInt().coerceIn(10, 999)

        // 2. 将用户手写笔迹光栅化到 32x32 归一化画布，与模板坐标网格保持 1:1 严格一致
        val bmp = Bitmap.createBitmap(32, 32, Bitmap.Config.ALPHA_8)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 3.0f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        val scaleX: Float
        val scaleY: Float
        val offX: Float
        val offY: Float
        val ratio = bw / bh
        if (ratio > 2.2f) {
            val targetH = max(4f, 28f / min(ratio, 5.0f))
            scaleX = 28f / bw
            scaleY = targetH / bh
            offX = 2f
            offY = (32f - targetH) * 0.5f
        } else if (ratio < 0.45f) {
            val targetW = max(4f, 28f * max(ratio, 0.2f))
            scaleX = targetW / bw
            scaleY = 28f / bh
            offX = (32f - targetW) * 0.5f
            offY = 2f
        } else {
            scaleX = 28f / bw
            scaleY = 28f / bh
            offX = 2f
            offY = 2f
        }

        val userOrient = FloatArray(64)
        val path = Path()
        for (stroke in strokes) {
            if (stroke.isEmpty()) continue
            path.reset()
            val p0x = offX + (stroke[0].x - minX) * scaleX
            val p0y = offY + (stroke[0].y - minY) * scaleY
            path.moveTo(p0x, p0y)
            var prevX = p0x
            var prevY = p0y
            for (i in 1 until stroke.size) {
                val cx = offX + (stroke[i].x - minX) * scaleX
                val cy = offY + (stroke[i].y - minY) * scaleY
                path.lineTo(cx, cy)

                val dx = cx - prevX
                val dy = cy - prevY
                val segLen = hypot(dx, dy)
                if (segLen > 0.2f) {
                    val mx = ((prevX + cx) * 0.5f).toInt().coerceIn(0, 31)
                    val my = ((prevY + cy) * 0.5f).toInt().coerceIn(0, 31)
                    val gx = (mx / 8).coerceIn(0, 3)
                    val gy = (my / 8).coerceIn(0, 3)
                    val baseIdx = (gy * 4 + gx) * 4
                    userOrient[baseIdx + 0] += abs(dx)
                    userOrient[baseIdx + 1] += abs(dy)
                    userOrient[baseIdx + 2] += abs(dx + dy) * 0.7071f
                    userOrient[baseIdx + 3] += abs(dx - dy) * 0.7071f
                }
                prevX = cx
                prevY = cy
            }
            if (stroke.size == 1) {
                canvas.drawPoint(p0x, p0y, paint)
            } else {
                canvas.drawPath(path, paint)
            }
        }

        var maxO = 0f
        for (v in userOrient) if (v > maxO) maxO = v
        if (maxO > 1e-4f) {
            for (i in 0 until 64) userOrient[i] /= maxO
        }

        val rawDensity = FloatArray(64)
        for (gy in 0 until 8) {
            for (gx in 0 until 8) {
                var sum = 0f
                for (py in 0 until 4) {
                    for (px in 0 until 4) {
                        val a = Color.alpha(bmp.getPixel(gx * 4 + px, gy * 4 + py))
                        sum += a / 255f
                    }
                }
                rawDensity[gy * 8 + gx] = sum / 16f
            }
        }
        // 3x3 柔性空间平滑（容忍手写位置偏斜与字形松散，大幅提升手写与标准模板的重合度）
        val userDensity = FloatArray(64)
        var maxD = 0f
        for (gy in 0 until 8) {
            for (gx in 0 until 8) {
                var nbMax = 0f
                for (dy in -1..1) {
                    for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val nx = gx + dx
                        val ny = gy + dy
                        if (nx in 0..7 && ny in 0..7) {
                            val v = rawDensity[ny * 8 + nx]
                            if (v > nbMax) nbMax = v
                        }
                    }
                }
                val smoothed = rawDensity[gy * 8 + gx] * 0.66f + nbMax * 0.34f
                userDensity[gy * 8 + gx] = smoothed
                if (smoothed > maxD) maxD = smoothed
            }
        }
        if (maxD > 1e-4f) {
            for (i in 0 until 64) userDensity[i] /= maxD
        }

        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        // 3. 在 3793 汉字特征模板库中进行「余弦空间密度 + 方向场 + 精确笔画数 + 柔性DP子序列 + 词频」联合打分
        var uNormD = 0f
        var uNormO = 0f
        for (i in 0 until 64) {
            uNormD += userDensity[i] * userDensity[i]
            uNormO += userOrient[i] * userOrient[i]
        }
        uNormD = sqrt(uNormD).coerceAtLeast(1e-4f)
        uNormO = sqrt(uNormO).coerceAtLeast(1e-4f)

        val userGugraySubs = extractUserGugraySubstrokes(strokes, minX, minY, bw, bh)
        val coreTopList = CORE_STROKE_DICT[dirCode] ?: emptyList()
        class ScoredHw(val ch: String, val score: Float)
        val scored = ArrayList<ScoredHw>(hwTemplates.size)
        val nStrokes = strokes.size

        for (tpl in hwTemplates) {
            val sc = tpl.strokeCount
            val scDiff = if (sc > 0) abs(nStrokes - sc) else 0
            if (sc > 0) {
                if (nStrokes == 1 && sc > 3) continue
                if (nStrokes == 2 && sc > 6) continue
                if (nStrokes == 3 && scDiff > 3) continue
                if (nStrokes >= 4 && scDiff > max(3, (nStrokes * 0.50f).toInt())) continue
            }

            var dotD = 0f
            var tNormD = 0f
            var dotO = 0f
            var tNormO = 0f
            val td = tpl.density64
            val to = tpl.orient64
            for (i in 0 until 64) {
                val dv = td[i]
                val ov = to[i]
                dotD += userDensity[i] * dv
                tNormD += dv * dv
                dotO += userOrient[i] * ov
                tNormO += ov * ov
            }
            val simD = dotD / (uNormD * sqrt(tNormD).coerceAtLeast(1e-4f))
            val simO = dotO / (uNormO * sqrt(tNormO).coerceAtLeast(1e-4f))

            val aspectDiff = abs(userAspect - tpl.aspectCode).toFloat() / max(userAspect, tpl.aspectCode).coerceAtLeast(80).toFloat()
            val aspectPenalty = if (nStrokes <= 2) aspectDiff * 0.14f else aspectDiff * 0.04f

            var strokeBonus = 0f
            if (sc > 0) {
                when (scDiff) {
                    0 -> strokeBonus += 0.16f
                    1 -> strokeBonus += 0.08f
                    2 -> strokeBonus += 0.0f
                    else -> strokeBonus -= scDiff * 0.05f
                }
            }
            if (tpl.strokeDirs.isNotEmpty() && dirCode.isNotEmpty()) {
                val colonIdx = tpl.strokeDirs.indexOf(':')
                val fullDirs = if (colonIdx >= 0) tpl.strokeDirs.substring(0, colonIdx) else tpl.strokeDirs
                val wbZones = if (colonIdx >= 0 && colonIdx + 1 < tpl.strokeDirs.length) tpl.strokeDirs.substring(colonIdx + 1) else ""

                val firstExpected = when {
                    wbZones.isNotEmpty() -> wbZones[0]
                    fullDirs.isNotEmpty() -> fullDirs[0]
                    else -> ' '
                }
                if (firstExpected != ' ') {
                    strokeBonus += charDirSim(dirCode[0], firstExpected) * 0.09f
                }
                if (wbZones.isNotEmpty()) {
                    val coreWb = if (wbZones.length >= 4) wbZones.substring(0, 3) else wbZones
                    strokeBonus += softSubseqScore(coreWb, dirCode) * 0.11f
                    strokeBonus += charDirSim(wbZones[wbZones.length - 1], dirCode[dirCode.length - 1]) * 0.05f
                }
                if (fullDirs.isNotEmpty()) {
                    if (fullDirs == dirCode) {
                        strokeBonus += 0.20f
                    } else {
                        strokeBonus += softSubseqScore(fullDirs, dirCode) * 0.14f
                    }
                }
            }

            val coreIdx = coreTopList.indexOf(tpl.ch)
            if (coreIdx >= 0) {
                strokeBonus += max(0.04f, 0.14f - coreIdx * 0.025f)
            }

            val gugrayTpl = mmahSubstrokeMap[tpl.ch]
            val gugrayBonus = if (gugrayTpl != null && userGugraySubs.isNotEmpty()) {
                computeGugraySubstrokeScore(userGugraySubs, gugrayTpl.substrokes) * 0.34f
            } else {
                0f
            }

            val normWt = (tpl.weight.toFloat() / 100000f).coerceIn(0f, 1f)
            val freqBonus = normWt * sqrt(normWt) * 0.12f
            val userBoost = ((userFreqMap[tpl.ch] ?: 0).coerceAtMost(20)) * 0.008f

            val totalScore = simD * 0.44f + simO * 0.38f + gugrayBonus - aspectPenalty + strokeBonus + freqBonus + userBoost
            scored.add(ScoredHw(tpl.ch, totalScore))
        }

        scored.sortByDescending { it.score }

        for (item in scored) {
            if (seen.add(item.ch)) {
                result.add(item.ch)
                if (result.size >= limit) break
            }
        }
        coreTopList.forEach { w ->
            if (seen.add(w) && result.size < limit) result.add(w)
        }
        return result
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()

        fun parseAtOffset(startPos: Int): List<String> {
            val words = ArrayList<String>()
            try {
                val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var pos = startPos
                while (pos + 4 < bytes.size) {
                    val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                    val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                    pos += 4 + pyIdxBytesLen
                    if (samePyCount <= 0 || samePyCount > 2500 || pyIdxBytesLen > 256 || pos >= bytes.size) break
                    for (i in 0 until samePyCount) {
                        if (pos + 2 >= bytes.size) break
                        val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2
                        if (wordByteLen <= 0 || wordByteLen > 128 || pos + wordByteLen > bytes.size) break
                        val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                        pos += wordByteLen
                        if (pos + 2 > bytes.size) break
                        val extLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2 + extLen
                        if (word.all { it in '一'..'龥' } && word.length in 1..16) {
                            words.add(word)
                        }
                    }
                }
            } catch (_: Exception) {}
            return words
        }

        val primaryOffset = if ((bytes[4].toInt() and 0xFF) == 0x45) 0x26C4 else 0x2628
        val primaryWords = parseAtOffset(primaryOffset)
        if (primaryWords.size >= 5) return primaryWords.distinct()
        val fallbackOffset = if (primaryOffset == 0x2628) 0x26C4 else 0x2628
        val fallbackWords = if (bytes.size > fallbackOffset) parseAtOffset(fallbackOffset) else emptyList()
        return (if (fallbackWords.size > primaryWords.size) fallbackWords else primaryWords).distinct()
    }
}

/**
 * Google ML Kit Digital Ink Recognition (zh-Hani-CN) 神经网络手写识别管理器：
 * - 自动兼容 ML Kit 18.x (`com.google.mlkit.vision.digitalink.*`) 与 19.x (`com.google.mlkit.vision.digitalink.recognition.*`) 包路径；
 * - 首次进入手写板或启动输入法时，自动检查并后台静默下载 `zh-Hani-CN` 简体中文手写神经网络模型（约 18MB）；
 * - 模型未就绪或无网期间自动无缝使用 `gugray/hanzi_lookup` 子笔画引擎 + 离线特征引擎兜底；
 * - 模型就绪后，将带真实毫秒时间戳 `(x, y, t)` 的笔迹送入 Google 神经网络，毫秒级返回连笔/倒笔顺/复杂字候选并与离线双擎融合。
 */
object MlKitHandwritingManager {

    enum class ModelState {
        NOT_INITIALIZED,
        CHECKING,
        DOWNLOADING,
        READY,
        UNAVAILABLE
    }

    @Volatile
    var modelState: ModelState = ModelState.NOT_INITIALIZED
        private set

    private val isCheckingOrDownloading = AtomicBoolean(false)
    private val latestRequestSeq = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var cachedModel: Any? = null

    @Volatile
    private var cachedRecognizer: Any? = null

    private val statusListeners = ArrayList<(ModelState) -> Unit>()

    fun addStatusListener(listener: (ModelState) -> Unit) {
        synchronized(statusListeners) {
            if (!statusListeners.contains(listener)) {
                statusListeners.add(listener)
            }
        }
        listener(modelState)
    }

    fun removeStatusListener(listener: (ModelState) -> Unit) {
        synchronized(statusListeners) {
            statusListeners.remove(listener)
        }
    }

    private fun notifyState(newState: ModelState) {
        modelState = newState
        mainHandler.post {
            val copy = synchronized(statusListeners) { statusListeners.toList() }
            for (l in copy) {
                try {
                    l(newState)
                } catch (_: Exception) {}
            }
        }
    }

    private fun resolveDigitalInkClass(simpleName: String): Class<*>? {
        val prefixes = arrayOf(
            "com.google.mlkit.vision.digitalink.",
            "com.google.mlkit.vision.digitalink.recognition.",
            "com.google.mlkit.vision.digitalink.common."
        )
        for (p in prefixes) {
            try {
                return Class.forName(p + simpleName)
            } catch (_: Throwable) {}
        }
        return null
    }

    private fun awaitTask(taskObj: Any?): Any? {
        if (taskObj == null) return null
        val tasksCls = Class.forName("com.google.android.gms.tasks.Tasks")
        val taskInterface = Class.forName("com.google.android.gms.tasks.Task")
        val awaitMethod = tasksCls.getMethod("await", taskInterface)
        return awaitMethod.invoke(null, taskObj)
    }

    private fun getOrBuildRecognizerAndModel(): Pair<Any, Any>? {
        val existModel = cachedModel
        val existRec = cachedRecognizer
        if (existModel != null && existRec != null) {
            return existModel to existRec
        }
        synchronized(this) {
            val m2 = cachedModel
            val r2 = cachedRecognizer
            if (m2 != null && r2 != null) {
                return m2 to r2
            }
            try {
                val idCls = resolveDigitalInkClass("DigitalInkRecognitionModelIdentifier") ?: return null
                val modelCls = resolveDigitalInkClass("DigitalInkRecognitionModel") ?: return null
                val optsCls = resolveDigitalInkClass("DigitalInkRecognizerOptions") ?: return null
                val recEntryCls = resolveDigitalInkClass("DigitalInkRecognition") ?: return null

                val fromTagMethod = idCls.getMethod("fromLanguageTag", String::class.java)
                val modelId = fromTagMethod.invoke(null, "zh-Hani-CN")
                    ?: fromTagMethod.invoke(null, "zh-Hans-CN")
                    ?: fromTagMethod.invoke(null, "zh-CN")
                    ?: return null

                val modelBuilderMethod = modelCls.getMethod("builder", idCls)
                val modelBuilder = modelBuilderMethod.invoke(null, modelId) ?: return null
                val model = modelBuilder.javaClass.getMethod("build").invoke(modelBuilder) ?: return null

                val optsBuilderMethod = optsCls.getMethod("builder", modelCls)
                val optsBuilder = optsBuilderMethod.invoke(null, model) ?: return null
                val options = optsBuilder.javaClass.getMethod("build").invoke(optsBuilder) ?: return null

                val getClientMethod = recEntryCls.getMethod("getClient", optsCls)
                val recognizer = getClientMethod.invoke(null, options) ?: return null

                cachedModel = model
                cachedRecognizer = recognizer
                return model to recognizer
            } catch (_: Throwable) {
                return null
            }
        }
    }

    fun ensureModelReady(context: Context? = null, onReadyChanged: ((Boolean) -> Unit)? = null) {
        if (modelState == ModelState.READY && cachedRecognizer != null) {
            onReadyChanged?.invoke(true)
            return
        }
        if (!isCheckingOrDownloading.compareAndSet(false, true)) {
            return
        }
        notifyState(ModelState.CHECKING)

        Thread {
            try {
                val pair = getOrBuildRecognizerAndModel()
                if (pair == null) {
                    isCheckingOrDownloading.set(false)
                    notifyState(ModelState.UNAVAILABLE)
                    mainHandler.post { onReadyChanged?.invoke(false) }
                    return@Thread
                }
                val model = pair.first
                val rmmCls = Class.forName("com.google.mlkit.common.model.RemoteModelManager")
                val remoteModelCls = Class.forName("com.google.mlkit.common.model.RemoteModel")
                val rmm = rmmCls.getMethod("getInstance").invoke(null)
                if (rmm == null) {
                    isCheckingOrDownloading.set(false)
                    notifyState(ModelState.UNAVAILABLE)
                    mainHandler.post { onReadyChanged?.invoke(false) }
                    return@Thread
                }

                val isDownloadedTask = rmmCls.getMethod("isModelDownloaded", remoteModelCls).invoke(rmm, model)
                val downloaded = (awaitTask(isDownloadedTask) as? Boolean) == true
                if (downloaded) {
                    isCheckingOrDownloading.set(false)
                    notifyState(ModelState.READY)
                    mainHandler.post { onReadyChanged?.invoke(true) }
                } else {
                    notifyState(ModelState.DOWNLOADING)
                    val condCls = Class.forName("com.google.mlkit.common.model.DownloadConditions")
                    val condBuilderCls = Class.forName("com.google.mlkit.common.model.DownloadConditions\$Builder")
                    val condBuilder = condBuilderCls.getDeclaredConstructor().newInstance() ?: return@Thread
                    val conditions = condBuilderCls.getMethod("build").invoke(condBuilder) ?: return@Thread
                    val downloadTask = rmmCls.getMethod("download", remoteModelCls, condCls).invoke(rmm, model, conditions)
                    awaitTask(downloadTask)
                    isCheckingOrDownloading.set(false)
                    notifyState(ModelState.READY)
                    mainHandler.post { onReadyChanged?.invoke(true) }
                }
            } catch (_: Throwable) {
                isCheckingOrDownloading.set(false)
                notifyState(ModelState.UNAVAILABLE)
                mainHandler.post { onReadyChanged?.invoke(false) }
            }
        }.start()
    }

    fun recognizeAsync(
        strokes: List<List<StrokePoint>>,
        canvasWidth: Float = 0f,
        canvasHeight: Float = 0f,
        preContext: String? = null,
        maxCandidates: Int = 20,
        onResult: (List<String>) -> Unit
    ): Boolean {
        if (strokes.isEmpty()) return false
        if (modelState != ModelState.READY) {
            ensureModelReady()
            return false
        }
        val pair = getOrBuildRecognizerAndModel() ?: return false
        val recognizer = pair.second
        val reqId = latestRequestSeq.incrementAndGet()

        Thread {
            try {
                if (reqId != latestRequestSeq.get()) return@Thread
                val inkCls = resolveDigitalInkClass("Ink") ?: return@Thread
                val strokeCls = resolveDigitalInkClass("Ink\$Stroke") ?: resolveDigitalInkClass("Stroke") ?: return@Thread
                val pointCls = resolveDigitalInkClass("Ink\$Point") ?: resolveDigitalInkClass("Point") ?: return@Thread

                val inkBuilder = inkCls.getMethod("builder").invoke(null) ?: return@Thread
                val inkBuilderCls = inkBuilder.javaClass
                val addStrokeMethod: Method = inkBuilderCls.methods.firstOrNull {
                    it.name == "addStroke" && it.parameterTypes.size == 1
                } ?: return@Thread

                val strokeBuilderMethod = strokeCls.getMethod("builder")
                val createPointWithTime = pointCls.methods.firstOrNull {
                    it.name == "create" && it.parameterTypes.size == 3
                }
                val createPointNoTime = pointCls.methods.firstOrNull {
                    it.name == "create" && it.parameterTypes.size == 2
                }

                var syntheticClock = 1000L
                for (s in strokes) {
                    if (s.isEmpty()) continue
                    val sb = strokeBuilderMethod.invoke(null) ?: continue
                    val addPointMethod = sb.javaClass.methods.firstOrNull {
                        it.name == "addPoint" && it.parameterTypes.size == 1
                    } ?: continue
                    for (pt in s) {
                        val ts = if (pt.t > 0L) pt.t else {
                            syntheticClock += 16L
                            syntheticClock
                        }
                        val pObj = if (createPointWithTime != null) {
                            createPointWithTime.invoke(null, pt.x, pt.y, ts)
                        } else {
                            createPointNoTime?.invoke(null, pt.x, pt.y)
                        }
                        if (pObj != null) {
                            addPointMethod.invoke(sb, pObj)
                        }
                    }
                    syntheticClock += 120L
                    val builtStroke = sb.javaClass.getMethod("build").invoke(sb)
                    if (builtStroke != null) {
                        addStrokeMethod.invoke(inkBuilder, builtStroke)
                    }
                }

                val inkObj = inkBuilderCls.getMethod("build").invoke(inkBuilder) ?: return@Thread
                val recSimple = recognizer.javaClass.methods.firstOrNull {
                    it.name == "recognize" && it.parameterTypes.size == 1
                } ?: return@Thread

                val taskObj = recSimple.invoke(recognizer, inkObj)
                val resultObj = awaitTask(taskObj) ?: return@Thread
                if (reqId != latestRequestSeq.get()) return@Thread

                val candsList = resultObj.javaClass.getMethod("getCandidates").invoke(resultObj) as? List<*>
                if (candsList != null) {
                    val out = ArrayList<String>(maxCandidates)
                    val seen = HashSet<String>()
                    for (item in candsList) {
                        if (item == null) continue
                        val rawText = (item.javaClass.getMethod("getText").invoke(item) as? String)?.trim() ?: continue
                        if (rawText.isEmpty()) continue
                        if (seen.add(rawText)) {
                            out.add(rawText)
                        }
                        if (rawText.length > 1) {
                            for (ch in rawText) {
                                if (ch in '\u4E00'..'\u9FA5') {
                                    val s = ch.toString()
                                    if (seen.add(s)) out.add(s)
                                }
                            }
                        }
                        if (out.size >= maxCandidates) break
                    }
                    if (out.isNotEmpty()) {
                        mainHandler.post {
                            if (reqId == latestRequestSeq.get()) {
                                onResult(out)
                            }
                        }
                    }
                }
            } catch (_: Throwable) {}
        }.start()
        return true
    }
}
