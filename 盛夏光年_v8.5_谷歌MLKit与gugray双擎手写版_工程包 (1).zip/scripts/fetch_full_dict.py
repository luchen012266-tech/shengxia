#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pre-compiles 86 Wubi + Segmented Pinyin + T14 Codes + Word Associations + English Dictionary
+ gugray/hanzi_lookup (MakeMeAHanzi graphics.txt 3-byte substrokes: direction, length, centerXY) at build time.
Preserves pre-compiled offline dictionaries when network is unavailable.
"""
import os
import json
import math
import urllib.request
from collections import defaultdict

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
RIME_ICE_8105_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/8105.dict.yaml"
RIME_ICE_BASE_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/base.dict.yaml"
RIME_ICE_ENG_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/en_dicts/en.dict.yaml"
LUNA_PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"
MMAH_GRAPHICS_URL = "https://raw.githubusercontent.com/skishore/makemeahanzi/master/graphics.txt"

CHAR_TO_T14 = {
    'q': '1', 'w': '1',
    'e': '2', 'r': '2',
    't': '3', 'y': '3',
    'u': '4', 'i': '4',
    'o': '5', 'p': '5',
    'a': '6', 's': '6',
    'd': '7', 'f': '7',
    'g': '8', 'h': '8',
    'j': '9', 'k': '9',
    'l': '0',
    'z': 'a', 'x': 'a',
    'c': 'b', 'v': 'b',
    'b': 'c', 'n': 'c',
    'm': 'd'
}

def to_t14(s):
    return "".join(CHAR_TO_T14.get(c, "") for c in s.lower())

def to_t14_abbr(seg_py):
    if "'" not in seg_py:
        return ""
    return "".join(CHAR_TO_T14.get(p[0], "") for p in seg_py.split("'") if p)

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def clean_py_syllable(s):
    s = s.strip().lower()
    return "".join(ch for ch in s if 'a' <= ch <= 'z')

def parse_rime_yaml(lines):
    in_body = False
    for line in lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip()
            weight = -1
            if len(parts) >= 3:
                w_str = parts[2].strip().rstrip("%")
                try:
                    weight = int(float(w_str))
                except ValueError:
                    weight = -1
            yield word, code, weight

def rdp_simplify(pts, eps):
    if len(pts) <= 2:
        return pts
    first, last = pts[0], pts[-1]
    dx, dy = last[0] - first[0], last[1] - first[1]
    chord = math.hypot(dx, dy)
    max_dist = -1.0
    max_idx = 0
    for i in range(1, len(pts) - 1):
        px, py = pts[i]
        if chord < 1e-4:
            dist = math.hypot(px - first[0], py - first[1])
        else:
            dist = abs((px - first[0]) * dy - (py - first[1]) * dx) / chord
        if dist > max_dist:
            max_dist = dist
            max_idx = i
    if max_dist > eps:
        left = rdp_simplify(pts[:max_idx + 1], eps)
        right = rdp_simplify(pts[max_idx:], eps)
        return left[:-1] + right
    return [first, last]

def extract_gugray_substrokes_hex(medians):
    """
    Implements gugray/hanzi_lookup 3-byte substroke feature extraction from MakeMeAHanzi medians:
    - Byte 1: Direction in [0, 2*pi) normalized to 0..255
    - Byte 2: Substroke length normalized to 0..255 relative to bounding square span
    - Byte 3: Centerpoint (cx << 4) | cy where cx, cy in 0..15 within character bounding box
    """
    strokes_scr = []
    min_x, min_y = 1e9, 1e9
    max_x, max_y = -1e9, -1e9
    for st in medians:
        s_pts = []
        for p in st:
            sx = float(p[0])
            sy = 900.0 - float(p[1])
            s_pts.append((sx, sy))
            if sx < min_x: min_x = sx
            if sx > max_x: max_x = sx
            if sy < min_y: min_y = sy
            if sy > max_y: max_y = sy
        if s_pts:
            strokes_scr.append(s_pts)
    if not strokes_scr:
        return ""
    bw = max(1.0, max_x - min_x)
    bh = max(1.0, max_y - min_y)
    span = max(bw, bh, 1.0)
    eps = max(14.0, span * 0.048)

    hex_parts = []
    two_pi = 2.0 * math.pi
    for s_pts in strokes_scr:
        pivots = rdp_simplify(s_pts, eps)
        for i in range(len(pivots) - 1):
            x0, y0 = pivots[i]
            x1, y1 = pivots[i + 1]
            dx, dy = x1 - x0, y1 - y0
            seg_len = math.hypot(dx, dy)
            if seg_len < 4.0 and len(pivots) > 2:
                continue
            ang = math.atan2(dy, dx)
            if ang < 0.0:
                ang += two_pi
            dir_b = int(round((ang / two_pi) * 255.0)) & 0xFF
            len_b = min(255, max(1, int(round((seg_len / span) * 255.0))))
            mx = (x0 + x1) * 0.5
            my = (y0 + y1) * 0.5
            cx = min(15, max(0, int(((mx - min_x) / bw) * 15.99)))
            cy = min(15, max(0, int(((my - min_y) / bh) * 15.99)))
            center_b = ((cx & 0x0F) << 4) | (cy & 0x0F)
            hex_parts.append(f"{dir_b:02x}{len_b:02x}{center_b:02x}")
            if len(hex_parts) >= 64:
                break
        if len(hex_parts) >= 64:
            break
    return "".join(hex_parts)

def main():
    wubi_lines = download_lines(WUBI_URL)
    ice_8105_lines = download_lines(RIME_ICE_8105_URL)
    ice_base_lines = download_lines(RIME_ICE_BASE_URL)
    ice_eng_lines = download_lines(RIME_ICE_ENG_URL)
    luna_lines = download_lines(LUNA_PINYIN_URL)

    # 1. Compile English dictionary
    eng_words = []
    seen_eng = set()
    curated_en_path = os.path.join(ASSETS_DIR, "en_daily_words.txt")
    if os.path.exists(curated_en_path):
        with open(curated_en_path, "r", encoding="utf-8") as cf:
            for line in cf:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                w = parts[0].strip()
                wt = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 85000
                if w and w not in seen_eng:
                    seen_eng.add(w)
                    seen_eng.add(w.lower())
                    eng_words.append((wt, w))

    if ice_eng_lines:
        for word, code, weight in parse_rime_yaml(ice_eng_lines):
            clean_w = word.strip()
            if 2 <= len(clean_w) <= 20 and clean_w.isalpha() and clean_w.lower() not in seen_eng:
                seen_eng.add(clean_w.lower())
                eff_wt = weight if weight > 0 else max(500, 16000 - len(clean_w) * 700)
                eng_words.append((eff_wt, clean_w))

    eng_words.sort(key=lambda x: (-x[0], len(x[1]), x[1].lower()))
    if eng_words:
        eng_path = os.path.join(ASSETS_DIR, "english_words.tsv")
        with open(eng_path, "w", encoding="utf-8") as ef:
            for wt, w in eng_words[:30000]:
                ef.write(f"{w}\t{wt}\n")
        print(f"Compiled {min(len(eng_words), 30000)} English words!")

    # 2. Load existing pre-compiled single_char_wubi.tsv as fallback baseline
    single_char_py = {}
    single_char_py_wt = defaultdict(int)
    single_char_wubi = {}
    single_char_wubi_len = {}

    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    if os.path.exists(single_path):
        with open(single_path, "r", encoding="utf-8") as sf:
            for line in sf:
                parts = line.strip().split("\t")
                if len(parts) >= 2 and len(parts[0]) == 1:
                    ch = parts[0]
                    wc = parts[1].strip()
                    py = parts[2].strip() if len(parts) >= 3 else ""
                    if wc:
                        single_char_wubi[ch] = wc
                        single_char_wubi_len[ch] = len(wc)
                    if py:
                        single_char_py[ch] = py
                        single_char_py_wt[ch] = 100

    for word, code, weight in parse_rime_yaml(ice_8105_lines):
        if len(word) == 1 and '\u4e00' <= word <= '\u9fa5':
            py = clean_py_syllable(code)
            if py and weight >= single_char_py_wt[word]:
                single_char_py[word] = py
                single_char_py_wt[word] = max(weight, 1)

    word_py_map = {}

    def record_py_word(word, raw_code, weight, boost=1):
        if not all('\u4e00' <= c <= '\u9fa5' for c in word):
            return
        syls = [clean_py_syllable(p) for p in raw_code.split(" ") if clean_py_syllable(p)]
        if len(syls) != len(word):
            return
        seg_py = "'".join(syls)
        eff_wt = (weight if weight > 0 else max(300, 15000 - len(word) * 1800)) * boost
        if word not in word_py_map or eff_wt > word_py_map[word][1]:
            word_py_map[word] = (seg_py, eff_wt)
        if len(word) == 1 and eff_wt > single_char_py_wt[word]:
            single_char_py[word] = syls[0]
            single_char_py_wt[word] = eff_wt

    for word, code, weight in parse_rime_yaml(ice_base_lines):
        record_py_word(word, code, weight, boost=1)

    for word, code, weight in parse_rime_yaml(luna_lines):
        record_py_word(word, code, weight, boost=1)

    wubi_entries = []
    for word, code, weight in parse_rime_yaml(wubi_lines):
        if not all('\u4e00' <= c <= '\u9fa5' for c in word):
            continue
        code = code.lower()
        wubi_entries.append((word, code, weight))
        if len(word) == 1:
            if word not in single_char_wubi or len(code) >= single_char_wubi_len[word]:
                single_char_wubi[word] = code
                single_char_wubi_len[word] = len(code)

    def gen_wubi86(word):
        n = len(word)
        if n == 1:
            return single_char_wubi.get(word, "")
        codes = [single_char_wubi.get(c, "") for c in word]
        if any(not c for c in codes):
            return ""
        if n == 2:
            return codes[0][:2] + codes[1][:2]
        elif n == 3:
            return codes[0][:1] + codes[1][:1] + codes[2][:2]
        else:
            return codes[0][:1] + codes[1][:1] + codes[2][:1] + codes[-1][:1]

    def get_seg_py(word):
        if word in word_py_map:
            return word_py_map[word][0]
        pys = [single_char_py.get(c, "") for c in word]
        if all(pys):
            return "'".join(pys)
        return ""

    compiled_rows = []
    seen_words_for_py = set()

    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    if os.path.exists(out_path):
        with open(out_path, "r", encoding="utf-8") as wf:
            for line in wf:
                parts = line.strip().split("\t")
                if len(parts) >= 7:
                    word, wcode, seg_py = parts[0], parts[1], parts[2]
                    wt = int(parts[6]) if parts[6].isdigit() else 5000
                    compiled_rows.append((word, wcode, seg_py, wt))
                    seen_words_for_py.add(word)

    daily_path = os.path.join(ASSETS_DIR, "cn_daily_phrases.txt")
    if os.path.exists(daily_path):
        with open(daily_path, "r", encoding="utf-8") as df:
            rank_wt = 99500
            for line in df:
                w = line.strip()
                if not w or w.startswith("#") or w in seen_words_for_py:
                    continue
                if all('\u4e00' <= c <= '\u9fa5' for c in w):
                    wc = gen_wubi86(w)
                    spy = get_seg_py(w)
                    if wc or spy:
                        compiled_rows.append((w, wc, spy, rank_wt))
                        seen_words_for_py.add(w)
                        rank_wt = max(65000, rank_wt - 5)

    for idx, (word, wcode, weight) in enumerate(wubi_entries):
        seg_py = get_seg_py(word)
        seen_words_for_py.add(word)
        if weight < 0:
            py_wt = word_py_map.get(word, ("", 0))[1]
            if len(word) == 1:
                py_wt = max(py_wt, single_char_py_wt.get(word, 0))
            base_order_score = max(100, 95000 - idx)
            weight = base_order_score + min(50000, py_wt // 2)
        compiled_rows.append((word, wcode, seg_py, weight))

    extra_py_candidates = []
    for word, (seg_py, weight) in word_py_map.items():
        if word not in seen_words_for_py and 1 <= len(word) <= 8:
            extra_py_candidates.append((weight, word, seg_py))
    extra_py_candidates.sort(reverse=True)

    for weight, word, seg_py in extra_py_candidates[:26000]:
        wcode = gen_wubi86(word)
        if wcode or seg_py:
            compiled_rows.append((word, wcode, seg_py, weight))
            seen_words_for_py.add(word)

    compiled_rows.sort(key=lambda x: x[3], reverse=True)
    compiled_rows = compiled_rows[:82000]

    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, seg_py, weight in compiled_rows:
            t14_w = to_t14(wcode) if wcode else ""
            t14_p = to_t14(seg_py.replace("'", "")) if seg_py else ""
            t14_a = to_t14_abbr(seg_py)
            f.write(f"{word}\t{wcode}\t{seg_py}\t{t14_w}\t{t14_p}\t{t14_a}\t{weight}\n")

    assoc_map = defaultdict(list)
    for word, _, _, weight in compiled_rows:
        if len(word) >= 2:
            p1 = word[0]
            s1 = word[1:]
            if len(assoc_map[p1]) < 18 and s1 not in assoc_map[p1]:
                assoc_map[p1].append(s1)
            if len(word) >= 3:
                p2 = word[:2]
                s2 = word[2:]
                if len(assoc_map[p2]) < 14 and s2 not in assoc_map[p2]:
                    assoc_map[p2].append(s2)

    assoc_path = os.path.join(ASSETS_DIR, "assoc_dict.tsv")
    with open(assoc_path, "w", encoding="utf-8") as f:
        for prefix, suffixes in assoc_map.items():
            if suffixes:
                f.write(f"{prefix}\t{','.join(suffixes)}\n")

    with open(single_path, "w", encoding="utf-8") as f:
        all_chars = set(single_char_wubi.keys()) | set(single_char_py.keys())
        for ch in all_chars:
            wcode = single_char_wubi.get(ch, "")
            py = single_char_py.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    # 3. Enrich handwriting_strokes.tsv AND compile gugray/hanzi_lookup mmah_substrokes.tsv from MakeMeAHanzi graphics.txt
    hw_path = os.path.join(ASSETS_DIR, "handwriting_strokes.tsv")
    sub_path = os.path.join(ASSETS_DIR, "mmah_substrokes.tsv")
    mmah_lines = download_lines(MMAH_GRAPHICS_URL)
    if mmah_lines:
        def classify_pts(pts):
            if len(pts) < 2: return "4"
            first, last = pts[0], pts[-1]
            dx, dy = last[0] - first[0], last[1] - first[1]
            chord = math.hypot(dx, dy)
            plen = sum(math.hypot(pts[i][0]-pts[i-1][0], pts[i][1]-pts[i-1][1]) for i in range(1, len(pts)))
            if plen < 8.0: return "4"
            if len(pts) >= 3:
                low_idx = max(range(len(pts)), key=lambda i: pts[i][1])
                if 0 < low_idx < len(pts) - 1:
                    dxm, dym = pts[low_idx][0] - first[0], pts[low_idx][1] - first[1]
                    if dym > 12.0 and abs(dxm) < dym * 0.24 and last[0] < pts[low_idx][0]:
                        tlen = sum(math.hypot(pts[i][0]-pts[i-1][0], pts[i][1]-pts[i-1][1]) for i in range(low_idx+1, len(pts)))
                        if tlen < dym * 0.42: return "2"
            if chord > 1.0 and plen / chord > 1.28: return "5"
            if chord > 6.0:
                ux, uy = dx / chord, dy / chord
                mdev = max(abs((p[0]-first[0])*uy - (p[1]-first[1])*ux) for p in pts)
                if mdev / chord > 0.20: return "5"
            if len(pts) >= 3:
                mid = len(pts) // 2
                v1x, v1y = pts[mid][0] - first[0], pts[mid][1] - first[1]
                v2x, v2y = last[0] - pts[mid][0], last[1] - pts[mid][1]
                n1, n2 = math.hypot(v1x, v1y), math.hypot(v2x, v2y)
                if n1 > 4.0 and n2 > 4.0 and (v1x*v2x + v1y*v2y)/(n1*n2) < 0.68:
                    return "5"
            adx, ady = abs(dx), abs(dy)
            if dx < 0 and dy > 0 and adx > ady * 0.20: return "3"
            if dy > 0 and ady > adx * 2.15: return "2"
            if dx > 0 and adx > ady * 1.35: return "1"
            if dx < 0 and dy >= -adx * 0.25: return "3"
            if dx >= 0 and dy >= 0: return "4"
            if dy < 0 and dx > 0: return "1"
            return "5"

        mmah_dirs = {}
        mmah_sub_rows = []
        for ml in mmah_lines:
            try:
                obj = json.loads(ml)
                ch = obj.get("character", "")
                meds = obj.get("medians", [])
                if len(ch) == 1 and meds:
                    d_str = "".join(classify_pts([(p[0], 900.0 - p[1]) for p in stroke]) for stroke in meds)
                    mmah_dirs[ch] = (len(meds), d_str)
                    sub_hex = extract_gugray_substrokes_hex(meds)
                    if sub_hex:
                        mmah_sub_rows.append(f"{ch}\t{len(meds)}\t{sub_hex}")
            except Exception:
                pass

        if mmah_sub_rows:
            with open(sub_path, "w", encoding="utf-8") as sf:
                for r in mmah_sub_rows:
                    sf.write(r + "\n")
            print(f"Compiled {len(mmah_sub_rows)} gugray/hanzi_lookup MakeMeAHanzi substroke templates!")

        if mmah_dirs and os.path.exists(hw_path):
            updated_hw = []
            with open(hw_path, "r", encoding="utf-8") as hf:
                for line in hf:
                    if not line.strip(): continue
                    p = line.strip().split("\t")
                    ch = p[0]
                    if ch in mmah_dirs and len(p) >= 8:
                        sc_m, fdirs_m = mmah_dirs[ch]
                        old_sdirs = p[7]
                        wb_part = old_sdirs.split(":")[1] if ":" in old_sdirs else ""
                        p[6] = str(sc_m)
                        p[7] = f"{fdirs_m}:{wb_part}"
                    updated_hw.append("\t".join(p))
            with open(hw_path, "w", encoding="utf-8") as hf:
                for r in updated_hw:
                    hf.write(r + "\n")
            print(f"Enriched {len(updated_hw)} handwriting templates with MakeMeAHanzi stroke trajectories!")

    print(f"Pre-compiled {len(compiled_rows)} entries and {len(assoc_map)} association prefixes!")

if __name__ == "__main__":
    main()
