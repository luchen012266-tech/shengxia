package com.shengxiaguangnian.ime

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * 深空星盘（DeepStarFx）
 *
 * 1:1 复刻参考视频「深空特效.mp4」第 35~46 帧那个点击特效：
 *   一次点击 →
 *     ① 一颗圆润的五角星，淡紫填充 + 白色描边 + 多层外发光
 *     ② 星心是一个「星盘」：白环 + 十字刻度 + 八角星
 *     ③ 左上一弯月牙
 *     ④ 四周星尘（四角闪星 + 小圆点）随机闪烁
 *     ⑤ 两条淡紫丝带绕着星角飘
 *   全程约 420ms：弹出（带一点回弹）→ 停留 → 消散。
 *
 * 存在的意义：这套"徽章式"美术是用代码画出来的矢量图，
 * 不依赖图片资源，所以能跟着键盘底色自适应，也能被 .keyfx 里的
 * "emblem": "deep_star" 直接调用。
 */
object DeepStarFx {
    const val EMBLEM = "deep_star"
    const val DURATION_MS = 520

    private const val PI_F = 3.1415927f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val tmpPath = Path()
    private val tmpA = Path()
    private val tmpB = Path()
    private val rectF = RectF()

    /** 四周星尘：x, y（单位是外接半径的倍数）, 大小, 闪烁相位 */
    private val SPARKLES = floatArrayOf(
        0.96f, -0.74f, 0.135f, 0.00f,
        1.14f, -0.02f, 0.080f, 0.33f,
        0.92f, 0.74f, 0.085f, 0.71f,
        0.52f, 1.06f, 0.050f, 0.18f,
        -0.52f, 1.08f, 0.060f, 0.56f,
        -1.06f, 0.44f, 0.070f, 0.86f,
        -1.04f, -0.36f, 0.048f, 0.40f,
        0.30f, -1.04f, 0.058f, 0.12f,
        -0.34f, -1.02f, 0.044f, 0.63f,
        1.02f, 0.40f, 0.036f, 0.27f,
        -0.86f, 0.84f, 0.034f, 0.79f
    )

    /** 小圆点：x, y, 半径, 相位 */
    private val DOTS = floatArrayOf(
        0.62f, -0.52f, 0.014f, 0.10f,
        -0.30f, -0.70f, 0.011f, 0.45f,
        0.30f, 0.62f, 0.016f, 0.70f,
        -0.72f, 0.16f, 0.012f, 0.25f,
        0.10f, -0.36f, 0.009f, 0.88f,
        0.78f, 0.14f, 0.010f, 0.52f
    )

    /**
     * @param rect  这颗键的可绘制区域（已经含了 pad）
     * @param t     0..1 的进度
     * @param light 键盘是不是浅色底（浅底要把白色换成深紫，否则看不见）
     */
    fun draw(canvas: Canvas, rect: RectF, t: Float, surfaceBg: Int?) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX()
        val cy = rect.centerY()
        val R = min(rect.width(), rect.height()) * 0.5f * 0.58f
        if (R <= 1f) return

        // ---- 时间曲线：0.16 之前"噗"地弹出来，之后轻轻扩散、飘散 ----
        val inT = (t / 0.16f).coerceIn(0f, 1f)
        val spreadT = ((t - 0.16f) / 0.84f).coerceIn(0f, 1f)
        // 弹出用回弹，扩散用缓出：整体像 breathed out 一样张开
        val pop = 0.34f + 0.72f * easeOutBack(inT) + 0.14f * easeOutCube(spreadT)
        val driftY = -R * 0.10f * spreadT
        // 透明度：快速亮起 → 停留 → 后半段化开
        val fadeOut = smooth(0.34f, 1.0f, t)
        val alpha = (inT * (1f - fadeOut)).coerceIn(0f, 1f)
        if (alpha <= 0.01f) return

        // ---- 自动取色：跟着键盘底色走 ----
        val bg = surfaceBg ?: 0xFF8FA3D8.toInt()
        val light = isLight(bg)
        val hsv = FloatArray(3)
        Color.colorToHSV(bg, hsv)
        val h = hsv[0]
        val line = if (light) hsvC(h, 0.88f, 0.34f) else hsvC(h, 0.10f, 1.00f)
        val glow = if (light) hsvC(h, 0.72f, 0.72f) else hsvC(h, 0.42f, 1.00f)
        val haze = if (light) hsvC(h, 0.66f, 0.80f) else hsvC(h, 0.38f, 1.00f)

        canvas.save()
        canvas.translate(cx, cy + driftY)
        // 极轻的旋转，几乎察觉不到，只是让画面"活着"
        canvas.rotate(-3f + 6f * t)
        canvas.scale(pop, pop)

        starPath(tmpA, 0f, 0f, R, R * 0.45f, 5, -88f, 0.32f)

        // ---- 大范围光晕（轻盈感主要来自这层）----
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            0f, 0f, R * (1.30f + 0.35f * spreadT),
            intArrayOf(
                withA(glow, (alpha * 0.26f * 255f).toInt()),
                withA(glow, (alpha * 0.08f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.50f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, 0f, R * 1.6f, p)
        p.shader = null

        // ---- 星体内部薄雾（很淡，保持通透）----
        canvas.save()
        canvas.clipPath(tmpA)
        p.shader = RadialGradient(
            -R * 0.12f, R * 0.16f, R * 1.05f,
            intArrayOf(
                withA(haze, (alpha * 0.22f * 255f).toInt()),
                withA(haze, (alpha * 0.09f * 255f).toInt()),
                withA(haze, (alpha * 0.03f * 255f).toInt())
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(-R * 1.2f, -R * 1.2f, R * 1.2f, R * 1.2f, p)
        p.shader = null
        canvas.restore()

        // ---- 描边：柔和三层，不要生硬的白边 ----
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = R * 0.26f
        p.color = withA(glow, (alpha * 0.055f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.strokeWidth = R * 0.10f
        p.color = withA(glow, (alpha * 0.11f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.strokeWidth = R * 0.012f
        p.color = withA(line, (alpha * 0.72f * 255f).toInt())
        canvas.drawPath(tmpA, p)

        // ---- 丝带：跟着扩散慢慢张开 ----
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 2) {
            val gw = 1f + 0.25f * spreadT
            tmpPath.reset()
            if (i == 0) {
                tmpPath.moveTo(-R * 0.60f * gw, R * 0.84f * gw)
                tmpPath.cubicTo(
                    -R * 1.05f * gw, R * 0.28f,
                    -R * 0.96f * gw, -R * 0.52f,
                    -R * 0.40f * gw, -R * 0.96f * gw
                )
            } else {
                tmpPath.moveTo(R * 0.52f * gw, -R * 0.92f * gw)
                tmpPath.cubicTo(
                    R * 1.06f * gw, -R * 0.28f,
                    R * 1.00f * gw, R * 0.44f,
                    R * 0.48f * gw, R * 0.96f * gw
                )
            }
            p.strokeWidth = R * 0.05f
            p.color = withA(glow, (alpha * 0.07f * 255f).toInt())
            canvas.drawPath(tmpPath, p)
        }

        // ---- 星心星盘：前期亮，扩散时先化掉 ----
        val dialA = (alpha * (1f - smooth(0.15f, 0.62f, t))).coerceIn(0f, 1f)
        if (dialA > 0.02f) {
            val rr = R * 0.44f * (1f + 0.12f * spreadT)
            p.style = Paint.Style.STROKE
            p.strokeWidth = R * 0.08f
            p.color = withA(glow, (dialA * 0.06f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rr, p)

            p.strokeWidth = R * 0.008f
            p.color = withA(line, (dialA * 0.75f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rr, p)
            canvas.drawLine(-rr * 1.16f, 0f, rr * 1.16f, 0f, p)
            canvas.drawLine(0f, -rr * 1.12f, 0f, -rr * 0.66f, p)
            canvas.drawLine(0f, rr * 0.66f, 0f, rr * 1.12f, p)
            p.strokeWidth = R * 0.005f
            p.color = withA(line, (dialA * 0.30f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rr * 0.74f, p)

            canvas.save()
            canvas.rotate(t * 9f)
            starPath(tmpB, 0f, 0f, rr * 0.78f, rr * 0.16f, 8, -90f, 0.05f)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            for (k in 0 until 2) {
                p.strokeWidth = rr * (0.20f - k * 0.07f)
                p.color = withA(glow, (dialA * (0.05f + k * 0.05f) * 255f).toInt())
                canvas.drawPath(tmpB, p)
            }
            p.style = Paint.Style.FILL
            p.color = withA(line, (dialA * 0.85f * 255f).toInt())
            canvas.drawPath(tmpB, p)
            canvas.restore()
        }

        // ---- 月牙：前期在，扩散时淡出 ----
        val moonA = (alpha * (1f - smooth(0.10f, 0.55f, t))).coerceIn(0f, 1f)
        if (moonA > 0.02f) {
            canvas.save()
            canvas.translate(-R * 0.80f, -R * 0.66f)
            canvas.rotate(-28f)
            tmpA.reset()
            tmpA.addCircle(0f, 0f, R * 0.150f, Path.Direction.CW)
            tmpB.reset()
            tmpB.addCircle(R * 0.070f, 0f, R * 0.135f, Path.Direction.CW)
            tmpA.op(tmpB, Path.Op.DIFFERENCE)
            p.style = Paint.Style.STROKE
            p.strokeWidth = R * 0.06f
            p.color = withA(glow, (moonA * 0.08f * 255f).toInt())
            canvas.drawPath(tmpA, p)
            p.style = Paint.Style.FILL
            p.color = withA(line, (moonA * 0.80f * 255f).toInt())
            canvas.drawPath(tmpA, p)
            canvas.restore()
        }

        // ---- 星尘：从中心向外飞散，慢慢闪，不再高频抖 ----
        val fly = 0.40f + 0.85f * easeOutCube(spreadT)
        val sparkleFade = (alpha * (1f - smooth(0.30f, 1.0f, t))).coerceIn(0f, 1f)
        if (sparkleFade > 0.02f) {
            p.style = Paint.Style.FILL
            var i = 0
            while (i + 3 < SPARKLES.size) {
                val bx = SPARKLES[i] * R
                val by = SPARKLES[i + 1] * R
                val sz = SPARKLES[i + 2] * R
                val ph = SPARKLES[i + 3]
                // 慢速呼吸，一个周期只闪一次半，肉眼是"轻轻眨眼"而不是频闪
                val tw = 0.55f + 0.45f * ((sin((spreadT * 1.6f + ph) * 2f * PI_F) + 1f) * 0.5f)
                drawSparkle(
                    canvas, bx * fly, by * fly,
                    sz * (0.45f + 0.55f * tw) * (1.15f - 0.35f * spreadT),
                    sparkleFade, tw, line, glow
                )
                i += 4
            }
            i = 0
            while (i + 3 < DOTS.size) {
                val bx = DOTS[i] * R
                val by = DOTS[i + 1] * R
                val sz = DOTS[i + 2] * R
                val ph = DOTS[i + 3]
                val tw = 0.45f + 0.55f * ((sin((spreadT * 1.2f + ph) * 2f * PI_F) + 1f) * 0.5f)
                p.style = Paint.Style.FILL
                p.color = withA(line, (sparkleFade * tw * 0.75f * 255f).toInt())
                canvas.drawCircle(bx * fly, by * fly, sz * (1f + 0.5f * spreadT), p)
                i += 4
            }
        }

        canvas.restore()
    }

    private fun isLight(c: Int): Boolean {
        val lum = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        return lum > 0.62f
    }

    private fun hsvC(h: Float, s: Float, v: Float): Int =
        Color.HSVToColor(floatArrayOf(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun easeOutCube(x: Float): Float {
        val d = 1f - x
        return 1f - d * d * d
    }

    /** 一颗四角闪星（凹边），带一点点光晕 */
    private fun drawSparkle(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        alpha: Float, tw: Float, core: Int, halo: Int
    ) {
        if (r <= 0.4f) return
        sparklePath(tmpA, cx, cy, r, 0.22f)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.85f
        p.color = withA(halo, (alpha * tw * 0.18f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.style = Paint.Style.FILL
        p.color = withA(core, (alpha * tw * 255f).toInt())
        canvas.drawPath(tmpA, p)
    }

    /** 圆角星：k=0.5 很圆润，k 越小越尖 */
    private fun starPath(
        out: Path, cx: Float, cy: Float, outer: Float, inner: Float,
        points: Int, rotDeg: Float, k: Float
    ) {
        out.reset()
        val n = points * 2
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians((rotDeg + i * 180.0 / points))
            xs[i] = cx + (r * cos(a)).toFloat()
            ys[i] = cy + (r * sin(a)).toFloat()
        }
        var first = true
        for (i in 0 until n) {
            val pv = (i - 1 + n) % n
            val nv = (i + 1) % n
            val px = xs[i] + (xs[pv] - xs[i]) * k
            val py = ys[i] + (ys[pv] - ys[i]) * k
            val qx = xs[i] + (xs[nv] - xs[i]) * k
            val qy = ys[i] + (ys[nv] - ys[i]) * k
            if (first) {
                out.moveTo(px, py)
                first = false
            } else {
                out.lineTo(px, py)
            }
            out.quadTo(xs[i], ys[i], qx, qy)
        }
        out.close()
    }

    private fun sparklePath(out: Path, cx: Float, cy: Float, r: Float, k: Float) {
        out.reset()
        out.moveTo(cx, cy - r)
        out.quadTo(cx + r * k, cy - r * k, cx + r, cy)
        out.quadTo(cx + r * k, cy + r * k, cx, cy + r)
        out.quadTo(cx - r * k, cy + r * k, cx - r, cy)
        out.quadTo(cx - r * k, cy - r * k, cx, cy - r)
        out.close()
    }

    private fun withA(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val d = x - 1f
        return 1f + (c1 + 1f) * d * d * d + c1 * d * d
    }
}
