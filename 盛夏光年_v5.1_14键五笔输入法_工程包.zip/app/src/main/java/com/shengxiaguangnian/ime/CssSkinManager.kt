package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class SkinConfig(
    val kbBgTop: Int = Color.parseColor("#DCE0F0"),
    val kbBgBottom: Int = Color.parseColor("#E6E9F6"),

    val topBarBgTop: Int = Color.parseColor("#F4F6FD"),
    val topBarBgBottom: Int = Color.parseColor("#E8ECF9"),
    val topBarBorder: Int = Color.parseColor("#FFFFFF"),
    val topBarText: Int = Color.parseColor("#454C66"),
    val topBarDivider: Int = Color.parseColor("#CBD2EA"),
    val topBarRadiusDp: Int = 22,

    val keyBgTop: Int = Color.parseColor("#FAFBFF"),
    val keyBgBottom: Int = Color.parseColor("#EAEFF9"),
    val keyPressedBg: Int = Color.parseColor("#DCE2F4"),
    val keyBorder: Int = Color.parseColor("#FFFFFF"),
    val keyText: Int = Color.parseColor("#2A3042"),
    val keyHint: Int = Color.parseColor("#7E87A6"),
    val keyRadiusDp: Int = 15,

    val funcKeyBgTop: Int = Color.parseColor("#F1F4FC"),
    val funcKeyBgBottom: Int = Color.parseColor("#E2E7F5"),
    val funcKeyBorder: Int = Color.parseColor("#F8FAFF"),
    val funcKeyText: Int = Color.parseColor("#454C66"),

    val punctKeyBgTop: Int = Color.parseColor("#F6F4FF"),
    val punctKeyBgBottom: Int = Color.parseColor("#E8E4FA"),
    val punctKeyBorder: Int = Color.parseColor("#DCD4F8"),

    val candidateText: Int = Color.parseColor("#2A3042"),
    val candidateHighlight: Int = Color.parseColor("#6C5CE7")
)

object CssSkinManager {

    const val SAMPLE_CSS_TEMPLATE = """/* 盛夏光年 · 自定义 CSS 皮肤示例 */
.keyboard-bg {
  background: linear-gradient(#DCE0F0, #E6E9F6);
}

.top-bar {
  background: linear-gradient(#F4F6FD, #E8ECF9);
  border-color: #FFFFFF;
  border-radius: 22px;
  color: #454C66;
  divider-color: #CBD2EA;
}

.key {
  background: linear-gradient(#FAFBFF, #EAEFF9);
  pressed-background: #DCE2F4;
  border-color: #FFFFFF;
  border-radius: 15px;
  color: #2A3042;
  hint-color: #7E87A6;
}

.key-func {
  background: linear-gradient(#F1F4FC, #E2E7F5);
  border-color: #F8FAFF;
  color: #454C66;
}

.key-punct {
  background: linear-gradient(#F6F4FF, #E8E4FA);
  border-color: #DCD4F8;
}

.candidate-bar {
  color: #2A3042;
  highlight-color: #6C5CE7;
}"""

    private var cachedSkin: SkinConfig? = null

    fun getSkin(context: Context): SkinConfig {
        cachedSkin?.let { return it }
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val css = prefs.getString("custom_skin_css", "") ?: ""
        val skin = if (css.isBlank()) SkinConfig() else parseCss(css)
        cachedSkin = skin
        return skin
    }

    fun saveCustomCss(context: Context, css: String) {
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString("custom_skin_css", css.trim())
            .apply()
        cachedSkin = null
    }

    fun resetToDefaultSkin(context: Context) {
        saveCustomCss(context, "")
    }

    fun getSavedCss(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("custom_skin_css", "") ?: ""
        return saved.ifBlank { SAMPLE_CSS_TEMPLATE }
    }

    private fun parseColorSafe(raw: String, fallback: Int): Int {
        return try {
            val clean = raw.trim().removeSuffix(";").trim()
            Color.parseColor(clean)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun parseGradientOrSolid(raw: String, defaultTop: Int, defaultBottom: Int): Pair<Int, Int> {
        val clean = raw.trim().removeSuffix(";").trim()
        if (clean.startsWith("linear-gradient", ignoreCase = true)) {
            val inside = clean.substringAfter("(").substringBeforeLast(")")
            val hexes = Regex("#[0-9a-fA-F]{6,8}").findAll(inside).map { it.value }.toList()
            if (hexes.size >= 2) {
                return parseColorSafe(hexes[0], defaultTop) to parseColorSafe(hexes[1], defaultBottom)
            } else if (hexes.size == 1) {
                val c = parseColorSafe(hexes[0], defaultTop)
                return c to c
            }
        }
        val hexMatch = Regex("#[0-9a-fA-F]{6,8}").find(clean)?.value
        if (hexMatch != null) {
            val c = parseColorSafe(hexMatch, defaultTop)
            return c to c
        }
        return defaultTop to defaultBottom
    }

    fun parseCss(css: String): SkinConfig {
        var cfg = SkinConfig()
        val noComments = css.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "")
        val blockRegex = Regex("([.\\w-]+)\\s*\\{([^}]*)\\}")
        for (match in blockRegex.findAll(noComments)) {
            val selector = match.groupValues[1].trim().lowercase()
            val body = match.groupValues[2]
            val props = HashMap<String, String>()
            body.split(";").forEach { line ->
                val colon = line.indexOf(':')
                if (colon > 0) {
                    val k = line.substring(0, colon).trim().lowercase()
                    val v = line.substring(colon + 1).trim()
                    if (k.isNotEmpty() && v.isNotEmpty()) props[k] = v
                }
            }

            when (selector) {
                ".keyboard-bg", "body" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.kbBgTop, cfg.kbBgBottom)
                        cfg = cfg.copy(kbBgTop = t, kbBgBottom = b)
                    }
                }
                ".top-bar" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.topBarBgTop, cfg.topBarBgBottom)
                        cfg = cfg.copy(topBarBgTop = t, topBarBgBottom = b)
                    }
                    props["border-color"]?.let { cfg = cfg.copy(topBarBorder = parseColorSafe(it, cfg.topBarBorder)) }
                    props["color"]?.let { cfg = cfg.copy(topBarText = parseColorSafe(it, cfg.topBarText)) }
                    props["divider-color"]?.let { cfg = cfg.copy(topBarDivider = parseColorSafe(it, cfg.topBarDivider)) }
                    props["border-radius"]?.let {
                        val r = it.lowercase().removeSuffix("px").removeSuffix("dp").trim().toIntOrNull()
                        if (r != null) cfg = cfg.copy(topBarRadiusDp = r.coerceIn(4, 32))
                    }
                }
                ".key" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.keyBgTop, cfg.keyBgBottom)
                        cfg = cfg.copy(keyBgTop = t, keyBgBottom = b)
                    }
                    props["pressed-background"]?.let { cfg = cfg.copy(keyPressedBg = parseColorSafe(it, cfg.keyPressedBg)) }
                    props["border-color"]?.let { cfg = cfg.copy(keyBorder = parseColorSafe(it, cfg.keyBorder)) }
                    props["color"]?.let { cfg = cfg.copy(keyText = parseColorSafe(it, cfg.keyText)) }
                    props["hint-color"]?.let { cfg = cfg.copy(keyHint = parseColorSafe(it, cfg.keyHint)) }
                    props["border-radius"]?.let {
                        val r = it.lowercase().removeSuffix("px").removeSuffix("dp").trim().toIntOrNull()
                        if (r != null) cfg = cfg.copy(keyRadiusDp = r.coerceIn(4, 28))
                    }
                }
                ".key-func" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.funcKeyBgTop, cfg.funcKeyBgBottom)
                        cfg = cfg.copy(funcKeyBgTop = t, funcKeyBgBottom = b)
                    }
                    props["border-color"]?.let { cfg = cfg.copy(funcKeyBorder = parseColorSafe(it, cfg.funcKeyBorder)) }
                    props["color"]?.let { cfg = cfg.copy(funcKeyText = parseColorSafe(it, cfg.funcKeyText)) }
                }
                ".key-punct" -> {
                    props["background"]?.let {
                        val (t, b) = parseGradientOrSolid(it, cfg.punctKeyBgTop, cfg.punctKeyBgBottom)
                        cfg = cfg.copy(punctKeyBgTop = t, punctKeyBgBottom = b)
                    }
                    props["border-color"]?.let { cfg = cfg.copy(punctKeyBorder = parseColorSafe(it, cfg.punctKeyBorder)) }
                }
                ".candidate-bar" -> {
                    props["color"]?.let { cfg = cfg.copy(candidateText = parseColorSafe(it, cfg.candidateText)) }
                    props["highlight-color"]?.let { cfg = cfg.copy(candidateHighlight = parseColorSafe(it, cfg.candidateHighlight)) }
                }
            }
        }
        return cfg
    }

    fun makeGradientDrawable(
        topColor: Int,
        bottomColor: Int,
        radiusPx: Int,
        strokeColor: Int? = null,
        strokeWidthPx: Int = 0
    ): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topColor, bottomColor)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            if (strokeColor != null && strokeWidthPx > 0) {
                setStroke(strokeWidthPx, strokeColor)
            }
        }
    }
}
