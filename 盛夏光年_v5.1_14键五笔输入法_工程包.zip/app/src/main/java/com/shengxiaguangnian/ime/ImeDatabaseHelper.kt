package com.shengxiaguangnian.ime

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

data class ClipItem(
    val id: Long,
    val content: String,
    val isPinned: Boolean,
    val timestamp: Long
)

data class PhraseItem(
    val id: Long,
    val category: String,
    val content: String,
    val isStarred: Boolean,
    val lastUsed: Long
)

class ImeDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "shengxia_ime.db", null, 5) {

    companion object {
        const val MAX_CLIPBOARD_ITEMS = 300
        val DEFAULT_CATEGORIES = listOf("收藏", "最近", "邮", "号", "叮", "演", "扮", "模块", "api")
        private val dbExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS clipboard_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL UNIQUE ON CONFLICT REPLACE,
                is_pinned INTEGER DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrase_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                sort_order INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                is_starred INTEGER DEFAULT 0,
                last_used INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_dict (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                wubi_code TEXT NOT NULL,
                pinyin_code TEXT NOT NULL,
                t14_wubi TEXT NOT NULL,
                t14_pinyin TEXT NOT NULL,
                weight INTEGER DEFAULT 5000
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_wubi ON user_dict(t14_wubi)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_pinyin ON user_dict(t14_pinyin)")

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())

        createV3Tables(db)

        DEFAULT_CATEGORIES.forEachIndexed { idx, name ->
            val cv = ContentValues().apply {
                put("name", name)
                put("sort_order", idx)
            }
            db.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }

        val samplePhrases = listOf(
            Triple("演", "### 角色扮演规则指令：《盛夏光年》 **【核心世界观】** 这是一个支持无限字数、零截断的专属常用语模板，点击卡片直接全文上屏，点击右侧箭头可展开或编辑。", 1),
            Triple("模块", "【模块指令模板】可在此分类下存放常用的系统提示词模块与世界观插件，不限字数。", 1),
            Triple("api", "【API 快捷配置】可在此处存放常用的接口地址、模型名称或参数片段。", 0)
        )
        samplePhrases.forEach { (cat, text, starred) ->
            val cv = ContentValues().apply {
                put("category", cat)
                put("content", text)
                put("is_starred", starred)
                put("last_used", System.currentTimeMillis())
            }
            db.insert("phrases", null, cv)
        }
    }

    private fun createV3Tables(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_freq (
                word TEXT PRIMARY KEY,
                freq INTEGER NOT NULL DEFAULT 1,
                last_used INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_bigram (
                prev_word TEXT NOT NULL,
                next_word TEXT NOT NULL,
                freq INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (prev_word, next_word)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        createV3Tables(db)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())
    }

    fun recordWordUsageAsync(word: String, prevWord: String?) {
        dbExecutor.execute {
            try {
                val now = System.currentTimeMillis()
                val db = writableDatabase
                db.execSQL(
                    "INSERT INTO user_freq(word, freq, last_used) VALUES(?, 1, ?) ON CONFLICT(word) DO UPDATE SET freq = freq + 1, last_used = ?",
                    arrayOf<Any>(word, now, now)
                )
                if (!prevWord.isNullOrEmpty() && prevWord != word) {
                    db.execSQL(
                        "INSERT INTO user_bigram(prev_word, next_word, freq) VALUES(?, ?, 1) ON CONFLICT(prev_word, next_word) DO UPDATE SET freq = freq + 1",
                        arrayOf<Any>(prevWord, word)
                    )
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * 一键重置个人高频字词排序为默认出厂排序
     */
    fun resetUserFrequencySorting() {
        try {
            val db = writableDatabase
            db.delete("user_freq", null, null)
            db.delete("user_bigram", null, null)
        } catch (_: Exception) {}
    }

    fun loadUserFreqMap(): HashMap<String, Int> {
        val map = HashMap<String, Int>()
        try {
            readableDatabase.rawQuery("SELECT word, freq FROM user_freq", null).use { c ->
                while (c.moveToNext()) {
                    map[c.getString(0)] = c.getInt(1)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserBigramMap(): HashMap<String, MutableList<String>> {
        val map = HashMap<String, MutableList<String>>()
        try {
            readableDatabase.rawQuery(
                "SELECT prev_word, next_word FROM user_bigram ORDER BY freq DESC LIMIT 2000",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0)
                    val n = c.getString(1)
                    val list = map.getOrPut(p) { ArrayList() }
                    if (list.size < 10) list.add(n)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    // --- 自定义表情与颜文字增删查 ---
    fun addCustomExpression(typeCategory: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val cv = ContentValues().apply {
            put("category", typeCategory)
            put("text", clean)
        }
        writableDatabase.insertWithOnConflict("custom_kaomoji", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getCustomExpressions(typeCategory: String): List<String> {
        val list = ArrayList<String>()
        try {
            readableDatabase.rawQuery(
                "SELECT text FROM custom_kaomoji WHERE category = ? ORDER BY id DESC",
                arrayOf(typeCategory)
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(c.getString(0))
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteCustomExpression(text: String) {
        writableDatabase.delete("custom_kaomoji", "text = ?", arrayOf(text))
    }

    // --- 剪贴板与常用语一键导出 / 导入备份 (JSON) ---
    fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("app", "盛夏光年")
        root.put("version", 5)

        val catsArr = JSONArray()
        getCategories().forEach { catsArr.put(it) }
        root.put("categories", catsArr)

        val phrasesArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, content, is_starred, last_used FROM phrases ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("content", c.getString(1))
                    put("is_starred", c.getInt(2))
                    put("last_used", c.getLong(3))
                }
                phrasesArr.put(obj)
            }
        }
        root.put("phrases", phrasesArr)

        val clipsArr = JSONArray()
        readableDatabase.rawQuery("SELECT content, is_pinned, created_at FROM clipboard_history ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("content", c.getString(0))
                    put("is_pinned", c.getInt(1))
                    put("created_at", c.getLong(2))
                }
                clipsArr.put(obj)
            }
        }
        root.put("clipboard", clipsArr)

        val kaomojiArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, text FROM custom_kaomoji ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("text", c.getString(1))
                }
                kaomojiArr.put(obj)
            }
        }
        root.put("custom_expressions", kaomojiArr)

        return root.toString(2)
    }

    fun importBackupJson(jsonStr: String): Pair<Int, Int> {
        val root = JSONObject(jsonStr)
        var phraseCount = 0
        var clipCount = 0
        val db = writableDatabase
        db.beginTransaction()
        try {
            root.optJSONArray("categories")?.let { arr ->
                for (i in 0 until arr.length()) {
                    addCategory(arr.getString(i))
                }
            }
            root.optJSONArray("phrases")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val cat = obj.optString("category", "演")
                    val content = obj.optString("content", "")
                    val starred = obj.optInt("is_starred", 0) == 1
                    if (content.isNotBlank()) {
                        addCategory(cat)
                        addOrUpdatePhrase(null, cat, content, starred)
                        phraseCount++
                    }
                }
            }
            root.optJSONArray("clipboard")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val content = obj.optString("content", "")
                    val pinned = obj.optInt("is_pinned", 0)
                    val createdAt = obj.optLong("created_at", System.currentTimeMillis())
                    if (content.isNotBlank()) {
                        val cv = ContentValues().apply {
                            put("content", content)
                            put("is_pinned", pinned)
                            put("created_at", createdAt)
                        }
                        db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                        clipCount++
                    }
                }
            }
            root.optJSONArray("custom_expressions")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    addCustomExpression(obj.optString("category", "kaomoji"), obj.optString("text", ""))
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return phraseCount to clipCount
    }

    fun addClip(text: String) {
        if (text.isBlank()) return
        dbExecutor.execute {
            try {
                val db = writableDatabase
                var pinned = 0
                db.rawQuery("SELECT is_pinned FROM clipboard_history WHERE content = ?", arrayOf(text)).use { c ->
                    if (c.moveToFirst()) pinned = c.getInt(0)
                }
                val cv = ContentValues().apply {
                    put("content", text)
                    put("is_pinned", pinned)
                    put("created_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

                db.execSQL("""
                    DELETE FROM clipboard_history
                    WHERE is_pinned = 0 AND id NOT IN (
                        SELECT id FROM clipboard_history
                        ORDER BY is_pinned DESC, created_at DESC
                        LIMIT $MAX_CLIPBOARD_ITEMS
                    )
                """.trimIndent())
            } catch (_: Exception) {}
        }
    }

    fun getClips(): List<ClipItem> {
        val list = mutableListOf<ClipItem>()
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history ORDER BY is_pinned DESC, created_at DESC LIMIT $MAX_CLIPBOARD_ITEMS",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(ClipItem(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getLong(3)))
            }
        }
        return list
    }

    fun toggleClipPin(id: Long, currentPinned: Boolean) {
        val cv = ContentValues().apply { put("is_pinned", if (currentPinned) 0 else 1) }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteClip(id: Long) {
        writableDatabase.delete("clipboard_history", "id = ?", arrayOf(id.toString()))
    }

    fun clearUnpinnedClips() {
        writableDatabase.delete("clipboard_history", "is_pinned = 0", null)
    }

    fun getCategories(): List<String> {
        val list = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM phrase_categories ORDER BY sort_order ASC, id ASC", null).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        if (!list.contains("收藏")) list.add(0, "收藏")
        if (!list.contains("最近")) list.add(1, "最近")
        return list.distinct()
    }

    fun addCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("name", trimmed)
            put("sort_order", 99)
        }
        writableDatabase.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun deleteCategory(name: String) {
        if (name == "收藏" || name == "最近") return
        writableDatabase.delete("phrase_categories", "name = ?", arrayOf(name))
        writableDatabase.delete("phrases", "category = ?", arrayOf(name))
    }

    fun getPhrasesByCategory(category: String): List<PhraseItem> {
        val list = mutableListOf<PhraseItem>()
        val query = when (category) {
            "收藏" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE is_starred = 1 ORDER BY id DESC"
            "最近" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE last_used > 0 ORDER BY last_used DESC LIMIT 50"
            else -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE category = ? ORDER BY is_starred DESC, id DESC"
        }
        val args = if (category == "收藏" || category == "最近") null else arrayOf(category)
        readableDatabase.rawQuery(query, args).use { c ->
            while (c.moveToNext()) {
                list.add(PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4)))
            }
        }
        return list
    }

    fun addOrUpdatePhrase(id: Long?, category: String, content: String, isStarred: Boolean) {
        if (content.isBlank()) return
        val targetCat = if (category == "收藏" || category == "最近") "演" else category
        val cv = ContentValues().apply {
            put("category", targetCat)
            put("content", content)
            put("is_starred", if (isStarred || category == "收藏") 1 else 0)
            put("last_used", System.currentTimeMillis())
        }
        if (id == null || id <= 0L) {
            writableDatabase.insert("phrases", null, cv)
        } else {
            writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
        }
    }

    fun togglePhraseStar(id: Long, currentStarred: Boolean) {
        val cv = ContentValues().apply { put("is_starred", if (currentStarred) 0 else 1) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun markPhraseUsed(id: Long) {
        val cv = ContentValues().apply { put("last_used", System.currentTimeMillis()) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deletePhrase(id: Long) {
        writableDatabase.delete("phrases", "id = ?", arrayOf(id.toString()))
    }

    fun insertUserWord(word: String, wubiCode: String, pinyinCode: String, weight: Int = 6000) {
        val cleanPy = pinyinCode.replace("'", "")
        val t14Wubi = T14WubiEngine.letterToT14Code(wubiCode)
        val t14Pinyin = T14WubiEngine.letterToT14Code(cleanPy)
        val cv = ContentValues().apply {
            put("word", word)
            put("wubi_code", wubiCode)
            put("pinyin_code", pinyinCode)
            put("t14_wubi", t14Wubi)
            put("t14_pinyin", t14Pinyin)
            put("weight", weight)
        }
        writableDatabase.insert("user_dict", null, cv)
        T14WubiEngine.markUserDictDirty()
    }
}
