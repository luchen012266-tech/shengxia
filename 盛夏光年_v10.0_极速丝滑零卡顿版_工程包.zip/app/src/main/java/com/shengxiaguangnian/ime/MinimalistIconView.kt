package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt



/**
 * 三大字体模块独立导入与缓存管理器：
 * 1. SLOT_ENG ("font_eng.ttf")：按键英文字母与数字字体
 * 2. SLOT_CAND ("font_cand.ttf")：中文候选词与状态栏字体
 * 3. SLOT_ENTER ("font_enter.ttf")：右下角自定义文字（如“盛夏光年”）专属字体
 */
object CustomFontManager {
    const val SLOT_ENG = "eng"
    const val SLOT_CAND = "cand"
    const val SLOT_ENTER = "enter"

    private var cachedEngTs: Long = -1L
    private var cachedCandTs: Long = -1L
    private var cachedEnterTs: Long = -1L

    private var engTypeface: Typeface? = null
    private var candTypeface: Typeface? = null
    private var enterTypeface: Typeface? = null

    fun getFontFile(context: Context, slot: String): File {
        return File(context.filesDir, "custom_font_$slot.ttf")
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_eng", 0L) xor
            (prefs.getLong("font_ts_cand", 0L) shl 1) xor
            (prefs.getLong("font_ts_enter", 0L) shl 2)
    }

    fun hasCustomFont(context: Context, slot: String): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_$slot", 0L) > 0L && getFontFile(context, slot).exists()
    }

    fun getCustomFontName(context: Context, slot: String): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("font_name_$slot", "未导入（使用系统默认）") ?: "未导入（使用系统默认）"
    }

    fun clearCustomFont(context: Context, slot: String) {
        try {
            getFontFile(context, slot).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("font_ts_$slot", 0L)
            .remove("font_name_$slot")
            .apply()
        synchronized(this) {
            when (slot) {
                SLOT_ENG -> { cachedEngTs = 0L; engTypeface = null }
                SLOT_CAND -> { cachedCandTs = 0L; candTypeface = null }
                SLOT_ENTER -> { cachedEnterTs = 0L; enterTypeface = null }
            }
        }
    }

    fun getEngKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_eng", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedEngTs && engTypeface != null) return engTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENG)
            if (f.exists()) {
                try {
                    engTypeface = Typeface.createFromFile(f)
                    cachedEngTs = ts
                    return engTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getCandidateTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_cand", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedCandTs && candTypeface != null) return candTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_CAND)
            if (f.exists()) {
                try {
                    candTypeface = Typeface.createFromFile(f)
                    cachedCandTs = ts
                    return candTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getEnterKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_enter", 0L)
        if (ts <= 0L) return getCandidateTypeface(context)
        if (ts == cachedEnterTs && enterTypeface != null) return enterTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENTER)
            if (f.exists()) {
                try {
                    enterTypeface = Typeface.createFromFile(f)
                    cachedEnterTs = ts
                    return enterTypeface!!
                } catch (_: Exception) {}
            }
            return getCandidateTypeface(context)
        }
    }
}


/**
 * 基于 OKLCH 感知均匀色彩空间的按键背光自动取色器：
 * - 完全独立于现有的 KeyboardBacklightOverlayView 光晕动画与双层渐变绘制；
 * - 直接根据单键最终生效的背景色（含按排配色、单键独立配色、随机跳色）计算背光色；
 * - 不设死板的统一饱和度下限，采用「比例温和增益 + 软上限压缩（Soft-Knee）」，保留浅色系的呼吸层次感；
 * - 针对人眼最敏感的绿/黄绿波段（Hue 100°~165°）施加平滑色度阻尼，根治荧光绿，同时绝不压低明度 L 导致浅粉/焦糖变灰；
 * - 自动区分浅色皮肤与深色皮肤（如暗夜黑金）：当检测到深色按键或深黑底板时，自动开启「暗底逆向提亮 + 暖珀流金」模式。
 */
object OklchBacklightExtractor {

    fun extractGlowColor(
        finalKeyBgColor: Int,
        kbBgColor: Int = Color.WHITE,
        themeTintColor: Int = Color.WHITE,
        explicitCssGlowColor: Int? = null
    ): Int {
        explicitCssGlowColor?.let { return it }

        val r = Color.red(finalKeyBgColor) / 255.0
        val g = Color.green(finalKeyBgColor) / 255.0
        val b = Color.blue(finalKeyBgColor) / 255.0

        val tr = Color.red(themeTintColor) / 255.0
        val tg = Color.green(themeTintColor) / 255.0
        val tb = Color.blue(themeTintColor) / 255.0

        val (l, c, hDeg) = srgbToOklch(r, g, b)
        val (_, themeC, themeHDeg) = srgbToOklch(tr, tg, tb)

        // 1. 深色按键 (L < 0.45，如黑粉皮肤的第3排深紫灰键、黑色功能键，或黑金皮肤的深黑功能键)：
        //    彻底移除写死的金色！若深色键自身色度较低 (c < 0.032)，自动借用当前皮肤的主色调色相 themeHDeg
        //    （黑粉皮肤自动发柔和樱花粉光晕，黑金皮肤自动发香槟金光晕，绝不串色！）
        if (l < 0.45) {
            val effectiveHue = when {
                c < 0.026 && themeC >= 0.014 -> themeHDeg
                c < 0.038 && themeC >= 0.018 -> blendHueDegrees(hDeg, themeHDeg, 0.55)
                else -> hDeg
            }
            val liftedL = (l + 0.42).coerceIn(0.76, 0.83)
            val baseC = max(c, themeC * 0.85)
            val liftedC = (baseC * 1.45 + 0.032).coerceIn(0.072, 0.110)
            return oklchToSrgbColor(liftedL, liftedC, effectiveHue)
        }

        // 2. 极低色度纯白/纯灰键 (C < 0.012)：若当前皮肤有明确主题色相则轻柔借用主题色相，否则给出清透冰蓝微光
        if (c < 0.012) {
            if (themeC >= 0.015) {
                val borrowedC = (themeC * 1.35 + 0.025).coerceIn(0.055, 0.088)
                return oklchToSrgbColor(0.84, borrowedC, themeHDeg)
            }
            return Color.parseColor("#B6CDF2")
        }

        // 3. 计算绿/黄绿敏感色相区的柔性色度上限（Hue 在 105°~165° 之间时人眼对绿光最敏感，软上限收敛防荧光）
        val greenSensitivity = when {
            hDeg in 105.0..165.0 -> {
                val distFromPeak = kotlin.math.abs(hDeg - 135.0) / 30.0
                1.0 - 0.28 * (1.0 - distFromPeak.coerceIn(0.0, 1.0))
            }
            else -> 1.0
        }

        val maxChromaCap = 0.128 * greenSensitivity

        // 4. 比例柔性色度增益（彻底移除 isDarkTheme 写死金色逻辑！让黑粉皮肤第1排浅粉键 #F0D8E5 忠实绽放樱花粉光晕，
        //    黑金皮肤暖杏仁白键 #FAF3E6 忠实绽放暖金光晕）
        val boostedC = if (l >= 0.80) {
            val rawC = c * 1.95 + 0.036
            softKneeCompress(rawC, maxChromaCap * 0.88, maxChromaCap)
        } else {
            val rawC = c * 1.22 + 0.020
            softKneeCompress(rawC, maxChromaCap * 0.85, maxChromaCap)
        }

        // 5. 感知明度 L 校正：绝不把浅色压暗成水泥灰！
        val targetL = when {
            l >= 0.85 -> (l * 0.93).coerceIn(0.82, 0.89)
            l >= 0.65 -> (l * 1.04).coerceIn(0.76, 0.86)
            else -> (l + 0.14).coerceIn(0.70, 0.80)
        }

        return oklchToSrgbColor(targetL, boostedC, hDeg)
    }

    private fun blendHueDegrees(h1: Double, h2: Double, ratioH2: Double): Double {
        val r1 = Math.toRadians(h1)
        val r2 = Math.toRadians(h2)
        val x = (1.0 - ratioH2) * cos(r1) + ratioH2 * cos(r2)
        val y = (1.0 - ratioH2) * sin(r1) + ratioH2 * sin(r2)
        var deg = Math.toDegrees(atan2(y, x))
        if (deg < 0.0) deg += 360.0
        return deg
    }

    private fun softKneeCompress(x: Double, knee: Double, maxVal: Double): Double {
        if (x <= knee) return x
        val excess = x - knee
        val span = (maxVal - knee).coerceAtLeast(0.005)
        return knee + span * (excess / (excess + span))
    }

    private fun srgbToLinear(v: Double): Double {
        return if (v <= 0.04045) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun linearToSrgb(v: Double): Double {
        val clamped = v.coerceIn(0.0, 1.0)
        return if (clamped <= 0.0031308) 12.92 * clamped else 1.055 * clamped.pow(1.0 / 2.4) - 0.055
    }

    private fun srgbToOklch(r: Double, g: Double, b: Double): Triple<Double, Double, Double> {
        val lr = srgbToLinear(r)
        val lg = srgbToLinear(g)
        val lb = srgbToLinear(b)

        val l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb)
        val m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb)
        val s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb)

        val okL = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
        val okA = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
        val okB = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s

        val c = hypot(okA, okB)
        var h = Math.toDegrees(atan2(okB, okA))
        if (h < 0.0) h += 360.0
        return Triple(okL, c, h)
    }

    private fun oklchToSrgbColor(l: Double, c: Double, hDeg: Double): Int {
        val hRad = Math.toRadians(hDeg)
        val okA = c * cos(hRad)
        val okB = c * sin(hRad)

        val l_ = l + 0.3963377774 * okA + 0.2158037573 * okB
        val m_ = l - 0.1055613458 * okA - 0.0638541728 * okB
        val s_ = l - 0.0894841775 * okA - 1.2914855480 * okB

        val lCube = l_ * l_ * l_
        val mCube = m_ * m_ * m_
        val sCube = s_ * s_ * s_

        val lr = +4.0767416621 * lCube - 3.3077115913 * mCube + 0.2309699292 * sCube
        val lg = -1.2684380046 * lCube + 2.6097574011 * mCube - 0.3413193965 * sCube
        val lb = -0.0041960863 * lCube - 0.7034186147 * mCube + 1.7076147010 * sCube

        val sr = (linearToSrgb(lr) * 255.0).toInt().coerceIn(0, 255)
        val sg = (linearToSrgb(lg) * 255.0).toInt().coerceIn(0, 255)
        val sb = (linearToSrgb(lb) * 255.0).toInt().coerceIn(0, 255)
        return Color.rgb(sr, sg, sb)
    }
}


/**
 * 零延迟按键敲击音效管理器（内置用户提供的清脆敲击音 key_click.wav，支持设置页 Switch 自由开关）
 */
object KeySoundManager {
    private const val CUSTOM_SOUND_FILE = "custom_key_sound.dat"
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    @Volatile
    private var loaded = false
    @Volatile
    private var loadedSoundTs: Long = -1L
    @Volatile
    private var cachedSoundEnabled: Boolean? = null
    @Volatile
    private var cachedCustomSoundTs: Long = -1L
    private val soundExecutor = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "ShengXia-KeySound").apply { isDaemon = true }
    }

    fun syncSoundPrefs(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        cachedSoundEnabled = prefs.getBoolean("key_sound_enabled", true)
        cachedCustomSoundTs = prefs.getLong("custom_sound_ts", 0L)
    }

    fun setSoundEnabledCached(enabled: Boolean) {
        cachedSoundEnabled = enabled
    }

    fun getCustomSoundFile(context: Context): File = File(context.filesDir, CUSTOM_SOUND_FILE)

    fun hasCustomSound(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_sound_ts", 0L) > 0L && getCustomSoundFile(context).exists()
    }

    fun getCustomSoundName(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("custom_sound_name", "自定义音效") ?: "自定义音效"
    }

    fun clearCustomSound(context: Context) {
        try {
            getCustomSoundFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_sound_ts", 0L)
            .remove("custom_sound_name")
            .apply()
        reloadSound(context)
    }

    fun reloadSound(context: Context) {
        synchronized(this) {
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            soundPool = null
            clickSoundId = 0
            loaded = false
            loadedSoundTs = -1L
            ensureInitialized(context)
        }
    }

    fun ensureInitialized(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val curTs = prefs.getLong("custom_sound_ts", 0L)
        if (soundPool != null && curTs == loadedSoundTs) return
        synchronized(this) {
            if (soundPool != null && curTs == loadedSoundTs) return
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            loaded = false
            clickSoundId = 0
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val sp = SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(attrs)
                    .build()
                sp.setOnLoadCompleteListener { pool, sampleId, status ->
                    if (status == 0 && sampleId == clickSoundId) {
                        loaded = true
                        if (pendingPreviewPlay) {
                            pendingPreviewPlay = false
                            pool.play(clickSoundId, 0.90f, 0.90f, 1, 0, 1.0f)
                        }
                    }
                }
                val customFile = getCustomSoundFile(context)
                clickSoundId = if (curTs > 0L && customFile.exists()) {
                    sp.load(customFile.absolutePath, 1)
                } else {
                    context.assets.openFd("key_click.wav").use { afd ->
                        sp.load(afd, 1)
                    }
                }
                soundPool = sp
                loadedSoundTs = curTs
            } catch (_: Exception) {}
        }
    }

    @Volatile
    private var pendingPreviewPlay = false

    fun playClick(context: Context, forcePreview: Boolean = false) {
        try {
            val enabled = cachedSoundEnabled ?: run {
                syncSoundPrefs(context)
                cachedSoundEnabled ?: true
            }
            if (!forcePreview && !enabled) return
            val sp = soundPool
            val sid = clickSoundId
            if (sp != null && loaded && sid != 0 && cachedCustomSoundTs == loadedSoundTs) {
                soundExecutor.execute {
                    try {
                        sp.play(sid, 0.88f, 0.88f, 1, 0, 1.0f)
                    } catch (_: Exception) {}
                }
                return
            }
            val appCtx = context.applicationContext
            soundExecutor.execute {
                try {
                    ensureInitialized(appCtx)
                    val pool = soundPool ?: return@execute
                    if (loaded && clickSoundId != 0) {
                        pool.play(clickSoundId, 0.88f, 0.88f, 1, 0, 1.0f)
                    } else if (forcePreview) {
                        pendingPreviewPlay = true
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }
}

/**
 * 纯色框架下的「自定义键盘背景图 + 实时高斯模糊底图采样」管理器：
 * - 当用户从相册上传背景图后，自动按 background-size: cover 铺满键盘底板；
 * - 同时预计算高平滑度高斯模糊底图 (blurredBitmap)，供所有半透明毛玻璃按键与顶栏实时读取并模糊对应坐标处的底图！
 */
object CustomBgManager {
    private const val FILE_NAME = "custom_kb_bg.png"
    private var cachedTimestamp: Long = -1L
    private var rawBitmap: Bitmap? = null
    private var blurredBitmap: Bitmap? = null

    fun getBgFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun hasCustomBg(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        return ts > 0L && getBgFile(context).exists()
    }

    fun clearCustomBg(context: Context) {
        try {
            getBgFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_bg_ts", 0L)
            .apply()
        synchronized(this) {
            cachedTimestamp = 0L
            rawBitmap = null
            blurredBitmap = null
        }
    }

    private fun ensureLoaded(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        if (ts <= 0L) {
            rawBitmap = null
            blurredBitmap = null
            cachedTimestamp = 0L
            return
        }
        if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
        synchronized(this) {
            if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
            val file = getBgFile(context)
            if (!file.exists()) {
                rawBitmap = null
                blurredBitmap = null
                cachedTimestamp = 0L
                return
            }
            try {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) {
                    rawBitmap = bmp
                    blurredBitmap = createGaussianBlurredBitmap(bmp)
                    cachedTimestamp = ts
                }
            } catch (_: Exception) {}
        }
    }

    fun getRawBitmap(context: Context): Bitmap? {
        if (cachedTimestamp >= 0L) return rawBitmap
        ensureLoaded(context)
        return rawBitmap
    }

    fun getBlurredBitmap(context: Context): Bitmap? {
        if (cachedTimestamp >= 0L) return blurredBitmap
        ensureLoaded(context)
        return blurredBitmap
    }

    fun invalidateBgCache() {
        cachedTimestamp = -1L
    }

    /**
     * 通过 1/4 下采样 + 3 遍可分离均值滤波（中心极限定理等效高半径高斯模糊）生成柔焦毛玻璃底图
     */
    private fun createGaussianBlurredBitmap(src: Bitmap): Bitmap {
        val sw = (src.width / 4).coerceAtLeast(64)
        val sh = (src.height / 4).coerceAtLeast(48)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        val tmp = IntArray(sw * sh)
        val radius = 6

        repeat(3) {
            // Horizontal pass
            for (y in 0 until sh) {
                val rowOff = y * sw
                for (x in 0 until sw) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val x0 = max(0, x - radius)
                    val x1 = min(sw - 1, x + radius)
                    for (ix in x0..x1) {
                        val c = pixels[rowOff + ix]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    tmp[rowOff + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
            // Vertical pass
            for (x in 0 until sw) {
                for (y in 0 until sh) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val y0 = max(0, y - radius)
                    val y1 = min(sh - 1, y + radius)
                    for (iy in y0..y1) {
                        val c = tmp[iy * sw + x]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    pixels[y * sw + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
        }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        return out
    }
}

/**
 * 自定义背景图的 background-size: cover + 可调节（0~100）背景毛玻璃程度渲染 Drawable：
 * - blurLevel = 0 时：100% 清晰显示用户上传的原图；
 * - blurLevel = 1..100 时：按比例平滑混合高清原图与柔焦高斯模糊底图，并叠加清透毛玻璃雾面光泽！
 */
class CustomCoverBgDrawable(
    private val rawBitmap: Bitmap,
    private val blurredBitmap: Bitmap?,
    var blurLevel: Int = 25
) : Drawable() {
    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val frostVeilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val matrix = Matrix()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val bw = b.width().toFloat()
        val bh = b.height().toFloat()
        if (bw <= 0f || bh <= 0f || rawBitmap.width <= 0 || rawBitmap.height <= 0) return

        val lv = blurLevel.coerceIn(0, 100)
        val save = canvas.save()
        canvas.clipRect(b)

        // 1. 绘制原图（当 blurLevel < 100 时作为清晰基底）
        if (lv < 100 || blurredBitmap == null) {
            val scale = max(bw / rawBitmap.width.toFloat(), bh / rawBitmap.height.toFloat())
            val dx = b.left + (bw - rawBitmap.width * scale) * 0.5f
            val dy = b.top + (bh - rawBitmap.height * scale) * 0.5f
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(dx, dy)
            canvas.drawBitmap(rawBitmap, matrix, rawPaint)
        }

        // 2. 按 0~100 程度叠加背景毛玻璃模糊层与轻柔雾面光泽
        if (lv > 0 && blurredBitmap != null && blurredBitmap.width > 0 && blurredBitmap.height > 0) {
            val bScale = max(bw / blurredBitmap.width.toFloat(), bh / blurredBitmap.height.toFloat())
            val bDx = b.left + (bw - blurredBitmap.width * bScale) * 0.5f
            val bDy = b.top + (bh - blurredBitmap.height * bScale) * 0.5f
            matrix.reset()
            matrix.setScale(bScale, bScale)
            matrix.postTranslate(bDx, bDy)
            blurPaint.alpha = (lv * 2.55f).toInt().coerceIn(0, 255)
            canvas.drawBitmap(blurredBitmap, matrix, blurPaint)

            // 随毛玻璃程度增加一点点清透雾白柔光感（最高约 22% 雾面感，不遮挡画面色彩）
            val veilAlpha = (lv * 0.56f).toInt().coerceIn(0, 56)
            if (veilAlpha > 0) {
                frostVeilPaint.color = Color.argb(veilAlpha, 255, 255, 255)
                canvas.drawRect(b, frostVeilPaint)
            }
        }
        canvas.restoreToCount(save)
    }

    private val paint = rawPaint

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 位于键盘最底层的「中心浓郁加深、四周柔和减淡」双层半透明背光层：
 * - 彻底摒弃刺眼的荧光亮色；
 * - 内层核心（innerGrad）自动比外层柔雾（outerGrad）再加深 22%，让按键中心位置呈现出浓郁温润的深睡莲绿/同色系深色核心，
 *   越往周围扩散越浅、越半透明，与莫奈花园及所有纯色皮肤完美融合。
 */
/**
 * 独立星河色彩适配器（与粒子几何形状、星芒绘制逻辑完全解耦）：
 * - 星芒核心恒定采用纯净高亮白 (#FFFFFF) 与近白星光色；
 * - 外围柔光继承当前皮肤主色相，但自动降低饱和度，彻底杜绝刺眼荧光色与深色背景下的「黄色烟雾感」；
 * - 同时自动适配深色背景与浅色背景，不将任何固定颜色写死到皮肤中。
 */
object StarlightColorAdapter {

    class StarlightPalette(
        val coreWhite: Int,
        val rayNearWhite: Int,
        val softHaloColor: Int,
        val ambientGlowColor: Int,
        val lightContrastShadowColor: Int,
        val meteorPrimaryTint: Int,
        val meteorAccent1: Int,
        val meteorAccent2: Int,
        val meteorLightHaloColor: Int,
        val isLightSurface: Boolean,
        val ambientAlphaScale: Float
    )

    private fun computeColorLum(c: Int): Float {
        return 0.2126f * (Color.red(c) / 255f) +
            0.7152f * (Color.green(c) / 255f) +
            0.0722f * (Color.blue(c) / 255f)
    }

    fun resolvePalette(
        rawGlowColor: Int,
        surfaceBgColor: Int? = null,
        keyboardBgColor: Int? = null
    ): StarlightPalette {
        val hsv = FloatArray(3)
        Color.colorToHSV(rawGlowColor, hsv)
        val rawH = hsv[0]
        val rawS = hsv[1]
        val rawV = hsv[2]

        // 综合判断键盘底板亮度与按键表面亮度：
        // 1) 若键盘底板本身是深色（如暗夜黑金 #14161D、深色黑粉 #18141A，kbLum < 0.38），哪怕字母键是暖白键，键下流光依然绽放在深黑缝隙上，严格采用深色高亮流光策略；
        // 2) 若键盘底板是浅色（如浅粉 #FAF2F3、奶白拿铁 #F5EFEA、莫奈浅蓝 #E4EDF7、薄荷奶黄 #F5F1EB），即便按到深酒红/深咖跳色键，键下流光也绽放在浅色底板上，严格采用浅色清透流光策略！
        val hasKbBg = keyboardBgColor != null && Color.alpha(keyboardBgColor) > 40
        val hasKeyBg = surfaceBgColor != null && Color.alpha(surfaceBgColor) > 40
        val surfaceLum = when {
            hasKbBg -> {
                val kbLum = computeColorLum(keyboardBgColor!!)
                if (kbLum < 0.38f) {
                    kbLum
                } else if (hasKeyBg) {
                    kbLum * 0.70f + computeColorLum(surfaceBgColor!!) * 0.30f
                } else {
                    kbLum
                }
            }
            hasKeyBg -> computeColorLum(surfaceBgColor!!)
            else -> computeColorLum(rawGlowColor)
        }
        val isLightSurface = surfaceLum >= 0.52f

        // 1. 针对偏黄/暖金波段 (Hue 26°~76°)，大幅降低外围光晕饱和度并向清冷月光香槟白偏移，彻底消除深色底上的“黄色烟雾”
        val isYellowWarmBand = rawH in 26f..76f
        val isGreenBand = rawH in 90f..168f

        // 2. 星芒近白过渡色（90% 纯白 + 10% 低饱和皮肤色相）
        val nearWhiteHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.0f else (rawS * 0.22f).coerceIn(0.04f, if (isYellowWarmBand) 0.10f else 0.15f),
            0.99f
        )
        val rayNearWhite = Color.HSVToColor(nearWhiteHsv)

        // 3. 星芒外围柔光色（继承皮肤色相但显著降低饱和度，清爽通透）
        val haloSatCap = when {
            rawS < 0.05f -> 0.08f
            isYellowWarmBand -> if (isLightSurface) 0.24f else 0.16f
            isGreenBand -> 0.25f
            else -> if (isLightSurface) 0.34f else 0.26f
        }
        val haloHsv = floatArrayOf(
            rawH,
            (rawS * 0.58f).coerceIn(0.08f, haloSatCap),
            if (isLightSurface) rawV.coerceIn(0.84f, 0.94f) else rawV.coerceIn(0.86f, 0.96f)
        )
        val softHaloColor = Color.HSVToColor(haloHsv)

        // 4. 底层环境背光晕颜色
        val ambientSatCap = when {
            rawS < 0.05f -> 0.10f
            isYellowWarmBand -> if (isLightSurface) 0.28f else 0.18f
            isGreenBand -> 0.28f
            else -> if (isLightSurface) 0.38f else 0.30f
        }
        val ambientHsv = floatArrayOf(
            rawH,
            (rawS * 0.65f).coerceIn(0.08f, ambientSatCap),
            if (isLightSurface) rawV.coerceIn(0.84f, 0.94f) else rawV.coerceIn(0.78f, 0.90f)
        )
        val ambientGlowColor = Color.HSVToColor(ambientHsv)

        // 5. 浅色背景专属柔和星影衬底色
        val contrastHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.14f else (rawS * 0.62f + 0.08f).coerceIn(0.20f, if (isYellowWarmBand) 0.30f else 0.38f),
            if (isLightSurface) 0.82f else 0.86f
        )
        val lightContrastShadowColor = Color.HSVToColor(contrastHsv)

        // 6. 🌙 键下不规则弧形流光细丝 & 簇状星语配色：
        //    - 深色皮肤 (!isLightSurface)：完全保留 v7.27 备受好评的高亮流光、主题染色与柔和光晕；
        //    - 浅色皮肤 (isLightSurface)：彻底根除以往 V=0.48~0.60 低明度 + 高饱和度造成的「发棕、发黑、浓重泥色团块」！
        //      采用高明度 (V=0.92~0.98) + 与皮肤协调的中等清透饱和度 (S=0.30~0.50)，并按浅粉/奶白暖金/薄荷绿/浅蓝分色带精准调校邻近色相。
        val baseHue = if (rawS < 0.05f) 215f else rawH

        val meteorPrimaryTint: Int
        val meteorAccent1: Int
        val meteorAccent2: Int
        val meteorLightHaloColor: Int

        if (isLightSurface) {
            val isPinkBand = (baseHue >= 320f || baseHue < 16f)
            val isWarmCreamBand = (baseHue in 16f..72f)
            val isMintGreenBand = (baseHue in 72f..172f)

            // 修正浅色底上容易发砖红/铁锈棕的色相敏感区 (4°~34°)
            val cleanBaseHue = when {
                baseHue in 4f..16f -> 350f + (baseHue - 4f) * 0.4f
                baseHue in 16f..36f -> 36f + (baseHue - 16f) * 0.35f
                else -> baseHue
            }

            if (isPinkBand) {
                // 浅粉/樱花粉系：清透樱花蜜桃粉，拒绝跨入 42° 橙黄导致发棕
                val pSat = (rawS * 0.68f + 0.22f).coerceIn(0.38f, 0.50f)
                val pVal = (rawV * 0.98f + 0.06f).coerceIn(0.94f, 0.98f)
                var accH1 = (cleanBaseHue + 6f) % 360f
                if (accH1 in 3f..320f) accH1 = 355f
                val accH2 = (cleanBaseHue - 10f + 360f) % 360f
                meteorPrimaryTint = Color.HSVToColor(floatArrayOf(cleanBaseHue, pSat, pVal))
                meteorAccent1 = Color.HSVToColor(floatArrayOf(accH1, (pSat * 0.94f).coerceIn(0.35f, 0.47f), 0.96f))
                meteorAccent2 = Color.HSVToColor(floatArrayOf(accH2, (pSat * 0.92f).coerceIn(0.35f, 0.47f), 0.95f))
                meteorLightHaloColor = Color.HSVToColor(floatArrayOf(cleanBaseHue, (pSat * 0.68f).coerceIn(0.20f, 0.32f), 0.99f))
            } else if (isWarmCreamBand) {
                // 奶白/焦糖拿铁/暖杏仁系：清透香槟暖金流光，高明度 V=0.94~0.97 + 适中饱和度，彻底告别深咖泥棕感
                val pSat = (rawS * 0.62f + 0.20f).coerceIn(0.34f, 0.44f)
                val pVal = (rawV * 0.98f + 0.06f).coerceIn(0.94f, 0.97f)
                val accH1 = (cleanBaseHue + 5f).coerceAtMost(46f)
                val accH2 = (cleanBaseHue - 4f).coerceAtLeast(33f)
                meteorPrimaryTint = Color.HSVToColor(floatArrayOf(cleanBaseHue, pSat, pVal))
                meteorAccent1 = Color.HSVToColor(floatArrayOf(accH1, (pSat * 0.92f).coerceIn(0.30f, 0.40f), 0.96f))
                meteorAccent2 = Color.HSVToColor(floatArrayOf(accH2, (pSat * 0.98f).coerceIn(0.34f, 0.44f), 0.95f))
                meteorLightHaloColor = Color.HSVToColor(floatArrayOf(cleanBaseHue, (pSat * 0.68f).coerceIn(0.20f, 0.30f), 0.99f))
            } else if (isMintGreenBand) {
                // 薄荷绿/青绿系：清透薄荷水绿
                val pSat = (rawS * 0.62f + 0.18f).coerceIn(0.36f, 0.48f)
                val pVal = (rawV * 0.96f + 0.06f).coerceIn(0.92f, 0.97f)
                val accH1 = (cleanBaseHue + 10f) % 360f
                val accH2 = (cleanBaseHue - 10f + 360f) % 360f
                meteorPrimaryTint = Color.HSVToColor(floatArrayOf(cleanBaseHue, pSat, pVal))
                meteorAccent1 = Color.HSVToColor(floatArrayOf(accH1, (pSat * 0.94f).coerceIn(0.34f, 0.45f), 0.95f))
                meteorAccent2 = Color.HSVToColor(floatArrayOf(accH2, (pSat * 0.92f).coerceIn(0.34f, 0.45f), 0.95f))
                meteorLightHaloColor = Color.HSVToColor(floatArrayOf(cleanBaseHue, (pSat * 0.68f).coerceIn(0.20f, 0.32f), 0.99f))
            } else {
                // 浅蓝/莫奈花园/薰衣草紫系：清透晴空蓝与鸢尾紫，告别暗沉灰靛蓝
                val pSat = (rawS * 0.66f + 0.20f).coerceIn(0.40f, 0.52f)
                val pVal = (rawV * 0.97f + 0.06f).coerceIn(0.93f, 0.98f)
                val accH1 = (cleanBaseHue + 10f) % 360f
                val accH2 = (cleanBaseHue - 10f + 360f) % 360f
                meteorPrimaryTint = Color.HSVToColor(floatArrayOf(cleanBaseHue, pSat, pVal))
                meteorAccent1 = Color.HSVToColor(floatArrayOf(accH1, (pSat * 0.94f).coerceIn(0.37f, 0.49f), 0.96f))
                meteorAccent2 = Color.HSVToColor(floatArrayOf(accH2, (pSat * 0.92f).coerceIn(0.37f, 0.49f), 0.96f))
                meteorLightHaloColor = Color.HSVToColor(floatArrayOf(cleanBaseHue, (pSat * 0.68f).coerceIn(0.22f, 0.34f), 0.99f))
            }
        } else {
            // 深色皮肤（黑粉、暗夜黑金等）：原汁原味保留 v7.27 高亮流光、主题色染色与柔和光晕
            meteorPrimaryTint = Color.HSVToColor(
                floatArrayOf(
                    baseHue,
                    (rawS * 0.36f + 0.10f).coerceIn(0.18f, 0.38f),
                    0.99f
                )
            )
            val accentHue1 = if (baseHue in 25f..68f) 344f else (baseHue + 18f) % 360f
            val accentHue2 = if (baseHue in 325f..360f || baseHue < 18f) 42f else (baseHue + 342f) % 360f
            meteorAccent1 = Color.HSVToColor(
                floatArrayOf(
                    accentHue1,
                    (rawS * 0.48f + 0.18f).coerceIn(0.28f, 0.54f),
                    0.98f
                )
            )
            meteorAccent2 = Color.HSVToColor(
                floatArrayOf(
                    accentHue2,
                    (rawS * 0.45f + 0.16f).coerceIn(0.26f, 0.50f),
                    0.97f
                )
            )
            meteorLightHaloColor = meteorPrimaryTint
        }

        val ambientAlphaScale = if (isLightSurface) 0.86f else if (isYellowWarmBand) 0.56f else 0.68f

        return StarlightPalette(
            coreWhite = Color.rgb(255, 255, 255),
            rayNearWhite = rayNearWhite,
            softHaloColor = softHaloColor,
            ambientGlowColor = ambientGlowColor,
            lightContrastShadowColor = lightContrastShadowColor,
            meteorPrimaryTint = meteorPrimaryTint,
            meteorAccent1 = meteorAccent1,
            meteorAccent2 = meteorAccent2,
            meteorLightHaloColor = meteorLightHaloColor,
            isLightSurface = isLightSurface,
            ambientAlphaScale = ambientAlphaScale
        )
    }
}

class KeyboardBacklightOverlayView(
    context: Context,
    val renderLayerMode: Int = LAYER_UNDER_GLOW,
    val clipCornerRadiusPx: Float = 0f,
    var keyboardSurfaceBgColor: Int? = null
) : View(context) {

    companion object {
        const val LAYER_UNDER_GLOW = 0
        const val LAYER_OVER_SPARKLE = 1
        const val LAYER_FULL_COMBINED = 2

        // 粒子形状枚举（复刻参考视频2：实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光微圆圈 ° + 明暗碎星尘 ·）
        const val SHAPE_SOLID_STAR4 = 0
        const val SHAPE_HOLLOW_STAR4 = 1
        const val SHAPE_SOFT_RING_PEARL = 2
        const val SHAPE_TWINKLE_DUST = 3

        // 1. 键盘上表面星点（移至「更多设置」独立保留）
        const val PREF_SPARKLE_ENABLED = "backlight_sparkle_enabled"
        const val PREF_SPARKLE_INTENSITY = "backlight_sparkle_intensity"
        const val DEFAULT_SPARKLE_INTENSITY = 82

        // 2. ☄️ 键盘下唯美星语（不规则弧形流光细丝 + 簇状星点：支持疏密、速度、距离三项独立调节）
        const val PREF_UNDER_BURST_ENABLED = "under_key_meteor_burst_enabled"
        const val PREF_UNDER_BURST_DENSITY = "under_key_burst_density"
        const val PREF_UNDER_BURST_SPEED = "under_key_burst_speed"
        const val PREF_UNDER_BURST_RANGE = "under_key_burst_range"
        const val PREF_QUICK_SLIDER_LOCK = "quick_panel_slider_lock"

        const val DEFAULT_UNDER_BURST_DENSITY = 65
        const val DEFAULT_UNDER_BURST_SPEED = 60
        const val DEFAULT_UNDER_BURST_RANGE = 48

        private var orbSeedCounter: Long = 1L

        @Volatile private var cachedSparkleEnabled: Boolean? = null
        @Volatile private var cachedSparkleIntensity: Int? = null
        @Volatile private var cachedUnderBurstEnabled: Boolean? = null
        @Volatile private var cachedUnderBurstDensity: Int? = null
        @Volatile private var cachedUnderBurstSpeed: Int? = null
        @Volatile private var cachedUnderBurstRange: Int? = null
        @Volatile private var cachedQuickSliderLocked: Boolean? = null

        fun syncCachedPrefs(context: Context) {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            cachedSparkleEnabled = prefs.getBoolean(PREF_SPARKLE_ENABLED, false)
            cachedSparkleIntensity = prefs.getInt(PREF_SPARKLE_INTENSITY, DEFAULT_SPARKLE_INTENSITY).coerceIn(10, 100)
            cachedUnderBurstEnabled = prefs.getBoolean(PREF_UNDER_BURST_ENABLED, true)
            cachedUnderBurstDensity = prefs.getInt(PREF_UNDER_BURST_DENSITY, DEFAULT_UNDER_BURST_DENSITY).coerceIn(10, 100)
            cachedUnderBurstSpeed = prefs.getInt(PREF_UNDER_BURST_SPEED, DEFAULT_UNDER_BURST_SPEED).coerceIn(10, 100)
            cachedUnderBurstRange = prefs.getInt(PREF_UNDER_BURST_RANGE, DEFAULT_UNDER_BURST_RANGE).coerceIn(10, 100)
            cachedQuickSliderLocked = prefs.getBoolean(PREF_QUICK_SLIDER_LOCK, true)
        }

        // --- 键帽表面星点（键盘上）开关与强度 ---
        fun isSparkleEnabled(context: Context): Boolean {
            cachedSparkleEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_SPARKLE_ENABLED, false).also { cachedSparkleEnabled = it }
        }

        fun setSparkleEnabled(context: Context, enabled: Boolean) {
            cachedSparkleEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_SPARKLE_ENABLED, enabled)
                .apply()
        }

        fun getSparkleIntensity(context: Context): Int {
            cachedSparkleIntensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_SPARKLE_INTENSITY, DEFAULT_SPARKLE_INTENSITY).coerceIn(10, 100).also { cachedSparkleIntensity = it }
        }

        fun setSparkleIntensity(context: Context, intensity: Int) {
            val clamped = intensity.coerceIn(10, 100)
            cachedSparkleIntensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_SPARKLE_INTENSITY, clamped)
                .apply()
        }

        fun getIntensityTierName(intensity: Int): String {
            return when {
                intensity < 42 -> "轻柔星尘"
                intensity < 75 -> "柔美星光"
                else -> "璀璨星河"
            }
        }

        // --- ☄️ 键盘下唯美弧形流光与星点开关及三项参数 ---
        fun isUnderBurstEnabled(context: Context): Boolean {
            cachedUnderBurstEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_UNDER_BURST_ENABLED, true).also { cachedUnderBurstEnabled = it }
        }

        fun setUnderBurstEnabled(context: Context, enabled: Boolean) {
            cachedUnderBurstEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_UNDER_BURST_ENABLED, enabled)
                .apply()
        }

        fun getUnderBurstDensity(context: Context): Int {
            cachedUnderBurstDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_DENSITY, DEFAULT_UNDER_BURST_DENSITY).coerceIn(10, 100).also { cachedUnderBurstDensity = it }
        }

        fun setUnderBurstDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedUnderBurstDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_DENSITY, clamped)
                .apply()
        }

        fun getUnderBurstSpeed(context: Context): Int {
            cachedUnderBurstSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_SPEED, DEFAULT_UNDER_BURST_SPEED).coerceIn(10, 100).also { cachedUnderBurstSpeed = it }
        }

        fun setUnderBurstSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedUnderBurstSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_SPEED, clamped)
                .apply()
        }

        fun getUnderBurstRange(context: Context): Int {
            cachedUnderBurstRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_RANGE, DEFAULT_UNDER_BURST_RANGE).coerceIn(10, 100).also { cachedUnderBurstRange = it }
        }

        fun setUnderBurstRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedUnderBurstRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_RANGE, clamped)
                .apply()
        }

        fun isQuickSliderLocked(context: Context): Boolean {
            cachedQuickSliderLocked?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_QUICK_SLIDER_LOCK, true).also { cachedQuickSliderLocked = it }
        }

        fun setQuickSliderLocked(context: Context, locked: Boolean) {
            cachedQuickSliderLocked = locked
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_QUICK_SLIDER_LOCK, locked)
                .apply()
        }
    }

    /**
     * 🌙 键下唯美光效 · 层级 1：不规则弧形流光细丝 (GossamerFlowRibbon)
     * - 彻底摒弃向外直刺的烟花直线！
     * - 采用贴合键帽转角与柔光边缘的弯弯流光游丝（两头如发丝般极细渐隐、中间柔亮微拱），
     *   随点击沿着弧线优雅滑过并自然消融，前端可伴随一颗微小四芒星点缀。
     */
    private class GossamerFlowRibbon(
        val startAngleRad: Float,
        val sweepAngleRad: Float,
        val angularDriftRad: Float,
        val baseOffsetPx: Float,
        val swellOutPx: Float,
        val maxHalfWidthPx: Float,
        val rippleWavePx: Float,
        val ripplePhase: Float,
        val brightness: Float,
        val colorVariant: Int,
        val hasTipStarlet: Boolean
    )

    /**
     * ✦ 键下唯美光效 · 层级 2：不对称簇状星点 (EtherealStarletParticle)
     * - 仅在按键周围随机 2~3 个不对称局部方位成簇绽放，保留 60% 以上呼吸留白；
     * - 形态包含：实心纤细小四芒星 (✦)、空心细线小四芒星 (✧)、柔光空心小光圈 (°)、明暗碎星尘 (·)；
     * - 轨迹采用「微弧度轻盈漾开 + 尾韵悬停闪烁微飘」，在主光晕变淡后依然温柔闪烁一下再化开。
     */
    private class EtherealStarletParticle(
        val shapeType: Int,
        val baseAngleRad: Float,
        val edgeDistPx: Float,
        val startOffsetPx: Float,
        val bloomReachPx: Float,
        val arcCurveDriftRad: Float,
        val afterglowFloatDx: Float,
        val afterglowFloatDy: Float,
        val sizePx: Float,
        val rotationDeg: Float,
        val spinDeg: Float,
        val brightness: Float,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleFreq: Float,
        val lingerBoost: Float
    )

    // 键帽表面星芒 · 第 1 层级：微小星尘
    private class MicroStardustParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 键帽表面星芒 · 第 2 层级：普通星点
    private class StarPointParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val haloRadiusPx: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 键帽表面星芒 · 第 3 层级：少量柔焦星云光斑
    private class SoftNebulaSpotParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val radiusPx: Float,
        val baseAlpha: Float
    )

    // 键帽表面星芒 · 第 4 层级：细长锐利的四角/六角星芒
    private class CelestialStarFlareParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val primaryRayPx: Float,
        val orthogonalRayPx: Float,
        val diagRayPx: Float,
        val baseHalfWidthPx: Float,
        val rotationDeg: Float,
        val isSixPointed: Boolean,
        val isHeroFlare: Boolean,
        val baseAlpha: Float,
        val twinklePhase: Float
    )

    private class SpotlightOrb(
        val sourceView: View?,
        val keyRect: RectF,
        val glowColor: Int,
        val palette: StarlightColorAdapter.StarlightPalette,
        val spawnTime: Long,
        var releaseTime: Long = 0L,
        val intensityNorm: Float,
        val burstSpeedNorm: Float,
        val flowRibbons: List<GossamerFlowRibbon>,
        val etherealStarlets: List<EtherealStarletParticle>,
        val stardustList: List<MicroStardustParticle>,
        val starPoints: List<StarPointParticle>,
        val nebulaSpots: List<SoftNebulaSpotParticle>,
        val starFlares: List<CelestialStarFlareParticle>
    ) {
        private val rGlow = Color.red(glowColor)
        private val gGlow = Color.green(glowColor)
        private val bGlow = Color.blue(glowColor)

        val unitOuterGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            intArrayOf(
                Color.argb(185, rGlow, gGlow, bGlow),
                Color.argb(160, rGlow, gGlow, bGlow),
                Color.argb(110, rGlow, gGlow, bGlow),
                Color.argb(56, rGlow, gGlow, bGlow),
                Color.argb(18, rGlow, gGlow, bGlow),
                Color.argb(0, rGlow, gGlow, bGlow)
            ),
            floatArrayOf(0f, 0.34f, 0.54f, 0.72f, 0.86f, 1.0f),
            Shader.TileMode.CLAMP
        )

        val unitInnerGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            intArrayOf(
                Color.argb(215, rGlow, gGlow, bGlow),
                Color.argb(185, rGlow, gGlow, bGlow),
                Color.argb(118, rGlow, gGlow, bGlow),
                Color.argb(40, rGlow, gGlow, bGlow),
                Color.argb(0, rGlow, gGlow, bGlow)
            ),
            floatArrayOf(0f, 0.42f, 0.65f, 0.85f, 1.0f),
            Shader.TileMode.CLAMP
        )

        val unitVeilGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            intArrayOf(
                Color.argb(56, rGlow, gGlow, bGlow),
                Color.argb(38, rGlow, gGlow, bGlow),
                Color.argb(14, rGlow, gGlow, bGlow),
                Color.argb(0, rGlow, gGlow, bGlow)
            ),
            floatArrayOf(0f, 0.48f, 0.78f, 1.0f),
            Shader.TileMode.CLAMP
        )
    }

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val starPath = Path()
    private val ribbonPath = Path()
    private val clipBoundsPath = Path()
    private val keyHoleClipPath = Path()
    private val shaderMatrix = Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    private fun computeKeyEdgeDist(hw: Float, hh: Float, angleRad: Float): Float {
        val ux = cos(angleRad)
        val uy = sin(angleRad)
        val rawEdge = min(hw / max(abs(ux), 0.001f), hh / max(abs(uy), 0.001f))
        val cornerFactor = 1f - 0.16f * min(abs(ux), abs(uy))
        return rawEdge * cornerFactor
    }

    private fun buildRandomOrb(
        sourceView: View?,
        rect: RectF,
        glowColor: Int,
        surfaceBgColor: Int? = null
    ): SpotlightOrb {
        val shouldSpawnSurfaceParticles = (renderLayerMode != LAYER_UNDER_GLOW) && isSparkleEnabled(context)
        // 仅在顶层精确镂空层 (LAYER_OVER_SPARKLE) 或完整预览层 (LAYER_FULL_COMBINED) 生成流光细丝与星团，
        // 避免底层与顶层在 3~4dp 按键缝隙中双重叠加绘制导致浅色底流光变浓发暗！
        val shouldSpawnUnderMeteor = (renderLayerMode != LAYER_UNDER_GLOW) && isUnderBurstEnabled(context)

        val rawIntensity = getSparkleIntensity(context)
        val normI = ((rawIntensity - 10f) / 90f).coerceIn(0f, 1f)

        val densityNorm = ((getUnderBurstDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val speedNorm = ((getUnderBurstSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val rangeNorm = ((getUnderBurstRange(context) - 10f) / 90f).coerceIn(0f, 1f)

        val palette = StarlightColorAdapter.resolvePalette(glowColor, surfaceBgColor, keyboardSurfaceBgColor)
        val now = SystemClock.uptimeMillis()

        val seed = System.nanoTime() xor
            ((sourceView?.hashCode()?.toLong() ?: 0x5A17L) shl 17) xor
            (orbSeedCounter++ * -7046029254386353131L)
        val rng = java.util.Random(seed)
        val twoPi = (Math.PI * 2.0).toFloat()

        // =========================================================================
        // A. 生成键盘下「唯美不规则弧形流光细丝 + 不对称簇状星群」（复刻参考视频2）
        // =========================================================================
        val flowRibbons: List<GossamerFlowRibbon>
        val etherealStarlets: List<EtherealStarletParticle>
        if (shouldSpawnUnderMeteor) {
            val hw = (rect.width() * 0.5f).coerceAtLeast(dpF(14f))
            val hh = (rect.height() * 0.5f).coerceAtLeast(dpF(14f))
            // 散开距离：10% 约 6dp（紧贴键缝），默认 48% 约 13dp（轻巧浮出键沿，绝不糊成一片），100% 约 23dp
            val maxBloomExtraPx = dpF(6.0f + rangeNorm * 17.5f)

            // 1. 选定 2~3 个不对称簇状主方位（留出大面积空白，绝不 360° 均匀撒满！）
            val clusterCount = when {
                densityNorm < 0.28f -> 2
                densityNorm < 0.78f -> if (rng.nextFloat() < 0.65f) 2 else 3
                else -> 3
            }
            val baseMainAng = rng.nextFloat() * twoPi
            val clusterAngles = FloatArray(clusterCount)
            clusterAngles[0] = baseMainAng
            if (clusterCount >= 2) {
                // 第二簇位于斜对角偏转 125°~195° 处，形成自然的不对称美感
                clusterAngles[1] = baseMainAng + (2.18f + rng.nextFloat() * 1.22f)
            }
            if (clusterCount >= 3) {
                clusterAngles[2] = baseMainAng + (4.25f + rng.nextFloat() * 0.85f)
            }

            // 2. 生成 1~3 缕「不规则弧形流光细丝」(GossamerFlowRibbons)
            //    贴着簇状方位所在的键帽边角柔和掠过，两头尖细渐隐、中间柔亮微拱
            val ribbonCount = when {
                densityNorm < 0.32f -> 1
                densityNorm < 0.76f -> 2
                else -> 3
            }
            val rList = ArrayList<GossamerFlowRibbon>(ribbonCount)
            for (rIdx in 0 until ribbonCount) {
                val anchorAng = clusterAngles[rIdx % clusterCount] + (rng.nextFloat() - 0.5f) * 0.35f
                val dirSign = if (rIdx % 2 == 0) 1f else -1f
                // 主流光丝跨度约 52°~82°，伴生流光丝跨度约 36°~56°
                val sweepMag = if (rIdx == 0) {
                    0.92f + rng.nextFloat() * 0.48f
                } else {
                    0.64f + rng.nextFloat() * 0.38f
                }
                val sweepRad = sweepMag * dirSign
                val startRad = anchorAng - sweepRad * 0.45f
                val driftRad = dirSign * (0.20f + rng.nextFloat() * 0.16f)
                val baseOff = dpF(0.6f + rng.nextFloat() * 1.8f)
                val swellOut = maxBloomExtraPx * (if (rIdx == 0) (0.48f + rng.nextFloat() * 0.26f) else (0.32f + rng.nextFloat() * 0.22f))
                val maxHalfW = dpF(if (rIdx == 0) (0.68f + rng.nextFloat() * 0.26f) else (0.48f + rng.nextFloat() * 0.20f))
                val wavePx = dpF(0.8f + rng.nextFloat() * 1.6f) * (if (rng.nextBoolean()) 1f else -1f)
                val colorVar = if (rIdx == 0) 0 else if (rIdx == 1) 1 else 2

                rList.add(
                    GossamerFlowRibbon(
                        startAngleRad = startRad,
                        sweepAngleRad = sweepRad,
                        angularDriftRad = driftRad,
                        baseOffsetPx = baseOff,
                        swellOutPx = swellOut,
                        maxHalfWidthPx = maxHalfW,
                        rippleWavePx = wavePx,
                        ripplePhase = rng.nextFloat() * twoPi,
                        brightness = if (rIdx == 0) 0.92f else 0.72f,
                        colorVariant = colorVar,
                        hasTipStarlet = (rIdx == 0)
                    )
                )
            }
            flowRibbons = rList

            // 3. 在每个不对称簇周围生成错落有致的星点群 (EtherealStarlets)
            //    包含：实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光微圆圈 ° + 明暗碎星尘 ·
            val totalParticlesTarget = (7 + (densityNorm * 16f).toInt() + rng.nextInt(3)).coerceIn(6, 25)
            val sList = ArrayList<EtherealStarletParticle>(totalParticlesTarget)

            for (cIdx in 0 until clusterCount) {
                val cCenterAng = clusterAngles[cIdx]
                val countInCluster = if (cIdx == 0) {
                    ((totalParticlesTarget * 0.46f).toInt()).coerceAtLeast(3)
                } else if (clusterCount == 2) {
                    (totalParticlesTarget - sList.size).coerceAtLeast(3)
                } else if (cIdx == 1) {
                    ((totalParticlesTarget * 0.32f).toInt()).coerceAtLeast(2)
                } else {
                    (totalParticlesTarget - sList.size).coerceAtLeast(2)
                }

                for (pIdx in 0 until countInCluster) {
                    // 簇内角度自然散落（中心紧凑、外围微散，只占约 ±26° 扇面，保留其余大片留白）
                    val angleSpread = (rng.nextFloat() + rng.nextFloat() - 1f) * 0.48f
                    val pAng = cCenterAng + angleSpread
                    val edgeDist = computeKeyEdgeDist(hw, hh, pAng)

                    // 形状分配：每簇必有 1 颗实心小四芒星 ✦、1 颗空心小星 ✧ 或柔光小光圈 °，其余为明暗碎星尘 ·
                    val shapeType = when {
                        pIdx == 0 -> SHAPE_SOLID_STAR4
                        pIdx == 1 -> if (cIdx == 0 || rng.nextFloat() < 0.62f) SHAPE_HOLLOW_STAR4 else SHAPE_SOFT_RING_PEARL
                        pIdx == 2 && countInCluster >= 5 -> if (rng.nextFloat() < 0.48f) SHAPE_SOFT_RING_PEARL else SHAPE_SOLID_STAR4
                        pIdx == 3 && countInCluster >= 7 && rng.nextFloat() < 0.45f -> SHAPE_HOLLOW_STAR4
                        else -> SHAPE_TWINKLE_DUST
                    }

                    val sizePx = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> dpF(if (pIdx == 0 && cIdx == 0) (3.4f + rng.nextFloat() * 1.3f) else (2.4f + rng.nextFloat() * 1.1f))
                        SHAPE_HOLLOW_STAR4 -> dpF(2.8f + rng.nextFloat() * 1.2f)
                        SHAPE_SOFT_RING_PEARL -> dpF(1.35f + rng.nextFloat() * 0.85f)
                        else -> dpF(0.45f + rng.nextFloat() * 0.62f) // 极细碎星尘
                    }

                    val distRatio = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> 0.38f + rng.nextFloat() * 0.52f
                        SHAPE_HOLLOW_STAR4 -> 0.45f + rng.nextFloat() * 0.55f
                        SHAPE_SOFT_RING_PEARL -> 0.30f + rng.nextFloat() * 0.58f
                        else -> 0.18f + rng.nextFloat() * 0.88f
                    }
                    val startOff = dpF(0.4f + rng.nextFloat() * 1.6f)
                    val bloomReach = maxBloomExtraPx * distRatio

                    // 微弧度曲线漂移 + 尾韵缓慢微飘（复刻视频2末尾小星星在空中轻轻闪烁漂浮的余韵）
                    val arcSign = if (cIdx % 2 == 0) 1f else -1f
                    val arcDrift = arcSign * (0.10f + rng.nextFloat() * 0.18f)
                    val floatAng = pAng + arcSign * (0.45f + rng.nextFloat() * 0.55f)
                    val floatDist = dpF(2.2f + rng.nextFloat() * 3.8f) * (0.75f + rangeNorm * 0.45f)

                    val bright = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> 0.88f + rng.nextFloat() * 0.12f
                        SHAPE_HOLLOW_STAR4 -> 0.82f + rng.nextFloat() * 0.16f
                        SHAPE_SOFT_RING_PEARL -> 0.65f + rng.nextFloat() * 0.25f
                        else -> if (rng.nextFloat() < 0.45f) (0.72f + rng.nextFloat() * 0.26f) else (0.28f + rng.nextFloat() * 0.32f)
                    }

                    val cvRoll = rng.nextFloat()
                    val colorVar = if (cvRoll < 0.58f) 0 else if (cvRoll < 0.80f) 1 else 2

                    sList.add(
                        EtherealStarletParticle(
                            shapeType = shapeType,
                            baseAngleRad = pAng,
                            edgeDistPx = edgeDist,
                            startOffsetPx = startOff,
                            bloomReachPx = bloomReach,
                            arcCurveDriftRad = arcDrift,
                            afterglowFloatDx = cos(floatAng) * floatDist,
                            afterglowFloatDy = sin(floatAng) * floatDist + dpF(1.2f), // 微带一丝轻盈垂落感
                            sizePx = sizePx,
                            rotationDeg = (rng.nextFloat() - 0.5f) * 36f,
                            spinDeg = (rng.nextFloat() - 0.5f) * 28f,
                            brightness = bright,
                            colorVariant = colorVar,
                            twinklePhase = rng.nextFloat() * twoPi,
                            twinkleFreq = 0.015f + rng.nextFloat() * 0.016f,
                            lingerBoost = if (shapeType != SHAPE_TWINKLE_DUST) 0.58f else 0.72f
                        )
                    )
                }
            }
            etherealStarlets = sList
        } else {
            flowRibbons = emptyList()
            etherealStarlets = emptyList()
        }

        if (!shouldSpawnSurfaceParticles) {
            return SpotlightOrb(
                sourceView = sourceView,
                keyRect = rect,
                glowColor = glowColor,
                palette = palette,
                spawnTime = now,
                releaseTime = 0L,
                intensityNorm = normI,
                burstSpeedNorm = speedNorm,
                flowRibbons = flowRibbons,
                etherealStarlets = etherealStarlets,
                stardustList = emptyList(),
                starPoints = emptyList(),
                nebulaSpots = emptyList(),
                starFlares = emptyList()
            )
        }

        // =========================================================================
        // B. 生成键盘上「表面璀璨星河（四角/六角星芒 + 星河微尘）」（独立保留）
        // =========================================================================
        val spreadScale = 0.78f + normI * 0.48f
        val spreadRx = (rect.width() * 0.54f + dpF(16f * spreadScale)).coerceAtLeast(dpF(26f))
        val spreadRy = (rect.height() * 0.54f + dpF(14f * spreadScale)).coerceAtLeast(dpF(22f))

        val galaxyAxisAngle = (rng.nextFloat() - 0.5f) * 1.9f
        val cosAxis = cos(galaxyAxisAngle)
        val sinAxis = sin(galaxyAxisAngle)

        val dustCount = (10 + (normI * normI * 24f + normI * 10f).toInt() + rng.nextInt(4)).coerceIn(8, 46)
        val stardustList = ArrayList<MicroStardustParticle>(dustCount)
        for (i in 0 until dustCount) {
            val alongBand = rng.nextFloat() < 0.68f
            val rx: Float
            val ry: Float
            if (alongBand) {
                val u = (rng.nextFloat() * 2f - 1f) * spreadRx * 0.96f
                val curveOffset = sin(u / spreadRx * 2.2f) * spreadRy * 0.16f
                val vSpread = (rng.nextFloat() + rng.nextFloat() - 1f) * spreadRy * 0.44f + curveOffset
                rx = u * cosAxis - vSpread * sinAxis
                ry = u * sinAxis + vSpread * cosAxis
            } else {
                val ang = rng.nextFloat() * twoPi
                val dist = 0.15f + rng.nextFloat() * 0.88f
                rx = cos(ang) * spreadRx * dist
                ry = sin(ang) * spreadRy * dist
            }
            val driftAng = atan2(ry, rx) + (rng.nextFloat() - 0.5f) * 0.5f
            val driftDist = dpF(1.2f + rng.nextFloat() * 2.8f)
            val radDp = 0.38f + rng.nextFloat() * 0.56f
            stardustList.add(
                MicroStardustParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(driftAng) * driftDist,
                    driftDy = sin(driftAng) * driftDist,
                    coreRadiusPx = dpF(radDp),
                    baseAlpha = (0.24f + rng.nextFloat() * 0.44f) * (0.68f + normI * 0.42f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.015f + rng.nextFloat() * 0.016f
                )
            )
        }

        val pointCount = (3 + (normI * 12f).toInt() + rng.nextInt(2)).coerceIn(3, 17)
        val starPoints = ArrayList<StarPointParticle>(pointCount)
        val ptBaseAng = rng.nextFloat() * twoPi
        for (i in 0 until pointCount) {
            val ang = ptBaseAng + (i.toFloat() / pointCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.65f
            val dist = 0.20f + rng.nextFloat() * 0.78f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val driftDist = dpF(1.5f + rng.nextFloat() * 3.0f)
            val coreDp = (0.72f + rng.nextFloat() * 0.65f) * (0.82f + normI * 0.28f)
            val haloDp = coreDp * (2.6f + rng.nextFloat() * 1.1f)
            starPoints.add(
                StarPointParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * driftDist,
                    driftDy = sin(ang) * driftDist,
                    haloRadiusPx = dpF(haloDp),
                    coreRadiusPx = dpF(coreDp),
                    baseAlpha = (0.52f + rng.nextFloat() * 0.42f) * (0.72f + normI * 0.38f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.012f + rng.nextFloat() * 0.012f
                )
            )
        }

        val nebulaCount = when {
            normI < 0.35f -> 1
            normI < 0.75f -> 2
            else -> 3
        }
        val nebulaSpots = ArrayList<SoftNebulaSpotParticle>(nebulaCount)
        for (i in 0 until nebulaCount) {
            val ang = galaxyAxisAngle + i * (Math.PI.toFloat()) + (rng.nextFloat() - 0.5f) * 0.9f
            val dist = 0.22f + rng.nextFloat() * 0.52f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val radDp = (4.2f + rng.nextFloat() * 3.0f) * (0.85f + normI * 0.25f)
            nebulaSpots.add(
                SoftNebulaSpotParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * dpF(2.0f),
                    driftDy = sin(ang) * dpF(2.0f),
                    radiusPx = dpF(radDp),
                    baseAlpha = (0.16f + rng.nextFloat() * 0.14f) * (0.75f + normI * 0.35f)
                )
            )
        }

        val heroCount = when {
            normI < 0.32f -> 1
            normI < 0.68f -> 2
            normI < 0.88f -> 3
            else -> 4
        }
        val miniCount = (1 + (normI * normI * 6.0f).toInt() + (if (normI > 0.5f) 1 else 0)).coerceIn(1, 7)
        val totalFlares = heroCount + miniCount
        val starFlares = ArrayList<CelestialStarFlareParticle>(totalFlares)
        val flareBaseAng = rng.nextFloat() * twoPi

        for (i in 0 until heroCount) {
            val ang = flareBaseAng + (i.toFloat() / heroCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.55f
            val dist = 0.30f + rng.nextFloat() * 0.54f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.2f + rng.nextFloat() * 2.2f)
            val rayScale = 0.72f + normI * 0.58f
            val primaryDp = (10.5f + rng.nextFloat() * 5.8f) * rayScale
            val primaryPx = dpF(primaryDp)
            val orthoPx = primaryPx * (0.64f + rng.nextFloat() * 0.26f)
            val diagPx = primaryPx * (0.28f + rng.nextFloat() * 0.14f)
            val halfW = dpF((0.48f + rng.nextFloat() * 0.22f) * (0.88f + normI * 0.18f))
            val isSix = (i == 1 && rng.nextFloat() < 0.55f) || (i >= 2 && rng.nextFloat() < 0.45f)
            val rotDeg = if (!isSix && rng.nextFloat() < 0.72f) {
                (if (rng.nextBoolean()) 0f else 90f) + (rng.nextFloat() - 0.5f) * 12f
            } else {
                (rng.nextFloat() - 0.5f) * 32f
            }
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = true,
                    baseAlpha = (0.88f + rng.nextFloat() * 0.12f) * (0.78f + normI * 0.32f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        val miniBaseAng = flareBaseAng + 0.48f
        for (i in 0 until miniCount) {
            val ang = miniBaseAng + (i.toFloat() / miniCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.72f
            val dist = 0.22f + rng.nextFloat() * 0.74f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.4f + rng.nextFloat() * 2.6f)
            val rayScale = 0.74f + normI * 0.46f
            val primaryDp = (5.0f + rng.nextFloat() * 3.6f) * rayScale
            val primaryPx = dpF(primaryDp)
            val orthoPx = primaryPx * (0.68f + rng.nextFloat() * 0.24f)
            val diagPx = if (rng.nextFloat() < 0.4f) primaryPx * 0.28f else 0f
            val halfW = dpF(0.36f + rng.nextFloat() * 0.16f)
            val isSix = rng.nextFloat() < 0.30f
            val rotDeg = (rng.nextFloat() - 0.5f) * 42f
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = false,
                    baseAlpha = (0.64f + rng.nextFloat() * 0.28f) * (0.72f + normI * 0.36f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        return SpotlightOrb(
            sourceView = sourceView,
            keyRect = rect,
            glowColor = glowColor,
            palette = palette,
            spawnTime = now,
            releaseTime = 0L,
            intensityNorm = normI,
            burstSpeedNorm = speedNorm,
            flowRibbons = flowRibbons,
            etherealStarlets = etherealStarlets,
            stardustList = stardustList,
            starPoints = starPoints,
            nebulaSpots = nebulaSpots,
            starFlares = starFlares
        )
    }

    fun triggerKeyDown(
        keyView: View,
        @Suppress("UNUSED_PARAMETER") cornerRadius: Float,
        glowColor: Int,
        surfaceBgColor: Int? = null
    ) {
        // 若当前为顶层星芒层，且用户已关闭「键下流光」与「键上星芒」，直接零开销返回，绝不空跑 120Hz 刷新循环！
        if (renderLayerMode == LAYER_OVER_SPARKLE && !isSparkleEnabled(context) && !isUnderBurstEnabled(context)) {
            return
        }
        val vw = if (keyView.width > 0) keyView.width.toFloat() else dpF(36f)
        val vh = if (keyView.height > 0) keyView.height.toFloat() else dpF(36f)

        var relLeft = -left.toFloat()
        var relTop = -top.toFloat()
        var cur: View? = keyView
        val overlayParent = this.parent
        var matchedAncestor = false
        while (cur != null) {
            relLeft += cur.left - cur.scrollX
            relTop += cur.top - cur.scrollY
            val p = cur.parent
            if (p === overlayParent) {
                matchedAncestor = true
                break
            }
            cur = p as? View
        }
        val left: Float
        val top: Float
        if (matchedAncestor) {
            left = relLeft
            top = relTop
        } else {
            getLocationInWindow(selfLoc)
            keyView.getLocationInWindow(targetLoc)
            left = (targetLoc[0] - selfLoc[0]).toFloat()
            top = (targetLoc[1] - selfLoc[1]).toFloat()
        }
        val right = left + vw
        val bottom = top + vh

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(buildRandomOrb(keyView, RectF(left, top, right, bottom), glowColor, surfaceBgColor))
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerPreviewBurst(glowColor: Int, surfaceBgColor: Int? = null) {
        val w = width.toFloat().coerceAtLeast(dpF(180f))
        val h = height.toFloat().coerceAtLeast(dpF(42f))
        val cx = w * (0.28f + (System.nanoTime() and 0xFF) / 580f)
        val cy = h * 0.5f
        val rect = RectF(cx - dpF(28f), cy - dpF(16f), cx + dpF(28f), cy + dpF(16f))
        val orb = buildRandomOrb(null, rect, glowColor, surfaceBgColor)
        orb.releaseTime = SystemClock.uptimeMillis()
        orbs.add(orb)
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    fun clearAllOrbs() {
        if (orbs.isNotEmpty()) {
            orbs.clear()
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val hasClip = clipCornerRadiusPx > 0.5f && width > 0 && height > 0
        val clipSave = if (hasClip) {
            val sc = canvas.save()
            clipBoundsPath.reset()
            tmpRectF.set(0f, 0f, width.toFloat(), height.toFloat())
            clipBoundsPath.addRoundRect(tmpRectF, clipCornerRadiusPx, clipCornerRadiusPx, Path.Direction.CW)
            canvas.clipPath(clipBoundsPath)
            sc
        } else -1

        val now = SystemClock.uptimeMillis()
        val outerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 32f else 40f)
        val innerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 16f else 20f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            // 速度倍率：10% 为 0.50x（慢动作星语余韵），默认 60% 为 1.02x（柔美呼吸同步），100% 为 1.45x（轻快灵动）
            val speedScale = 0.50f + orb.burstSpeedNorm * 0.95f
            val holdMs = 150f / speedScale
            val fadeMs = 580f / speedScale
            val totalMs = holdMs + fadeMs

            val progress: Float
            val driftProgress: Float
            if (orb.releaseTime == 0L) {
                val heldElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()
                progress = 1.0f
                driftProgress = (heldElapsed / 540f).coerceIn(0f, 0.40f)
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.05f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.95f * (1f - t) * (1f - t)
                }
                driftProgress = (0.16f + 0.84f * (elapsed / totalMs)).coerceIn(0f, 1f)
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val pal = orb.palette
            val rGlow = Color.red(orb.glowColor)
            val gGlow = Color.green(orb.glowColor)
            val bGlow = Color.blue(orb.glowColor)

            val masterPaintAlpha = (progress * 255f).toInt().coerceIn(0, 255)
            // 1. 底层选色背光光晕（复用预构建的单位 RadialGradient，0 对象分配！）
            if (renderLayerMode == LAYER_UNDER_GLOW || renderLayerMode == LAYER_FULL_COMBINED) {
                val rxOut = (orb.keyRect.width() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                val ryOut = (orb.keyRect.height() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                shaderMatrix.reset()
                shaderMatrix.setScale(rxOut / baseRadius, ryOut / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                orb.unitOuterGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = orb.unitOuterGrad
                orbPaint.alpha = masterPaintAlpha
                tmpRectF.set(cx - rxOut, cy - ryOut, cx + rxOut, cy + ryOut)
                canvas.drawOval(tmpRectF, orbPaint)

                val rxIn = (orb.keyRect.width() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                val ryIn = (orb.keyRect.height() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                shaderMatrix.reset()
                shaderMatrix.setScale(rxIn / baseRadius, ryIn / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                orb.unitInnerGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = orb.unitInnerGrad
                orbPaint.alpha = masterPaintAlpha
                tmpRectF.set(cx - rxIn, cy - ryIn, cx + rxIn, cy + ryIn)
                canvas.drawOval(tmpRectF, orbPaint)

                // 1B. 在单层合并模式 (LAYER_FULL_COMBINED) 下绘制「不规则弧形流光细丝 + 簇状星语」
                if (renderLayerMode == LAYER_FULL_COMBINED &&
                    (orb.flowRibbons.isNotEmpty() || orb.etherealStarlets.isNotEmpty())
                ) {
                    drawUnderKeyEtherealBloom(
                        canvas = canvas,
                        orb = orb,
                        now = now,
                        orbProgress = progress,
                        speedScale = speedScale,
                        alphaScale = 1.0f,
                        clipOutKeyCenter = true
                    )
                }
            } else if (renderLayerMode == LAYER_OVER_SPARKLE) {
                // 1C. 将当前按下的键帽圆角矩形精确镂空 (EVEN_ODD)，让弧形流光细丝与簇状小星芒
                //     从键帽底下边角自然漾出，既绝不遮挡当前键帽，又不会被邻键切掉尾韵星点，且不与底层重复叠加！
                if (orb.flowRibbons.isNotEmpty() || orb.etherealStarlets.isNotEmpty()) {
                    drawUnderKeyEtherealBloom(
                        canvas = canvas,
                        orb = orb,
                        now = now,
                        orbProgress = progress,
                        speedScale = speedScale,
                        alphaScale = 1.0f,
                        clipOutKeyCenter = true
                    )
                }

                if (orb.starFlares.isNotEmpty()) {
                    val rxVeil = (orb.keyRect.width() * 0.58f + dpF(18f)).coerceAtLeast(dpF(36f))
                    val ryVeil = (orb.keyRect.height() * 0.58f + dpF(16f)).coerceAtLeast(dpF(32f))
                    shaderMatrix.reset()
                    shaderMatrix.setScale(rxVeil / baseRadius, ryVeil / baseRadius)
                    shaderMatrix.postTranslate(cx, cy)
                    orb.unitVeilGrad.setLocalMatrix(shaderMatrix)
                    orbPaint.shader = orb.unitVeilGrad
                    orbPaint.alpha = masterPaintAlpha
                    tmpRectF.set(cx - rxVeil, cy - ryVeil, cx + rxVeil, cy + ryVeil)
                    canvas.drawOval(tmpRectF, orbPaint)
                }
            }
            orbPaint.alpha = 255

            // 2. 绘制键盘上「表面璀璨星河」四层粒子体系（可在「更多设置」中独立开关）
            if (renderLayerMode != LAYER_UNDER_GLOW &&
                (orb.stardustList.isNotEmpty() || orb.starPoints.isNotEmpty() || orb.starFlares.isNotEmpty())
            ) {
                val lifeElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()
                val rHalo = Color.red(pal.softHaloColor)
                val gHalo = Color.green(pal.softHaloColor)
                val bHalo = Color.blue(pal.softHaloColor)
                val rNearW = Color.red(pal.rayNearWhite)
                val gNearW = Color.green(pal.rayNearWhite)
                val bNearW = Color.blue(pal.rayNearWhite)
                val rShadow = Color.red(pal.lightContrastShadowColor)
                val gShadow = Color.green(pal.lightContrastShadowColor)
                val bShadow = Color.blue(pal.lightContrastShadowColor)

                for (neb in orb.nebulaSpots) {
                    val nx = cx + neb.relX + neb.driftDx * driftProgress
                    val ny = cy + neb.relY + neb.driftDy * driftProgress
                    val nr = neb.radiusPx
                    val nAlpha = (progress * neb.baseAlpha).coerceIn(0f, 1f)
                    val nebColR = if (pal.isLightSurface) rShadow else rHalo
                    val nebColG = if (pal.isLightSurface) gShadow else gHalo
                    val nebColB = if (pal.isLightSurface) bShadow else bHalo
                    val nebGrad = RadialGradient(
                        nx,
                        ny,
                        nr,
                        intArrayOf(
                            Color.argb((125f * nAlpha).toInt().coerceIn(0, 255), nebColR, nebColG, nebColB),
                            Color.argb((58f * nAlpha).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                            Color.argb(0, rHalo, gHalo, bHalo)
                        ),
                        floatArrayOf(0f, 0.52f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = nebGrad
                    canvas.drawCircle(nx, ny, nr, particleFillPaint)
                }

                particleFillPaint.shader = null
                for (dust in orb.stardustList) {
                    val dx = cx + dust.relX + dust.driftDx * driftProgress
                    val dy = cy + dust.relY + dust.driftDy * driftProgress
                    val twinkle = 0.62f + 0.38f * sin(lifeElapsed * dust.twinkleFreq + dust.twinklePhase)
                    val dAlpha = (progress * dust.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val cr = dust.coreRadiusPx

                    if (pal.isLightSurface) {
                        particleFillPaint.color = Color.argb(
                            (95f * dAlpha).toInt().coerceIn(0, 255),
                            rShadow,
                            gShadow,
                            bShadow
                        )
                        canvas.drawCircle(dx, dy, cr * 1.95f, particleFillPaint)
                    } else {
                        particleFillPaint.color = Color.argb(
                            (75f * dAlpha).toInt().coerceIn(0, 255),
                            rHalo,
                            gHalo,
                            bHalo
                        )
                        canvas.drawCircle(dx, dy, cr * 1.75f, particleFillPaint)
                    }

                    particleFillPaint.color = Color.argb(
                        (235f * dAlpha).toInt().coerceIn(0, 255),
                        rNearW,
                        gNearW,
                        bNearW
                    )
                    canvas.drawCircle(dx, dy, cr, particleFillPaint)
                }

                for (pt in orb.starPoints) {
                    val px = cx + pt.relX + pt.driftDx * driftProgress
                    val py = cy + pt.relY + pt.driftDy * driftProgress
                    val twinkle = 0.70f + 0.30f * sin(lifeElapsed * pt.twinkleFreq + pt.twinklePhase)
                    val pAlpha = (progress * pt.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val hr = pt.haloRadiusPx
                    val cr = pt.coreRadiusPx

                    val midHaloR = if (pal.isLightSurface) rShadow else rHalo
                    val midHaloG = if (pal.isLightSurface) gShadow else gHalo
                    val midHaloB = if (pal.isLightSurface) bShadow else bHalo

                    val ptGrad = RadialGradient(
                        px,
                        py,
                        hr,
                        intArrayOf(
                            Color.argb((245f * pAlpha).toInt().coerceIn(0, 255), 255, 255, 255),
                            Color.argb((165f * pAlpha).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                            Color.argb((78f * pAlpha).toInt().coerceIn(0, 255), midHaloR, midHaloG, midHaloB),
                            Color.argb(0, midHaloR, midHaloG, midHaloB)
                        ),
                        floatArrayOf(0f, 0.24f, 0.56f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = ptGrad
                    canvas.drawCircle(px, py, hr, particleFillPaint)

                    particleFillPaint.shader = null
                    particleFillPaint.color = Color.argb(
                        (255f * pAlpha).toInt().coerceIn(0, 255),
                        255,
                        255,
                        255
                    )
                    canvas.drawCircle(px, py, cr * 0.75f, particleFillPaint)
                }

                for (flare in orb.starFlares) {
                    val fx = cx + flare.relX + flare.driftDx * driftProgress
                    val fy = cy + flare.relY + flare.driftDy * driftProgress
                    val pulse = 0.88f + 0.12f * sin(lifeElapsed * 0.014f + flare.twinklePhase)
                    val fAlpha = (progress * flare.baseAlpha * pulse).coerceIn(0f, 1f)
                    val lenScale = 0.88f + 0.14f * progress
                    drawCelestialStarFlare(
                        canvas = canvas,
                        sx = fx,
                        sy = fy,
                        primaryRayPx = flare.primaryRayPx * lenScale,
                        orthogonalRayPx = flare.orthogonalRayPx * lenScale,
                        diagRayPx = flare.diagRayPx * lenScale,
                        baseHalfWidthPx = flare.baseHalfWidthPx,
                        rotationDeg = flare.rotationDeg,
                        isSixPointed = flare.isSixPointed,
                        isHeroFlare = flare.isHeroFlare,
                        alphaFactor = fAlpha,
                        pal = pal
                    )
                }
            }
        }

        if (clipSave != -1) {
            canvas.restoreToCount(clipSave)
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    /**
     * 🌙 复刻参考视频2「唯美不规则弧形流光细丝 + 簇状星点余韵」：
     * 1. 零放射直线：彻底告别死板烟花感，采用 1~3 缕贴合键帽转角的弯弯弧形流光游丝；
     * 2. 疏密留白：仅在 2~3 个不对称角落绽放「实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光小光圈 ° + 明暗碎星尘 ·」；
     * 3. 两段式余韵：前半段随底光轻盈漾开，后半段当底光渐淡时，小星点沿微弧线轻轻漂浮闪烁后再缓缓消融。
     */
    private fun drawUnderKeyEtherealBloom(
        canvas: Canvas,
        orb: SpotlightOrb,
        now: Long,
        orbProgress: Float,
        speedScale: Float,
        alphaScale: Float,
        clipOutKeyCenter: Boolean
    ) {
        val impactElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat() * speedScale
        // 第一阶段：轻盈绽开 (0 ~ 280ms)，采用柔滑 cubic ease-out
        val rawT = (impactElapsed / 280f).coerceIn(0f, 1f)
        val invT = 1f - rawT
        val bloomEase = 1f - invT * invT * invT

        // 第二阶段：尾韵微弧漂浮 (0 ~ 680ms)
        val afterglowDriftT = (impactElapsed / 640f).coerceIn(0f, 1f)

        // 即使长按按键不松手，流光与星点也在约 720ms 后温柔消融
        val holdDecay = if (impactElapsed <= 280f) {
            1.0f
        } else {
            ((740f - impactElapsed) / 460f).coerceIn(0f, 1f)
        }

        val holeSave = if (clipOutKeyCenter && width > 0 && height > 0) {
            val sc = canvas.save()
            keyHoleClipPath.reset()
            keyHoleClipPath.fillType = Path.FillType.EVEN_ODD
            keyHoleClipPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val insetPx = dpF(1.0f)
            tmpRectF.set(
                orb.keyRect.left + insetPx,
                orb.keyRect.top + insetPx,
                orb.keyRect.right - insetPx,
                orb.keyRect.bottom - insetPx
            )
            val kr = dpF(9.5f)
            keyHoleClipPath.addRoundRect(tmpRectF, kr, kr, Path.Direction.CW)
            canvas.clipPath(keyHoleClipPath)
            sc
        } else -1

        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val hw = (orb.keyRect.width() * 0.5f).coerceAtLeast(dpF(14f))
        val hh = (orb.keyRect.height() * 0.5f).coerceAtLeast(dpF(14f))
        val pal = orb.palette
        val rNearW = Color.red(pal.rayNearWhite)
        val gNearW = Color.green(pal.rayNearWhite)
        val bNearW = Color.blue(pal.rayNearWhite)
        val rLightHalo = Color.red(pal.meteorLightHaloColor)
        val gLightHalo = Color.green(pal.meteorLightHaloColor)
        val bLightHalo = Color.blue(pal.meteorLightHaloColor)

        particleFillPaint.shader = null

        // =====================================================================
        // 1. 绘制「不规则弧形流光细丝」(GossamerFlowRibbons)
        // =====================================================================
        val ribbonMasterAlpha = (orbProgress * holdDecay * alphaScale).coerceIn(0f, 1f)
        if (ribbonMasterAlpha > 0.02f) {
            for (ribbon in orb.flowRibbons) {
                val rAlpha = (ribbonMasterAlpha * ribbon.brightness).coerceIn(0f, 1f)
                if (rAlpha <= 0.02f) continue

                val tintColor = when (ribbon.colorVariant) {
                    1 -> pal.meteorAccent1
                    2 -> pal.meteorAccent2
                    else -> pal.meteorPrimaryTint
                }
                val rT = Color.red(tintColor)
                val gT = Color.green(tintColor)
                val bT = Color.blue(tintColor)

                val curStartAng = ribbon.startAngleRad + ribbon.angularDriftRad * afterglowDriftT
                val curSweepAng = ribbon.sweepAngleRad * (0.68f + 0.32f * bloomEase)

                // A. 外层柔焦光晕丝（浅色表面采用更柔和的高明度浅色晕染，绝不形成深色团块；深色表面完全保持原样）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx * (if (pal.isLightSurface) 1.68f else 1.75f),
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = 0.0f,
                    sEnd = 1.0f
                )
                val auraR = if (pal.isLightSurface) rLightHalo else rT
                val auraG = if (pal.isLightSurface) gLightHalo else gT
                val auraB = if (pal.isLightSurface) bLightHalo else bT
                val auraAlpha = (if (pal.isLightSurface) 96f else 115f) * rAlpha
                particleFillPaint.color = Color.argb(auraAlpha.toInt().coerceIn(0, 255), auraR, auraG, auraB)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // B. 中层丝滑彩色流光主体（1.0 倍宽：浅色表面呈现清透中等饱和度主题色，清晰可见且绝不发黑发棕）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx,
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = 0.06f,
                    sEnd = 0.94f
                )
                val midR = if (pal.isLightSurface) rT else (rT * 0.42f + rNearW * 0.58f).toInt()
                val midG = if (pal.isLightSurface) gT else (gT * 0.42f + gNearW * 0.58f).toInt()
                val midB = if (pal.isLightSurface) bT else (bBBlend(bT, bNearW))
                val bodyAlpha = (if (pal.isLightSurface) 208f else 210f) * rAlpha
                particleFillPaint.color = Color.argb(bodyAlpha.toInt().coerceIn(0, 255), midR, midG, midB)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // C. 内芯高亮银白游丝（浅色表面采用 0.44 倍纤细白芯，既保持清晰高光又绝不掩盖两侧彩色流光弧线）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx * (if (pal.isLightSurface) 0.44f else 0.52f),
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = if (pal.isLightSurface) 0.20f else 0.18f,
                    sEnd = if (pal.isLightSurface) 0.84f else 0.86f
                )
                val coreAlpha = (if (pal.isLightSurface) 244f else 250f) * rAlpha
                particleFillPaint.color = Color.argb(coreAlpha.toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // D. 主流光丝前端伴随一枚灵动小四芒星闪（复刻视频2第1款流光弧顶端的微星）
                if (ribbon.hasTipStarlet) {
                    val tipS = 0.82f
                    val tipAng = curStartAng + curSweepAng * tipS
                    val tipArch = sin(tipS * Math.PI.toFloat())
                    val tipEdge = computeKeyEdgeDist(hw, hh, tipAng)
                    val tipR = tipEdge + ribbon.baseOffsetPx + ribbon.swellOutPx * bloomEase * tipArch
                    val tipX = cx + cos(tipAng) * tipR
                    val tipY = cy + sin(tipAng) * tipR
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = tipX,
                        sy = tipY,
                        rayLenPx = dpF(2.8f) * (0.75f + 0.25f * bloomEase),
                        rotationDeg = (tipAng * 180f / Math.PI.toFloat()) + 15f,
                        alpha = rAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
            }
        }

        // =====================================================================
        // 2. 绘制「不对称簇状星群」（实心小四芒星 ✦ + 空心小星 ✧ + 柔光小光圈 ° + 明暗碎星尘 ·）
        // =====================================================================
        for (star in orb.etherealStarlets) {
            // 星点拥有更温柔的尾韵：主光晕变淡时，星点依然在空中保持闪烁再缓缓消散
            val lingerProgress = orbProgress.pow(star.lingerBoost)
            val twinkle = 0.64f + 0.36f * sin(impactElapsed * star.twinkleFreq + star.twinklePhase)
            val sAlpha = (lingerProgress * holdDecay * alphaScale * star.brightness * twinkle).coerceIn(0f, 1f)
            if (sAlpha <= 0.02f) continue

            // 运动轨迹：微弧度漾开 + 尾韵轻飘
            val curAng = star.baseAngleRad + star.arcCurveDriftRad * bloomEase
            val curRadialDist = star.edgeDistPx + star.startOffsetPx + star.bloomReachPx * bloomEase
            val sx = cx + cos(curAng) * curRadialDist + star.afterglowFloatDx * afterglowDriftT
            val sy = cy + sin(curAng) * curRadialDist + star.afterglowFloatDy * afterglowDriftT

            val tintColor = when (star.colorVariant) {
                1 -> pal.meteorAccent1
                2 -> pal.meteorAccent2
                else -> pal.meteorPrimaryTint
            }
            val rT = Color.red(tintColor)
            val gT = Color.green(tintColor)
            val bT = Color.blue(tintColor)

            when (star.shapeType) {
                SHAPE_SOLID_STAR4 -> {
                    val curRot = star.rotationDeg + star.spinDeg * afterglowDriftT
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        rayLenPx = star.sizePx * (0.82f + 0.18f * twinkle),
                        rotationDeg = curRot,
                        alpha = sAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
                SHAPE_HOLLOW_STAR4 -> {
                    val curRot = star.rotationDeg + star.spinDeg * afterglowDriftT
                    drawHollowFourPointStarlet(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        rayLenPx = star.sizePx * (0.85f + 0.15f * twinkle),
                        rotationDeg = curRot,
                        alpha = sAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
                SHAPE_SOFT_RING_PEARL -> {
                    val pr = star.sizePx
                    // 柔和内雾
                    particleFillPaint.color = Color.argb(
                        ((if (pal.isLightSurface) 95f else 62f) * sAlpha).toInt().coerceIn(0, 255),
                        rT,
                        gT,
                        bT
                    )
                    canvas.drawCircle(sx, sy, pr * 1.15f, particleFillPaint)
                    // 精致细线小光圈
                    particleStrokePaint.strokeWidth = dpF(0.68f)
                    particleStrokePaint.color = Color.argb(
                        ((if (pal.isLightSurface) 225f else 205f) * sAlpha).toInt().coerceIn(0, 255),
                        if (pal.isLightSurface) rT else (rT * 0.32f + 255 * 0.68f).toInt(),
                        if (pal.isLightSurface) gT else (gT * 0.32f + 255 * 0.68f).toInt(),
                        if (pal.isLightSurface) bT else (bT * 0.32f + 255 * 0.68f).toInt()
                    )
                    canvas.drawCircle(sx, sy, pr, particleStrokePaint)
                }
                else -> {
                    // 明暗错落的微星尘 (SHAPE_TWINKLE_DUST)
                    val cr = star.sizePx
                    if (pal.isLightSurface) {
                        particleFillPaint.color = Color.argb(
                            (130f * sAlpha).toInt().coerceIn(0, 255),
                            rLightHalo,
                            gLightHalo,
                            bLightHalo
                        )
                        canvas.drawCircle(sx, sy, cr * 2.1f, particleFillPaint)
                        particleFillPaint.color = Color.argb(
                            (228f * sAlpha).toInt().coerceIn(0, 255),
                            rT,
                            gT,
                            bT
                        )
                        canvas.drawCircle(sx, sy, cr * 1.25f, particleFillPaint)
                    } else {
                        particleFillPaint.color = Color.argb(
                            (105f * sAlpha).toInt().coerceIn(0, 255),
                            rT,
                            gT,
                            bT
                        )
                        canvas.drawCircle(sx, sy, cr * 1.95f, particleFillPaint)
                    }
                    particleFillPaint.color = Color.argb(
                        (252f * sAlpha).toInt().coerceIn(0, 255),
                        255,
                        255,
                        255
                    )
                    canvas.drawCircle(sx, sy, cr * (if (pal.isLightSurface) 0.65f else 0.85f), particleFillPaint)
                }
            }
        }

        if (holeSave != -1) {
            canvas.restoreToCount(holeSave)
        }
    }

    private fun bBBlend(bT: Int, bNearW: Int): Int {
        return (bT * 0.42f + bNearW * 0.58f).toInt().coerceIn(0, 255)
    }

    /**
     * 构建两头尖细如游丝、中间柔亮微拱的「不规则弧形流光细丝」几何路径
     */
    private fun buildCurvedGossamerRibbonPath(
        cx: Float,
        cy: Float,
        hw: Float,
        hh: Float,
        startAngle: Float,
        sweepAngle: Float,
        baseOffsetPx: Float,
        swellOutPx: Float,
        maxHalfWidthPx: Float,
        rippleWavePx: Float,
        ripplePhase: Float,
        sStart: Float,
        sEnd: Float
    ) {
        ribbonPath.reset()
        val steps = 8
        // 沿着弧线正向采样外侧边缘
        for (i in 0..steps) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val ux = cos(ang)
            val uy = sin(ang)
            val edgeDist = computeKeyEdgeDist(hw, hh, ang)
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.2f + ripplePhase) * rippleWavePx * arch
            val centerR = edgeDist + baseOffsetPx + swellOutPx * arch + wave
            // 丝线半宽在两端收束为 0，中间柔润饱满
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rOut = centerR + halfW
            val x = cx + ux * rOut
            val y = cy + uy * rOut
            if (i == 0) {
                ribbonPath.moveTo(x, y)
            } else {
                ribbonPath.lineTo(x, y)
            }
        }
        // 沿着弧线反向采样内侧边缘闭合
        for (i in steps downTo 0) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val ux = cos(ang)
            val uy = sin(ang)
            val edgeDist = computeKeyEdgeDist(hw, hh, ang)
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.2f + ripplePhase) * rippleWavePx * arch
            val centerR = edgeDist + baseOffsetPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rIn = centerR - halfW
            val x = cx + ux * rIn
            val y = cy + uy * rIn
            ribbonPath.lineTo(x, y)
        }
        ribbonPath.close()
    }

    /**
     * 绘制实心纤细小四芒星 ✦（带同色系柔晕 + 纯白璀璨星芯）
     */
    private fun drawSolidFourPointStarlet(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int,
        isLightSurface: Boolean
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        // 柔和星晕底衬
        particleFillPaint.color = Color.argb(
            ((if (isLightSurface) 140f else 95f) * alpha).toInt().coerceIn(0, 255),
            rT,
            gT,
            bT
        )
        canvas.drawCircle(0f, 0f, rayLenPx * 0.56f, particleFillPaint)

        val orthoLen = rayLenPx * 0.78f
        val waist = rayLenPx * 0.14f

        // 外层同色系星芒轮廓
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        particleFillPaint.color = Color.argb(
            ((if (isLightSurface) 238f else 210f) * alpha).toInt().coerceIn(0, 255),
            if (isLightSurface) rT else (rT * 0.38f + 255 * 0.62f).toInt(),
            if (isLightSurface) gT else (gT * 0.38f + 255 * 0.62f).toInt(),
            if (isLightSurface) bT else (bT * 0.38f + 255 * 0.62f).toInt()
        )
        canvas.drawPath(starPath, particleFillPaint)

        // 内层高亮纯白星核
        val innerScale = if (isLightSurface) 0.62f else 0.74f
        canvas.scale(innerScale, innerScale)
        particleFillPaint.color = Color.argb((255f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, particleFillPaint)

        canvas.restoreToCount(sc)
    }

    /**
     * 绘制空心细线小四芒星 ✧（复刻参考视频2标志性的精致镂空小星）
     */
    private fun drawHollowFourPointStarlet(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int,
        isLightSurface: Boolean
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val orthoLen = rayLenPx * 0.82f
        val waist = rayLenPx * 0.20f

        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        // 先画一层微弱同色柔雾描边
        particleStrokePaint.strokeWidth = dpF(1.25f)
        particleStrokePaint.color = Color.argb(
            ((if (isLightSurface) 175f else 115f) * alpha).toInt().coerceIn(0, 255),
            rT,
            gT,
            bT
        )
        canvas.drawPath(starPath, particleStrokePaint)

        // 再画纤细透亮的空心星线
        particleStrokePaint.strokeWidth = dpF(0.68f)
        particleStrokePaint.color = Color.argb(
            ((if (isLightSurface) 242f else 238f) * alpha).toInt().coerceIn(0, 255),
            if (isLightSurface) rT else (rT * 0.25f + 255 * 0.75f).toInt(),
            if (isLightSurface) gT else (gT * 0.25f + 255 * 0.75f).toInt(),
            if (isLightSurface) bT else (bT * 0.25f + 255 * 0.75f).toInt()
        )
        canvas.drawPath(starPath, particleStrokePaint)

        canvas.restoreToCount(sc)
    }

    private fun buildSlenderStarFlarePath(
        primaryLen: Float,
        orthoLen: Float,
        diagLen: Float,
        baseW: Float,
        isSixPointed: Boolean
    ) {
        starPath.reset()
        if (isSixPointed) {
            val angles = floatArrayOf(
                0f,
                (Math.PI / 3.0).toFloat(),
                (2.0 * Math.PI / 3.0).toFloat()
            )
            for (idx in angles.indices) {
                val a = angles[idx]
                val rayL = if (idx == 0) primaryLen else orthoLen * 0.88f
                val rw = if (idx == 0) baseW else baseW * 0.78f
                addSymmetricNeedlePair(a, rayL, rw)
            }
        } else {
            addSymmetricNeedlePair(0f, primaryLen, baseW)
            addSymmetricNeedlePair((Math.PI * 0.5).toFloat(), orthoLen, baseW * 0.88f)
            if (diagLen > 1.2f) {
                val dw = baseW * 0.52f
                addSymmetricNeedlePair((Math.PI * 0.25).toFloat(), diagLen, dw)
                addSymmetricNeedlePair((Math.PI * 0.75).toFloat(), diagLen, dw)
            }
        }
    }

    private fun addSymmetricNeedlePair(angleRad: Float, rayLen: Float, halfBaseW: Float) {
        val ux = cos(angleRad)
        val uy = sin(angleRad)
        val px = -uy
        val py = ux
        val cDist = rayLen * 0.11f
        val cW = halfBaseW * 0.075f

        starPath.moveTo(px * halfBaseW, py * halfBaseW)
        starPath.quadTo(ux * cDist + px * cW, uy * cDist + py * cW, ux * rayLen, uy * rayLen)
        starPath.quadTo(ux * cDist - px * cW, uy * cDist - py * cW, -px * halfBaseW, -py * halfBaseW)
        starPath.close()

        starPath.moveTo(-px * halfBaseW, -py * halfBaseW)
        starPath.quadTo(-ux * cDist - px * cW, -uy * cDist - py * cW, -ux * rayLen, -uy * rayLen)
        starPath.quadTo(-ux * cDist + px * cW, -uy * cDist + py * cW, px * halfBaseW, py * halfBaseW)
        starPath.close()
    }

    private fun drawCelestialStarFlare(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        primaryRayPx: Float,
        orthogonalRayPx: Float,
        diagRayPx: Float,
        baseHalfWidthPx: Float,
        rotationDeg: Float,
        isSixPointed: Boolean,
        isHeroFlare: Boolean,
        alphaFactor: Float,
        pal: StarlightColorAdapter.StarlightPalette
    ) {
        if (primaryRayPx <= 1f || alphaFactor <= 0.01f) return
        val save = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val rHalo = Color.red(pal.softHaloColor)
        val gHalo = Color.green(pal.softHaloColor)
        val bHalo = Color.blue(pal.softHaloColor)
        val rNearW = Color.red(pal.rayNearWhite)
        val gNearW = Color.green(pal.rayNearWhite)
        val bNearW = Color.blue(pal.rayNearWhite)
        val rShadow = Color.red(pal.lightContrastShadowColor)
        val gShadow = Color.green(pal.lightContrastShadowColor)
        val bShadow = Color.blue(pal.lightContrastShadowColor)

        val haloR = (primaryRayPx * (if (isHeroFlare) 0.44f else 0.40f)).coerceAtLeast(dpF(3.2f))
        val haloColR = if (pal.isLightSurface) rShadow else rHalo
        val haloColG = if (pal.isLightSurface) gShadow else gHalo
        val haloColB = if (pal.isLightSurface) bShadow else bHalo
        val haloCenterAlpha = (if (pal.isLightSurface) 118f else 92f) * alphaFactor
        val haloGrad = RadialGradient(
            0f,
            0f,
            haloR,
            intArrayOf(
                Color.argb(haloCenterAlpha.toInt().coerceIn(0, 255), haloColR, haloColG, haloColB),
                Color.argb((haloCenterAlpha * 0.42f).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.48f, 1.0f),
            Shader.TileMode.CLAMP
        )
        orbPaint.shader = haloGrad
        canvas.drawCircle(0f, 0f, haloR, orbPaint)

        if (pal.isLightSurface) {
            buildSlenderStarFlarePath(
                primaryLen = primaryRayPx * 1.02f,
                orthoLen = orthogonalRayPx * 1.02f,
                diagLen = diagRayPx,
                baseW = baseHalfWidthPx * 1.45f,
                isSixPointed = isSixPointed
            )
            val shadowRayGrad = RadialGradient(
                0f,
                0f,
                primaryRayPx * 1.02f,
                intArrayOf(
                    Color.argb((148f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((86f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((24f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb(0, rShadow, gShadow, bShadow)
                ),
                floatArrayOf(0f, 0.32f, 0.72f, 1.0f),
                Shader.TileMode.CLAMP
            )
            particleFillPaint.shader = shadowRayGrad
            canvas.drawPath(starPath, particleFillPaint)
        }

        buildSlenderStarFlarePath(
            primaryLen = primaryRayPx,
            orthoLen = orthogonalRayPx,
            diagLen = diagRayPx,
            baseW = baseHalfWidthPx,
            isSixPointed = isSixPointed
        )
        val rayGrad = RadialGradient(
            0f,
            0f,
            primaryRayPx,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((232f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((115f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((28f * alphaFactor).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.18f, 0.48f, 0.80f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = rayGrad
        canvas.drawPath(starPath, particleFillPaint)

        val coreR = (baseHalfWidthPx * (if (isHeroFlare) 2.3f else 1.9f)).coerceAtLeast(dpF(1.3f))
        val coreGrad = RadialGradient(
            0f,
            0f,
            coreR,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((210f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb(0, rNearW, gNearW, bNearW)
            ),
            floatArrayOf(0f, 0.45f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = coreGrad
        canvas.drawCircle(0f, 0f, coreR, particleFillPaint)

        canvas.restoreToCount(save)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 统一按键与顶栏背景视图（支持三大渲染模式）：
 * 1. 莫奈花园模式 (bitmap != null)：渲染 1:1 油画睡莲键帽贴图；
 * 2. 纯色框架 + 已上传自定义背景图模式 (useFrostedCustomBg = true)：
 *    自动定位当前按键在键盘中的坐标，实时读取并模糊对应位置的底图 (CustomBgManager.getBlurredBitmap)，
 *    再叠加半透明毛玻璃键帽底色与细腻磨砂白边；
 * 3. 纯色框架默认模式：渲染干净的纯色键帽，按下时自动呈现柔和同色系反馈。
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#528262"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT,
    private val useFrostedCustomBg: Boolean = false
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    KeySoundManager.playClick(context)
                }
                if (enableGlow) {
                    val bgSample = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else null
                    forEachBacklightOverlay { overlay ->
                        if (value) {
                            overlay.triggerKeyDown(this, cornerRadiusPx, glowColor, bgSample)
                        } else {
                            overlay.triggerKeyUp(this)
                        }
                    }
                }
                invalidate()
            }
        }

    private var cachedOverlays: List<KeyboardBacklightOverlayView>? = null

    private inline fun forEachBacklightOverlay(action: (KeyboardBacklightOverlayView) -> Unit) {
        val existing = cachedOverlays
        if (existing != null) {
            for (ov in existing) action(ov)
            return
        }
        var p = parent
        val found = ArrayList<KeyboardBacklightOverlayView>(2)
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    found.add(child)
                }
            }
            if (found.isNotEmpty()) {
                cachedOverlays = found
                for (ov in found) action(ov)
                return
            }
            p = p.parent
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cachedOverlays = null
        frostedCoordsValid = false
    }

    private fun findRootKbContainer(): View? {
        var cur: View? = this
        var last: View? = null
        while (cur != null) {
            last = cur
            val np = cur.parent
            cur = if (np is View) np else null
        }
        return last
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val frostBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.0f, resources.displayMetrics)
        color = Color.argb(135, 255, 255, 255)
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()
    private val blurMatrix = Matrix()
    private val selfLoc = IntArray(2)
    private val rootLoc = IntArray(2)
    private var frostedCoordsValid = false
    private var cachedRelX = 0f
    private var cachedRelY = 0f
    private var cachedRootW = 0f
    private var cachedRootH = 0f

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        if (changed) frostedCoordsValid = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        val blurredBg = if (useFrostedCustomBg) CustomBgManager.getBlurredBitmap(context) else null

        // 极速通道（模式 3：纯色键帽）：直接使用 GPU 硬件加速的 drawRoundRect，彻底免除高开销的 canvas.clipPath 蒙版裁剪！
        if (bitmap == null && blurredBg == null) {
            if (fallbackBgTop != Color.TRANSPARENT) {
                val drawCol = if (isKeyPressedState) blendLivelyPressColor(fallbackBgTop, glowColor) else fallbackBgTop
                fallbackFillPaint.color = Color.argb(
                    255,
                    Color.red(drawCol),
                    Color.green(drawCol),
                    Color.blue(drawCol)
                )
                canvas.drawRoundRect(keyRectF, r, r, fallbackFillPaint)
            }
            return
        }

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            // 模式 1：莫奈花园专属油画键帽贴图
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (blurredBg != null) {
            // 模式 2：纯色框架下已上传自定义背景图 -> 缓存相对坐标读取并模糊对应坐标处的底图 + 半透明毛玻璃键帽层
            if (!frostedCoordsValid || cachedRootW <= 1f || cachedRootH <= 1f) {
                val rootV = findRootKbContainer()
                cachedRootW = (rootV?.width ?: width).toFloat().coerceAtLeast(1f)
                cachedRootH = (rootV?.height ?: height).toFloat().coerceAtLeast(1f)
                getLocationInWindow(selfLoc)
                rootV?.getLocationInWindow(rootLoc)
                cachedRelX = (selfLoc[0] - rootLoc[0]).toFloat()
                cachedRelY = (selfLoc[1] - rootLoc[1]).toFloat()
                frostedCoordsValid = true
            }

            val scale = max(cachedRootW / blurredBg.width.toFloat(), cachedRootH / blurredBg.height.toFloat())
            val dx = (cachedRootW - blurredBg.width * scale) * 0.5f - cachedRelX
            val dy = (cachedRootH - blurredBg.height * scale) * 0.5f - cachedRelY
            blurMatrix.reset()
            blurMatrix.setScale(scale, scale)
            blurMatrix.postTranslate(dx, dy)
            canvas.drawBitmap(blurredBg, blurMatrix, bmpPaint)

            // 叠加半透明毛玻璃键帽色（按下时向灵动光晕色轻柔过渡 22%，绝不压暗变灰！）
            val baseCol = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else Color.WHITE
            val tintCol = if (isKeyPressedState) blendLivelyPressColor(baseCol, glowColor) else baseCol
            val frostAlpha = if (isKeyPressedState) 138 else 110
            fallbackFillPaint.color = Color.argb(
                frostAlpha,
                Color.red(tintCol),
                Color.green(tintCol),
                Color.blue(tintCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)

        if (blurredBg != null && bitmap == null) {
            val half = frostBorderPaint.strokeWidth * 0.5f
            keyRectF.set(half, half, w - half, h - half)
            canvas.drawRoundRect(keyRectF, r, r, frostBorderPaint)
        }
    }

    private fun blendLivelyPressColor(baseColor: Int, livelyGlowColor: Int): Int {
        val r = (Color.red(baseColor) * 0.72f + Color.red(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val g = (Color.green(baseColor) * 0.72f + Color.green(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val b = (Color.blue(baseColor) * 0.72f + Color.blue(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }
}

/**
 * 现代圆角极简风「顶部状态栏 4 图标视图」（复刻参考图 1000128623.jpg & 1000128608.jpg）：
 * - 与圆角按键风格高度统一，采用圆角方糖（Squircle）微填充底衬 + 圆润胶囊线条：
 *   0 (设置)：现代圆角四宫格控制中心图标（3 枚圆角方格 + 右上角点睛圆点）
 *   1 (表情)：圆角方糖微填充萌系笑脸图标（圆润胶囊眼 + 柔和微笑弧）
 *   2 (常用)：圆角书签卡片图标（圆角外框 + 双胶囊横线 + 右上角小折角）
 *   3 (收起)：圆角胶囊下折图标（柔和圆角底衬 + 宽角圆头下折箭头 + 底部短横）
 * - 在莫奈花园模式下支持渲染水彩睡莲图标。
 */
/**
 * 顶部状态栏 5 图标独立自定义上传与大小/染色管理器：
 * - 支持为 5 个顶栏槽位独立上传自定义 PNG/WebP/JPG 图标：
 *   0 (TYPE_SETTINGS)：第1个 - 设置（内置默认：去猫脸保留耳廓与小胡须的圆润猫猫头）
 *   1 (TYPE_EMOJI)：第2个 - 表情（内置默认：大小双爱心）
 *   4 (TYPE_CLIPBOARD)：第3个 - 剪贴板（内置默认：环绕小星球）
 *   2 (TYPE_FAVORITE)：第4个 - 收藏/常用语（内置默认：圆润胖五角星）
 *   3 (TYPE_COLLAPSE)：第5个 - 收起键盘（内置默认：三尖圆珠小皇冠）
 * - 智能背景处理：若用户上传的是透明底 PNG，直接保留透明通道并自动裁切多余透明边距；
 *   若用户上传的是白底/纯浅色底图片，自动识别四角背景色并智能抠除转为透明底！
 * - 支持「线条随皮肤自动变色」与「保留彩色原图本色」两种渲染模式自由切换。
 * - 支持 14dp ~ 34dp 无级调节顶栏图标显示大小（默认 22dp，精致不突兀）。
 */
object CustomTopIconManager {
    const val DEFAULT_ICON_SIZE_DP = 22
    const val MIN_ICON_SIZE_DP = 14
    const val MAX_ICON_SIZE_DP = 34

    private val customBmpCache = HashMap<Int, Pair<Long, Bitmap>>()

    fun getSlotFile(context: Context, iconType: Int): File {
        return File(context.filesDir, "custom_top_icon_$iconType.png")
    }

    fun getSlotTimestamp(context: Context, iconType: Int): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_top_icon_ts_$iconType", 0L)
    }

    fun getSlotPresetIconId(context: Context, iconType: Int): Int {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getInt("top_slot_preset_icon_$iconType", iconType)
    }

    fun setSlotPresetIconId(context: Context, iconType: Int, presetId: Int) {
        try {
            getSlotFile(context, iconType).delete()
        } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putInt("top_slot_preset_icon_$iconType", presetId)
            .putLong("custom_top_icon_ts_$iconType", 0L)
            .putLong("custom_top_icon_global_ts", now)
            .apply()
        synchronized(customBmpCache) {
            customBmpCache.remove(iconType)
        }
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val tintFlag = if (isFollowSkinColor(context)) 1L else 0L
        val sizeDp = getIconSizeDp(context).toLong()
        val presetHash = (getSlotPresetIconId(context, 0).toLong() shl 5) xor
            (getSlotPresetIconId(context, 1).toLong() shl 8) xor
            (getSlotPresetIconId(context, 2).toLong() shl 11) xor
            (getSlotPresetIconId(context, 3).toLong() shl 14) xor
            (getSlotPresetIconId(context, 4).toLong() shl 17)
        return getSlotTimestamp(context, 0) xor
            (getSlotTimestamp(context, 1) shl 1) xor
            (getSlotTimestamp(context, 2) shl 2) xor
            (getSlotTimestamp(context, 3) shl 3) xor
            (getSlotTimestamp(context, 4) shl 4) xor
            presetHash xor
            (tintFlag shl 20) xor
            (sizeDp shl 24) xor
            prefs.getLong("custom_top_icon_global_ts", 0L)
    }

    fun hasCustomIcon(context: Context, iconType: Int): Boolean {
        return getSlotTimestamp(context, iconType) > 0L && getSlotFile(context, iconType).exists()
    }

    fun isFollowSkinColor(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("custom_top_icon_follow_skin", true)
    }

    fun setFollowSkinColor(context: Context, follow: Boolean) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("custom_top_icon_follow_skin", follow)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun getIconSizeDp(context: Context): Int {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getInt("top_bar_icon_size_dp", DEFAULT_ICON_SIZE_DP).coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
    }

    fun setIconSizeDp(context: Context, sizeDp: Int) {
        val clamped = sizeDp.coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("top_bar_icon_size_dp", clamped)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun clearCustomIcon(context: Context, iconType: Int) {
        try {
            getSlotFile(context, iconType).delete()
        } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .remove("top_slot_preset_icon_$iconType")
            .putLong("custom_top_icon_ts_$iconType", 0L)
            .putLong("custom_top_icon_global_ts", now)
            .apply()
        synchronized(customBmpCache) {
            customBmpCache.remove(iconType)
        }
    }

    fun clearAllCustomIcons(context: Context) {
        for (t in listOf(0, 1, 2, 3, 4)) {
            try {
                getSlotFile(context, t).delete()
            } catch (_: Exception) {}
        }
        val now = System.currentTimeMillis()
        val editor = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE).edit()
        for (t in listOf(0, 1, 2, 3, 4)) {
            editor.remove("top_slot_preset_icon_$t")
            editor.putLong("custom_top_icon_ts_$t", 0L)
        }
        editor.putLong("custom_top_icon_global_ts", now).apply()
        synchronized(customBmpCache) {
            customBmpCache.clear()
        }
    }

    fun getCustomBitmap(context: Context, iconType: Int): Bitmap? {
        val ts = getSlotTimestamp(context, iconType)
        if (ts <= 0L) return null
        synchronized(customBmpCache) {
            val cached = customBmpCache[iconType]
            if (cached != null && cached.first == ts && !cached.second.isRecycled) {
                return cached.second
            }
            val f = getSlotFile(context, iconType)
            if (!f.exists()) return null
            try {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp != null) {
                    customBmpCache[iconType] = ts to bmp
                    return bmp
                }
            } catch (_: Exception) {}
            return null
        }
    }

    /**
     * 导入并智能处理用户上传的图标：
     * 1. 若原图自带透明通道（PNG/WebP），完整保留透明通道与抗锯齿边缘；
     * 2. 若原图是不透明白底/浅色底图片，自动采样四角背景色并智能去底转为透明通道；
     * 3. 自动裁切四周多余空白并保留均匀呼吸边距，存入应用私有目录。
     */
    fun saveCustomIconFromBitmap(context: Context, iconType: Int, rawBitmap: Bitmap): Boolean {
        try {
            val maxDim = 256
            val rw = rawBitmap.width
            val rh = rawBitmap.height
            if (rw <= 0 || rh <= 0) return false

            val scaled = if (rw > maxDim || rh > maxDim) {
                val ratio = minOf(maxDim.toFloat() / rw.toFloat(), maxDim.toFloat() / rh.toFloat())
                Bitmap.createScaledBitmap(
                    rawBitmap,
                    (rw * ratio).toInt().coerceAtLeast(1),
                    (rh * ratio).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                rawBitmap.copy(Bitmap.Config.ARGB_8888, true)
            }

            val w = scaled.width
            val h = scaled.height
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)

            // 检测是否已有透明背景
            var transparentCount = 0
            for (p in pixels) {
                val a = (p ushr 24) and 0xFF
                if (a < 210) transparentCount++
            }
            val hasNativeAlpha = transparentCount > (w * h) / 25

            if (!hasNativeAlpha) {
                // 自动采样四角背景色，智能抠除纯色底
                val corners = intArrayOf(
                    pixels[0],
                    pixels[w - 1],
                    pixels[(h - 1) * w],
                    pixels[(h - 1) * w + (w - 1)]
                )
                var bgR = 0f
                var bgG = 0f
                var bgB = 0f
                for (c in corners) {
                    bgR += ((c shr 16) and 0xFF)
                    bgG += ((c shr 8) and 0xFF)
                    bgB += (c and 0xFF)
                }
                bgR /= 4f
                bgG /= 4f
                bgB /= 4f

                var maxDist = 1f
                for (p in pixels) {
                    val dr = ((p shr 16) and 0xFF) - bgR
                    val dg = ((p shr 8) and 0xFF) - bgG
                    val db = (p and 0xFF) - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    if (d > maxDist) maxDist = d
                }

                val lowThresh = (maxDist * 0.16f).coerceAtLeast(18f)
                val highThresh = (maxDist * 0.52f).coerceAtLeast(lowThresh + 16f)

                for (i in pixels.indices) {
                    val p = pixels[i]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val dr = r - bgR
                    val dg = g - bgG
                    val db = b - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    val t = ((d - lowThresh) / (highThresh - lowThresh)).coerceIn(0f, 1f)
                    val smoothA = (t * t * (3f - 2f * t) * 255f).toInt().coerceIn(0, 255)
                    pixels[i] = (smoothA shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            // 自动寻找有效像素边界并适度留白裁切
            var minX = w
            var minY = h
            var maxX = 0
            var maxY = 0
            for (y in 0 until h) {
                val rowOff = y * w
                for (x in 0 until w) {
                    val a = (pixels[rowOff + x] ushr 24) and 0xFF
                    if (a > 24) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }

            val processed = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            processed.setPixels(pixels, 0, w, 0, 0, w, h)

            val finalBmp = if (minX <= maxX && minY <= maxY) {
                val padX = ((maxX - minX + 1) * 0.05f).toInt().coerceAtLeast(2)
                val padY = ((maxY - minY + 1) * 0.05f).toInt().coerceAtLeast(2)
                val cx0 = (minX - padX).coerceAtLeast(0)
                val cy0 = (minY - padY).coerceAtLeast(0)
                val cx1 = (maxX + padX).coerceAtMost(w - 1)
                val cy1 = (maxY + padY).coerceAtMost(h - 1)
                Bitmap.createBitmap(processed, cx0, cy0, (cx1 - cx0 + 1).coerceAtLeast(1), (cy1 - cy0 + 1).coerceAtLeast(1))
            } else {
                processed
            }

            val outFile = getSlotFile(context, iconType)
            FileOutputStream(outFile).use { fos ->
                finalBmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            val now = System.currentTimeMillis()
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putLong("custom_top_icon_ts_$iconType", now)
                .putLong("custom_top_icon_global_ts", now)
                .apply()
            synchronized(customBmpCache) {
                customBmpCache[iconType] = now to finalBmp
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }
}

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = false
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0       // 🐱 小胡须圆润猫猫头
        const val TYPE_EMOJI = 1          // 💕 大小双爱心（图5同款）
        const val TYPE_PHRASE = 2         // ⭐ 圆润胖五角小星星（图5同款）
        const val TYPE_FAVORITE = 2       // ⭐ 圆润胖五角小星星（图5同款）
        const val TYPE_COLLAPSE = 3       // 👑 三尖圆珠小皇冠（图5同款）
        const val TYPE_CLIPBOARD = 4      // 🪐 环绕小星球（图5同款）
        const val ICON_BOW = 5            // 🎀 甜心蝴蝶结（图5同款全新重绘）
        const val ICON_FLOWER = 6         // 🌸 六瓣小樱花（图5同款全新重绘）
        const val ICON_SPARKLES = 7       // ✨ 双子闪星芒（图5同款）
        const val ICON_CLOVER = 8         // 🍀 四叶幸运草（图5同款）
        const val ICON_LUCKY_CLOVER = 9   // ☘️ 带茎幸运草（图5同款）
        const val ICON_METEOR = 10        // 🌠 弧线许愿星（图5同款）
        const val ICON_SNOWFLAKE = 11     // ❄️ 晶莹小雪花（图5同款）
        const val ICON_BOOK = 12          // 📖 翻开小书本（图5同款）
        const val ICON_STAR_MOON = 13     // 🌙 弯月伴萌星
        const val ICON_MAGIC_WAND = 14    // 🪄 魔法小星杖

        val ALL_PRESET_ICONS: List<Pair<Int, String>> = listOf(
            ICON_BOW to "🎀蝴蝶结",
            ICON_FLOWER to "🌸小樱花",
            ICON_SPARKLES to "✨双星芒",
            ICON_CLOVER to "🍀四叶草",
            ICON_LUCKY_CLOVER to "☘️幸运草",
            ICON_METEOR to "🌠许愿星",
            ICON_SNOWFLAKE to "❄️小雪花",
            ICON_BOOK to "📖小书本",
            ICON_STAR_MOON to "🌙星月",
            ICON_MAGIC_WAND to "🪄星杖",
            TYPE_SETTINGS to "🐱猫猫头",
            TYPE_EMOJI to "💕双爱心",
            TYPE_CLIPBOARD to "🪐小星球",
            TYPE_FAVORITE to "⭐胖星星",
            TYPE_COLLAPSE to "👑小皇冠"
        )

        fun getPresetIconName(presetId: Int): String {
            return ALL_PRESET_ICONS.firstOrNull { it.first == presetId }?.second ?: "✨可爱图标"
        }

        private val cuteBitmapCache = HashMap<Int, Bitmap>()

        fun getCuteHollowBitmap(context: Context, type: Int): Bitmap? {
            if (type == ICON_STAR_MOON || type == ICON_MAGIC_WAND) return null
            synchronized(cuteBitmapCache) {
                cuteBitmapCache[type]?.let { if (!it.isRecycled) return it }
                val assetName = when (type) {
                    TYPE_SETTINGS -> "cute_icons/icon_cat.png"
                    TYPE_EMOJI -> "cute_icons/icon_paw.png"
                    TYPE_CLIPBOARD -> "cute_icons/icon_heart.png"
                    TYPE_PHRASE -> "cute_icons/icon_star.png"
                    TYPE_COLLAPSE -> "cute_icons/icon_sakura.png"
                    ICON_BOW -> "cute_icons/icon_bow.png"
                    ICON_FLOWER -> "cute_icons/icon_flower.png"
                    ICON_SPARKLES -> "cute_icons/icon_sparkles.png"
                    ICON_CLOVER -> "cute_icons/icon_clover.png"
                    ICON_LUCKY_CLOVER -> "cute_icons/icon_lucky_clover.png"
                    ICON_METEOR -> "cute_icons/icon_meteor.png"
                    ICON_SNOWFLAKE -> "cute_icons/icon_snowflake.png"
                    ICON_BOOK -> "cute_icons/icon_book.png"
                    else -> "cute_icons/icon_star.png"
                }
                try {
                    context.assets.open(assetName).use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) {
                            cuteBitmapCache[type] = bmp
                            return bmp
                        }
                    }
                } catch (_: Exception) {}
                return null
            }
        }
    }

    private val tintedBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(iconColor, PorterDuff.Mode.SRC_IN)
    }
    private val rawColorBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(3.0f))
        color = iconColor
    }

    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        tintedBitmapPaint.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
        strokePaint.color = newColor
        fineStrokePaint.color = newColor
        starStrokePaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f

        // 0. 莫奈花园油画睡莲特殊皮肤专属状态栏：优先绘制原版水彩睡莲/花苞/荷叶图标（1:1 复刻图5，绝不变成猫猫头！）
        if (useBotanicalStyle) {
            val lotusIdx = when (iconType) {
                TYPE_SETTINGS -> 0
                TYPE_EMOJI -> 1
                TYPE_CLIPBOARD, TYPE_PHRASE -> 2
                TYPE_COLLAPSE -> 3
                else -> 0
            }
            val lotusBmp = MonetTextureManager.getTopIconBitmap(context, lotusIdx)
            if (lotusBmp != null && lotusBmp.width > 0 && lotusBmp.height > 0) {
                val aspect = lotusBmp.width.toFloat() / lotusBmp.height.toFloat()
                var drawH = h * 0.94f
                var drawW = drawH * aspect
                if (drawW > w * 0.96f) {
                    drawW = w * 0.96f
                    drawH = drawW / aspect
                }
                srcRect.set(0, 0, lotusBmp.width, lotusBmp.height)
                dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
                canvas.drawBitmap(lotusBmp, srcRect, dstRectF, rawColorBitmapPaint)
                return
            }
        }

        // 1. 优先检查用户是否为该槽位上传了自定义状态栏图标
        val customBmp = CustomTopIconManager.getCustomBitmap(context, iconType)
        if (customBmp != null && customBmp.width > 0 && customBmp.height > 0) {
            val aspect = customBmp.width.toFloat() / customBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, customBmp.width, customBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            val paintToUse = if (CustomTopIconManager.isFollowSkinColor(context)) tintedBitmapPaint else rawColorBitmapPaint
            canvas.drawBitmap(customBmp, srcRect, dstRectF, paintToUse)
            return
        }

        // 2. 检查当前顶栏槽位选中的内置可爱图标（支持在 15 款图 5 同款可爱图标间任意换装！）
        val presetId = CustomTopIconManager.getSlotPresetIconId(context, iconType)
        if (presetId == ICON_STAR_MOON || presetId == ICON_MAGIC_WAND) {
            val r = minOf(w, h) * 0.38f
            if (presetId == ICON_MAGIC_WAND) {
                WildcardCuteIconView.drawVectorStarWand(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path)
            } else {
                WildcardCuteIconView.drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
            }
            return
        }

        val cuteBmp = getCuteHollowBitmap(context, presetId)
        if (cuteBmp != null && cuteBmp.width > 0 && cuteBmp.height > 0) {
            val aspect = cuteBmp.width.toFloat() / cuteBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, cuteBmp.width, cuteBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            canvas.drawBitmap(cuteBmp, srcRect, dstRectF, tintedBitmapPaint)
            return
        }

        val r = minOf(w, h) * 0.42f
        drawCuteHollowIcon(canvas, cx, cy, r)
    }

    private fun drawCuteHollowIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val cyCat = cy + r * 0.05f
                path.reset()
                path.moveTo(cx - r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx, cyCat - r * 0.46f, cx + r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx + r * 0.62f, cyCat - r * 0.86f, cx + r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx + r * 0.94f, cyCat - r * 0.52f, cx + r * 0.92f, cyCat - r * 0.12f)
                path.cubicTo(cx + r * 1.12f, cyCat + r * 0.44f, cx + r * 0.64f, cyCat + r * 0.82f, cx, cyCat + r * 0.82f)
                path.cubicTo(cx - r * 0.64f, cyCat + r * 0.82f, cx - r * 1.12f, cyCat + r * 0.44f, cx - r * 0.92f, cyCat - r * 0.12f)
                path.quadTo(cx - r * 0.94f, cyCat - r * 0.52f, cx - r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx - r * 0.62f, cyCat - r * 0.86f, cx - r * 0.36f, cyCat - r * 0.42f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - r * 0.74f, cyCat + r * 0.15f, cx - r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx - r * 0.70f, cyCat + r * 0.32f, cx - r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.74f, cyCat + r * 0.15f, cx + r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.70f, cyCat + r * 0.32f, cx + r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
            }
            else -> {
                val outerR = r * 0.96f
                val innerR = r * 0.54f
                path.reset()
                for (i in 0 until 10) {
                    val ang = Math.toRadians((-90.0 + i * 36.0))
                    val rad = if (i % 2 == 0) outerR else innerR
                    val px = cx + (rad * cos(ang)).toFloat()
                    val py = cy + (rad * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, starStrokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class BackspaceIconView(
    context: Context,
    private val iconColor: Int
) : View(context) {

    private val tagPath = Path()
    private val cornerEffect = CornerPathEffect(dpF(3.8f))

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(36, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor))
        pathEffect = cornerEffect
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
        pathEffect = cornerEffect
    }

    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        color = iconColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val halfW = dpF(10.5f)
        val halfH = dpF(7.2f)
        val noseX = cx - halfW
        val bodyLeft = cx - halfW * 0.38f
        val rightX = cx + halfW

        tagPath.reset()
        tagPath.moveTo(noseX, cy)
        tagPath.lineTo(bodyLeft, cy - halfH)
        tagPath.lineTo(rightX, cy - halfH)
        tagPath.lineTo(rightX, cy + halfH)
        tagPath.lineTo(bodyLeft, cy + halfH)
        tagPath.close()

        // 100% 纯镂空退格键图标（去除半透明灰色内填充）
        canvas.drawPath(tagPath, strokePaint)

        // 内部居中偏右一点的圆头 × 号
        val xCenter = (bodyLeft + rightX) * 0.5f + dpF(0.6f)
        val xSpan = dpF(2.7f)
        canvas.drawLine(xCenter - xSpan, cy - xSpan, xCenter + xSpan, cy + xSpan, crossPaint)
        canvas.drawLine(xCenter + xSpan, cy - xSpan, xCenter - xSpan, cy + xSpan, crossPaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}


/**
 * 空格键专属「迷你精致镂空小话筒」图标视图 (SpaceHollowMicIconView)：
 * - 专为「空格键长按呼出语音输入」设计，尺寸极袖珍（约 11.5dp × 13dp），100% 纤细圆头镂空线条 (1.32dp)；
 * - 颜色自动跟随当前皮肤空格键文字色 (iconColor) 并带 78% 温润半透明度，与莫奈花园、樱花粉、暗夜黑金及所有自定义 CSS 皮肤浑然一体！
 */
class SpaceHollowMicIconView(
    context: Context,
    private var iconColor: Int
) : View(context) {

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.32f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = applySoftAlpha(iconColor)
    }

    private val capsuleRect = RectF()
    private val cradleRect = RectF()

    private fun applySoftAlpha(c: Int): Int {
        val baseA = Color.alpha(c)
        val targetA = ((baseA * 0.78f).toInt()).coerceIn(90, 225)
        return Color.argb(targetA, Color.red(c), Color.green(c), Color.blue(c))
    }

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = applySoftAlpha(newColor)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val unit = min(w, h) * 0.42f

        // 1. 顶部镂空圆润胶囊收音头
        val capHalfW = unit * 0.42f
        val capTop = cy - unit * 0.94f
        val capBottom = cy + unit * 0.14f
        capsuleRect.set(cx - capHalfW, capTop, cx + capHalfW, capBottom)
        canvas.drawRoundRect(capsuleRect, capHalfW, capHalfW, strokePaint)

        // 2. 中部 U 型半圆托架
        val cradleRadius = unit * 0.74f
        val arcCenterY = cy - unit * 0.18f
        cradleRect.set(
            cx - cradleRadius,
            arcCenterY - cradleRadius,
            cx + cradleRadius,
            arcCenterY + cradleRadius
        )
        canvas.drawArc(cradleRect, 12f, 156f, false, strokePaint)

        // 3. 底部纤细竖杆与迷你横底座
        val stemTop = arcCenterY + cradleRadius
        val stemBottom = cy + unit * 0.92f
        canvas.drawLine(cx, stemTop, cx, stemBottom, strokePaint)
        val baseHalfW = unit * 0.44f
        canvas.drawLine(cx - baseHalfW, stemBottom, cx + baseHalfW, stemBottom, strokePaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 通配键专属「萌系镂空可爱图标」视图 (WildcardCuteIconView)：
 * - 图标大小与顶部状态栏图标大小 (CustomTopIconManager.getIconSizeDp) 1:1 完全同步绑定，绝不偏大突兀！
 * - 内置 15 款图 5 同款可爱镂空图标（含全新重绘的图 5 甜心蝴蝶结、六瓣小樱花、双子星芒、四叶草、幸运草、许愿流星、小雪花、小书本等）。
 */
class WildcardCuteIconView(
    context: Context,
    private var iconColor: Int,
    @Suppress("UNUSED_PARAMETER") private var iconScale: Float = 1.0f
) : View(context) {

    companion object {
        const val STYLE_STAR_MOON = 0       // 🌙 星月伴闪
        const val STYLE_MAGIC_WAND = 1      // 🪄 魔法星杖
        const val STYLE_CUTE_BOW = 2        // 🎀 甜心蝴蝶结（图5同款全新重绘）
        const val STYLE_SAKURA = 3          // 🌸 六瓣小樱花（图5同款全新重绘）
        const val STYLE_TEXT_LABEL = 4      // 🔤 经典文字「通配」
        const val STYLE_SPARKLES = 5        // ✨ 双子闪星芒（图5同款）
        const val STYLE_CLOVER = 6          // 🍀 四叶草（图5同款）
        const val STYLE_LUCKY_CLOVER = 7    // ☘️ 带茎幸运草（图5同款）
        const val STYLE_METEOR = 8          // 🌠 弧线许愿星（图5同款）
        const val STYLE_SNOWFLAKE = 9       // ❄️ 晶莹小雪花（图5同款）
        const val STYLE_BOOK = 10           // 📖 翻开小书本（图5同款）
        const val STYLE_CAT = 11            // 🐱 小胡须猫猫头
        const val STYLE_HEART = 12          // 💕 大小双爱心
        const val STYLE_PLANET = 13         // 🪐 环绕小星球
        const val STYLE_STAR = 14           // ⭐ 圆润胖星星
        const val STYLE_CROWN = 15          // 👑 三尖小皇冠

        val ALL_WILDCARD_STYLES: List<Pair<Int, String>> = listOf(
            STYLE_CUTE_BOW to "🎀蝴蝶结",
            STYLE_SAKURA to "🌸小樱花",
            STYLE_SPARKLES to "✨双星芒",
            STYLE_CLOVER to "🍀四叶草",
            STYLE_LUCKY_CLOVER to "☘️幸运草",
            STYLE_METEOR to "🌠许愿星",
            STYLE_SNOWFLAKE to "❄️小雪花",
            STYLE_BOOK to "📖小书本",
            STYLE_STAR_MOON to "🌙星月",
            STYLE_MAGIC_WAND to "🪄星杖",
            STYLE_CAT to "🐱猫猫头",
            STYLE_HEART to "💕双爱心",
            STYLE_PLANET to "🪐小星球",
            STYLE_STAR to "⭐胖星星",
            STYLE_CROWN to "👑小皇冠",
            STYLE_TEXT_LABEL to "🔤文字"
        )

        fun getStyleDisplayName(style: Int): String {
            return ALL_WILDCARD_STYLES.firstOrNull { it.first == style }?.second ?: "🎀蝴蝶结"
        }

        fun getWildcardIconStyle(context: Context): Int {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt("wildcard_cute_icon_style", STYLE_CUTE_BOW).coerceIn(0, 15)
        }

        fun setWildcardIconStyle(context: Context, style: Int) {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putInt("wildcard_cute_icon_style", style.coerceIn(0, 15))
                .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
                .apply()
        }

        fun mapWildcardStyleToPresetId(style: Int): Int = when (style) {
            STYLE_CUTE_BOW -> MinimalistIconView.ICON_BOW
            STYLE_SAKURA -> MinimalistIconView.ICON_FLOWER
            STYLE_SPARKLES -> MinimalistIconView.ICON_SPARKLES
            STYLE_CLOVER -> MinimalistIconView.ICON_CLOVER
            STYLE_LUCKY_CLOVER -> MinimalistIconView.ICON_LUCKY_CLOVER
            STYLE_METEOR -> MinimalistIconView.ICON_METEOR
            STYLE_SNOWFLAKE -> MinimalistIconView.ICON_SNOWFLAKE
            STYLE_BOOK -> MinimalistIconView.ICON_BOOK
            STYLE_CAT -> MinimalistIconView.TYPE_SETTINGS
            STYLE_HEART -> MinimalistIconView.TYPE_EMOJI
            STYLE_PLANET -> MinimalistIconView.TYPE_CLIPBOARD
            STYLE_STAR -> MinimalistIconView.TYPE_FAVORITE
            STYLE_CROWN -> MinimalistIconView.TYPE_COLLAPSE
            STYLE_STAR_MOON -> MinimalistIconView.ICON_STAR_MOON
            STYLE_MAGIC_WAND -> MinimalistIconView.ICON_MAGIC_WAND
            else -> MinimalistIconView.ICON_BOW
        }

        fun drawVectorStarMoon(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            r: Float,
            strokePaint: Paint,
            fineStrokePaint: Paint,
            starStrokePaint: Paint,
            path: Path,
            arcRect: RectF
        ) {
            val moonCx = cx - r * 0.14f
            val moonCy = cy + r * 0.04f
            val outerR = r * 0.86f
            path.reset()
            arcRect.set(moonCx - outerR, moonCy - outerR, moonCx + outerR, moonCy + outerR)
            path.addArc(arcRect, 42f, 266f)
            canvas.drawPath(path, strokePaint)

            val startAng = Math.toRadians(42.0)
            val endAng = Math.toRadians(308.0)
            val sx = moonCx + (outerR * cos(startAng)).toFloat()
            val sy = moonCy + (outerR * sin(startAng)).toFloat()
            val ex = moonCx + (outerR * cos(endAng)).toFloat()
            val ey = moonCy + (outerR * sin(endAng)).toFloat()

            path.reset()
            path.moveTo(ex, ey)
            path.cubicTo(
                moonCx - outerR * 0.42f, moonCy - outerR * 0.36f,
                moonCx - outerR * 0.38f, moonCy + outerR * 0.44f,
                sx, sy
            )
            canvas.drawPath(path, strokePaint)

            val starCx = cx + r * 0.42f
            val starCy = cy - r * 0.22f
            val sOut = r * 0.45f
            val sIn = r * 0.24f
            path.reset()
            for (i in 0 until 10) {
                val ang = Math.toRadians(-90.0 + i * 36.0 + 12.0)
                val rad = if (i % 2 == 0) sOut else sIn
                val px = starCx + (rad * cos(ang)).toFloat()
                val py = starCy + (rad * sin(ang)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            canvas.drawPath(path, starStrokePaint)

            val spX = cx - r * 0.60f
            val spY = cy - r * 0.62f
            val arm = r * 0.18f
            canvas.drawLine(spX - arm, spY, spX + arm, spY, fineStrokePaint)
            canvas.drawLine(spX, spY - arm, spX, spY + arm, fineStrokePaint)
        }

        fun drawVectorStarWand(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            r: Float,
            strokePaint: Paint,
            fineStrokePaint: Paint,
            starStrokePaint: Paint,
            path: Path
        ) {
            val starCx = cx - r * 0.20f
            val starCy = cy - r * 0.20f
            val sOut = r * 0.64f
            val sIn = r * 0.36f
            path.reset()
            for (i in 0 until 10) {
                val ang = Math.toRadians(-135.0 + i * 36.0)
                val rad = if (i % 2 == 0) sOut else sIn
                val px = starCx + (rad * cos(ang)).toFloat()
                val py = starCy + (rad * sin(ang)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            canvas.drawPath(path, starStrokePaint)

            val hStartX = starCx + sIn * 0.72f
            val hStartY = starCy + sIn * 0.72f
            val hEndX = cx + r * 0.82f
            val hEndY = cy + r * 0.82f
            canvas.drawLine(hStartX, hStartY, hEndX, hEndY, strokePaint)

            val bowX = (hStartX + hEndX) * 0.48f
            val bowY = (hStartY + hEndY) * 0.48f
            path.reset()
            path.moveTo(bowX, bowY)
            path.quadTo(bowX + r * 0.36f, bowY - r * 0.34f, bowX + r * 0.42f, bowY - r * 0.06f)
            path.quadTo(bowX + r * 0.26f, bowY + r * 0.12f, bowX, bowY)
            path.moveTo(bowX, bowY)
            path.quadTo(bowX - r * 0.34f, bowY + r * 0.36f, bowX - r * 0.06f, bowY + r * 0.42f)
            path.quadTo(bowX + r * 0.12f, bowY + r * 0.26f, bowX, bowY)
            canvas.drawPath(path, fineStrokePaint)

            val spX = cx + r * 0.54f
            val spY = cy - r * 0.56f
            val arm = r * 0.18f
            canvas.drawLine(spX - arm, spY, spX + arm, spY, fineStrokePaint)
            canvas.drawLine(spX, spY - arm, spX, spY + arm, fineStrokePaint)
        }
    }

    private val tintedBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(iconColor, PorterDuff.Mode.SRC_IN)
    }
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.62f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.42f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.58f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(2.2f))
        color = iconColor
    }

    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f

        // 严格与顶部状态栏图标大小 (CustomTopIconManager.getIconSizeDp) 1:1 绑定同步！
        val topIconDp = CustomTopIconManager.getIconSizeDp(context).toFloat()
        val boxH = min(h * 0.78f, dpF(topIconDp))
        val boxW = min(w * 0.88f, boxH * 1.38f)

        val style = getWildcardIconStyle(context)
        if (style == STYLE_STAR_MOON) {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
            return
        } else if (style == STYLE_MAGIC_WAND) {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarWand(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path)
            return
        }

        val presetId = mapWildcardStyleToPresetId(style)
        val cuteBmp = MinimalistIconView.getCuteHollowBitmap(context, presetId)
        if (cuteBmp != null && cuteBmp.width > 0 && cuteBmp.height > 0) {
            val aspect = cuteBmp.width.toFloat() / cuteBmp.height.toFloat()
            var drawH = boxH * 0.90f
            var drawW = drawH * aspect
            if (drawW > boxW * 0.94f) {
                drawW = boxW * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, cuteBmp.width, cuteBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            canvas.drawBitmap(cuteBmp, srcRect, dstRectF, tintedBitmapPaint)
        } else {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 盛夏光年 · 拼音同款星轨圈圈 + 夏以昼同款流光星芒光晕旋转视图 (StarlightVoiceWaveView)：
 * - 1:1 还原参考图中的中央圆盘极简白话筒 + 三层旋转同心星轨圆弧与轨道白珍珠；
 * - 深度融合「夏以昼」同款多层旋转流光星云大光晕 + 3 缕弯弯弧形流光游丝 (GossamerFlowRibbons) +
 *   环绕旋转闪烁的实心四芒星 (✦)、空心四芒星 (✧)、十字星耀与柔光微星尘；
 * - 轻点或按住说话时，圈圈与夏以昼流光星芒光晕 60FPS 丝滑同步旋转，并随说话音量实时呼吸绽放！
 */
class StarlightVoiceWaveView(
    context: Context,
    private var glowColor: Int,
    private var surfaceBgColor: Int,
    private var keyboardSurfaceBgColor: Int
) : View(context) {

    var isListeningState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (!value) targetRmsNorm = 0.12f
                tapSparkleBoost = 1.0f
                lastFrameMs = SystemClock.uptimeMillis()
                postInvalidateOnAnimation()
            }
        }

    private var currentRmsNorm = 0.15f
    private var targetRmsNorm = 0.15f
    private var rotAngleRad = 0f
    private var tapSparkleBoost = 0.35f
    private var lastFrameMs = 0L

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ribbonPath = Path()
    private val starPath = Path()
    private val ovalRect = RectF()

    private var palette = StarlightColorAdapter.resolvePalette(
        rawGlowColor = glowColor,
        surfaceBgColor = surfaceBgColor,
        keyboardBgColor = keyboardSurfaceBgColor
    )

    // 预置 14 颗环绕星轨旋转的「夏以昼同款簇状星点」（实心四芒星 ✦ + 空心四芒星 ✧ + 柔光小光圈 ° + 闪烁星尘 ·）
    private data class OrbitStarParticle(
        val shapeType: Int,     // 0=实心四芒星✦, 1=空心四芒星✧, 2=柔光小光圈°, 3=闪烁微星尘·, 4=修长十字星耀✷
        val baseAngleRad: Float,
        val radiusFactor: Float,
        val speedFactor: Float,
        val sizeDp: Float,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleSpeed: Float
    )

    private val orbitStars = listOf(
        // 簇 1（左上星群）
        OrbitStarParticle(4, 0.35f, 1.38f, 1.08f, 5.2f, 0, 0.2f, 0.008f),
        OrbitStarParticle(0, 0.58f, 1.18f, 1.15f, 3.8f, 1, 1.1f, 0.011f),
        OrbitStarParticle(1, 0.82f, 1.48f, 0.92f, 3.4f, 0, 2.4f, 0.009f),
        OrbitStarParticle(2, 0.44f, 1.54f, 1.02f, 1.8f, 2, 0.7f, 0.010f),
        OrbitStarParticle(3, 0.70f, 1.30f, 1.18f, 1.2f, 0, 3.1f, 0.014f),
        // 簇 2（右下星群）
        OrbitStarParticle(4, 2.52f, 1.42f, 1.05f, 4.8f, 1, 1.8f, 0.009f),
        OrbitStarParticle(0, 2.78f, 1.12f, 1.22f, 3.6f, 0, 0.5f, 0.012f),
        OrbitStarParticle(1, 3.05f, 1.50f, 0.88f, 3.2f, 2, 2.9f, 0.010f),
        OrbitStarParticle(2, 2.36f, 1.28f, 1.12f, 1.7f, 1, 4.0f, 0.011f),
        OrbitStarParticle(3, 2.92f, 1.36f, 0.96f, 1.1f, 0, 1.5f, 0.015f),
        // 簇 3（右上/左下灵动伴星）
        OrbitStarParticle(0, 4.55f, 1.26f, 1.10f, 3.5f, 2, 2.1f, 0.010f),
        OrbitStarParticle(1, 4.88f, 1.46f, 0.94f, 3.0f, 0, 3.7f, 0.012f),
        OrbitStarParticle(2, 5.20f, 1.16f, 1.20f, 1.6f, 1, 0.9f, 0.013f),
        OrbitStarParticle(3, 5.55f, 1.52f, 0.86f, 1.2f, 2, 4.8f, 0.016f)
    )

    fun setListening(listening: Boolean) {
        isListeningState = listening
    }

    fun triggerTapSparkle() {
        tapSparkleBoost = 1.0f
        postInvalidateOnAnimation()
    }

    fun updatePalette(newGlow: Int, newSurfaceBg: Int, newKbBg: Int) {
        glowColor = newGlow
        surfaceBgColor = newSurfaceBg
        keyboardSurfaceBgColor = newKbBg
        palette = StarlightColorAdapter.resolvePalette(
            rawGlowColor = glowColor,
            surfaceBgColor = surfaceBgColor,
            keyboardBgColor = keyboardSurfaceBgColor
        )
        invalidate()
    }

    fun updateRmsDb(rmsdB: Float) {
        targetRmsNorm = ((rmsdB + 2f) / 11f).coerceIn(0.12f, 1.0f)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val baseR = min(w, h) * 0.255f
        val now = SystemClock.uptimeMillis()

        val dtSec = if (lastFrameMs == 0L) 0.016f else ((now - lastFrameMs).coerceIn(1L, 64L) / 1000f)
        lastFrameMs = now

        currentRmsNorm += (targetRmsNorm - currentRmsNorm) * 0.25f
        if (!isListeningState && tapSparkleBoost > 0.02f) {
            tapSparkleBoost = (tapSparkleBoost - dtSec * 0.55f).coerceAtLeast(0f)
        }

        // 旋转角速度：说话聆听时轻盈欢快旋转并随声音分贝加速；待机时温柔慢速星轨流转
        val activeEnergy = if (isListeningState) (0.75f + currentRmsNorm * 0.65f) else (0.28f + tapSparkleBoost * 0.52f)
        val angularSpeed = if (isListeningState) {
            1.55f + currentRmsNorm * 1.45f
        } else {
            0.48f + tapSparkleBoost * 0.95f
        }
        rotAngleRad = (rotAngleRad + dtSec * angularSpeed) % (Math.PI.toFloat() * 200f)

        val pulse = if (isListeningState) {
            1.0f + currentRmsNorm * 0.38f + 0.07f * sin(now * 0.010f)
        } else {
            1.0f + 0.04f * sin(now * 0.0045f) + tapSparkleBoost * 0.12f
        }

        val tintCol = palette.meteorPrimaryTint
        val acc1 = palette.meteorAccent1
        val acc2 = palette.meteorAccent2
        val haloCol = palette.softHaloColor
        val rT = Color.red(tintCol)
        val gT = Color.green(tintCol)
        val bT = Color.blue(tintCol)
        val rA1 = Color.red(acc1)
        val gA1 = Color.green(acc1)
        val bA1 = Color.blue(acc1)
        val rA2 = Color.red(acc2)
        val gA2 = Color.green(acc2)
        val bA2 = Color.blue(acc2)

        // =========================================================================
        // 1. 夏以昼同款「多层旋转星云大光晕」（中心呼吸柔光 + 3 团随圈圈同步旋转的流光星云团）
        // =========================================================================
        val outerR = baseR * pulse * 1.72f
        val mainAuraGrad = RadialGradient(
            cx, cy, outerR.coerceAtLeast(12f),
            intArrayOf(
                Color.argb(if (isListeningState) 185 else 115, rT, gT, bT),
                Color.argb(if (isListeningState) 110 else 62, rA1, gA1, bA1),
                Color.argb(if (isListeningState) 45 else 22, rA2, gA2, bA2),
                Color.argb(0, rT, gT, bT)
            ),
            floatArrayOf(0f, 0.45f, 0.76f, 1f),
            Shader.TileMode.CLAMP
        )
        fillPaint.shader = mainAuraGrad
        canvas.drawCircle(cx, cy, outerR, fillPaint)

        // 3 朵随星轨旋转的偏心夏以昼柔光星云团，让光晕本身呈现灵动的流转呼吸感
        for (k in 0 until 3) {
            val cloudAng = rotAngleRad * (1.05f + k * 0.12f) + k * 2.094f
            val orbitDist = baseR * (0.52f + 0.18f * sin(now * 0.005f + k * 1.7f)) * pulse
            val ncx = cx + cos(cloudAng) * orbitDist
            val ncy = cy + sin(cloudAng) * orbitDist
            val cloudR = baseR * (0.95f + 0.22f * activeEnergy)
            val cCol = when (k) {
                0 -> tintCol
                1 -> acc1
                else -> haloCol
            }
            val cr = Color.red(cCol)
            val cg = Color.green(cCol)
            val cb = Color.blue(cCol)
            val cloudAlpha = ((if (isListeningState) 92f else 48f) * (0.82f + 0.18f * sin(now * 0.008f + k))).toInt().coerceIn(0, 160)
            fillPaint.shader = RadialGradient(
                ncx, ncy, cloudR.coerceAtLeast(8f),
                intArrayOf(
                    Color.argb(cloudAlpha, cr, cg, cb),
                    Color.argb((cloudAlpha * 0.45f).toInt(), cr, cg, cb),
                    Color.argb(0, cr, cg, cb)
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(ncx, ncy, cloudR, fillPaint)
        }
        fillPaint.shader = null

        // =========================================================================
        // 2. 拼音同款「三层旋转同心圆弧 + 轨道星珠」（1:1 复刻截图圈圈并在说话时丝滑旋转）
        // =========================================================================
        for (i in 0 until 3) {
            val dir = if (i == 1) -0.82f else (1.0f + i * 0.22f)
            val phase = rotAngleRad * dir + i * 2.1f
            val ringR = baseR * (0.88f + i * 0.24f) * (if (isListeningState) (0.96f + currentRmsNorm * 0.24f) else 1.0f)
            val col = when (i) {
                0 -> tintCol
                1 -> acc1
                else -> acc2
            }
            val rc = Color.red(col)
            val gc = Color.green(col)
            val bc = Color.blue(col)

            // 外层微光衬底弧
            ringPaint.strokeWidth = dpF(if (i == 0) 4.5f else 3.2f)
            ringPaint.color = Color.argb(if (isListeningState) (65 - i * 12) else (36 - i * 8), rc, gc, bc)
            ovalRect.set(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
            val startDeg = Math.toDegrees(phase.toDouble()).toFloat() % 360f
            canvas.drawArc(ovalRect, startDeg, 115f + i * 20f, false, ringPaint)
            canvas.drawArc(ovalRect, startDeg + 180f, 95f + i * 15f, false, ringPaint)

            // 核心精致圆弧线
            ringPaint.strokeWidth = dpF(if (i == 0) 2.2f else 1.45f)
            ringPaint.color = Color.argb(
                if (isListeningState) (210 - i * 35) else (135 - i * 24),
                rc, gc, bc
            )
            canvas.drawArc(ovalRect, startDeg, 115f + i * 20f, false, ringPaint)
            canvas.drawArc(ovalRect, startDeg + 180f, 95f + i * 15f, false, ringPaint)

            // 环轨上的发光白珍珠圆点
            val starAng = phase + 0.6f
            val sx = cx + cos(starAng) * ringR
            val sy = cy + sin(starAng) * ringR
            fillPaint.color = Color.argb(if (isListeningState) 110 else 60, rc, gc, bc)
            canvas.drawCircle(sx, sy, dpF(4.6f), fillPaint)
            fillPaint.color = Color.argb(if (isListeningState) 245 else 175, 255, 255, 255)
            canvas.drawCircle(sx, sy, dpF(2.25f), fillPaint)
        }

        // =========================================================================
        // 3. 夏以昼同款「旋转弯弯弧形流光游丝 + 顶端领航四芒星 ✦」(Gossamer Meteor Ribbons)
        // =========================================================================
        val ribbonAlphaBase = if (isListeningState) (0.78f + 0.22f * currentRmsNorm).coerceIn(0f, 1f) else (0.42f + 0.45f * tapSparkleBoost).coerceIn(0f, 1f)
        for (rIdx in 0 until 3) {
            val rDir = if (rIdx == 1) -1.12f else (1.28f - rIdx * 0.15f)
            val startAng = rotAngleRad * rDir + rIdx * 2.09f + 0.85f
            val sweepAng = (if (rIdx == 0) 1.25f else 0.96f) * (if (rIdx == 1) -1f else 1f)
            val baseOrbitR = baseR * (0.98f + rIdx * 0.23f) * (if (isListeningState) (0.96f + currentRmsNorm * 0.26f) else 1.0f)
            val swellPx = dpF(5.5f + rIdx * 2.2f) * (0.75f + 0.45f * activeEnergy)
            val maxHalfW = dpF(if (rIdx == 0) 1.35f else 1.05f)
            val wavePx = dpF(1.8f) * (if (rIdx % 2 == 0) 1f else -1f)
            val wavePhase = now * 0.007f + rIdx * 1.9f

            val cCol = when (rIdx) {
                0 -> tintCol
                1 -> acc1
                else -> acc2
            }
            val rc = Color.red(cCol)
            val gc = Color.green(cCol)
            val bc = Color.blue(cCol)

            // A. 外层柔焦星晕游丝
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW * 1.85f, wavePx, wavePhase, 0f, 1f)
            fillPaint.color = Color.argb((105f * ribbonAlphaBase).toInt().coerceIn(0, 255), rc, gc, bc)
            canvas.drawPath(ribbonPath, fillPaint)

            // B. 中层丝滑彩色流光主体
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW, wavePx, wavePhase, 0.06f, 0.94f)
            val midR = (rc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            val midG = (gc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            val midB = (bc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            fillPaint.color = Color.argb((210f * ribbonAlphaBase).toInt().coerceIn(0, 255), midR, midG, midB)
            canvas.drawPath(ribbonPath, fillPaint)

            // C. 内芯璀璨纯白游丝
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW * 0.48f, wavePx, wavePhase, 0.18f, 0.86f)
            fillPaint.color = Color.argb((248f * ribbonAlphaBase).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawPath(ribbonPath, fillPaint)

            // D. 流光游丝前端领航的闪烁四芒星 ✦
            val tipS = 0.86f
            val tipAng = startAng + sweepAng * tipS
            val tipArch = sin(tipS * Math.PI.toFloat())
            val tipR = baseOrbitR + swellPx * tipArch + sin(tipS * 5.2f + wavePhase) * wavePx * tipArch
            val tipX = cx + cos(tipAng) * tipR
            val tipY = cy + sin(tipAng) * tipR
            drawVoiceSolidFourPointStar(
                canvas = canvas,
                sx = tipX,
                sy = tipY,
                rayLenPx = dpF(if (rIdx == 0) 3.8f else 3.1f) * (0.85f + 0.25f * activeEnergy),
                rotationDeg = Math.toDegrees(tipAng.toDouble()).toFloat() + 18f,
                alpha = ribbonAlphaBase,
                rT = rc,
                gT = gc,
                bT = bc
            )
        }

        // =========================================================================
        // 4. 夏以昼同款「环绕闪烁簇状星群」（实心四芒星 ✦ + 空心四芒星 ✧ + 十字星耀 ✷ + 柔光圈 ° + 星尘 ·）
        // =========================================================================
        for (star in orbitStars) {
            val curAng = star.baseAngleRad + rotAngleRad * star.speedFactor
            val breatheOut = 1.0f + (if (isListeningState) currentRmsNorm * 0.24f else 0.0f) + 0.05f * sin(now * 0.005f + star.twinklePhase)
            val rad = baseR * star.radiusFactor * breatheOut
            val sx = cx + cos(curAng) * rad
            val sy = cy + sin(curAng) * rad

            val twinkle = 0.58f + 0.42f * sin(now * star.twinkleSpeed + star.twinklePhase)
            val sAlpha = ((if (isListeningState) 0.96f else 0.62f) * twinkle).coerceIn(0.05f, 1.0f)

            val cCol = when (star.colorVariant) {
                1 -> acc1
                2 -> acc2
                else -> tintCol
            }
            val rc = Color.red(cCol)
            val gc = Color.green(cCol)
            val bc = Color.blue(cCol)
            val sizePx = dpF(star.sizeDp) * (0.86f + 0.22f * twinkle)
            val rotDeg = Math.toDegrees((curAng * 0.6f).toDouble()).toFloat()

            when (star.shapeType) {
                0 -> drawVoiceSolidFourPointStar(canvas, sx, sy, sizePx, rotDeg, sAlpha, rc, gc, bc)
                1 -> drawVoiceHollowFourPointStar(canvas, sx, sy, sizePx, rotDeg, sAlpha, rc, gc, bc)
                4 -> drawVoiceCelestialCrossFlare(canvas, sx, sy, sizePx, rotDeg * 0.4f, sAlpha, rc, gc, bc)
                2 -> {
                    // 柔光小光圈 °
                    fillPaint.color = Color.argb((72f * sAlpha).toInt().coerceIn(0, 255), rc, gc, bc)
                    canvas.drawCircle(sx, sy, sizePx * 1.25f, fillPaint)
                    ringPaint.strokeWidth = dpF(0.85f)
                    ringPaint.color = Color.argb((220f * sAlpha).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx, sy, sizePx, ringPaint)
                }
                else -> {
                    // 璀璨微星尘 ·
                    fillPaint.color = Color.argb((115f * sAlpha).toInt().coerceIn(0, 255), rc, gc, bc)
                    canvas.drawCircle(sx, sy, sizePx * 2.1f, fillPaint)
                    fillPaint.color = Color.argb((250f * sAlpha).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx, sy, sizePx * 0.9f, fillPaint)
                }
            }
        }

        // =========================================================================
        // 5. 中心星光麦克风圆盘与极简白话筒图标（1:1 复刻截图）
        // =========================================================================
        val coreR = baseR * 0.68f
        fillPaint.color = Color.argb(if (palette.isLightSurface) 225 else 200, rT, gT, bT)
        canvas.drawCircle(cx, cy, coreR, fillPaint)

        // 圆盘边缘柔白微高光圈
        ringPaint.strokeWidth = dpF(1.1f)
        ringPaint.color = Color.argb(if (isListeningState) 145 else 85, 255, 255, 255)
        canvas.drawCircle(cx, cy, coreR, ringPaint)

        // 中央纯白极简麦克风图标
        ringPaint.color = Color.WHITE
        ringPaint.strokeWidth = dpF(2.0f)
        val micW = dpF(5.5f)
        val micH = dpF(9.5f)
        ovalRect.set(cx - micW, cy - micH - dpF(2f), cx + micW, cy + micH - dpF(4f))
        canvas.drawRoundRect(ovalRect, micW, micW, ringPaint)
        ovalRect.set(cx - dpF(9.5f), cy - dpF(8f), cx + dpF(9.5f), cy + dpF(8.5f))
        canvas.drawArc(ovalRect, 15f, 150f, false, ringPaint)
        canvas.drawLine(cx, cy + dpF(8.5f), cx, cy + dpF(13f), ringPaint)
        canvas.drawLine(cx - dpF(5f), cy + dpF(13f), cx + dpF(5f), cy + dpF(13f), ringPaint)

        if (isAttachedToWindow && visibility == VISIBLE) {
            postInvalidateOnAnimation()
        }
    }

    private fun buildCircularGossamerRibbonPath(
        cx: Float,
        cy: Float,
        baseRadiusPx: Float,
        startAngle: Float,
        sweepAngle: Float,
        swellOutPx: Float,
        maxHalfWidthPx: Float,
        rippleWavePx: Float,
        ripplePhase: Float,
        sStart: Float,
        sEnd: Float
    ) {
        ribbonPath.reset()
        val steps = 12
        for (i in 0..steps) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.0f + ripplePhase) * rippleWavePx * arch
            val centerR = baseRadiusPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rOut = centerR + halfW
            val x = cx + cos(ang) * rOut
            val y = cy + sin(ang) * rOut
            if (i == 0) ribbonPath.moveTo(x, y) else ribbonPath.lineTo(x, y)
        }
        for (i in steps downTo 0) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.0f + ripplePhase) * rippleWavePx * arch
            val centerR = baseRadiusPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rIn = centerR - halfW
            val x = cx + cos(ang) * rIn
            val y = cy + sin(ang) * rIn
            ribbonPath.lineTo(x, y)
        }
        ribbonPath.close()
    }

    private fun drawVoiceSolidFourPointStar(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 0.6f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        fillPaint.color = Color.argb((110f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
        canvas.drawCircle(0f, 0f, rayLenPx * 0.62f, fillPaint)

        val orthoLen = rayLenPx * 0.78f
        val waist = rayLenPx * 0.15f
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        fillPaint.color = Color.argb(
            (225f * alpha).toInt().coerceIn(0, 255),
            (rT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255),
            (gT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255),
            (bT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255)
        )
        canvas.drawPath(starPath, fillPaint)

        val coreLen = rayLenPx * 0.56f
        val coreOrtho = orthoLen * 0.56f
        val coreWaist = waist * 0.52f
        starPath.reset()
        starPath.moveTo(0f, -coreLen)
        starPath.quadTo(coreWaist, -coreWaist, coreOrtho, 0f)
        starPath.quadTo(coreWaist, coreWaist, 0f, coreLen)
        starPath.quadTo(-coreWaist, coreWaist, -coreOrtho, 0f)
        starPath.quadTo(-coreWaist, -coreWaist, 0f, -coreLen)
        starPath.close()
        fillPaint.color = Color.argb((252f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, fillPaint)

        canvas.restoreToCount(sc)
    }

    private fun drawVoiceHollowFourPointStar(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val orthoLen = rayLenPx * 0.82f
        val waist = rayLenPx * 0.22f
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        ringPaint.strokeWidth = dpF(0.95f)
        ringPaint.color = Color.argb(
            (225f * alpha).toInt().coerceIn(0, 255),
            (rT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255),
            (gT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255),
            (bT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255)
        )
        canvas.drawPath(starPath, ringPaint)
        canvas.restoreToCount(sc)
    }

    private fun drawVoiceCelestialCrossFlare(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 1.0f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        // 柔和星芒中心光晕
        fillPaint.color = Color.argb((125f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
        canvas.drawCircle(0f, 0f, rayLenPx * 0.68f, fillPaint)

        val longR = rayLenPx * 1.15f
        val shortR = rayLenPx * 0.72f
        val diagR = rayLenPx * 0.42f
        val waist = rayLenPx * 0.11f

        // 对角细芒
        ringPaint.strokeWidth = dpF(0.75f)
        ringPaint.color = Color.argb((170f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawLine(-diagR, -diagR, diagR, diagR, ringPaint)
        canvas.drawLine(-diagR, diagR, diagR, -diagR, ringPaint)

        // 主十字星耀
        starPath.reset()
        starPath.moveTo(0f, -longR)
        starPath.quadTo(waist, -waist, shortR, 0f)
        starPath.quadTo(waist, waist, 0f, longR)
        starPath.quadTo(-waist, waist, -shortR, 0f)
        starPath.quadTo(-waist, -waist, 0f, -longR)
        starPath.close()
        fillPaint.color = Color.argb((248f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, fillPaint)

        canvas.restoreToCount(sc)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
