package com.shengxiaguangnian.ime

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import java.io.FileOutputStream
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class SettingsActivity : AppCompatActivity() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private lateinit var cssInputBox: EditText
    private lateinit var importedDictListContainer: LinearLayout
    private lateinit var importDictStatusTv: TextView

    private val REQ_IMPORT_DICT = 1001
    private val REQ_EXPORT_BACKUP = 1002
    private val REQ_IMPORT_BACKUP = 1003
    private val REQ_IMPORT_CSS = 1004
    private val REQ_PICK_BG_IMAGE = 1005
    private val REQ_PICK_SOUND = 1006
    private val REQ_PICK_FONT_ENG = 1007
    private val REQ_PICK_FONT_CAND = 1008
    private val REQ_PICK_FONT_ENTER = 1009
    private val REQ_PICK_TOP_ICON_BASE = 1020 // 1020 + iconType (0..4)
    private val REQ_VOICE_AUDIO_PERM = 1099
    private val REQ_SYSTEM_VOICE_POPUP = 1100
    private lateinit var personalWordsListContainer: LinearLayout
    private val topIconSlotStatusMap = HashMap<Int, TextView>()
    private lateinit var customBgStatusTv: TextView
    private lateinit var customSoundStatusTv: TextView
    private lateinit var fontEngStatusTv: TextView
    private lateinit var fontCandStatusTv: TextView
    private lateinit var fontEnterStatusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = ImeDatabaseHelper(this)
        val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        T14WubiEngine.ensureInitializedAsync(this, dbHelper)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EEF0F8"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(36))
        }

        val titleTv = TextView(this).apply {
            text = "盛夏光年 v9.1 · 五笔语音与智能词频版"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(titleTv)

        val openDedicatedEditorHeroBtn = Button(this).apply {
            text = "📋 打开「剪贴板与收藏分类专门编辑页」\n（支持自由归类目录 · 提取网址 · 百度收藏快速搬家）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#3B5998"),
                Color.parseColor("#2B4275"),
                dp(12),
                Color.parseColor("#5C7CBE"),
                dp(1)
            )
            setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(12)
            layoutParams = lp
            setOnClickListener {
                showDedicatedPhraseClipboardEditorPage(
                    initialSubMode = "phrases",
                    initialCategory = "收藏",
                    editPhraseId = -1L,
                    editClipId = -1L
                )
            }
        }
        root.addView(openDedicatedEditorHeroBtn)

        val subTv = TextView(this).apply {
            text = "🔒 零联网权限纯单机 · 哈希秒查词库管理 · 几码归几码智能排序 · CSS皮肤"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#5A627A"))
            setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(subTv)

        // 1. 启用与切换输入法
        val stepCard = makeCard("1. 启用与切换「盛夏光年」")
        stepCard.addView(Button(this).apply {
            text = "在系统设置中勾选「盛夏光年」"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        stepCard.addView(Button(this).apply {
            text = "切换当前输入法为「盛夏光年」"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        stepCard.addView(Button(this).apply {
            text = "🎙️ 授权麦克风权限（开启空格键长按语音输入）"
            setOnClickListener {
                requestVoiceRecordPermission()
            }
        })
        root.addView(stepCard)

        // 1.1 🎙️ 60秒长语音直录引擎设置（彻底绕开小米 AsrService 5.00秒硬超时限制）
        val voiceEngineCard = makeCard("🎙️ 60秒长语音直录引擎（彻底解决小米 5 秒断连）")
        val voiceEngineStatusTv = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        fun refreshVoiceEngineStatusText() {
            val curKey = prefs.getString("voice_api_key", "")?.trim() ?: ""
            val curModel = prefs.getString("voice_api_model", "FunAudioLLM/SenseVoiceSmall") ?: "FunAudioLLM/SenseVoiceSmall"
            if (curKey.isNotEmpty()) {
                voiceEngineStatusTv.text = "✅ 当前状态：已开启 AudioRecord 60 秒长语音直录引擎（模型：$curModel，已彻底绕开小米 5 秒限制，支持连续说 60 秒 + 停顿自动分段上屏）"
                voiceEngineStatusTv.setTextColor(Color.parseColor("#1E7E34"))
                voiceEngineStatusTv.setBackgroundColor(Color.parseColor("#E8F5E9"))
            } else {
                voiceEngineStatusTv.text = "⚠️ 当前状态：使用小米系统默认语音（com.xiaomi.mibrain.speech 存在 5.00 秒强制超时）。填入下方任意 API Key 即可切换为本机 AudioRecord 60 秒不限时直录！"
                voiceEngineStatusTv.setTextColor(Color.parseColor("#B45309"))
                voiceEngineStatusTv.setBackgroundColor(Color.parseColor("#FFFBEB"))
            }
        }
        refreshVoiceEngineStatusText()
        voiceEngineCard.addView(voiceEngineStatusTv)

        val presetHintTv = TextView(this).apply {
            text = "第一步：点选下方任意一种语音识别服务预设（硅基流动 SenseVoiceSmall 模型永久 0 元免费，或直接用你现成的 Gemini / OpenAI Key）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.parseColor("#5A627A"))
            setPadding(0, dp(8), 0, dp(4))
        }
        voiceEngineCard.addView(presetHintTv)

        val endpointInput = EditText(this).apply {
            hint = "接口地址 (如 https://api.siliconflow.cn/v1/audio/transcriptions)"
            setText(prefs.getString("voice_api_endpoint", "https://api.siliconflow.cn/v1/audio/transcriptions"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setSingleLine(true)
        }
        val modelInput = EditText(this).apply {
            hint = "模型名称 (如 FunAudioLLM/SenseVoiceSmall 或 gemini-2.5-flash)"
            setText(prefs.getString("voice_api_model", "FunAudioLLM/SenseVoiceSmall"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setSingleLine(true)
        }
        val keyInput = EditText(this).apply {
            hint = "在此粘贴 API Key（如 sk-... 或 AIza...）"
            setText(prefs.getString("voice_api_key", ""))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setSingleLine(true)
        }

        val presetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        presetRow.addView(Button(this).apply {
            text = "硅基免费SenseVoice"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                prefs.edit().putString("voice_api_provider", "openai_whisper").apply()
                endpointInput.setText("https://api.siliconflow.cn/v1/audio/transcriptions")
                modelInput.setText("FunAudioLLM/SenseVoiceSmall")
                Toast.makeText(this@SettingsActivity, "已填入硅基流动免费 SenseVoiceSmall 预设，请粘贴硅基 API Key 后点保存", Toast.LENGTH_SHORT).show()
            }
        })
        presetRow.addView(Button(this).apply {
            text = "Gemini原生语音"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                prefs.edit().putString("voice_api_provider", "gemini").apply()
                endpointInput.setText("https://generativelanguage.googleapis.com")
                modelInput.setText("gemini-2.5-flash")
                Toast.makeText(this@SettingsActivity, "已填入 Gemini 语音识别预设，请粘贴 Gemini API Key 后点保存", Toast.LENGTH_SHORT).show()
            }
        })
        presetRow.addView(Button(this).apply {
            text = "Groq/OpenAI"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                prefs.edit().putString("voice_api_provider", "openai_whisper").apply()
                endpointInput.setText("https://api.groq.com/openai/v1/audio/transcriptions")
                modelInput.setText("whisper-large-v3-turbo")
                Toast.makeText(this@SettingsActivity, "已填入 Whisper 预设，请粘贴 API Key 后点保存", Toast.LENGTH_SHORT).show()
            }
        })
        voiceEngineCard.addView(presetRow)

        val keyRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        keyInput.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val pasteKeyBtn = Button(this).apply {
            text = "粘贴Key"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clipTxt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this@SettingsActivity)?.toString()?.trim() ?: ""
                if (clipTxt.isNotEmpty()) {
                    keyInput.setText(clipTxt)
                    Toast.makeText(this@SettingsActivity, "已从剪贴板粘贴 Key", Toast.LENGTH_SHORT).show()
                }
            }
        }
        keyRow.addView(keyInput)
        keyRow.addView(pasteKeyBtn)
        voiceEngineCard.addView(keyRow)
        voiceEngineCard.addView(endpointInput)
        voiceEngineCard.addView(modelInput)

        val saveVoiceEngineBtn = Button(this).apply {
            text = "💾 保存并开启 60 秒长语音直录（彻底告别小米 5 秒断连）"
            setTextColor(Color.parseColor("#1E7E34"))
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener {
                val k = keyInput.text.toString().trim()
                val ep = endpointInput.text.toString().trim().ifEmpty { "https://api.siliconflow.cn/v1/audio/transcriptions" }
                val md = modelInput.text.toString().trim().ifEmpty { "FunAudioLLM/SenseVoiceSmall" }
                val prov = if (ep.contains("googleapis.com", ignoreCase = true) || md.startsWith("gemini", ignoreCase = true)) "gemini" else "openai_whisper"
                prefs.edit()
                    .putString("voice_api_key", k)
                    .putString("voice_api_endpoint", ep)
                    .putString("voice_api_model", md)
                    .putString("voice_api_provider", prov)
                    .apply()
                refreshVoiceEngineStatusText()
                Toast.makeText(
                    this@SettingsActivity,
                    if (k.isNotEmpty()) "✅ 已启用 AudioRecord 60 秒长语音直录引擎！" else "已切换回小米系统默认语音引擎",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        voiceEngineCard.addView(saveVoiceEngineBtn)

        val sysVoiceAndClearRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        sysVoiceAndClearRow.addView(Button(this).apply {
            text = "🎙️ 测试小米系统语音弹窗"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                launchSystemVoicePopupActivity()
            }
        })
        sysVoiceAndClearRow.addView(Button(this).apply {
            text = "清空Key(用小米默认)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                keyInput.setText("")
                prefs.edit().putString("voice_api_key", "").apply()
                refreshVoiceEngineStatusText()
                Toast.makeText(this@SettingsActivity, "已恢复为小米系统默认语音引擎", Toast.LENGTH_SHORT).show()
            }
        })
        voiceEngineCard.addView(sysVoiceAndClearRow)
        root.addView(voiceEngineCard)

        // 1.2 键盘敲击音效开关与自定义音效上传
        val soundCard = makeCard("键盘敲击音效与自定义音频设置")
        val soundSwitch = Switch(this).apply {
            text = "开启按键与候选选字敲击音效（打字+选首字/候选词全连贯发声）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setTextColor(Color.parseColor("#2A3042"))
            isChecked = prefs.getBoolean("key_sound_enabled", true)
            setPadding(dp(4), dp(6), dp(4), dp(6))
            setOnCheckedChangeListener { _, isChecked ->
                KeySoundManager.setSoundEnabledCached(isChecked)
                prefs.edit().putBoolean("key_sound_enabled", isChecked).apply()
                if (isChecked) {
                    KeySoundManager.playClick(this@SettingsActivity, forcePreview = true)
                }
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启按键敲击音效" else "已关闭按键敲击音效",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        customSoundStatusTv = TextView(this).apply {
            val hasCustom = KeySoundManager.hasCustomSound(this@SettingsActivity)
            val sName = KeySoundManager.getCustomSoundName(this@SettingsActivity)
            text = if (hasCustom) "当前使用音效：自定义音效（$sName）" else "当前使用音效：内置默认敲击音"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#3B5998"))
            setPadding(dp(4), dp(2), dp(4), dp(6))
        }
        val soundBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val uploadSoundBtn = Button(this).apply {
            text = "上传自定义音效"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择音频文件 (.wav / .mp3 / .ogg)"), REQ_PICK_SOUND)
            }
        }
        val resetSoundBtn = Button(this).apply {
            text = "恢复默认音效"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                KeySoundManager.clearCustomSound(this@SettingsActivity)
                customSoundStatusTv.text = "当前使用音效：内置默认敲击音"
                KeySoundManager.playClick(this@SettingsActivity, forcePreview = true)
                Toast.makeText(this@SettingsActivity, "已恢复内置默认敲击音！", Toast.LENGTH_SHORT).show()
            }
        }
        soundBtnRow.addView(uploadSoundBtn)
        soundBtnRow.addView(resetSoundBtn)
        soundCard.addView(soundSwitch)
        soundCard.addView(customSoundStatusTv)
        soundCard.addView(soundBtnRow)
        root.addView(soundCard)

        // 1.5 自定义键盘右下角文字（原「盛夏光年」按键）
        val enterTextCard = makeCard("✨ 自定义键盘右下角文字（默认：盛夏光年）")
        val enterTextDesc = TextView(this).apply {
            text = "随时修改键盘右下角回车键显示的文字（4个字会自动排成精致的上下两行，也可以用 / 手动分行，如：盛夏/光年、暴富/暴美、biu~）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(6))
        }
        val enterTextInput = EditText(this).apply {
            setText(prefs.getString("custom_enter_text", "") ?: "")
            hint = "默认显示：盛夏光年（直接输入你想换的字）"
            setSingleLine(true)
        }
        val enterBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val saveEnterTextBtn = Button(this).apply {
            text = "💾 保存右下角文字"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val newText = enterTextInput.text.toString().trim()
                if (newText.isEmpty()) {
                    prefs.edit().remove("custom_enter_text").apply()
                    Toast.makeText(this@SettingsActivity, "已恢复默认「盛夏光年」！弹出键盘即可看到", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString("custom_enter_text", newText).apply()
                    Toast.makeText(this@SettingsActivity, "右下角文字已更新为「$newText」！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val resetEnterTextBtn = Button(this).apply {
            text = "↺ 恢复「盛夏光年」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                enterTextInput.setText("")
                prefs.edit().remove("custom_enter_text").apply()
                Toast.makeText(this@SettingsActivity, "已恢复默认「盛夏光年」！", Toast.LENGTH_SHORT).show()
            }
        }
        enterBtnRow.addView(saveEnterTextBtn)
        enterBtnRow.addView(resetEnterTextBtn)
        enterTextCard.addView(enterTextDesc)
        enterTextCard.addView(enterTextInput)
        enterTextCard.addView(enterBtnRow)
        root.addView(enterTextCard)

        // 2. 剪贴板与常用语导出 / 导入备份 (.json)
        val backupCard = makeCard("2. 剪贴板与常用语导出 / 导入备份")
        val backupDesc = TextView(this).apply {
            text = "可将全部 300 条剪贴板、自定义常用语分类与万字指令、自定义颜文字一键打包导出为 .json 文件，换机或重装随时恢复："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        backupCard.addView(backupDesc)

        val backupBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val exportBtn = Button(this).apply {
            text = "📤 导出备份 (.json)"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "盛夏光年_常用语与剪贴板备份.json")
                }
                startActivityForResult(intent, REQ_EXPORT_BACKUP)
            }
        }
        val importBackupBtn = Button(this).apply {
            text = "📥 导入恢复 (.json)"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择备份 .json 文件"), REQ_IMPORT_BACKUP)
            }
        }
        backupBtnRow.addView(exportBtn)
        backupBtnRow.addView(importBackupBtn)
        backupCard.addView(backupBtnRow)
        root.addView(backupCard)

        // 3. 添加自定义表情与颜文字
        val kaomojiCard = makeCard("3. 添加自定义表情与颜文字（长按键盘内自定义项可删除）")
        val customExpInput = EditText(this).apply {
            hint = "输入你想添加的颜文字或表情组合，如：(๑•̀ㅂ•́)و✧ 或 🐱✨"
        }
        val expBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addToKaomojiBtn = Button(this).apply {
            text = "＋加入「颜文字」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val t = customExpInput.text.toString().trim()
                if (t.isNotEmpty()) {
                    dbHelper.addCustomExpression("kaomoji", t)
                    customExpInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已加入颜文字「经典」分类首位！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val addToEmojiBtn = Button(this).apply {
            text = "＋加入「Emoji」"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val t = customExpInput.text.toString().trim()
                if (t.isNotEmpty()) {
                    dbHelper.addCustomExpression("emoji", t)
                    customExpInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已加入 Emoji「笑脸」分类首位！", Toast.LENGTH_SHORT).show()
                }
            }
        }
        expBtnRow.addView(addToKaomojiBtn)
        expBtnRow.addView(addToEmojiBtn)
        kaomojiCard.addView(customExpInput)
        kaomojiCard.addView(expBtnRow)
        root.addView(kaomojiCard)

        // 4. 高频字词自动排序说明与一键重置
        val freqCard = makeCard("4. 个人高频字词自动排序与重置")
        val freqDesc = TextView(this).apply {
            text = "工作原理（几码归几码精准记忆）：系统严格按你当时输入的码数（1码、2码、3码、4码各管各的）记录你最后选过的字/词，下次打相同编码时直接排第 1 位，绝不会出现长编码词语越级抢占 1 码单字的情况。若想恢复初始词库顺序，可点击下方重置："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        val resetFreqBtn = Button(this).apply {
            text = "一键重置文字默认排序（清空个人高频记忆）"
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("确认重置文字默认排序？")
                    .setMessage("重置后将清空您日常打字积累的个人高频选词顺序，恢复初始默认词序（不会删除词库词条）。确定要重置吗？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("确定重置") { _, _ ->
                        T14WubiEngine.resetUserFrequency(dbHelper)
                        Toast.makeText(this@SettingsActivity, "已重置所有字词为默认排序！", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
        }
        freqCard.addView(freqDesc)
        freqCard.addView(resetFreqBtn)
        root.addView(freqCard)

        // 4.5 三大字体模块独立导入（① 英文字母字体；② 中文候选词字体；③ 右下角自定义文字字体）
        val fontCard = makeCard("三大字体模块独立导入（支持本地 .ttf / .otf 字体）")
        val fontDesc = TextView(this).apply {
            text = "可分别为键盘的三大区域导入不同的手机本地字体文件（互不干扰，随时可单独恢复默认）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(6))
        }
        fontCard.addView(fontDesc)

        // ① 英文字母字体
        fontEngStatusTv = TextView(this).apply {
            text = "① 按键英文字母字体：${CustomFontManager.getCustomFontName(this@SettingsActivity, CustomFontManager.SLOT_ENG)}"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val fontEngRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontEngRow.addView(Button(this).apply {
            text = "导入英文字母字体"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择英文字母字体 (.ttf / .otf)"), REQ_PICK_FONT_ENG)
            }
        })
        fontEngRow.addView(Button(this).apply {
            text = "恢复默认"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.55f)
            setOnClickListener {
                CustomFontManager.clearCustomFont(this@SettingsActivity, CustomFontManager.SLOT_ENG)
                fontEngStatusTv.text = "① 按键英文字母字体：未导入（使用系统默认）"
                Toast.makeText(this@SettingsActivity, "已恢复默认英文字母字体！", Toast.LENGTH_SHORT).show()
            }
        })
        fontCard.addView(fontEngStatusTv)
        fontCard.addView(fontEngRow)

        // ② 中文候选词字体
        fontCandStatusTv = TextView(this).apply {
            text = "② 中文候选词字体：${CustomFontManager.getCustomFontName(this@SettingsActivity, CustomFontManager.SLOT_CAND)}"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(8), 0, dp(2))
        }
        val fontCandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontCandRow.addView(Button(this).apply {
            text = "导入中文候选词字体"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择中文候选词字体 (.ttf / .otf)"), REQ_PICK_FONT_CAND)
            }
        })
        fontCandRow.addView(Button(this).apply {
            text = "恢复默认"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.55f)
            setOnClickListener {
                CustomFontManager.clearCustomFont(this@SettingsActivity, CustomFontManager.SLOT_CAND)
                fontCandStatusTv.text = "② 中文候选词字体：未导入（使用系统默认）"
                Toast.makeText(this@SettingsActivity, "已恢复默认中文候选词字体！", Toast.LENGTH_SHORT).show()
            }
        })
        fontCard.addView(fontCandStatusTv)
        fontCard.addView(fontCandRow)

        // ③ 右下角自定义文字（如“盛夏光年”）字体
        fontEnterStatusTv = TextView(this).apply {
            text = "③ 右下角自定义文字字体：${CustomFontManager.getCustomFontName(this@SettingsActivity, CustomFontManager.SLOT_ENTER)}"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(8), 0, dp(2))
        }
        val fontEnterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontEnterRow.addView(Button(this).apply {
            text = "导入右下角专属字体"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(Intent.createChooser(intent, "选择右下角专属字体 (.ttf / .otf)"), REQ_PICK_FONT_ENTER)
            }
        })
        fontEnterRow.addView(Button(this).apply {
            text = "恢复默认"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.55f)
            setOnClickListener {
                CustomFontManager.clearCustomFont(this@SettingsActivity, CustomFontManager.SLOT_ENTER)
                fontEnterStatusTv.text = "③ 右下角自定义文字字体：未导入（使用系统默认）"
                Toast.makeText(this@SettingsActivity, "已恢复默认右下角文字字体！", Toast.LENGTH_SHORT).show()
            }
        })
        fontCard.addView(fontEnterStatusTv)
        fontCard.addView(fontEnterRow)
        root.addView(fontCard)

        // 5. 双层架构皮肤设置（莫奈花园特殊皮肤 + 纯色/自定义背景图毛玻璃框架 + CSS 编辑器）
        val topIconCard = makeCard("4.5 状态栏与通配键图标大小同步调节 · 15 款可爱图标换装与 PNG 上传")
        val topIconGuideTv = TextView(this).apply {
            text = "💡 图标换装与大小同步说明：\n" +
                "• 大小 1:1 联动：下方滑块会同时控制「顶部状态栏 5 个图标」与「键盘通配键图标」的大小，视觉比例完全一致！\n" +
                "• 内置 15 款图 5 同款可爱镂空图标（含全新甜心蝴蝶结、六瓣小樱花、双子星芒、四叶草、幸运草、许愿流星、小雪花、小书本等），点击「🎨 选内置图标」即可直接为任意状态栏位置或通配键换装，也支持上传你自己的 PNG 图片。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#3B5998"))
            setPadding(0, 0, 0, dp(8))
        }
        topIconCard.addView(topIconGuideTv)

        val initTopIconDp = CustomTopIconManager.getIconSizeDp(this)
        val topIconSizeTitleTv = TextView(this).apply {
            text = "状态栏与通配键图标大小：$initTopIconDp dp（可调范围 14 ~ 34 dp，默认精致尺寸 22 dp）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#222634"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val topIconSizeSeek = SeekBar(this).apply {
            max = CustomTopIconManager.MAX_ICON_SIZE_DP - CustomTopIconManager.MIN_ICON_SIZE_DP
            progress = initTopIconDp - CustomTopIconManager.MIN_ICON_SIZE_DP
            setPadding(dp(4), dp(4), dp(4), dp(8))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val dpVal = CustomTopIconManager.MIN_ICON_SIZE_DP + progress
                    CustomTopIconManager.setIconSizeDp(this@SettingsActivity, dpVal)
                    topIconSizeTitleTv.text = "状态栏与通配键图标大小：$dpVal dp（可调范围 14 ~ 34 dp，默认精致尺寸 22 dp）"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        topIconCard.addView(topIconSizeTitleTv)
        topIconCard.addView(topIconSizeSeek)

        val followSkinSwitch = Switch(this).apply {
            text = "自定义图标随皮肤自动变色（线条/镂空图标推荐开启；若上传彩色多色贴纸请关闭）"
            textSize = 12.5f
            isChecked = CustomTopIconManager.isFollowSkinColor(this@SettingsActivity)
            setPadding(0, dp(4), 0, dp(8))
            setOnCheckedChangeListener { _, isChecked ->
                CustomTopIconManager.setFollowSkinColor(this@SettingsActivity, isChecked)
            }
        }
        topIconCard.addView(followSkinSwitch)

        // 通配键专属换装卡片
        val wcBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#FFF5F8"),
                Color.parseColor("#FCEEF3"),
                dp(8),
                Color.parseColor("#F3C6D6"),
                dp(1)
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(8)
            layoutParams = lp
        }
        val wcStatusTv = TextView(this).apply {
            val curSt = WildcardCuteIconView.getWildcardIconStyle(this@SettingsActivity)
            text = "✨ 键盘「通配键」图标：当前为【${WildcardCuteIconView.getStyleDisplayName(curSt)}】（大小跟随上方状态栏滑块）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#8A3B58"))
        }
        wcBox.addView(wcStatusTv)
        wcBox.addView(Button(this).apply {
            text = "🎨 更换「通配键」可爱图标（15款图5同款 + 文字模式）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setOnClickListener {
                val styles = WildcardCuteIconView.ALL_WILDCARD_STYLES
                val names = styles.map { it.second }.toTypedArray()
                android.app.AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("选择「通配键」可爱图标")
                    .setItems(names) { _, which ->
                        val picked = styles[which]
                        WildcardCuteIconView.setWildcardIconStyle(this@SettingsActivity, picked.first)
                        wcStatusTv.text = "✨ 键盘「通配键」图标：当前为【${picked.second}】（大小跟随上方状态栏滑块）"
                        Toast.makeText(this@SettingsActivity, "通配键已换为：${picked.second}", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
        })
        topIconCard.addView(wcBox)

        val slotMetaList = listOf(
            Triple(MinimalistIconView.TYPE_SETTINGS, "第 1 个图标（设置）", "默认：🐱猫猫头"),
            Triple(MinimalistIconView.TYPE_EMOJI, "第 2 个图标（表情）", "默认：💕双爱心"),
            Triple(MinimalistIconView.TYPE_CLIPBOARD, "第 3 个图标（剪贴板）", "默认：🪐小星球"),
            Triple(MinimalistIconView.TYPE_FAVORITE, "第 4 个图标（收藏）", "默认：⭐胖星星"),
            Triple(MinimalistIconView.TYPE_COLLAPSE, "第 5 个图标（收起）", "默认：👑小皇冠")
        )

        slotMetaList.forEach { (slotType, slotTitle, defaultDesc) ->
            val slotBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = CssSkinManager.makeGradientDrawable(
                    Color.parseColor("#F7F8FC"),
                    Color.parseColor("#F1F3F9"),
                    dp(8),
                    Color.parseColor("#DCE1EE"),
                    dp(1)
                )
                setPadding(dp(10), dp(8), dp(10), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(6)
                layoutParams = lp
            }
            val statusTv = TextView(this).apply {
                val hasCustom = CustomTopIconManager.hasCustomIcon(this@SettingsActivity, slotType)
                val presetId = CustomTopIconManager.getSlotPresetIconId(this@SettingsActivity, slotType)
                text = when {
                    hasCustom -> "$slotTitle：✅ 已启用你上传的自定义 PNG"
                    presetId != slotType -> "$slotTitle：🎨 已换装为【${MinimalistIconView.getPresetIconName(presetId)}】"
                    else -> "$slotTitle：$defaultDesc"
                }
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor(if (hasCustom || presetId != slotType) "#2B5B84" else "#333A4D"))
            }
            topIconSlotStatusMap[slotType] = statusTv
            slotBox.addView(statusTv)

            val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btnRow.addView(Button(this).apply {
                text = "🎨 选内置图标"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.05f)
                setOnClickListener {
                    val presets = MinimalistIconView.ALL_PRESET_ICONS
                    val names = presets.map { it.second }.toTypedArray()
                    android.app.AlertDialog.Builder(this@SettingsActivity)
                        .setTitle("为 $slotTitle 选择内置可爱图标")
                        .setItems(names) { _, which ->
                            val picked = presets[which]
                            CustomTopIconManager.setSlotPresetIconId(this@SettingsActivity, slotType, picked.first)
                            statusTv.text = "$slotTitle：🎨 已换装为【${picked.second}】"
                            statusTv.setTextColor(Color.parseColor("#2B5B84"))
                            Toast.makeText(this@SettingsActivity, "$slotTitle 已换为：${picked.second}", Toast.LENGTH_SHORT).show()
                        }
                        .show()
                }
            })
            btnRow.addView(Button(this).apply {
                text = "上传(.png)"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.95f)
                setOnClickListener {
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                    }
                    startActivityForResult(Intent.createChooser(intent, "选择 $slotTitle 的 PNG 图标"), REQ_PICK_TOP_ICON_BASE + slotType)
                }
            })
            btnRow.addView(Button(this).apply {
                text = "默认"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.65f)
                setOnClickListener {
                    CustomTopIconManager.clearCustomIcon(this@SettingsActivity, slotType)
                    statusTv.text = "$slotTitle：$defaultDesc"
                    statusTv.setTextColor(Color.parseColor("#333A4D"))
                    Toast.makeText(this@SettingsActivity, "已恢复 $slotTitle 为默认图标！", Toast.LENGTH_SHORT).show()
                }
            })
            slotBox.addView(btnRow)
            topIconCard.addView(slotBox)
        }

        topIconCard.addView(Button(this).apply {
            text = "🔄 一键恢复全部 5 个状态栏默认图标与默认大小 (22dp)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setOnClickListener {
                CustomTopIconManager.clearAllCustomIcons(this@SettingsActivity)
                CustomTopIconManager.setIconSizeDp(this@SettingsActivity, CustomTopIconManager.DEFAULT_ICON_SIZE_DP)
                topIconSizeSeek.progress = CustomTopIconManager.DEFAULT_ICON_SIZE_DP - CustomTopIconManager.MIN_ICON_SIZE_DP
                slotMetaList.forEach { (slotType, slotTitle, defaultDesc) ->
                    topIconSlotStatusMap[slotType]?.apply {
                        text = "$slotTitle：$defaultDesc"
                        setTextColor(Color.parseColor("#333A4D"))
                    }
                }
                Toast.makeText(this@SettingsActivity, "已恢复全部 5 个默认状态栏图标及 22dp 精致尺寸！", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(topIconCard)

        val skinCard = makeCard("5. 皮肤设置与 CSS 编辑器（支持上传自定义背景图）")

        val bgArchNote = TextView(this).apply {
            text = "架构说明：「莫奈花园」为唯一自带油画贴图的特殊皮肤；其余皮肤均采用「纯色框架」。在纯色框架下上传自定义背景图后，底图会自动以 cover 模式铺满键盘，所有按键自动开启半透明毛玻璃效果并实时模糊底图；不上传则默认使用纯色背景。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#555555"))
            setPadding(0, 0, 0, dp(8))
        }
        skinCard.addView(bgArchNote)

        customBgStatusTv = TextView(this).apply {
            val hasBg = CustomBgManager.hasCustomBg(this@SettingsActivity)
            text = if (hasBg) "当前底图状态：已启用自定义背景图（纯色框架下按键已开启半透明毛玻璃）" else "当前底图状态：未上传自定义背景图（默认使用纯色背景）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#3B5998"))
            setPadding(0, 0, 0, dp(6))
        }
        skinCard.addView(customBgStatusTv)

        val customBgBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val uploadBgBtn = Button(this).apply {
            text = "上传自定义背景图"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(Intent.createChooser(intent, "从相册选择键盘背景图"), REQ_PICK_BG_IMAGE)
            }
        }
        val clearBgBtn = Button(this).apply {
            text = "清除自定义背景图"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                CustomBgManager.clearCustomBg(this@SettingsActivity)
                customBgStatusTv.text = "当前底图状态：未上传自定义背景图（默认使用纯色背景）"
                Toast.makeText(this@SettingsActivity, "已清除自定义背景图，恢复纯色背景！", Toast.LENGTH_SHORT).show()
            }
        }
        customBgBtnRow.addView(uploadBgBtn)
        customBgBtnRow.addView(clearBgBtn)
        skinCard.addView(customBgBtnRow)

        val initBlurLevel = prefs.getInt("custom_bg_blur_level", 25).coerceIn(0, 100)
        val bgBlurTitleTv = TextView(this).apply {
            text = "上传背景图的毛玻璃效果程度：$initBlurLevel / 100（0为完全清晰原图，100为最浓毛玻璃）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(8), 0, dp(2))
        }
        val bgBlurSeekBar = SeekBar(this).apply {
            max = 100
            progress = initBlurLevel
            setPadding(dp(4), dp(4), dp(4), dp(10))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = progress.coerceIn(0, 100)
                    prefs.edit().putInt("custom_bg_blur_level", lv).apply()
                    bgBlurTitleTv.text = "上传背景图的毛玻璃效果程度：$lv / 100（0为完全清晰原图，100为最浓毛玻璃）"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        skinCard.addView(bgBlurTitleTv)
        skinCard.addView(bgBlurSeekBar)

        // 💡 0. 按键底部基础柔光晕染总开关（可在关闭下方星点时一并关闭，彻底进入 0 光效极速模式）
        val baseGlowSwitch = Switch(this).apply {
            text = "💡 开启按键底部基础柔光光晕（关闭后彻底停用底层光晕渲染，享受极致跟手零功耗）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1E2436"))
            isChecked = (prefs.getString("key_glow_mode", "on") ?: "on") != "off"
            setPadding(dp(4), dp(6), dp(4), dp(8))
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putString("key_glow_mode", if (isChecked) "on" else "off").apply()
            }
        }
        skinCard.addView(baseGlowSwitch)

        // 💧 0A. 键盘上特效 1：「水纹落雨 · 浅层水波微漾（Liquid Ripple）」（独立开关 + 密度 / 速度 / 范围 三项独立调节）
        val rippleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#F5F8FF"),
                Color.parseColor("#EDF2FE"),
                dp(10),
                Color.parseColor("#C7D6F4"),
                dp(1)
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val initRpOn = KeyboardBacklightOverlayView.isLiquidRippleEnabled(this)
        val initRpDensity = KeyboardBacklightOverlayView.getLiquidRippleDensity(this)
        val initRpSpeed = KeyboardBacklightOverlayView.getLiquidRippleSpeed(this)
        val initRpRange = KeyboardBacklightOverlayView.getLiquidRippleRange(this)

        val rippleSwitch = Switch(this).apply {
            text = "💧 开启键盘上「水纹落雨：浅层水波微漾（Liquid Ripple）」特效（可与下方暗夜微尘同时开启或单独关闭）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1E2436"))
            isChecked = initRpOn
            setOnCheckedChangeListener { _, isChecked ->
                KeyboardBacklightOverlayView.setLiquidRippleEnabled(this@SettingsActivity, isChecked)
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启「水纹落雨」特效！" else "已关闭「水纹落雨」特效",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val rpNoteTv = TextView(this).apply {
            text = "🌊 视觉意境：敲击瞬间以触点为圆心缓缓荡开 1~3 圈极细半透明白波峰与暮色水影折光槽，浅色与莫兰迪皮肤上清澈灵动。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.parseColor("#52607A"))
            setPadding(0, dp(2), 0, dp(4))
        }
        val rpDensityTitleTv = TextView(this).apply {
            text = "💧 水纹密度与圈数：$initRpDensity%（范围 10% ~ 100%，控制涟漪层数 1~3 圈与折光清晰度）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val rpDensitySeek = SeekBar(this).apply {
            max = 90
            progress = (initRpDensity - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setLiquidRippleDensity(this@SettingsActivity, lv)
                    rpDensityTitleTv.text = "💧 水纹密度与圈数：$lv%（范围 10% ~ 100%，控制涟漪层数 1~3 圈与折光清晰度）"
                    if (fromUser && !rippleSwitch.isChecked) rippleSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val rpSpeedTitleTv = TextView(this).apply {
            text = "💧 水纹荡开速度：$initRpSpeed%（范围 10% ~ 100%，越低越如静湖慢漾，越高越轻快灵动）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val rpSpeedSeek = SeekBar(this).apply {
            max = 90
            progress = (initRpSpeed - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setLiquidRippleSpeed(this@SettingsActivity, lv)
                    rpSpeedTitleTv.text = "💧 水纹荡开速度：$lv%（范围 10% ~ 100%，越低越如静湖慢漾，越高越轻快灵动）"
                    if (fromUser && !rippleSwitch.isChecked) rippleSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val rpRangeTitleTv = TextView(this).apply {
            text = "💧 水纹扩散范围：$initRpRange%（范围 10% ~ 100%，控制水波涟漪在键帽表面荡开的半径大小）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val rpRangeSeek = SeekBar(this).apply {
            max = 90
            progress = (initRpRange - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setLiquidRippleRange(this@SettingsActivity, lv)
                    rpRangeTitleTv.text = "💧 水纹扩散范围：$lv%（范围 10% ~ 100%，控制水波涟漪在键帽表面荡开的半径大小）"
                    if (fromUser && !rippleSwitch.isChecked) rippleSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val rpPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun addRpPresetBtn(label: String, d: Int, s: Int, r: Int) {
            rpPresetRow.addView(Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
                setOnClickListener {
                    KeyboardBacklightOverlayView.setLiquidRippleDensity(this@SettingsActivity, d)
                    KeyboardBacklightOverlayView.setLiquidRippleSpeed(this@SettingsActivity, s)
                    KeyboardBacklightOverlayView.setLiquidRippleRange(this@SettingsActivity, r)
                    KeyboardBacklightOverlayView.setLiquidRippleEnabled(this@SettingsActivity, true)
                    rippleSwitch.isChecked = true
                    rpDensitySeek.progress = d - 10
                    rpSpeedSeek.progress = s - 10
                    rpRangeSeek.progress = r - 10
                    rpDensityTitleTv.text = "💧 水纹密度与圈数：$d%（范围 10% ~ 100%，控制涟漪层数 1~3 圈与折光清晰度）"
                    rpSpeedTitleTv.text = "💧 水纹荡开速度：$s%（范围 10% ~ 100%，越低越如静湖慢漾，越高越轻快灵动）"
                    rpRangeTitleTv.text = "💧 水纹扩散范围：$r%（范围 10% ~ 100%，控制水波涟漪在键帽表面荡开的半径大小）"
                }
            })
        }
        addRpPresetBtn("微澜(单圈)", 30, 50, 42)
        addRpPresetBtn("暮色湖水", 62, 55, 58)
        addRpPresetBtn("慢漾静湖", 72, 34, 66)
        addRpPresetBtn("听雨眠(三圈)", 88, 42, 78)

        rippleBox.addView(rippleSwitch)
        rippleBox.addView(rpNoteTv)
        rippleBox.addView(rpDensityTitleTv)
        rippleBox.addView(rpDensitySeek)
        rippleBox.addView(rpSpeedTitleTv)
        rippleBox.addView(rpSpeedSeek)
        rippleBox.addView(rpRangeTitleTv)
        rippleBox.addView(rpRangeSeek)
        rippleBox.addView(rpPresetRow)
        skinCard.addView(rippleBox)

        // ✦ 0B. 键盘上特效 2：「暗夜微尘 / 幽夜流星 · 星屑沉落（Stardust Fall）」（独立开关 + 密度 / 速度 / 范围 三项独立调节）
        val stardustBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#F8F5FE"),
                Color.parseColor("#F0EBFC"),
                dp(10),
                Color.parseColor("#D5C8F2"),
                dp(1)
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val initSdOn = KeyboardBacklightOverlayView.isStardustFallEnabled(this)
        val initSdDensity = KeyboardBacklightOverlayView.getStardustFallDensity(this)
        val initSdSpeed = KeyboardBacklightOverlayView.getStardustFallSpeed(this)
        val initSdRange = KeyboardBacklightOverlayView.getStardustFallRange(this)

        val stardustSwitch = Switch(this).apply {
            text = "✦ 开启键盘上「暗夜微尘 / 幽夜流星：极细碎闪与星屑沉落」特效（可与水纹落雨同时开启或单独关闭）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1E2436"))
            isChecked = initSdOn
            setOnCheckedChangeListener { _, isChecked ->
                KeyboardBacklightOverlayView.setStardustFallEnabled(this@SettingsActivity, isChecked)
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启「暗夜微尘 / 幽夜流星」特效！" else "已关闭「暗夜微尘」特效",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val sdNoteTv = TextView(this).apply {
            text = "🌠 视觉意境：按键四周迸出 2~10 颗直径 2~3dp 的极细四芒星尘（✦/✧），顺着重力微微下沉消融；浅色皮肤自动采用深暮紫同色微星配纯白星芯。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.parseColor("#52607A"))
            setPadding(0, dp(2), 0, dp(4))
        }
        val sdDensityTitleTv = TextView(this).apply {
            text = "✦ 微尘星屑密度：$initSdDensity%（范围 10% ~ 100%，控制每次敲击迸出并下沉的四芒微星数量）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val sdDensitySeek = SeekBar(this).apply {
            max = 90
            progress = (initSdDensity - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setStardustFallDensity(this@SettingsActivity, lv)
                    sdDensityTitleTv.text = "✦ 微尘星屑密度：$lv%（范围 10% ~ 100%，控制每次敲击迸出并下沉的四芒微星数量）"
                    if (fromUser && !stardustSwitch.isChecked) stardustSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val sdSpeedTitleTv = TextView(this).apply {
            text = "✦ 微尘沉落速度：$initSdSpeed%（范围 10% ~ 100%，控制四芒星尘随重力下沉与消融的快慢）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val sdSpeedSeek = SeekBar(this).apply {
            max = 90
            progress = (initSdSpeed - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setStardustFallSpeed(this@SettingsActivity, lv)
                    sdSpeedTitleTv.text = "✦ 微尘沉落速度：$lv%（范围 10% ~ 100%，控制四芒星尘随重力下沉与消融的快慢）"
                    if (fromUser && !stardustSwitch.isChecked) stardustSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val sdRangeTitleTv = TextView(this).apply {
            text = "✦ 微尘散落范围：$initSdRange%（范围 10% ~ 100%，控制星屑向外微漾与向下沉落的垂落距离）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val sdRangeSeek = SeekBar(this).apply {
            max = 90
            progress = (initSdRange - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setStardustFallRange(this@SettingsActivity, lv)
                    sdRangeTitleTv.text = "✦ 微尘散落范围：$lv%（范围 10% ~ 100%，控制星屑向外微漾与向下沉落的垂落距离）"
                    if (fromUser && !stardustSwitch.isChecked) stardustSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val sdPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun addSdPresetBtn(label: String, d: Int, s: Int, r: Int) {
            sdPresetRow.addView(Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
                setOnClickListener {
                    KeyboardBacklightOverlayView.setStardustFallDensity(this@SettingsActivity, d)
                    KeyboardBacklightOverlayView.setStardustFallSpeed(this@SettingsActivity, s)
                    KeyboardBacklightOverlayView.setStardustFallRange(this@SettingsActivity, r)
                    KeyboardBacklightOverlayView.setStardustFallEnabled(this@SettingsActivity, true)
                    stardustSwitch.isChecked = true
                    sdDensitySeek.progress = d - 10
                    sdSpeedSeek.progress = s - 10
                    sdRangeSeek.progress = r - 10
                    sdDensityTitleTv.text = "✦ 微尘星屑密度：$d%（范围 10% ~ 100%，控制每次敲击迸出并下沉的四芒微星数量）"
                    sdSpeedTitleTv.text = "✦ 微尘沉落速度：$s%（范围 10% ~ 100%，控制四芒星尘随重力下沉与消融的快慢）"
                    sdRangeTitleTv.text = "✦ 微尘散落范围：$r%（范围 10% ~ 100%，控制星屑向外微漾与向下沉落的垂落距离）"
                }
            })
        }
        addSdPresetBtn("疏星微尘", 32, 52, 40)
        addSdPresetBtn("幽夜流星", 64, 56, 55)
        addSdPresetBtn("慢落星羽", 70, 34, 62)
        addSdPresetBtn("星雨纷落", 90, 46, 76)

        stardustBox.addView(stardustSwitch)
        stardustBox.addView(sdNoteTv)
        stardustBox.addView(sdDensityTitleTv)
        stardustBox.addView(sdDensitySeek)
        stardustBox.addView(sdSpeedTitleTv)
        stardustBox.addView(sdSpeedSeek)
        stardustBox.addView(sdRangeTitleTv)
        stardustBox.addView(sdRangeSeek)
        stardustBox.addView(sdPresetRow)
        skinCard.addView(stardustBox)

        // ☄️ 1. 键盘下星点与光线迸发（键底陨石星爆光效：支持光点线条密度 / 迸发速度 / 迸发范围 三项独立调节）
        val underBurstBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#F5F7FE"),
                Color.parseColor("#ECF0FC"),
                dp(10),
                Color.parseColor("#C9D5F2"),
                dp(1)
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val initUbOn = KeyboardBacklightOverlayView.isUnderBurstEnabled(this)
        val initUbDensity = KeyboardBacklightOverlayView.getUnderBurstDensity(this)
        val initUbSpeed = KeyboardBacklightOverlayView.getUnderBurstSpeed(this)
        val initUbRange = KeyboardBacklightOverlayView.getUnderBurstRange(this)

        val underBurstSwitch = Switch(this).apply {
            text = "🌙 开启键盘下「不规则弧形流光细丝 + 唯美簇状星点（✦/✧/°/·）」光效"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1E2436"))
            isChecked = initUbOn
            setOnCheckedChangeListener { _, isChecked ->
                KeyboardBacklightOverlayView.setUnderBurstEnabled(this@SettingsActivity, isChecked)
                if (isChecked) {
                    prefs.edit().putString("key_glow_mode", "on").apply()
                    if (!baseGlowSwitch.isChecked) baseGlowSwitch.isChecked = true
                }
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启键盘下星点与光线迸发光效！" else "已关闭键盘下星点迸发",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val ubColorNoteTv = TextView(this).apply {
            text = "🎨 配色自适应：深色皮肤采用「高亮银白星光 + 30%背光同色 + 邻近和谐彩星」；浅色皮肤自动加深着色浓度防隐形。"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.parseColor("#52607A"))
            setPadding(0, dp(2), 0, dp(4))
        }

        val ubDensityTitleTv = TextView(this).apply {
            text = "✨ 星点与流光丝疏密：$initUbDensity%（范围 10% ~ 100%，控制弧形流光细丝与不对称星点簇的疏密）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val ubDensitySeek = SeekBar(this).apply {
            max = 90
            progress = (initUbDensity - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setUnderBurstDensity(this@SettingsActivity, lv)
                    ubDensityTitleTv.text = "✨ 星点与流光丝疏密：$lv%（范围 10% ~ 100%，控制弧形流光细丝与不对称星点簇的疏密）"
                    if (fromUser && !underBurstSwitch.isChecked) underBurstSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        val ubSpeedTitleTv = TextView(this).apply {
            text = "⚡ 绽放与余韵速度：$initUbSpeed%（范围 10% ~ 100%，控制流光漾开与末尾小星闪烁消融快慢）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val ubSpeedSeek = SeekBar(this).apply {
            max = 90
            progress = (initUbSpeed - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(4))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setUnderBurstSpeed(this@SettingsActivity, lv)
                    ubSpeedTitleTv.text = "⚡ 绽放与余韵速度：$lv%（范围 10% ~ 100%，控制流光漾开与末尾小星闪烁消融快慢）"
                    if (fromUser && !underBurstSwitch.isChecked) underBurstSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        val ubRangeTitleTv = TextView(this).apply {
            text = "🎯 星点散开距离：$initUbRange%（范围 10% ~ 100%，控制流光丝与小星芒浮出键帽边缘的远近）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val ubRangeSeek = SeekBar(this).apply {
            max = 90
            progress = (initUbRange - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(2), dp(4), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setUnderBurstRange(this@SettingsActivity, lv)
                    ubRangeTitleTv.text = "🎯 星点散开距离：$lv%（范围 10% ~ 100%，控制流光丝与小星芒浮出键帽边缘的远近）"
                    if (fromUser && !underBurstSwitch.isChecked) underBurstSwitch.isChecked = true
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }

        val ubPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun addUbPresetBtn(label: String, d: Int, s: Int, r: Int) {
            ubPresetRow.addView(Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
                setOnClickListener {
                    KeyboardBacklightOverlayView.setUnderBurstDensity(this@SettingsActivity, d)
                    KeyboardBacklightOverlayView.setUnderBurstSpeed(this@SettingsActivity, s)
                    KeyboardBacklightOverlayView.setUnderBurstRange(this@SettingsActivity, r)
                    KeyboardBacklightOverlayView.setUnderBurstEnabled(this@SettingsActivity, true)
                    prefs.edit().putString("key_glow_mode", "on").apply()
                    underBurstSwitch.isChecked = true
                    ubDensitySeek.progress = d - 10
                    ubSpeedSeek.progress = s - 10
                    ubRangeSeek.progress = r - 10
                    ubDensityTitleTv.text = "✨ 星点与流光丝疏密：$d%（范围 10% ~ 100%，控制弧形流光细丝与不对称星点簇的疏密）"
                    ubSpeedTitleTv.text = "⚡ 绽放与余韵速度：$s%（范围 10% ~ 100%，控制流光漾开与末尾小星闪烁消融快慢）"
                    ubRangeTitleTv.text = "🎯 星点散开距离：$r%（范围 10% ~ 100%，控制流光丝与小星芒浮出键帽边缘的远近）"
                }
            })
        }
        addUbPresetBtn("清透留白", 38, 62, 36)
        addUbPresetBtn("默认星语", 65, 60, 48)
        addUbPresetBtn("慢动作星韵", 72, 35, 56)
        addUbPresetBtn("唯美流光", 88, 52, 64)

        underBurstBox.addView(underBurstSwitch)
        underBurstBox.addView(ubColorNoteTv)
        underBurstBox.addView(ubDensityTitleTv)
        underBurstBox.addView(ubDensitySeek)
        underBurstBox.addView(ubSpeedTitleTv)
        underBurstBox.addView(ubSpeedSeek)
        underBurstBox.addView(ubRangeTitleTv)
        underBurstBox.addView(ubRangeSeek)
        underBurstBox.addView(ubPresetRow)
        skinCard.addView(underBurstBox)

        // ✨ 2. 键盘上表面星点（键帽表面四角/六角星芒 + 星河微尘，已从状态栏快捷菜单移至此处主菜单独立保留）
        val sparkleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(
                Color.parseColor("#F7F8FC"),
                Color.parseColor("#EFF2FA"),
                dp(10),
                Color.parseColor("#D6DDF0"),
                dp(1)
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val initSpOn = KeyboardBacklightOverlayView.isSparkleEnabled(this)
        val initSpLv = KeyboardBacklightOverlayView.getSparkleIntensity(this)
        val sparkleTitleTv = TextView(this).apply {
            text = "✨ 键盘上表面星芒强弱程度：$initSpLv%（范围 10% ~ 100%，可与上方键下星爆同时开启或单独使用）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(4), 0, dp(2))
        }
        val sparkleSwitch = Switch(this).apply {
            text = "✨ 开启键盘上「表面璀璨星芒（键帽表面四角/六角星芒 + 星河微尘）」光效（主菜单独立保留）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#222634"))
            isChecked = initSpOn
            setOnCheckedChangeListener { _, isChecked ->
                KeyboardBacklightOverlayView.setSparkleEnabled(this@SettingsActivity, isChecked)
                if (isChecked) {
                    prefs.edit().putString("key_glow_mode", "on").apply()
                    if (!baseGlowSwitch.isChecked) baseGlowSwitch.isChecked = true
                }
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启键盘上表面星芒光效！" else "已关闭键盘上表面星芒",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        val sparkleSeekBar = SeekBar(this).apply {
            max = 90 // 10..100
            progress = (initSpLv - 10).coerceIn(0, 90)
            setPadding(dp(4), dp(4), dp(4), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val lv = (10 + progress).coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setSparkleIntensity(this@SettingsActivity, lv)
                    sparkleTitleTv.text = "✨ 键盘上表面星芒强弱程度：$lv%（范围 10% ~ 100%，可与上方键下星爆同时开启或单独使用）"
                    if (fromUser && !sparkleSwitch.isChecked) {
                        sparkleSwitch.isChecked = true
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        val sparklePresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun addSparklePresetBtn(label: String, targetLv: Int) {
            sparklePresetRow.addView(Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setPadding(dp(2), 0, dp(2), 0)
                layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f)
                setOnClickListener {
                    val clamped = targetLv.coerceIn(10, 100)
                    KeyboardBacklightOverlayView.setSparkleIntensity(this@SettingsActivity, clamped)
                    KeyboardBacklightOverlayView.setSparkleEnabled(this@SettingsActivity, true)
                    prefs.edit().putString("key_glow_mode", "on").apply()
                    sparkleSwitch.isChecked = true
                    sparkleSeekBar.progress = clamped - 10
                    sparkleTitleTv.text = "✨ 键盘上表面星芒强弱程度：$clamped%（范围 10% ~ 100%，可与上方键下星爆同时开启或单独使用）"
                }
            })
        }
        addSparklePresetBtn("轻柔(30%)", 30)
        addSparklePresetBtn("柔美(55%)", 55)
        addSparklePresetBtn("默认(82%)", 82)
        addSparklePresetBtn("璀璨(95%)", 95)
        sparkleBox.addView(sparkleSwitch)
        sparkleBox.addView(sparkleTitleTv)
        sparkleBox.addView(sparkleSeekBar)
        sparkleBox.addView(sparklePresetRow)
        skinCard.addView(sparkleBox)

        var isCssBoxExpanded = false
        cssInputBox = EditText(this).apply {
            setText(CssSkinManager.getSavedCss(this@SettingsActivity))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            minLines = 10
            maxLines = 16
            gravity = Gravity.TOP or Gravity.START
            setBackgroundColor(Color.parseColor("#F7F8FC"))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isVerticalScrollBarEnabled = true
            overScrollMode = android.view.View.OVER_SCROLL_ALWAYS
            movementMethod = android.text.method.ScrollingMovementMethod.getInstance()
            // 关键修复：手指在 CSS 代码框内上下滑动时，禁止外层 ScrollView 抢夺触摸事件，实现单指丝滑滚动代码！
            setOnTouchListener { v, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN,
                    android.view.MotionEvent.ACTION_MOVE -> {
                        if (!isCssBoxExpanded) {
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                        }
                    }
                    android.view.MotionEvent.ACTION_UP,
                    android.view.MotionEvent.ACTION_CANCEL -> {
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                }
                false
            }
        }

        // 统一网格对齐按钮样式生成器（彻底解决图3按钮换行高度不一致、6列挤压溢出问题！）
        fun makeAlignedGridButton(label: String, textSp: Float = 13f, onClick: (Button) -> Unit): Button {
            return Button(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
                isSingleLine = true
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                includeFontPadding = false
                setPadding(dp(4), 0, dp(4), 0)
                val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                lp.setMargins(dp(4), dp(4), dp(4), dp(4))
                layoutParams = lp
                setOnClickListener { onClick(this) }
            }
        }

        // 第 1 行（2列等宽对齐）：清除代码 | 示例代码
        val codeHelperRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        codeHelperRow.addView(makeAlignedGridButton("清除代码", 13.5f) {
            cssInputBox.setText("")
            Toast.makeText(this@SettingsActivity, "已清空代码编辑框，可直接粘贴或编写新代码", Toast.LENGTH_SHORT).show()
        })
        codeHelperRow.addView(makeAlignedGridButton("示例代码", 13.5f) {
            cssInputBox.setText(CssSkinManager.SAMPLE_COMMENTED_CSS)
            Toast.makeText(this@SettingsActivity, "已载入带完整中文注释的 CSS 示例代码！修改颜色后点「应用上方 CSS 皮肤」即可", Toast.LENGTH_LONG).show()
        })

        // 第 2 行（2列等宽对齐）：应用上方 CSS 皮肤 | 导入 .CSS 文件
        val skinBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        skinBtnRow.addView(makeAlignedGridButton("应用上方 CSS 皮肤", 13.5f) {
            CssSkinManager.saveCustomCss(this@SettingsActivity, cssInputBox.text.toString())
            Toast.makeText(this@SettingsActivity, "CSS 皮肤已生效！弹出键盘即可查看", Toast.LENGTH_SHORT).show()
        })
        skinBtnRow.addView(makeAlignedGridButton("导入 .CSS 文件", 13.5f) {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(Intent.createChooser(intent, "选择 .css 皮肤文件"), REQ_IMPORT_CSS)
        })

        // 第 3 & 4 行（6个预设皮肤分为 2行×3列 标准网格，与下方第5行3列严丝合缝对齐！）
        val presetRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val presetRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun bumpAccentSeed(forceShuffleOnPreset: Boolean = true) {
            prefs.edit()
                .putInt("random_accent_seed", (System.currentTimeMillis() xor System.nanoTime()).toInt())
                .putBoolean("force_shuffle_on_preset_keys", forceShuffleOnPreset)
                .apply()
        }
        presetRow1.addView(makeAlignedGridButton("薄荷奶黄", 13f) {
            bumpAccentSeed(true)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.DEFAULT_GRAY_CSS)
            cssInputBox.setText(CssSkinManager.DEFAULT_GRAY_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为薄荷奶黄撞色皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow1.addView(makeAlignedGridButton("莫奈花园", 13f) {
            cssInputBox.setText(CssSkinManager.MONET_WATER_LILY_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.MONET_WATER_LILY_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为莫奈花园专属皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow1.addView(makeAlignedGridButton("焦糖拿铁", 13f) {
            bumpAccentSeed(true)
            cssInputBox.setText(CssSkinManager.LATTE_MAILLARD_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.LATTE_MAILLARD_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为焦糖拿铁分排皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow2.addView(makeAlignedGridButton("薰衣草紫", 13f) {
            bumpAccentSeed(true)
            cssInputBox.setText(CssSkinManager.LAVENDER_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.LAVENDER_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为薰衣草紫藤撞色皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow2.addView(makeAlignedGridButton("樱花粉", 13f) {
            bumpAccentSeed(false)
            cssInputBox.setText(CssSkinManager.SAKURA_PINK_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.SAKURA_PINK_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为图4同款「豆沙玫瑰·夜樱初绽」樱花粉皮肤！", Toast.LENGTH_SHORT).show()
        })
        presetRow2.addView(makeAlignedGridButton("暗夜黑金", 13f) {
            bumpAccentSeed(true)
            cssInputBox.setText(CssSkinManager.DARK_MODE_CSS)
            CssSkinManager.saveCustomCss(this@SettingsActivity, CssSkinManager.DARK_MODE_CSS)
            Toast.makeText(this@SettingsActivity, "已切换为暗夜黑金月相皮肤！", Toast.LENGTH_SHORT).show()
        })

        // 第 5 行（3列等高单行对齐）：跳色：已开启 | 换跳色位置 | 字位：左上
        val accentAndLayoutRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun accentLabelText(): String {
            val on = prefs.getBoolean("random_accent_enabled", true)
            return if (on) "跳色：已开启" else "跳色：已关闭"
        }
        val toggleAccentBtn = makeAlignedGridButton(accentLabelText(), 12.5f) { btn ->
            val next = !prefs.getBoolean("random_accent_enabled", true)
            prefs.edit().putBoolean("random_accent_enabled", next).apply()
            btn.text = accentLabelText()
            Toast.makeText(this@SettingsActivity, if (next) "已开启 1~3 键和谐随机跳色！" else "已关闭随机跳色", Toast.LENGTH_SHORT).show()
        }
        val shuffleAccentBtn = makeAlignedGridButton("换跳色位置", 12.5f) {
            prefs.edit().putBoolean("random_accent_enabled", true).apply()
            bumpAccentSeed(true)
            toggleAccentBtn.text = "跳色：已开启"
            Toast.makeText(this@SettingsActivity, "已随机更换跳色按键位置！弹出键盘即可查看", Toast.LENGTH_SHORT).show()
        }
        val alignOrder = listOf("auto", "center", "top-left", "top-right", "bottom-left", "bottom-right")
        fun alignDisplayName(m: String): String = when (m) {
            "top-left" -> "左上"
            "top-right" -> "右上"
            "bottom-left" -> "左下"
            "bottom-right" -> "右下"
            "center" -> "居中"
            else -> "默认"
        }
        fun curAlignLabel(): String {
            val cur = prefs.getString("key_label_align_mode", "auto") ?: "auto"
            return "字位：${alignDisplayName(cur)}"
        }
        val toggleLayoutBtn = makeAlignedGridButton(curAlignLabel(), 12.5f) { btn ->
            val cur = prefs.getString("key_label_align_mode", "auto") ?: "auto"
            val next = alignOrder[(alignOrder.indexOf(cur).coerceAtLeast(0) + 1) % alignOrder.size]
            prefs.edit().putString("key_label_align_mode", next).apply()
            btn.text = curAlignLabel()
            Toast.makeText(this@SettingsActivity, "按键字母位置已切换为「${alignDisplayName(next)}」！", Toast.LENGTH_SHORT).show()
        }
        accentAndLayoutRow.addView(toggleAccentBtn)
        accentAndLayoutRow.addView(shuffleAccentBtn)
        accentAndLayoutRow.addView(toggleLayoutBtn)

        // 自定义皮肤收藏库：保存键（自定义起名） + 打开键（滑动点选自动填入 CSS 代码）
        var lastOpenedCustomSkinName = ""
        val savedSkinStorageRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        lateinit var openSavedSkinBtnRef: Button
        fun buildOpenSavedSkinBtnLabel(): String {
            val count = CssSkinManager.getSavedSkinList(this@SettingsActivity).size
            return if (count > 0) "📂 打开皮肤 ($count)" else "📂 打开皮肤"
        }

        val saveCustomSkinBtn = makeAlignedGridButton("💾 保存皮肤", 13.5f) {
            val currentCss = cssInputBox.text.toString().trim()
            if (currentCss.isEmpty()) {
                Toast.makeText(this@SettingsActivity, "当前 CSS 代码框为空，请先输入或粘贴皮肤代码再保存哦！", Toast.LENGTH_SHORT).show()
                return@makeAlignedGridButton
            }
            val nameInput = EditText(this@SettingsActivity).apply {
                hint = "给这款皮肤起个名字（如：蜜桃星河 / 奶黄撞色）"
                setSingleLine(true)
                if (lastOpenedCustomSkinName.isNotEmpty()) {
                    setText(lastOpenedCustomSkinName)
                    setSelection(0, lastOpenedCustomSkinName.length)
                }
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            val inputContainer = FrameLayout(this@SettingsActivity).apply {
                setPadding(dp(18), dp(8), dp(18), dp(4))
                addView(nameInput)
            }
            AlertDialog.Builder(this@SettingsActivity)
                .setTitle("💾 保存当前 CSS 皮肤")
                .setMessage("输入皮肤名称后点击保存，即可收入你的专属皮肤库（同名会自动更新）：")
                .setView(inputContainer)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存") { _, _ ->
                    val rawName = nameInput.text.toString().trim()
                    val finalName = if (rawName.isNotEmpty()) {
                        rawName
                    } else {
                        val sdf = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                        "我的皮肤 ${sdf.format(Date())}"
                    }
                    CssSkinManager.saveNamedSkin(this@SettingsActivity, finalName, currentCss)
                    lastOpenedCustomSkinName = finalName
                    openSavedSkinBtnRef.text = buildOpenSavedSkinBtnLabel()
                    Toast.makeText(this@SettingsActivity, "✅ 已保存皮肤「$finalName」！随时可点「打开皮肤」选用", Toast.LENGTH_SHORT).show()
                }
                .show()
        }

        fun showSavedSkinPickerDialog() {
            val savedList = CssSkinManager.getSavedSkinList(this@SettingsActivity)
            if (savedList.isEmpty()) {
                Toast.makeText(this@SettingsActivity, "还没有保存过皮肤哦！调好喜欢的 CSS 代码后点左边的「💾 保存皮肤」即可收藏", Toast.LENGTH_LONG).show()
                return
            }
            var dialogRef: AlertDialog? = null
            val listScroll = ScrollView(this@SettingsActivity).apply {
                setPadding(dp(14), dp(8), dp(14), dp(8))
            }
            val listCol = LinearLayout(this@SettingsActivity).apply {
                orientation = LinearLayout.VERTICAL
            }
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

            savedList.forEach { item ->
                val previewCfg = try {
                    CssSkinManager.parseCss(item.css)
                } catch (_: Exception) {
                    SkinConfig()
                }
                val itemRow = LinearLayout(this@SettingsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = CssSkinManager.makeGradientDrawable(
                        Color.parseColor("#F7F8FC"),
                        Color.parseColor("#EFF2F9"),
                        dp(10),
                        Color.parseColor("#D5DCEB"),
                        dp(1)
                    )
                    setPadding(dp(12), dp(10), dp(10), dp(10))
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.bottomMargin = dp(8)
                    layoutParams = lp
                    setOnClickListener {
                        cssInputBox.setText(item.css)
                        lastOpenedCustomSkinName = item.name
                        dialogRef?.dismiss()
                        Toast.makeText(
                            this@SettingsActivity,
                            "已填入皮肤「${item.name}」的 CSS 代码！点击「应用上方 CSS 皮肤」即可换上",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                // 3 枚配色预览小圆点（底板色、主按键色、功能键色）
                val swatchRow = LinearLayout(this@SettingsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, 0, dp(10), 0)
                }
                listOf(previewCfg.kbBgTop, previewCfg.keyBgTop, previewCfg.funcKeyBgTop).forEach { col ->
                    val dot = android.view.View(this@SettingsActivity).apply {
                        background = CssSkinManager.makeGradientDrawable(col, col, dp(8), Color.parseColor("#B0B6C4"), dp(1))
                        val dlp = LinearLayout.LayoutParams(dp(14), dp(14))
                        dlp.rightMargin = dp(4)
                        layoutParams = dlp
                    }
                    swatchRow.addView(dot)
                }
                itemRow.addView(swatchRow)

                val textCol = LinearLayout(this@SettingsActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                val nameTv = TextView(this@SettingsActivity).apply {
                    text = item.name
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#222634"))
                }
                val timeStr = if (item.updatedAt > 0L) sdf.format(Date(item.updatedAt)) else ""
                val subTvItem = TextView(this@SettingsActivity).apply {
                    text = "点击直接填入 CSS 代码" + (if (timeStr.isNotEmpty()) " · $timeStr" else "")
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    setTextColor(Color.parseColor("#667085"))
                }
                textCol.addView(nameTv)
                textCol.addView(subTvItem)
                itemRow.addView(textCol)

                val delSkinBtn = TextView(this@SettingsActivity).apply {
                    text = "🗑 删除"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setTextColor(Color.parseColor("#D94336"))
                    setPadding(dp(10), dp(6), dp(6), dp(6))
                    setOnClickListener {
                        AlertDialog.Builder(this@SettingsActivity)
                            .setTitle("确认删除皮肤？")
                            .setMessage("确定要从已存皮肤库中删除「${item.name}」吗？")
                            .setNegativeButton("取消", null)
                            .setPositiveButton("删除") { _, _ ->
                                CssSkinManager.deleteNamedSkin(this@SettingsActivity, item.name)
                                openSavedSkinBtnRef.text = buildOpenSavedSkinBtnLabel()
                                dialogRef?.dismiss()
                                Toast.makeText(this@SettingsActivity, "已删除皮肤「${item.name}」", Toast.LENGTH_SHORT).show()
                                if (CssSkinManager.getSavedSkinList(this@SettingsActivity).isNotEmpty()) {
                                    showSavedSkinPickerDialog()
                                }
                            }
                            .show()
                    }
                }
                itemRow.addView(delSkinBtn)
                listCol.addView(itemRow)
            }

            listScroll.addView(listCol)
            dialogRef = AlertDialog.Builder(this@SettingsActivity)
                .setTitle("📂 选择已保存的皮肤（点击即填入代码）")
                .setView(listScroll)
                .setNegativeButton("关闭", null)
                .create()
            dialogRef?.show()
        }

        openSavedSkinBtnRef = makeAlignedGridButton(buildOpenSavedSkinBtnLabel(), 13.5f) {
            showSavedSkinPickerDialog()
        }
        savedSkinStorageRow.addView(saveCustomSkinBtn)
        savedSkinStorageRow.addView(openSavedSkinBtnRef)

        val cssScrollNavRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        cssScrollNavRow.addView(makeAlignedGridButton("⬆️ 代码顶部", 12f) {
            cssInputBox.setSelection(0)
            cssInputBox.scrollTo(0, 0)
        })
        cssScrollNavRow.addView(makeAlignedGridButton("⬇️ 代码底部", 12f) {
            val len = cssInputBox.text?.length ?: 0
            cssInputBox.setSelection(len)
        })
        cssScrollNavRow.addView(makeAlignedGridButton("↕️ 展开长代码框", 12f) { btn ->
            isCssBoxExpanded = !isCssBoxExpanded
            if (isCssBoxExpanded) {
                cssInputBox.maxLines = 200
                btn.text = "↕️ 收起代码框(16行)"
                Toast.makeText(this@SettingsActivity, "已展开完整 CSS 代码框，可直接随页面上下滑动修改！", Toast.LENGTH_SHORT).show()
            } else {
                cssInputBox.maxLines = 16
                btn.text = "↕️ 展开长代码框"
                Toast.makeText(this@SettingsActivity, "已收起为 16 行独立内滚框（单指在框内上下划动即可滚动代码）", Toast.LENGTH_SHORT).show()
            }
            cssInputBox.requestLayout()
        })
        skinCard.addView(cssScrollNavRow)
        skinCard.addView(cssInputBox)
        skinCard.addView(savedSkinStorageRow)
        skinCard.addView(codeHelperRow)
        skinCard.addView(skinBtnRow)
        skinCard.addView(presetRow1)
        skinCard.addView(presetRow2)
        skinCard.addView(accentAndLayoutRow)
        root.addView(skinCard)

        // 6. 常用语管理（无字数限制）
        val phraseCard = makeCard("6. 常用语与分类标签管理（无字数限制）")
        val categorySpinner = Spinner(this)
        fun refreshSpinner() {
            val cats = dbHelper.getCategories().filter { it != "最近" }
            categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
            val defaultCat = intent.getStringExtra("default_category")
            if (defaultCat != null) {
                val idx = cats.indexOf(defaultCat)
                if (idx >= 0) categorySpinner.setSelection(idx)
            }
        }
        refreshSpinner()
        phraseCard.addView(categorySpinner)

        val newCatInput = EditText(this).apply {
            hint = "输入新分类名（如：咒语 / 设定 / 常用）"
        }
        val catBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addCatBtn = Button(this).apply {
            text = "＋新增分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val name = newCatInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    dbHelper.addCategory(name)
                    newCatInput.setText("")
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已添加分类：$name", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val delCatBtn = Button(this).apply {
            text = "删除选中分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val sel = categorySpinner.selectedItem?.toString() ?: return@setOnClickListener
                if (sel == "收藏" || sel == "最近") {
                    Toast.makeText(this@SettingsActivity, "基础分类不可删除", Toast.LENGTH_SHORT).show()
                } else {
                    dbHelper.deleteCategory(sel)
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已删除分类：$sel", Toast.LENGTH_SHORT).show()
                }
            }
        }
        catBtnRow.addView(addCatBtn)
        catBtnRow.addView(delCatBtn)
        phraseCard.addView(newCatInput)
        phraseCard.addView(catBtnRow)

        val phraseInput = EditText(this).apply {
            hint = "在此粘贴或输入长篇常用语（无字数上限，支持 10000+ 字）..."
            minLines = 4
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
        }
        val starCheck = CheckBox(this).apply {
            text = "同时加入「收藏」星标置顶"
            isChecked = true
        }
        val savePhraseBtn = Button(this).apply {
            text = "保存常用语到选中分类"
            setOnClickListener {
                val cat = categorySpinner.selectedItem?.toString() ?: "演"
                val content = phraseInput.text.toString()
                if (content.isNotBlank()) {
                    dbHelper.addOrUpdatePhrase(null, cat, content, starCheck.isChecked)
                    phraseInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已保存至「$cat」（共 ${content.length} 字）", Toast.LENGTH_SHORT).show()
                }
            }
        }
        phraseCard.addView(phraseInput)
        phraseCard.addView(starCheck)
        phraseCard.addView(savePhraseBtn)
        root.addView(phraseCard)

        // 7. 词库扩展、自动组词与五笔编码诊断管理 (.scel / .txt)
        val dictCard = makeCard("7. 词库扩展、自动组词与五笔编码诊断管理（O(1) 独立哈希索引）")
        val dictPerfNote = TextView(this).apply {
            text = "💡 智能词频与防误触说明：\n1) 同编码下按「输入编码 + 候选词」独立累计选择次数，误选 1 次绝不永久翻转首选，且下次正常选词时误选记录会自动衰减清零；\n2) 开启下方「高频自动组词」后，词库未收录的新词（如连打「吐」「槽」）高频输入满 5 次即自动合成 86 五笔码收录入库！"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#4B5563"))
            setPadding(0, 0, 0, dp(8))
        }
        dictCard.addView(dictPerfNote)

        // 7.1 自动组词开关与次数阈值设置
        val autoPhraseSwitch = Switch(this).apply {
            val curTh = prefs.getInt("auto_phrase_threshold", 5)
            text = "✨ 开启高频连续单字输入自动组词（默认连打满 $curTh 次自动收录进词库）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(Color.parseColor("#2A3042"))
            isChecked = prefs.getBoolean("auto_phrase_learn_enabled", true)
            setPadding(dp(4), dp(4), dp(4), dp(6))
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean("auto_phrase_learn_enabled", isChecked).apply()
                Toast.makeText(
                    this@SettingsActivity,
                    if (isChecked) "已开启高频自动组词" else "已关闭高频自动组词",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        dictCard.addView(autoPhraseSwitch)

        val thresholdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        listOf(3 to "满3次收录", 5 to "满5次收录(推荐)", 8 to "满8次收录").forEach { (thVal, thLabel) ->
            val btn = Button(this).apply {
                text = thLabel
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    prefs.edit().putInt("auto_phrase_threshold", thVal).putBoolean("auto_phrase_learn_enabled", true).apply()
                    autoPhraseSwitch.isChecked = true
                    autoPhraseSwitch.text = "✨ 开启高频连续单字输入自动组词（当前连打满 $thVal 次自动收录进词库）"
                    Toast.makeText(this@SettingsActivity, "已设置连续输入满 $thVal 次自动组词收录！", Toast.LENGTH_SHORT).show()
                }
            }
            thresholdRow.addView(btn)
        }
        dictCard.addView(thresholdRow)

        // 7.2 词条新增与五笔编码全链路诊断器
        val wordInput = EditText(this).apply {
            hint = "输入要添加或诊断查询的词（如：吐槽 / 薅羊毛 / 显眼包）"
        }
        val codeInput = EditText(this).apply {
            hint = "86五笔编码（留空即可！系统自动按 2+2 / 1+1+2 / 1+1+1+末1 规则合成）"
        }

        val diagResultTv = TextView(this).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#1E3A8A"))
            setBackgroundColor(Color.parseColor("#F0F4FF"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = android.view.View.GONE
        }

        val wordActionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val diagnoseWordBtn = Button(this).apply {
            text = "🔍 诊断查询词条"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val w = wordInput.text.toString().trim()
                if (w.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请先在上方输入框输入要诊断的字或词（如：或许 / 括号）", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                diagResultTv.visibility = android.view.View.VISIBLE
                diagResultTv.text = T14WubiEngine.diagnoseWordInEngine(this@SettingsActivity, dbHelper, w)
            }
        }
        val pinWordTopBtn = Button(this).apply {
            text = "📌 一键置顶为第1首选"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f)
            setOnClickListener {
                val w = wordInput.text.toString().trim()
                if (w.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请先输入要置顶为第1首选的字或词（如：或许 / 括号）", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val customCode = codeInput.text.toString().trim()
                val msg = T14WubiEngine.pinWordToTopForCode(w, customCode, dbHelper)
                diagResultTv.visibility = android.view.View.VISIBLE
                diagResultTv.text = msg + "\n\n" + T14WubiEngine.diagnoseWordInEngine(this@SettingsActivity, dbHelper, w)
                refreshImportedDictListUI()
                Toast.makeText(this@SettingsActivity, msg, Toast.LENGTH_SHORT).show()
            }
        }
        val addWordBtn = Button(this).apply {
            text = "＋添加词库"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.85f)
            setOnClickListener {
                val w = wordInput.text.toString().trim()
                if (w.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请先输入要添加的词条", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                var wcode = codeInput.text.toString().trim().lowercase()
                if (wcode.isEmpty()) {
                    wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                }
                val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                if (wcode.isEmpty() && py.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请填写该词的五笔编码", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                dbHelper.insertUserWord(w, wcode, py, 9600, "手动添加")
                T14WubiEngine.reloadUserDict(dbHelper)
                diagResultTv.visibility = android.view.View.VISIBLE
                diagResultTv.text = T14WubiEngine.diagnoseWordInEngine(this@SettingsActivity, dbHelper, w)
                wordInput.setText("")
                codeInput.setText("")
                refreshImportedDictListUI()
                Toast.makeText(this@SettingsActivity, "✅ 已收录词组「$w」(五笔码: $wcode)", Toast.LENGTH_SHORT).show()
            }
        }
        wordActionRow.addView(diagnoseWordBtn)
        wordActionRow.addView(pinWordTopBtn)
        wordActionRow.addView(addWordBtn)

        val recentKeystrokeTv = TextView(this).apply {
            text = T14WubiEngine.getRecentTypingDiagReport()
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.parseColor("#2A3042"))
            setBackgroundColor(Color.parseColor("#F7F8FC"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val refreshKeystrokeBtn = Button(this).apply {
            text = "🔄 刷新最近 15 次五笔按键与候选记录（排查拆字习惯神器）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setOnClickListener {
                recentKeystrokeTv.text = T14WubiEngine.getRecentTypingDiagReport()
                Toast.makeText(this@SettingsActivity, "已刷新最近五笔按键记录！", Toast.LENGTH_SHORT).show()
            }
        }

        val importScelBtn = Button(this).apply {
            text = "📂 选择手机中的 .scel (搜狗细胞词库) 或 .txt 词表批量导入"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(intent, "选择 .scel 或 .txt 词库文件"), REQ_IMPORT_DICT)
            }
        }

        importDictStatusTv = TextView(this).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#D94336"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
            visibility = android.view.View.GONE
        }

        val personalHeader = TextView(this).apply {
            text = "✨ 我的个人词条明细（手动添加 & 自动组词，可单独删除）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(10), 0, dp(4))
        }
        personalWordsListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val packListHeader = TextView(this).apply {
            text = "📚 已挂载的词库来源汇总（内置词库、导入词库与个人词库物理分离）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#2A3042"))
            setPadding(0, dp(12), 0, dp(6))
        }

        importedDictListContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        dictCard.addView(wordInput)
        dictCard.addView(codeInput)
        dictCard.addView(wordActionRow)
        dictCard.addView(diagResultTv)
        dictCard.addView(refreshKeystrokeBtn)
        dictCard.addView(recentKeystrokeTv)
        dictCard.addView(importScelBtn)
        dictCard.addView(importDictStatusTv)
        dictCard.addView(personalHeader)
        dictCard.addView(personalWordsListContainer)
        dictCard.addView(packListHeader)
        dictCard.addView(importedDictListContainer)
        root.addView(dictCard)
        refreshImportedDictListUI()

        scroll.addView(root)
        setContentView(scroll)
        when (intent.getStringExtra("open_tab")) {
            "voice_permission" -> requestVoiceRecordPermission()
            "system_voice_popup" -> launchSystemVoicePopupActivity()
            "voice_engine_settings" -> scroll.post { scroll.smoothScrollTo(0, voiceEngineCard.top) }
            "enter_text" -> enterTextInput.requestFocus()
            "top_icon_settings" -> scroll.post { scroll.smoothScrollTo(0, topIconCard.top) }
            "skin_settings" -> scroll.post { scroll.smoothScrollTo(0, skinCard.top) }
            "dict_diag" -> scroll.post {
                recentKeystrokeTv.text = T14WubiEngine.getRecentTypingDiagReport()
                scroll.smoothScrollTo(0, dictCard.top)
                wordInput.requestFocus()
            }
            "phrases", "dedicated_phrase_clip_editor" -> {
                val subMode = intent.getStringExtra("editor_sub_mode") ?: "phrases"
                val defCat = intent.getStringExtra("default_category") ?: "收藏"
                val editPId = intent.getLongExtra("edit_phrase_id", -1L)
                val editCId = intent.getLongExtra("edit_clip_id", -1L)
                showDedicatedPhraseClipboardEditorPage(subMode, defCat, editPId, editCId)
            }
        }
    }

    /**
     * 独立全屏「剪贴板与收藏分类专门编辑页」（专为整理分类目录、修改长文、提取网址及从百度输入法批量搬家打造！）
     */
    private fun showDedicatedPhraseClipboardEditorPage(
        initialSubMode: String = "phrases",
        initialCategory: String = "收藏",
        editPhraseId: Long = -1L,
        editClipId: Long = -1L
    ) {
        var currentSubMode = initialSubMode // "phrases" | "clips" | "migrate"
        var selectedCategory = initialCategory.ifEmpty { "收藏" }
        var editingPhraseId: Long? = if (editPhraseId > 0L) editPhraseId else null
        var editingClipId: Long? = if (editClipId > 0L) editClipId else null
        val selectedClipIdsForBatch = HashSet<Long>()

        if (editingPhraseId != null) {
            dbHelper.getPhraseById(editingPhraseId!!)?.let { p ->
                selectedCategory = p.category
            }
        }

        val pageScroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F4F5F9"))
        }
        val pageRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(28))
        }

        fun rebuildPage() {
            pageRoot.removeAllViews()

            // 1. 顶部导航栏
            val topNav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 0, 0, dp(10))
            }
            val backToMainBtn = Button(this).apply {
                text = "‹ 返回设置首页"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setOnClickListener {
                    intent.removeExtra("open_tab")
                    recreate()
                }
            }
            val pageTitleTv = TextView(this).apply {
                text = "剪贴板与收藏专门编辑页"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#222634"))
                setPadding(dp(10), 0, 0, 0)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            topNav.addView(backToMainBtn)
            topNav.addView(pageTitleTv)
            pageRoot.addView(topNav)

            // 2. 三大工作模式切换栏
            val modeRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(10)
                layoutParams = lp
            }
            listOf(
                "phrases" to "⭐ 收藏与分类目录",
                "clips" to "📋 剪贴板与提网址",
                "migrate" to "🚀 百度收藏极速搬家"
            ).forEach { (mKey, mTitle) ->
                val active = (currentSubMode == mKey)
                val tabBtn = TextView(this).apply {
                    text = mTitle
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    setTextColor(if (active) Color.WHITE else Color.parseColor("#333A4D"))
                    gravity = Gravity.CENTER
                    background = CssSkinManager.makeGradientDrawable(
                        if (active) Color.parseColor("#3B5998") else Color.WHITE,
                        if (active) Color.parseColor("#2B4275") else Color.parseColor("#ECEFF5"),
                        dp(10),
                        Color.parseColor(if (active) "#3B5998" else "#D5DAE5"),
                        dp(1)
                    )
                    setPadding(dp(8), dp(9), dp(8), dp(9))
                    val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    lp.setMargins(dp(3), 0, dp(3), 0)
                    layoutParams = lp
                    setOnClickListener {
                        currentSubMode = mKey
                        editingPhraseId = null
                        editingClipId = null
                        rebuildPage()
                    }
                }
                modeRow.addView(tabBtn)
            }
            pageRoot.addView(modeRow)

            // ==================== 模式 A：⭐ 收藏与分类目录管理 ====================
            if (currentSubMode == "phrases") {
                val catCard = makeCard("📁 第一步：选择或管理你的分类目录（支持将收藏文字自由归类到任意目录）")
                val catScroll = HorizontalScrollView(this).apply {
                    isHorizontalScrollBarEnabled = false
                }
                val catChipRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(4), 0, dp(8))
                }
                val allCats = listOf("全部") + dbHelper.getCategories()
                if (!allCats.contains(selectedCategory)) selectedCategory = "收藏"

                allCats.forEach { catName ->
                    val active = (catName == selectedCategory)
                    val chip = TextView(this).apply {
                        text = catName
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        setTextColor(if (active) Color.WHITE else Color.parseColor("#2C3446"))
                        background = CssSkinManager.makeGradientDrawable(
                            if (active) Color.parseColor("#4A6FE3") else Color.parseColor("#EEF1F7"),
                            if (active) Color.parseColor("#3858C8") else Color.parseColor("#E4E8F2"),
                            dp(16),
                            Color.parseColor(if (active) "#4A6FE3" else "#D0D7E6"),
                            dp(1)
                        )
                        setPadding(dp(14), dp(6), dp(14), dp(6))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.rightMargin = dp(8)
                        layoutParams = lp
                        setOnClickListener {
                            selectedCategory = catName
                            rebuildPage()
                        }
                    }
                    catChipRow.addView(chip)
                }
                catScroll.addView(catChipRow)
                catCard.addView(catScroll)

                val catManageRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                }
                catManageRow.addView(Button(this).apply {
                    text = "＋新建目录"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener {
                        val input = EditText(this@SettingsActivity).apply {
                            hint = "输入新目录名（如：演 / 扮 / 模块 / 咒语 / 地址）"
                        }
                        AlertDialog.Builder(this@SettingsActivity)
                            .setTitle("新建分类目录")
                            .setView(input)
                            .setNegativeButton("取消", null)
                            .setPositiveButton("创建") { _, _ ->
                                val name = input.text.toString().trim()
                                if (name.isNotEmpty()) {
                                    dbHelper.addCategory(name)
                                    selectedCategory = name
                                    Toast.makeText(this@SettingsActivity, "已创建目录「$name」！", Toast.LENGTH_SHORT).show()
                                    rebuildPage()
                                }
                            }
                            .show()
                    }
                })
                if (selectedCategory !in listOf("全部", "收藏", "最近")) {
                    catManageRow.addView(Button(this).apply {
                        text = "✎ 重命名「$selectedCategory」"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        setOnClickListener {
                            val input = EditText(this@SettingsActivity).apply {
                                setText(selectedCategory)
                            }
                            AlertDialog.Builder(this@SettingsActivity)
                                .setTitle("重命名目录「$selectedCategory」")
                                .setView(input)
                                .setNegativeButton("取消", null)
                                .setPositiveButton("保存") { _, _ ->
                                    val newName = input.text.toString().trim()
                                    if (dbHelper.renameCategory(selectedCategory, newName)) {
                                        selectedCategory = newName
                                        Toast.makeText(this@SettingsActivity, "已重命名为「$newName」！", Toast.LENGTH_SHORT).show()
                                        rebuildPage()
                                    }
                                }
                                .show()
                        }
                    })
                    catManageRow.addView(Button(this).apply {
                        text = "🗑 删除目录"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setTextColor(Color.parseColor("#D94336"))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.8f)
                        setOnClickListener {
                            AlertDialog.Builder(this@SettingsActivity)
                                .setTitle("确认删除目录「$selectedCategory」？")
                                .setMessage("删除该目录将同时移除该目录下的常用语，确定删除吗？")
                                .setNegativeButton("取消", null)
                                .setPositiveButton("确定删除") { _, _ ->
                                    dbHelper.deleteCategory(selectedCategory)
                                    selectedCategory = "收藏"
                                    rebuildPage()
                                }
                                .show()
                        }
                    })
                }
                catCard.addView(catManageRow)
                pageRoot.addView(catCard)

                // 编辑或新增卡片
                val editingItem = editingPhraseId?.let { dbHelper.getPhraseById(it) }
                val editorCard = makeCard(
                    if (editingItem != null) "✎ 正在编辑收藏内容（可修改文字或直接点选下方目录切换归类）"
                    else "➕ 新增收藏 / 常用语（无字数限制，支持万字长设定）"
                )
                val assignableCats = dbHelper.getAssignableCategories()
                var targetSaveCat = editingItem?.category
                    ?: if (selectedCategory in assignableCats) selectedCategory else "收藏"

                val targetCatLabel = TextView(this).apply {
                    text = "归属目录：当前将存入「$targetSaveCat」（点击下方标签可切换目录）："
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    typeface = Typeface.DEFAULT_BOLD
                    setTextColor(Color.parseColor("#2B4275"))
                    setPadding(0, 0, 0, dp(4))
                }
                editorCard.addView(targetCatLabel)

                val targetCatScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val targetCatRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(2), 0, dp(6))
                }
                val targetChipViews = ArrayList<Pair<String, TextView>>()
                fun refreshTargetChipStyles() {
                    targetCatLabel.text = "归属目录：当前将存入「$targetSaveCat」（点击下方标签可切换目录）："
                    for ((cName, tv) in targetChipViews) {
                        val on = (cName == targetSaveCat)
                        tv.text = if (on) "✓ $cName" else cName
                        tv.setTextColor(if (on) Color.WHITE else Color.parseColor("#333A4D"))
                        tv.background = CssSkinManager.makeGradientDrawable(
                            if (on) Color.parseColor("#3B5998") else Color.parseColor("#EEF1F7"),
                            if (on) Color.parseColor("#2B4275") else Color.parseColor("#E4E8F2"),
                            dp(12),
                            Color.parseColor(if (on) "#3B5998" else "#D0D7E6"),
                            dp(1)
                        )
                    }
                }
                assignableCats.forEach { cName ->
                    val tv = TextView(this).apply {
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                        setPadding(dp(12), dp(5), dp(12), dp(5))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.rightMargin = dp(6)
                        layoutParams = lp
                        setOnClickListener {
                            targetSaveCat = cName
                            refreshTargetChipStyles()
                        }
                    }
                    targetChipViews.add(cName to tv)
                    targetCatRow.addView(tv)
                }
                refreshTargetChipStyles()
                targetCatScroll.addView(targetCatRow)
                editorCard.addView(targetCatScroll)

                val contentEdit = EditText(this).apply {
                    hint = "在此输入或粘贴收藏内容（支持像《曼谷之夜》那样的长篇设定，不限字数）..."
                    setText(editingItem?.content ?: "")
                    minLines = 4
                    maxLines = 12
                    gravity = Gravity.TOP or Gravity.START
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                }
                val starCheckBox = CheckBox(this).apply {
                    text = "同时点亮 ★ 星标（使其在「收藏」标签下也置顶显示）"
                    isChecked = editingItem?.isStarred ?: true
                }
                val editorBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                editorBtnRow.addView(Button(this).apply {
                    text = if (editingItem != null) "💾 保存修改并归入该目录" else "➕ 存入所选目录"
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    setOnClickListener {
                        val txt = contentEdit.text.toString()
                        if (txt.isNotBlank()) {
                            dbHelper.addOrUpdatePhrase(editingItem?.id, targetSaveCat, txt, starCheckBox.isChecked)
                            Toast.makeText(this@SettingsActivity, "已保存至「$targetSaveCat」目录！", Toast.LENGTH_SHORT).show()
                            editingPhraseId = null
                            selectedCategory = targetSaveCat
                            rebuildPage()
                        }
                    }
                })
                if (editingItem != null) {
                    editorBtnRow.addView(Button(this).apply {
                        text = "取消编辑"
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.55f)
                        setOnClickListener {
                            editingPhraseId = null
                            rebuildPage()
                        }
                    })
                }
                editorCard.addView(contentEdit)
                editorCard.addView(starCheckBox)
                editorCard.addView(editorBtnRow)
                pageRoot.addView(editorCard)

                // 当前目录下的所有条目列表
                val listPhrases = dbHelper.getPhrasesByCategory(selectedCategory)
                val listCard = makeCard("📚 当前「$selectedCategory」目录内容（共 ${listPhrases.size} 条 · 点击「📁 换目录」可随时移动分类）")
                if (listPhrases.isEmpty()) {
                    val emptyTv = TextView(this).apply {
                        text = "当前「$selectedCategory」目录下暂无条目。\n您可以在上方直接粘贴新增，或者切到「收藏 / 全部」点击任意条目的【📁 换目录】把它归类到这里！"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        setTextColor(Color.parseColor("#777777"))
                        setPadding(dp(8), dp(16), dp(8), dp(16))
                    }
                    listCard.addView(emptyTv)
                } else {
                    listPhrases.forEach { item ->
                        val itemBox = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            background = CssSkinManager.makeGradientDrawable(
                                Color.parseColor("#F8F9FC"),
                                Color.parseColor("#F2F4F8"),
                                dp(10),
                                Color.parseColor("#DDE2EE"),
                                dp(1)
                            )
                            setPadding(dp(10), dp(8), dp(10), dp(8))
                            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                            lp.bottomMargin = dp(8)
                            layoutParams = lp
                        }
                        val metaRow = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                        }
                        val badgeTv = TextView(this).apply {
                            text = "${if (item.isStarred) "★ " else ""}📁 所属目录：【${item.category}】 · 共 ${item.content.length} 字"
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            typeface = Typeface.DEFAULT_BOLD
                            setTextColor(Color.parseColor("#3B5998"))
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        }
                        metaRow.addView(badgeTv)
                        itemBox.addView(metaRow)

                        val bodyTv = TextView(this).apply {
                            text = if (item.content.length > 260) item.content.substring(0, 260) + "…" else item.content
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                            setTextColor(Color.parseColor("#222634"))
                            maxLines = 4
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setPadding(0, dp(4), 0, dp(6))
                            setOnClickListener {
                                editingPhraseId = item.id
                                selectedCategory = item.category
                                rebuildPage()
                                pageScroll.post { pageScroll.smoothScrollTo(0, 0) }
                            }
                        }
                        itemBox.addView(bodyTv)

                        val urls = ImeDatabaseHelper.extractUrls(item.content)
                        if (urls.isNotEmpty()) {
                            urls.forEach { u ->
                                val urlBtn = TextView(this).apply {
                                    text = "🔗 提取到网址（点击复制纯网址）：$u"
                                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                                    setTextColor(Color.parseColor("#1D4ED8"))
                                    setPadding(dp(6), dp(4), dp(6), dp(4))
                                    setOnClickListener {
                                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                        cm.setPrimaryClip(android.content.ClipData.newPlainText("url", u))
                                        Toast.makeText(this@SettingsActivity, "已复制纯网址：$u", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                itemBox.addView(urlBtn)
                            }
                        }

                        val opRow = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                        }
                        opRow.addView(Button(this).apply {
                            text = "✎ 编辑文字"
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            setOnClickListener {
                                editingPhraseId = item.id
                                rebuildPage()
                                pageScroll.post { pageScroll.smoothScrollTo(0, 0) }
                            }
                        })
                        opRow.addView(Button(this).apply {
                            text = "📁 换目录(${item.category})"
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f)
                            setOnClickListener {
                                val cats = dbHelper.getAssignableCategories().toTypedArray()
                                AlertDialog.Builder(this@SettingsActivity)
                                    .setTitle("将该条文字归类到哪个目录？")
                                    .setItems(cats) { _, which ->
                                        val chosen = cats[which]
                                        dbHelper.movePhraseToCategory(item.id, chosen)
                                        Toast.makeText(this@SettingsActivity, "已成功归类到「$chosen」目录！", Toast.LENGTH_SHORT).show()
                                        rebuildPage()
                                    }
                                    .setNeutralButton("＋新建目录并移入") { _, _ ->
                                        val inp = EditText(this@SettingsActivity).apply { hint = "输入新目录名称" }
                                        AlertDialog.Builder(this@SettingsActivity)
                                            .setTitle("新建目录并移入此条文字")
                                            .setView(inp)
                                            .setNegativeButton("取消", null)
                                            .setPositiveButton("确定移入") { _, _ ->
                                                val newCat = inp.text.toString().trim()
                                                if (newCat.isNotEmpty()) {
                                                    dbHelper.movePhraseToCategory(item.id, newCat)
                                                    selectedCategory = newCat
                                                    Toast.makeText(this@SettingsActivity, "已创建并归类到「$newCat」！", Toast.LENGTH_SHORT).show()
                                                    rebuildPage()
                                                }
                                            }
                                            .show()
                                    }
                                    .setNegativeButton("取消", null)
                                    .show()
                            }
                        })
                        opRow.addView(Button(this).apply {
                            text = "🗑 删除"
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                            setTextColor(Color.parseColor("#D94336"))
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.75f)
                            setOnClickListener {
                                AlertDialog.Builder(this@SettingsActivity)
                                    .setTitle("确认删除该条常用语？")
                                    .setMessage("删除后不可恢复，确定删除吗？")
                                    .setNegativeButton("取消", null)
                                    .setPositiveButton("确定删除") { _, _ ->
                                        dbHelper.deletePhrase(item.id)
                                        rebuildPage()
                                    }
                                    .show()
                            }
                        })
                        itemBox.addView(opRow)
                        listCard.addView(itemBox)
                    }
                }
                pageRoot.addView(listCard)
            }

            // ==================== 模式 B：📋 剪贴板管理与提取网址/批量归类 ====================
            else if (currentSubMode == "clips") {
                val clips = dbHelper.getClips()
                if (editingClipId != null) {
                    val editingClip = dbHelper.getClipById(editingClipId!!)
                    if (editingClip != null) {
                        val editClipCard = makeCard("✎ 正在编辑剪贴板内容")
                        val clipEditBox = EditText(this).apply {
                            setText(editingClip.content)
                            minLines = 4
                            maxLines = 12
                            gravity = Gravity.TOP or Gravity.START
                        }
                        val editClipBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                        editClipBtnRow.addView(Button(this).apply {
                            text = "💾 保存剪贴板修改"
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            setOnClickListener {
                                val newTxt = clipEditBox.text.toString()
                                if (newTxt.isNotBlank()) {
                                    dbHelper.updateClipContent(editingClip.id, newTxt)
                                    editingClipId = null
                                    Toast.makeText(this@SettingsActivity, "已更新该条剪贴板内容！", Toast.LENGTH_SHORT).show()
                                    rebuildPage()
                                }
                            }
                        })
                        editClipBtnRow.addView(Button(this).apply {
                            text = "取消"
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f)
                            setOnClickListener {
                                editingClipId = null
                                rebuildPage()
                            }
                        })
                        editClipCard.addView(clipEditBox)
                        editClipCard.addView(editClipBtnRow)
                        pageRoot.addView(editClipCard)
                    }
                }

                val batchCard = makeCard("📋 剪贴板列表（共 ${clips.size}/300 条 · 支持勾选批量转存到指定收藏目录！）")
                val batchBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                batchBtnRow.addView(Button(this).apply {
                    text = if (selectedClipIdsForBatch.size == clips.size && clips.isNotEmpty()) "取消全选" else "☑️ 全选本页"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.8f)
                    setOnClickListener {
                        if (selectedClipIdsForBatch.size == clips.size) {
                            selectedClipIdsForBatch.clear()
                        } else {
                            clips.forEach { selectedClipIdsForBatch.add(it.id) }
                        }
                        rebuildPage()
                    }
                })
                batchBtnRow.addView(Button(this).apply {
                    text = "📁 将已勾选(${selectedClipIdsForBatch.size}条)批量归类到目录..."
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f)
                    setOnClickListener {
                        if (selectedClipIdsForBatch.isEmpty()) {
                            Toast.makeText(this@SettingsActivity, "请先在下方勾选要归类的剪贴板条目", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }
                        val cats = dbHelper.getAssignableCategories().toTypedArray()
                        AlertDialog.Builder(this@SettingsActivity)
                            .setTitle("将勾选的 ${selectedClipIdsForBatch.size} 条内容归入哪个目录？")
                            .setItems(cats) { _, which ->
                                val targetCat = cats[which]
                                var count = 0
                                clips.filter { it.id in selectedClipIdsForBatch }.forEach { c ->
                                    dbHelper.addOrUpdatePhrase(null, targetCat, c.content, true)
                                    count++
                                }
                                selectedClipIdsForBatch.clear()
                                Toast.makeText(this@SettingsActivity, "✅ 已将 $count 条内容批量归入「$targetCat」目录！", Toast.LENGTH_LONG).show()
                                selectedCategory = targetCat
                                currentSubMode = "phrases"
                                rebuildPage()
                            }
                            .setNegativeButton("取消", null)
                            .show()
                    }
                })
                batchCard.addView(batchBtnRow)

                clips.forEach { clip ->
                    val clipBox = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        background = CssSkinManager.makeGradientDrawable(
                            Color.parseColor("#F8F9FC"),
                            Color.parseColor("#F2F4F8"),
                            dp(10),
                            Color.parseColor("#DDE2EE"),
                            dp(1)
                        )
                        setPadding(dp(10), dp(8), dp(10), dp(8))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.topMargin = dp(8)
                        layoutParams = lp
                    }
                    val topLine = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                    }
                    val cb = CheckBox(this).apply {
                        isChecked = clip.id in selectedClipIdsForBatch
                        text = if (clip.isPinned) "📌 已置顶" else "勾选归类"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setOnCheckedChangeListener { _, isChecked ->
                            if (isChecked) selectedClipIdsForBatch.add(clip.id) else selectedClipIdsForBatch.remove(clip.id)
                        }
                    }
                    topLine.addView(cb)
                    clipBox.addView(topLine)

                    val txtTv = TextView(this).apply {
                        text = if (clip.content.length > 260) clip.content.substring(0, 260) + "…" else clip.content
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        setTextColor(Color.parseColor("#222634"))
                        maxLines = 4
                        ellipsize = android.text.TextUtils.TruncateAt.END
                        setPadding(0, dp(4), 0, dp(6))
                        setOnClickListener {
                            editingClipId = clip.id
                            rebuildPage()
                            pageScroll.post { pageScroll.smoothScrollTo(0, 0) }
                        }
                    }
                    clipBox.addView(txtTv)

                    val urls = ImeDatabaseHelper.extractUrls(clip.content)
                    if (urls.isNotEmpty()) {
                        urls.forEach { u ->
                            val uBtn = TextView(this).apply {
                                text = "🔗 提取纯网址（点击直接复制该网址）：$u"
                                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                                typeface = Typeface.DEFAULT_BOLD
                                setTextColor(Color.parseColor("#1D4ED8"))
                                background = CssSkinManager.makeGradientDrawable(
                                    Color.parseColor("#E8F0FE"),
                                    Color.parseColor("#DCE7FC"),
                                    dp(6),
                                    Color.parseColor("#B6C9F8"),
                                    dp(1)
                                )
                                setPadding(dp(8), dp(5), dp(8), dp(5))
                                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                                lp.bottomMargin = dp(6)
                                layoutParams = lp
                                setOnClickListener {
                                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", u))
                                    dbHelper.addClip(u)
                                    Toast.makeText(this@SettingsActivity, "已提取纯网址并置顶到剪贴板：$u", Toast.LENGTH_SHORT).show()
                                    rebuildPage()
                                }
                            }
                            clipBox.addView(uBtn)
                        }
                    }

                    val actRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    actRow.addView(Button(this).apply {
                        text = "☆ 收藏到目录"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.15f)
                        setOnClickListener {
                            val cats = dbHelper.getAssignableCategories().toTypedArray()
                            AlertDialog.Builder(this@SettingsActivity)
                                .setTitle("将该条剪贴板存入哪个目录？")
                                .setItems(cats) { _, which ->
                                    val chosen = cats[which]
                                    dbHelper.addOrUpdatePhrase(null, chosen, clip.content, true)
                                    Toast.makeText(this@SettingsActivity, "已存入「$chosen」目录！", Toast.LENGTH_SHORT).show()
                                }
                                .setNegativeButton("取消", null)
                                .show()
                        }
                    })
                    actRow.addView(Button(this).apply {
                        text = "✎ 编辑"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.85f)
                        setOnClickListener {
                            editingClipId = clip.id
                            rebuildPage()
                            pageScroll.post { pageScroll.smoothScrollTo(0, 0) }
                        }
                    })
                    actRow.addView(Button(this).apply {
                        text = "🗑 删除"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setTextColor(Color.parseColor("#D94336"))
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.75f)
                        setOnClickListener {
                            dbHelper.deleteClip(clip.id)
                            rebuildPage()
                        }
                    })
                    clipBox.addView(actRow)
                    batchCard.addView(clipBox)
                }
                pageRoot.addView(batchCard)
            }

            // ==================== 模式 C：🚀 百度收藏极速连续搬家模式 ====================
            else {
                val migrateCard = makeCard("🚀 百度输入法收藏「极速连续搬家台」")
                val tipTv = TextView(this).apply {
                    text = "💡 极速搬家方法：\n1. 先在下方点选你要搬入的目录（如：演 / 扮 / 模块 / api）；\n2. 点击下方大输入框，用百度输入法点一下你要搬过来的常用语卡片，再点【⚡ 存入并清空继续下一条】——输入框会自动清空并保持焦点，无需关键盘，一分钟即可搬完几十条！"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTextColor(Color.parseColor("#334155"))
                    setPadding(0, 0, 0, dp(10))
                }
                migrateCard.addView(tipTv)

                val assignable = dbHelper.getAssignableCategories()
                if (selectedCategory !in assignable) selectedCategory = assignable.firstOrNull() ?: "演"

                val dirScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
                val dirRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(0, dp(4), 0, dp(8))
                }
                assignable.forEach { cName ->
                    val on = (cName == selectedCategory)
                    val chip = TextView(this).apply {
                        text = if (on) "📁 目标目录：$cName ✓" else cName
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                        typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        setTextColor(if (on) Color.WHITE else Color.parseColor("#2C3446"))
                        background = CssSkinManager.makeGradientDrawable(
                            if (on) Color.parseColor("#3B5998") else Color.parseColor("#EEF1F7"),
                            if (on) Color.parseColor("#2B4275") else Color.parseColor("#E4E8F2"),
                            dp(14),
                            Color.parseColor(if (on) "#3B5998" else "#D0D7E6"),
                            dp(1)
                        )
                        setPadding(dp(14), dp(6), dp(14), dp(6))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.rightMargin = dp(8)
                        layoutParams = lp
                        setOnClickListener {
                            selectedCategory = cName
                            rebuildPage()
                        }
                    }
                    dirRow.addView(chip)
                }
                dirScroll.addView(dirRow)
                migrateCard.addView(dirScroll)

                val fastInput = EditText(this).apply {
                    hint = "点此呼出键盘 -> 点击百度收藏上屏 -> 点击下方「⚡ 存入并继续下一条」..."
                    minLines = 5
                    maxLines = 12
                    gravity = Gravity.TOP or Gravity.START
                }
                val countStatusTv = TextView(this).apply {
                    text = "当前「$selectedCategory」目录已有 ${dbHelper.getPhrasesByCategory(selectedCategory).size} 条内容"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    setTextColor(Color.parseColor("#3B5998"))
                    setPadding(0, dp(4), 0, dp(4))
                }
                val fastSaveBtn = Button(this).apply {
                    text = "⚡ 存入「$selectedCategory」目录并自动清空（继续粘下一条）"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    typeface = Typeface.DEFAULT_BOLD
                    setOnClickListener {
                        val txt = fastInput.text.toString()
                        if (txt.isNotBlank()) {
                            dbHelper.addOrUpdatePhrase(null, selectedCategory, txt, true)
                            fastInput.setText("")
                            fastInput.requestFocus()
                            val newCount = dbHelper.getPhrasesByCategory(selectedCategory).size
                            countStatusTv.text = "✅ 已存入！当前「$selectedCategory」目录已有 $newCount 条内容，请继续粘贴下一条"
                            Toast.makeText(this@SettingsActivity, "已存入「$selectedCategory」！请继续下一条", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                migrateCard.addView(fastInput)
                migrateCard.addView(countStatusTv)
                migrateCard.addView(fastSaveBtn)
                pageRoot.addView(migrateCard)
            }
        }

        rebuildPage()
        pageScroll.addView(pageRoot)
        setContentView(pageScroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SYSTEM_VOICE_POPUP) {
            if (resultCode == Activity.RESULT_OK && data != null) {
                val results = data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
                val best = results?.firstOrNull()?.trim() ?: ""
                if (best.isNotEmpty()) {
                    val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putString("pending_system_voice_text", best).apply()
                    try {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("voice", best))
                        dbHelper.addClip(best)
                    } catch (_: Exception) {}
                    Toast.makeText(this, "🎙️ 已识别并自动上屏：$best", Toast.LENGTH_SHORT).show()
                }
            }
            finish()
            return
        }
        if (resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return

        when (requestCode) {
            REQ_EXPORT_BACKUP -> {
                Thread {
                    try {
                        val json = dbHelper.exportBackupJson()
                        contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray(Charsets.UTF_8))
                        }
                        runOnUiThread {
                            Toast.makeText(this, "✅ 导出备份成功！", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_BACKUP -> {
                Thread {
                    try {
                        val json = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                        val (pCount, cCount) = dbHelper.importBackupJson(json)
                        runOnUiThread {
                            Toast.makeText(this, "✅ 成功导入 $pCount 条常用语与 $cCount 条剪贴板记录！", Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导入失败：文件格式不正确", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_CSS -> {
                try {
                    val css = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText() ?: ""
                    if (css.isNotBlank()) {
                        cssInputBox.setText(css)
                        CssSkinManager.saveCustomCss(this, css)
                        Toast.makeText(this, "已成功导入并应用 .css 皮肤文件！", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "读取 CSS 文件失败", Toast.LENGTH_SHORT).show()
                }
            }
            REQ_PICK_BG_IMAGE -> {
                Thread {
                    try {
                        val rawBmp = contentResolver.openInputStream(uri)?.use { ins ->
                            BitmapFactory.decodeStream(ins)
                        }
                        if (rawBmp != null) {
                            val maxDim = 1280
                            val w = rawBmp.width
                            val h = rawBmp.height
                            val scaledBmp = if (w > maxDim || h > maxDim) {
                                val ratio = minOf(maxDim.toFloat() / w.toFloat(), maxDim.toFloat() / h.toFloat())
                                Bitmap.createScaledBitmap(
                                    rawBmp,
                                    (w * ratio).toInt().coerceAtLeast(1),
                                    (h * ratio).toInt().coerceAtLeast(1),
                                    true
                                )
                            } else {
                                rawBmp
                            }
                            val outFile = CustomBgManager.getBgFile(this)
                            FileOutputStream(outFile).use { fos ->
                                scaledBmp.compress(Bitmap.CompressFormat.PNG, 95, fos)
                            }
                            val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putLong("custom_bg_ts", System.currentTimeMillis()).apply()

                            // 若当前处于莫奈花园特殊皮肤，自动切换到纯色/自定义底图框架，使上传的背景图与毛玻璃按键立即生效
                            val curSkin = CssSkinManager.getSkin(this)
                            val switchedFromMonet = curSkin.waterLilyDecor
                            if (switchedFromMonet) {
                                CssSkinManager.saveCustomCss(this, CssSkinManager.SAMPLE_COMMENTED_CSS)
                            }

                            runOnUiThread {
                                if (switchedFromMonet) {
                                    cssInputBox.setText(CssSkinManager.SAMPLE_COMMENTED_CSS)
                                }
                                customBgStatusTv.text = "当前底图状态：已启用自定义背景图（纯色框架下按键已开启半透明毛玻璃）"
                                Toast.makeText(
                                    this,
                                    "自定义背景图已上传生效！已自动应用 cover 铺满并开启按键毛玻璃效果",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            runOnUiThread {
                                Toast.makeText(this, "无法解析所选图片，请换一张图片重试", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "上传背景图失败：${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            REQ_PICK_SOUND -> {
                val soundFileName = resolveFileName(uri).ifEmpty { "自定义音效" }
                Thread {
                    try {
                        val outFile = KeySoundManager.getCustomSoundFile(this)
                        var copiedBytes = 0L
                        contentResolver.openInputStream(uri)?.use { ins ->
                            FileOutputStream(outFile).use { fos ->
                                copiedBytes = ins.copyTo(fos)
                            }
                        }
                        if (copiedBytes > 0L) {
                            val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                            prefs.edit()
                                .putLong("custom_sound_ts", System.currentTimeMillis())
                                .putString("custom_sound_name", soundFileName)
                                .putBoolean("key_sound_enabled", true)
                                .apply()
                            KeySoundManager.reloadSound(this)
                            runOnUiThread {
                                customSoundStatusTv.text = "当前使用音效：自定义音效（$soundFileName）"
                                KeySoundManager.playClick(this, forcePreview = true)
                                Toast.makeText(this, "已应用自定义音效「$soundFileName」！", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            runOnUiThread {
                                Toast.makeText(this, "读取音频文件失败，请换一个音频文件重试", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导入音效失败：${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            in REQ_PICK_TOP_ICON_BASE..(REQ_PICK_TOP_ICON_BASE + 4) -> {
                val slotType = requestCode - REQ_PICK_TOP_ICON_BASE
                Thread {
                    try {
                        val rawBmp = contentResolver.openInputStream(uri)?.use { ins ->
                            BitmapFactory.decodeStream(ins)
                        }
                        if (rawBmp != null && CustomTopIconManager.saveCustomIconFromBitmap(this, slotType, rawBmp)) {
                            runOnUiThread {
                                val slotTitle = when (slotType) {
                                    MinimalistIconView.TYPE_SETTINGS -> "第 1 个图标（设置）"
                                    MinimalistIconView.TYPE_EMOJI -> "第 2 个图标（表情）"
                                    MinimalistIconView.TYPE_CLIPBOARD -> "第 3 个图标（剪贴板）"
                                    MinimalistIconView.TYPE_FAVORITE -> "第 4 个图标（收藏）"
                                    MinimalistIconView.TYPE_COLLAPSE -> "第 5 个图标（收起）"
                                    else -> "顶栏图标"
                                }
                                topIconSlotStatusMap[slotType]?.apply {
                                    text = "$slotTitle：✅ 已启用你上传的自定义图标"
                                    setTextColor(Color.parseColor("#2B5B84"))
                                }
                                Toast.makeText(this, "✅ $slotTitle 自定义图标已生效（已自动处理透明通道与等比缩放）！", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            runOnUiThread {
                                Toast.makeText(this, "无法解析所选图标图片，请换一张 PNG 图片重试", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导入自定义图标失败：${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }.start()
            }
            REQ_PICK_FONT_ENG, REQ_PICK_FONT_CAND, REQ_PICK_FONT_ENTER -> {
                val slot = when (requestCode) {
                    REQ_PICK_FONT_ENG -> CustomFontManager.SLOT_ENG
                    REQ_PICK_FONT_CAND -> CustomFontManager.SLOT_CAND
                    else -> CustomFontManager.SLOT_ENTER
                }
                val fontFileName = resolveFileName(uri).ifEmpty { "自定义字体.ttf" }
                Thread {
                    try {
                        val outFile = CustomFontManager.getFontFile(this, slot)
                        var copied = 0L
                        contentResolver.openInputStream(uri)?.use { ins ->
                            FileOutputStream(outFile).use { fos ->
                                copied = ins.copyTo(fos)
                            }
                        }
                        val testTf = if (copied > 0L) Typeface.createFromFile(outFile) else null
                        if (testTf != null && testTf != Typeface.DEFAULT) {
                            val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                            prefs.edit()
                                .putLong("font_ts_$slot", System.currentTimeMillis())
                                .putString("font_name_$slot", fontFileName)
                                .apply()
                            runOnUiThread {
                                when (slot) {
                                    CustomFontManager.SLOT_ENG -> fontEngStatusTv.text = "① 按键英文字母字体：$fontFileName"
                                    CustomFontManager.SLOT_CAND -> fontCandStatusTv.text = "② 中文候选词字体：$fontFileName"
                                    CustomFontManager.SLOT_ENTER -> fontEnterStatusTv.text = "③ 右下角自定义文字字体：$fontFileName"
                                }
                                Toast.makeText(this, "已成功导入并应用字体「$fontFileName」！弹出键盘即可查看", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            outFile.delete()
                            runOnUiThread {
                                Toast.makeText(this, "所选文件不是有效的 .ttf / .otf 字体文件，请重新选择", Toast.LENGTH_LONG).show()
                            }
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            Toast.makeText(this, "导入字体失败：请确认选择的是有效的 .ttf 或 .otf 字体文件", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            REQ_IMPORT_DICT -> {
                val fileName = resolveFileName(uri)
                importDictStatusTv.visibility = android.view.View.VISIBLE
                importDictStatusTv.text = "⏳ 正在解析「$fileName」并生成 86 五笔哈希索引，请稍候..."
                Thread {
                    var importedCount = 0
                    try {
                        val lowerName = fileName.lowercase()
                        val path = uri.toString().lowercase()
                        val isScel = lowerName.endsWith(".scel") || path.endsWith(".scel")
                        val batchList = ArrayList<Triple<String, String, String>>(4096)
                        contentResolver.openInputStream(uri)?.use { ins ->
                            if (isScel) {
                                val words = T14WubiEngine.parseSogouScel(ins)
                                for (w in words) {
                                    val wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                                    val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                                    if (wcode.isNotEmpty() || py.isNotEmpty()) {
                                        batchList.add(Triple(w, wcode, py))
                                    }
                                }
                            } else {
                                val reader = BufferedReader(InputStreamReader(ins, Charsets.UTF_8))
                                val seenInFile = HashSet<String>()
                                var inRimeHeader = false
                                reader.forEachLine { rawLine ->
                                    val clean = rawLine.trim().removePrefix("\uFEFF")
                                    if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                                    if (clean == "---") {
                                        inRimeHeader = true
                                        return@forEachLine
                                    }
                                    if (clean == "...") {
                                        inRimeHeader = false
                                        return@forEachLine
                                    }
                                    if (inRimeHeader) return@forEachLine

                                    val parts = clean.split(Regex("[\\t\\s,]+"))
                                    if (parts.isEmpty()) return@forEachLine

                                    val p0 = parts[0].trim()
                                    val p1 = if (parts.size >= 2) parts[1].trim() else ""
                                    val p0IsAsciiLetters = p0.isNotEmpty() && p0.all { it in 'a'..'z' || it in 'A'..'Z' }
                                    val p1HasChinese = p1.any { it.code in 0x4E00..0x9FA5 }

                                    // 智能识别「编码在前、词条在后」(如 kfgj 吐槽) 与「词条在前、编码在后」(如 吐槽 kfgj) 两种主流码表格式！
                                    val w: String
                                    val rawCodeOrPy: String
                                    if (p0IsAsciiLetters && p1HasChinese) {
                                        w = p1
                                        rawCodeOrPy = p0.lowercase()
                                    } else {
                                        w = p0
                                        rawCodeOrPy = p1.lowercase()
                                    }

                                    if (w.isEmpty()) return@forEachLine
                                    val isEngWord = w.length >= 2 && w.all { it in 'a'..'z' || it in 'A'..'Z' || it == '-' || it == '\'' }
                                    if (isEngWord) {
                                        if (seenInFile.add(w.lowercase())) {
                                            batchList.add(Triple(w, "__en__", w.lowercase()))
                                        }
                                    } else if (w.any { it.code in 0x4E00..0x9FA5 }) {
                                        // 区分第 2 列究竟是 86 五笔编码 (1~4位 a~y 字母) 还是拼音 (含 ' 或长度>4 或含 z)
                                        val isExplicitWubi = rawCodeOrPy.length in 1..4 && rawCodeOrPy.all { it in 'a'..'y' }
                                        val wcode = if (isExplicitWubi) {
                                            rawCodeOrPy
                                        } else {
                                            T14WubiEngine.generateWubi86CodeForWord(w)
                                        }
                                        val py = if (!isExplicitWubi && rawCodeOrPy.isNotEmpty() && rawCodeOrPy.all { it in 'a'..'z' || it == '\'' }) {
                                            rawCodeOrPy
                                        } else {
                                            T14WubiEngine.generateSegmentedPinyinForWord(w)
                                        }
                                        val dedupKey = "$w|$wcode"
                                        if ((wcode.isNotEmpty() || py.isNotEmpty()) && seenInFile.add(dedupKey)) {
                                            batchList.add(Triple(w, wcode, py))
                                        }
                                    }
                                }
                            }
                        }
                        if (batchList.isNotEmpty()) {
                            importedCount = dbHelper.importDictionaryBatch(fileName, batchList, 7200)
                            T14WubiEngine.reloadUserDict(dbHelper)
                        }
                    } catch (_: Exception) {}
                    runOnUiThread {
                        if (importedCount > 0) {
                            importDictStatusTv.text = "✅ 已成功导入「$fileName」($importedCount 词)，已加入下方列表！"
                            Toast.makeText(this, "成功导入「$fileName」共 $importedCount 条词组！", Toast.LENGTH_LONG).show()
                        } else {
                            importDictStatusTv.text = "⚠️ 未能从「$fileName」解析出词条，请确认文件为未加密的搜狗 .scel 或 UTF-8 .txt 格式"
                            Toast.makeText(this, "未解析出有效词条，请检查文件格式", Toast.LENGTH_LONG).show()
                        }
                        refreshImportedDictListUI()
                    }
                }.start()
            }
        }
    }

    private fun resolveFileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) {
                    val name = c.getString(idx)?.trim()
                    if (!name.isNullOrEmpty()) return name
                }
            }
        } catch (_: Exception) {}
        val seg = uri.lastPathSegment ?: "导入词库.scel"
        return seg.substringAfterLast('/').substringAfterLast(':').ifEmpty { "导入词库.scel" }
    }

    private fun launchSystemVoicePopupActivity() {
        try {
            val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
                putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "请说话（识别后自动填入输入框）")
            }
            startActivityForResult(intent, REQ_SYSTEM_VOICE_POPUP)
        } catch (e: Exception) {
            Toast.makeText(this, "当前系统未找到原生语音弹窗组件：${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestVoiceRecordPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "✅ 麦克风权限已开启，长按空格键即可使用语音输入！", Toast.LENGTH_SHORT).show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_VOICE_AUDIO_PERM)
            }
        } else {
            Toast.makeText(this, "✅ 麦克风权限已就绪！", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_VOICE_AUDIO_PERM) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            Toast.makeText(
                this,
                if (granted) "✅ 已授予麦克风权限！现在长按五笔键盘空格键即可直接语音打字" else "⚠️ 未授予麦克风权限，语音输入需要麦克风权限才能听音识字",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun refreshPersonalWordsListUI() {
        if (!::personalWordsListContainer.isInitialized) return
        personalWordsListContainer.removeAllViews()
        val rows = dbHelper.getRecentCustomAndAutoUserWords(40)
        val pendingAuto = dbHelper.getAutoPhraseCandidateProgress()

        if (pendingAuto.isNotEmpty()) {
            val th = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE).getInt("auto_phrase_threshold", 5)
            val progStr = pendingAuto.take(6).joinToString(" · ") { "${it.first}(${it.second}/$th)" }
            val progTv = TextView(this).apply {
                text = "⏳ 自动组词累计中：$progStr"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Color.parseColor("#4B5563"))
                setPadding(dp(8), dp(4), dp(8), dp(6))
            }
            personalWordsListContainer.addView(progTv)
        }

        if (rows.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "暂无手动添加或自动组词收录的个人词条（当您连续单字输入新词满设定次数，或在上方点击「＋添加到我的五笔词库」后，词条将显示在此处）"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Color.parseColor("#888888"))
                setPadding(dp(8), dp(6), dp(8), dp(6))
                setBackgroundColor(Color.parseColor("#F7F8FC"))
            }
            personalWordsListContainer.addView(emptyTv)
            return
        }

        for (r in rows) {
            val itemRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#F7F9FE"))
                setPadding(dp(10), dp(6), dp(8), dp(6))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(4)
                layoutParams = lp
            }
            val tagBadge = if (r.sourceName == "自动组词") "🤖自动组词" else "✍️手动添加"
            val tv = TextView(this).apply {
                text = "$tagBadge  「${r.word}」  五笔:${r.wubiCode.ifEmpty { "-" }} · 14键:${r.t14Wubi.ifEmpty { "-" }}"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setTextColor(Color.parseColor("#222634"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val delBtn = Button(this).apply {
                text = "删除"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setTextColor(Color.parseColor("#D94336"))
                setOnClickListener {
                    dbHelper.deleteUserDictRowById(r.id)
                    T14WubiEngine.reloadUserDict(dbHelper)
                    refreshImportedDictListUI()
                    Toast.makeText(this@SettingsActivity, "已删除个人词条「${r.word}」", Toast.LENGTH_SHORT).show()
                }
            }
            itemRow.addView(tv)
            itemRow.addView(delBtn)
            personalWordsListContainer.addView(itemRow)
        }
    }

    private fun refreshImportedDictListUI() {
        refreshPersonalWordsListUI()
        if (!::importedDictListContainer.isInitialized) return
        importedDictListContainer.removeAllViews()
        val packs = dbHelper.getImportedDictPacks()
        if (packs.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "当前暂无已导入的外部词库（在上方选择 .scel 或 .txt 导入后，会在此处显示词库名、词条数量与删除按钮）"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setTextColor(Color.parseColor("#888888"))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.parseColor("#F7F8FC"))
            }
            importedDictListContainer.addView(emptyTv)
            return
        }

        val totalWords = packs.sumOf { it.wordCount }
        val summaryTv = TextView(this).apply {
            text = "目前已挂载 ${packs.size} 个扩展词库来源，共 $totalWords 条词组（已建立 O(1) 内存哈希索引）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(Color.parseColor("#4B5563"))
            setPadding(0, 0, 0, dp(6))
        }
        importedDictListContainer.addView(summaryTv)

        val sdf = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
        for (pack in packs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(Color.parseColor("#F3F4F8"))
                setPadding(dp(12), dp(8), dp(10), dp(8))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.bottomMargin = dp(6)
                layoutParams = lp
            }

            val timeStr = if (pack.importedAt > 0L) " · ${sdf.format(Date(pack.importedAt))}" else ""
            val infoTv = TextView(this).apply {
                text = "📦 ${pack.packName}\n共 ${pack.wordCount} 词$timeStr"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(Color.parseColor("#222428"))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val delBtn = Button(this).apply {
                text = "删除"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(Color.parseColor("#D94336"))
                setOnClickListener {
                    AlertDialog.Builder(this@SettingsActivity)
                        .setTitle("确认删除词库？")
                        .setMessage("确定要删除已导入的词库「${pack.packName}」（共 ${pack.wordCount} 词）吗？此操作不可恢复。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("确定删除") { _, _ ->
                            val removed = dbHelper.deleteDictionaryPack(pack.packName)
                            Thread { T14WubiEngine.reloadUserDict(dbHelper) }.start()
                            Toast.makeText(this@SettingsActivity, "已删除「${pack.packName}」（共移除 $removed 词）！", Toast.LENGTH_SHORT).show()
                            refreshImportedDictListUI()
                        }
                        .show()
                }
            }

            row.addView(infoTv)
            row.addView(delBtn)
            importedDictListContainer.addView(row)
        }

        if (packs.size >= 2 || totalWords > 100) {
            val clearAllBtn = Button(this).apply {
                text = "一键清空全部已导入扩展词库（不影响内置 86 五笔词库）"
                setTextColor(Color.parseColor("#D94336"))
                setOnClickListener {
                    AlertDialog.Builder(this@SettingsActivity)
                        .setTitle("确认清空全部扩展词库？")
                        .setMessage("确定要清空全部已导入的扩展词库（共 $totalWords 词）吗？内置 86 五笔词库不受影响，但已导入词库清空后不可恢复。")
                        .setNegativeButton("取消", null)
                        .setPositiveButton("确定清空") { _, _ ->
                            val removed = dbHelper.clearAllUserDict()
                            Thread { T14WubiEngine.reloadUserDict(dbHelper) }.start()
                            Toast.makeText(this@SettingsActivity, "已清空全部扩展词库（共移除 $removed 词）！", Toast.LENGTH_SHORT).show()
                            refreshImportedDictListUI()
                        }
                        .show()
                }
            }
            importedDictListContainer.addView(clearAllBtn)
        }
    }

    private fun makeCard(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(16)
            layoutParams = lp

            val tv = TextView(this@SettingsActivity).apply {
                text = title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#2A3042"))
                setPadding(0, 0, 0, dp(10))
            }
            addView(tv)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
