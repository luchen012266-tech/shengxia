package com.shengxiaguangnian.ime

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

data class Candidate(
    val word: String,
    val wubiHint: String?,
    val displayCode: String,
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val t14PyAbbr: String,
    val weight: Int
)

object T14WubiEngine {
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    // 将内部 14 键编码还原为纯字母（彻底杜绝 8'7'nv 或 9 等数字出现在左上角浮窗！）
    private val T14_CODE_TO_LETTER = mapOf(
        '1' to "q", '2' to "e", '3' to "t", '4' to "u", '5' to "o",
        '6' to "a", '7' to "d", '8' to "g", '9' to "j", '0' to "l",
        'a' to "z", 'b' to "c", 'c' to "n", 'd' to "m"
    )

    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "dun", "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )

    private val wubiExactIndex = HashMap<String, MutableList<DictEntry>>(20000)
    private val wubiPrefixIndex = HashMap<String, MutableList<DictEntry>>(8000)
    private val pinyinExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val pinyinPrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val pinyinAbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)

    // 26 键英文单词前缀索引（支持词频权重与个人高频动态提权，容量扩大至每前缀 250 词）
    private val englishPrefixIndex = HashMap<String, MutableList<Pair<String, Int>>>(12000)
    private val englishExactSet = HashSet<String>(25000)

    private val t14SyllableMap = LinkedHashMap<String, String>()
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)

    // 用户导入词库专用 O(1) 哈希索引（同时支持中文词库与英文 .txt 词库！）
    private class UserDictIndex(
        val wubiExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val wubiPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinExact: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinPrefix: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val pinyinAbbr: HashMap<String, MutableList<DictEntry>> = HashMap(),
        val englishPrefix: HashMap<String, MutableList<Pair<String, Int>>> = HashMap()
    )
    @Volatile
    private var userDictIndex = UserDictIndex()

    private val userFreqMap = HashMap<String, Int>()
    private val userCodeMruMap = HashMap<String, Long>()
    private var mruSequenceCounter = System.currentTimeMillis()
    private val userBigramMap = HashMap<String, MutableList<String>>()
    private val builtInAssocMap = HashMap<String, List<String>>(15000)
    private val defaultCommonAssoc = listOf("的", "了", "是", "在", "我", "有", "和", "就", "不", "都", "也", "很", "可以", "什么", "自己", "知道", "觉得", "现在")

    private val isLoaded = AtomicBoolean(false)
    private val isLoading = AtomicBoolean(false)
    private val userDictDirty = AtomicBoolean(false)

    fun markUserDictDirty() {
        userDictDirty.set(true)
    }

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    fun ensureInitializedAsync(context: Context, dbHelper: ImeDatabaseHelper) {
        if (isLoaded.get()) {
            if (userDictDirty.compareAndSet(true, false)) {
                Thread { reloadUserDict(dbHelper) }.start()
            }
            return
        }
        if (!isLoading.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        Thread {
            loadAllInternal(appCtx, dbHelper)
            isLoaded.set(true)
            isLoading.set(false)
        }.start()
    }

    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        ensureInitializedAsync(context, dbHelper)
    }

    private fun loadAllInternal(context: Context, dbHelper: ImeDatabaseHelper) {
        for (syl in VALID_SYLLABLES) {
            val code = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code)) {
                t14SyllableMap[code] = syl
            }
        }

        // 1. 加载内置高频英文日常与 AI 词库 (en_daily_words.txt) + 主英文词典 (english_words.tsv)
        val seenEngLoaded = HashSet<String>(30000)
        fun indexEnglishWord(word: String, weight: Int) {
            if (word.length < 2) return
            val lower = word.lowercase()
            englishExactSet.add(lower)
            if (!seenEngLoaded.add(lower)) return
            val maxP = minOf(8, lower.length)
            for (len in 1..maxP) {
                val pref = lower.substring(0, len)
                val list = englishPrefixIndex.getOrPut(pref) { ArrayList(16) }
                if (list.size < 250) list.add(word to weight)
            }
        }
        for (assetName in listOf("en_daily_words.txt", "english_words.tsv")) {
            try {
                context.assets.open(assetName).use { ins ->
                    var autoWt = 95000
                    BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                        val clean = line.trim()
                        if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                        val tab = clean.indexOf('\t')
                        val word = (if (tab > 0) clean.substring(0, tab) else clean).trim()
                        val wt = if (tab > 0) clean.substring(tab + 1).trim().toIntOrNull() ?: autoWt else autoWt
                        autoWt = maxOf(1000, autoWt - 5)
                        indexEnglishWord(word, wt)
                    }
                }
            } catch (_: Exception) {}
        }

        // 2. 加载单字五笔与拼音码表
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载词语联想表
        try {
            context.assets.open("assoc_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) {
                        val prefix = line.substring(0, tab)
                        val suffixes = line.substring(tab + 1).split(',').filter { it.isNotEmpty() }
                        if (suffixes.isNotEmpty()) {
                            builtInAssocMap[prefix] = suffixes
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. 加载主词库并建立哈希索引
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 65536).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 4) {
                        val word = parts[0]
                        val wcode = parts[1]
                        val segPy = parts[2]
                        val t14W: String
                        val t14P: String
                        val t14A: String
                        val weight: Int
                        if (parts.size >= 7) {
                            t14W = parts[3]
                            t14P = parts[4]
                            t14A = parts[5]
                            weight = parts[6].toIntOrNull() ?: 500
                        } else {
                            t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                            t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                            t14A = extractPyAbbrT14(segPy)
                            weight = parts[3].toIntOrNull() ?: 500
                        }

                        if (word.isNotEmpty()) {
                            val de = DictEntry(word, wcode, segPy, t14W, t14P, t14A, weight)
                            indexEntry(de)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 5. 运行时兜底加载内置「中文日常高频用语词库」(cn_daily_phrases.txt)，确保每一条日常口语在五笔与拼音下都拥有高优先级
        try {
            context.assets.open("cn_daily_phrases.txt").use { ins ->
                var dailyWt = 9950
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val w = line.trim()
                    if (w.isEmpty() || w.startsWith("#")) return@forEachLine
                    val wcode = generateWubi86CodeForWord(w)
                    val segPy = generateSegmentedPinyinForWord(w)
                    val t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                    val t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                    val t14A = extractPyAbbrT14(segPy)
                    if (t14W.isNotEmpty() || t14P.isNotEmpty()) {
                        indexEntry(DictEntry(w, wcode, segPy, t14W, t14P, t14A, dailyWt))
                    }
                    dailyWt = maxOf(8800, dailyWt - 1)
                }
            }
        } catch (_: Exception) {}

        // 6. 将最常用的 AI 与日常英文词同步注入 14 键拼音前缀索引，即使不切到 26 键也能在中文键盘下直接盲打 gemini / gpt / deepseek / css！
        val topCrossModeEng = listOf(
            "gemini", "Gemini", "deepseek", "DeepSeek", "chatgpt", "ChatGPT", "gpt", "GPT",
            "claude", "Claude", "grok", "Grok", "openai", "copilot", "github", "android",
            "apk", "css", "oklch", "rgb", "hsv", "hsl", "love", "hello", "baby", "okay"
        )
        for ((idx, ew) in topCrossModeEng.withIndex()) {
            val t14P = letterToT14Code(ew)
            if (t14P.isNotEmpty()) {
                indexEntry(DictEntry(ew, "", ew.lowercase(), "", t14P, "", 9600 - idx * 10))
            }
        }

        userFreqMap.putAll(dbHelper.loadUserFreqMap())
        userCodeMruMap.putAll(dbHelper.loadUserCodeMruMap())
        userBigramMap.putAll(dbHelper.loadUserBigramMap())
        reloadUserDict(dbHelper)
    }

    private fun indexEntry(de: DictEntry) {
        if (de.t14Wubi.isNotEmpty()) {
            val exactList = wubiExactIndex.getOrPut(de.t14Wubi) { ArrayList(6) }
            if (exactList.size < 80) exactList.add(de)

            // 扩大五笔前缀索引容量到 250 条，确保敲第 1、2、3 码（如打 "天际" gdbf 敲到 gdb）时永远有五笔候选词！
            val maxPref = minOf(3, de.t14Wubi.length - 1)
            for (len in 1..maxPref) {
                val pref = de.t14Wubi.substring(0, len)
                val pList = wubiPrefixIndex.getOrPut(pref) { ArrayList(12) }
                if (pList.size < 250) pList.add(de)
            }
        }

        if (de.t14Pinyin.isNotEmpty()) {
            val pyExact = pinyinExactIndex.getOrPut(de.t14Pinyin) { ArrayList(6) }
            if (pyExact.size < 60) pyExact.add(de)

            if (de.word.length == 1 && pyExact.size <= 8) {
                val scList = t14SingleCharByPy.getOrPut(de.t14Pinyin) { ArrayList(4) }
                if (scList.size < 8) scList.add(de)
            }

            val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
            for (len in 1..maxPyPref) {
                val pref = de.t14Pinyin.substring(0, len)
                val pList = pinyinPrefixIndex.getOrPut(pref) { ArrayList(10) }
                if (pList.size < 120) pList.add(de)
            }
        }

        if (de.t14PyAbbr.length in 2..6) {
            val aList = pinyinAbbrIndex.getOrPut(de.t14PyAbbr) { ArrayList(6) }
            if (aList.size < 40) aList.add(de)
        }
    }

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        val nextIdx = UserDictIndex()
        try {
            dbHelper.readableDatabase.rawQuery(
                "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val w = c.getString(0)
                    val wc = c.getString(1)
                    if (wc == "__en__" || (w.length >= 2 && w.all { it in 'a'..'z' || it in 'A'..'Z' || it == '-' || it == '\'' })) {
                        val lower = w.lowercase()
                        val wt = c.getInt(5).coerceAtLeast(90000)
                        val maxP = minOf(8, lower.length)
                        for (len in 1..maxP) {
                            val pref = lower.substring(0, len)
                            val list = nextIdx.englishPrefix.getOrPut(pref) { ArrayList(12) }
                            if (list.size < 200) list.add(w to wt)
                        }
                        continue
                    }
                    val py = c.getString(2).ifEmpty { generateSegmentedPinyinForWord(w) }
                    val de = DictEntry(
                        word = w,
                        wubiCode = wc,
                        segmentedPinyin = py,
                        t14Wubi = c.getString(3),
                        t14Pinyin = c.getString(4),
                        t14PyAbbr = extractPyAbbrT14(py),
                        weight = c.getInt(5)
                    )
                    if (de.t14Wubi.isNotEmpty()) {
                        val exList = nextIdx.wubiExact.getOrPut(de.t14Wubi) { ArrayList(4) }
                        if (exList.size < 60) exList.add(de)
                        val maxPref = minOf(3, de.t14Wubi.length - 1)
                        for (len in 1..maxPref) {
                            val pref = de.t14Wubi.substring(0, len)
                            val pList = nextIdx.wubiPrefix.getOrPut(pref) { ArrayList(8) }
                            if (pList.size < 80) pList.add(de)
                        }
                    }
                    if (de.t14Pinyin.isNotEmpty()) {
                        val pyEx = nextIdx.pinyinExact.getOrPut(de.t14Pinyin) { ArrayList(4) }
                        if (pyEx.size < 50) pyEx.add(de)
                        val maxPyPref = minOf(14, de.t14Pinyin.length - 1)
                        for (len in 2..maxPyPref) {
                            val pref = de.t14Pinyin.substring(0, len)
                            val pList = nextIdx.pinyinPrefix.getOrPut(pref) { ArrayList(6) }
                            if (pList.size < 50) pList.add(de)
                        }
                    }
                    if (de.t14PyAbbr.length in 2..6) {
                        val aList = nextIdx.pinyinAbbr.getOrPut(de.t14PyAbbr) { ArrayList(4) }
                        if (aList.size < 40) aList.add(de)
                    }
                }
            }
            userDictIndex = nextIdx
        } catch (_: Exception) {}
    }

    fun resetUserFrequency(dbHelper: ImeDatabaseHelper) {
        userFreqMap.clear()
        userCodeMruMap.clear()
        userBigramMap.clear()
        dbHelper.resetUserFrequencySorting()
    }

    fun onWordCommitted(word: String, prevWord: String?, dbHelper: ImeDatabaseHelper, t14Code: String = "") {
        if (word.isEmpty()) return
        userFreqMap[word] = (userFreqMap[word] ?: 0) + 1
        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (t14Code.isNotEmpty()) {
            userCodeMruMap["$t14Code|$word"] = mruSequenceCounter
        }
        if (!prevWord.isNullOrEmpty() && prevWord != word) {
            val list = userBigramMap.getOrPut(prevWord) { ArrayList() }
            list.remove(word)
            list.add(0, word)
            if (list.size > 12) list.removeAt(list.lastIndex)
        }
        dbHelper.recordWordUsageAsync(word, prevWord, t14Code, mruSequenceCounter)
    }

    fun getAssociations(committedWord: String, limit: Int = 28): List<String> {
        if (committedWord.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        userBigramMap[committedWord]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }
        val lastCharStr = committedWord.takeLast(1)
        userBigramMap[lastCharStr]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }

        builtInAssocMap[committedWord]?.forEach { suffix ->
            if (seen.add(suffix) && result.size < limit) result.add(suffix)
        }
        if (committedWord.length >= 2) {
            builtInAssocMap[lastCharStr]?.forEach { suffix ->
                if (seen.add(suffix) && result.size < limit) result.add(suffix)
            }
        }

        for (cw in defaultCommonAssoc) {
            if (cw != committedWord && seen.add(cw) && result.size < limit) {
                result.add(cw)
            }
        }
        return result
    }

    /**
     * 记录用户在 26 键英文模式下选定或输入的英文单词，动态提升其高频排序并持久化记忆！
     */
    fun onEnglishWordCommitted(word: String, rawPrefix: String, dbHelper: ImeDatabaseHelper) {
        val clean = word.trim()
        if (clean.length < 2) return
        val lower = clean.lowercase()
        val prefLower = rawPrefix.trim().lowercase()

        val freqKey = "en_freq|$lower"
        val newFreq = (userFreqMap[freqKey] ?: 0) + 1
        userFreqMap[freqKey] = newFreq

        mruSequenceCounter = maxOf(System.currentTimeMillis(), mruSequenceCounter + 1L)
        if (prefLower.isNotEmpty()) {
            userCodeMruMap["en_mru:$prefLower|$lower"] = mruSequenceCounter
        }
        val maxP = minOf(8, lower.length)
        for (len in 1..maxP) {
            val p = lower.substring(0, len)
            userCodeMruMap["en_any:$p|$lower"] = mruSequenceCounter
            val list = englishPrefixIndex.getOrPut(p) { ArrayList(16) }
            if (list.none { it.first.equals(clean, ignoreCase = true) }) {
                list.add(0, clean to 92000)
            }
        }
        englishExactSet.add(lower)
        dbHelper.recordWordUsageAsync(freqKey, null, if (prefLower.isNotEmpty()) "en_mru:$prefLower" else "", mruSequenceCounter)
    }

    /**
     * 26 键英文模式下的智能高频单词联想与补全：
     * 1. 结合用户导入的英文词库、内置高频 AI/日常词库、以及用户个人打字词频记忆 (en_freq / en_mru) 综合排序；
     * 2. 高频词与个人常用词永远排在最前面（第 1 或第 2 个选项）：
     *    - 例如仅敲 2 个字母 "ge"，"gemini" 立即出现在第 2 个选项（[ge, gemini, get, ...]）；
     *    - 若敲 3 个及以上字母（如 "gem"）且原串不是完整常用词，或该前缀下你曾亲手选过 "gemini"，则 "gemini" 直接排第 1 位！
     */
    fun queryEnglishCandidates(rawInput: String, limit: Int = 28): List<String> {
        if (rawInput.isEmpty()) return emptyList()
        val lower = rawInput.lowercase()
        val isAllUpper = rawInput.length >= 2 && rawInput.all { it.isUpperCase() }
        val isCapitalized = rawInput[0].isUpperCase() && !isAllUpper
        val prefKey = lower.take(8)

        val candidatesMap = LinkedHashMap<String, Pair<String, Int>>()
        userDictIndex.englishPrefix[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                if (!candidatesMap.containsKey(key)) {
                    candidatesMap[key] = w to (wt + 60000)
                }
            }
        }
        englishPrefixIndex[prefKey]?.forEach { (w, wt) ->
            if (w.lowercase().startsWith(lower)) {
                val key = w.lowercase()
                val existing = candidatesMap[key]
                if (existing == null || wt > existing.second) {
                    candidatesMap[key] = w to wt
                }
            }
        }

        class ScoredEng(
            val displayWord: String,
            val lowerWord: String,
            val exactMru: Long,
            val userFreq: Int,
            val anyMru: Long,
            val baseWeight: Int
        )

        val scoredList = ArrayList<ScoredEng>(candidatesMap.size)
        for ((wLower, pair) in candidatesMap) {
            val rawW = pair.first
            val baseWt = pair.second
            val formatted = when {
                isAllUpper -> rawW.uppercase()
                isCapitalized -> rawW.replaceFirstChar { it.uppercaseChar() }
                else -> rawW
            }
            val exMru = userCodeMruMap["en_mru:$lower|$wLower"] ?: 0L
            val uFreq = userFreqMap["en_freq|$wLower"] ?: 0
            val anyMru = userCodeMruMap["en_any:$lower|$wLower"] ?: 0L
            // 优先匹配长度更接近的高频词，避免超长生僻词抢位
            val lenPenalty = (wLower.length - lower.length).coerceAtLeast(0) * 180
            scoredList.add(ScoredEng(formatted, wLower, exMru, uFreq, anyMru, baseWt - lenPenalty))
        }

        scoredList.sortWith { a, b ->
            when {
                a.exactMru != b.exactMru -> b.exactMru.compareTo(a.exactMru)
                a.userFreq != b.userFreq -> b.userFreq.compareTo(a.userFreq)
                a.anyMru != b.anyMru -> b.anyMru.compareTo(a.anyMru)
                else -> b.baseWeight.compareTo(a.baseWeight)
            }
        }

        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        // 判断是否将最佳高频补全词直接排到第 1 位（否则排在第 2 位，紧跟在原始字母后面）
        val topCand = scoredList.firstOrNull { !it.displayWord.equals(rawInput, ignoreCase = false) }
        val promoteTopToFirst = topCand != null && (
            topCand.exactMru > 0L ||
            topCand.userFreq >= 2 ||
            (lower.length >= 3 && !englishExactSet.contains(lower))
        )

        if (promoteTopToFirst && topCand != null) {
            if (seen.add(topCand.displayWord)) result.add(topCand.displayWord)
            if (seen.add(rawInput)) result.add(rawInput)
        } else {
            if (seen.add(rawInput)) result.add(rawInput)
            if (topCand != null && seen.add(topCand.displayWord)) result.add(topCand.displayWord)
        }

        for (item in scoredList) {
            if (seen.add(item.displayWord)) {
                result.add(item.displayWord)
                if (result.size >= limit) break
            }
        }
        return result
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    /**
     * 将 14 键编码转换为左上角浮窗显示的纯字母串（彻底杜绝 '8'、'7'、'9' 等内部数字编号出现！）
     */
    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code ->
            t14SyllableMap[code] ?: code.map { ch -> T14_CODE_TO_LETTER[ch] ?: ch.toString() }.joinToString("")
        }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    fun queryCandidates(t14Input: String, rawFallback: String, limit: Int = 90): List<Candidate> {
        if (t14Input.isEmpty() || !isLoaded.get()) return emptyList()

        val exactWubi = ArrayList<Candidate>(32)
        val prefixWubi = ArrayList<Candidate>(48)
        val exactPinyin = ArrayList<Candidate>(40)
        val abbrPinyin = ArrayList<Candidate>(24)
        val prefixPinyin = ArrayList<Candidate>(32)
        val seen = HashSet<String>(128)

        val isLongPinyinMode = t14Input.length > 4
        val segmentedDisplay = segmentT14ToPinyinDisplay(t14Input, rawFallback)

        // 方案一（几码归几码）：不跨码长全局加权，仅对当前精确输入码位 t14Input 做专属置顶记忆
        fun userBoost(@Suppress("UNUSED_PARAMETER") word: String): Int = 0

        val uIdx = userDictIndex
        if (!isLongPinyinMode) {
            uIdx.wubiExact[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(Candidate(e.word, null, e.wubiCode, e.weight + 50000, true))
                }
            }
            uIdx.wubiPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(Candidate(e.word, null, e.wubiCode.take(t14Input.length), e.weight + 20000, true))
                }
            }
        }
        uIdx.pinyinExact[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                exactPinyin.add(Candidate(e.word, wHint, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 50000, false))
            }
        }
        if (t14Input.length in 2..6) {
            uIdx.pinyinAbbr[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    abbrPinyin.add(Candidate(e.word, wHint, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + 20000, false))
                }
            }
        }
        if (t14Input.length in 2..14) {
            uIdx.pinyinPrefix[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    prefixPinyin.add(Candidate(e.word, wHint, segmentedDisplay, e.weight + 10000, false))
                }
            }
        }

        if (!isLongPinyinMode) {
            wubiExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
            wubiPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode.take(t14Input.length),
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
        }

        pinyinExactIndex[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = wHint,
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + userBoost(e.word) + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }

        if (t14Input.length in 2..6) {
            pinyinAbbrIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        if (t14Input.length <= 14) {
            pinyinPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        fun codeMru(word: String): Long = userCodeMruMap["$t14Input|$word"] ?: 0L

        val mruComparator = Comparator<Candidate> { a, b ->
            val luA = codeMru(a.word)
            val luB = codeMru(b.word)
            if (luA != luB) {
                luB.compareTo(luA) // 方案一（几码归几码）：仅在当前完全相同的输入码位下选过的字词直接排第 1！
            } else {
                val ufA = userFreqMap[a.word] ?: 0
                val ufB = userFreqMap[b.word] ?: 0
                if (ufA != ufB && (luA > 0L || luB > 0L)) {
                    ufB.compareTo(ufA)
                } else {
                    b.weight.compareTo(a.weight)
                }
            }
        }

        // 叠字连打快捷识别（如连敲 GH 打 hhhhh 自动出 哈哈哈哈哈，连敲 AS 出 啊啊啊啊，连敲 QW 出 呜呜呜呜）
        // 修复：之前「哈哈哈哈哈」因同时存在于日常词库的简拼索引 (abbrPinyin) 中，提前占用了 seen 集合，
        // 导致叠字连打跳过「哈哈哈哈哈」、反而把不在词库里的「嘿嘿嘿嘿嘿」「哼哼哼哼哼」塞到第 1、2 位，把「哈哈哈哈哈」挤在固定第 3 位！
        val repeatCandidatesTop = ArrayList<Candidate>(4)
        if (t14Input.length >= 3 && t14Input.all { it == t14Input[0] }) {
            val n = t14Input.length
            val repeatPresets = when (t14Input[0]) {
                '8' -> listOf("哈" to "h", "嘿" to "h", "哼" to "h")
                '6' -> listOf("啊" to "a", "呀" to "a")
                '1' -> listOf("呜" to "w", "哇" to "w")
                'a' -> listOf("嘻" to "x")
                '5' -> listOf("哦" to "o", "噢" to "o")
                '0' -> listOf("啦" to "l", "略" to "l")
                'd' -> listOf("么" to "m", "喵" to "m")
                else -> emptyList()
            }
            if (repeatPresets.isNotEmpty()) {
                for ((idx, pair) in repeatPresets.withIndex()) {
                    val (chStr, codeCh) = pair
                    val repWord = chStr.repeat(n)
                    // 移除之前在简拼/前缀列表中低权重占位的同名叠字，统一按「哈 -> 嘿 -> 哼」顺位与个人高频记忆排序
                    abbrPinyin.removeAll { it.word == repWord }
                    prefixPinyin.removeAll { it.word == repWord }
                    exactPinyin.removeAll { it.word == repWord }
                    seen.add(repWord)
                    if (n > 4) {
                        repeatCandidatesTop.add(Candidate(repWord, null, codeCh.repeat(n), 9999999 - idx * 100, false))
                    } else if (exactWubi.none { it.word == repWord }) {
                        exactWubi.add(Candidate(repWord, null, codeCh.repeat(n), 50 - idx, false))
                    }
                }
                if (repeatCandidatesTop.size > 1) {
                    repeatCandidatesTop.sortWith(mruComparator)
                }
            }
        }

        if (exactWubi.size > 1) exactWubi.sortWith(mruComparator)
        if (prefixWubi.size > 1) prefixWubi.sortWith(mruComparator)
        if (exactPinyin.size > 1) exactPinyin.sortWith(mruComparator)
        if (abbrPinyin.size > 1) abbrPinyin.sortWith(mruComparator)
        if (prefixPinyin.size > 1) prefixPinyin.sortWith(mruComparator)

        val result = ArrayList<Candidate>(limit)
        for (rc in repeatCandidatesTop) {
            result.add(rc)
        }

        if (!isLongPinyinMode) {
            for (c in exactWubi) {
                if (result.size < limit) result.add(c)
            }
            for (c in prefixWubi) {
                if (result.size < limit) result.add(c)
            }
            for (c in exactPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in abbrPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in prefixPinyin) {
                if (result.size < limit) result.add(c)
            }
        } else {
            for (c in exactPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in abbrPinyin) {
                if (result.size < limit) result.add(c)
            }
            for (c in prefixPinyin) {
                if (result.size < limit) result.add(c)
            }
        }

        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight + userBoost(it.word) }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val wHint = generateWubi86CodeForWord(synthWord)
                    val insertPos = if (isLongPinyinMode) exactPinyin.size.coerceAtMost(result.size) else result.size
                    result.add(
                        insertPos,
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = fc.wubiCode,
                            displayCode = segmentedDisplay,
                            weight = fc.weight + userBoost(fc.word),
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        // 全源统一「几码归几码」高频置顶：
        // 无论候选词来自五笔精确、五笔前缀、拼音全拼、拼音简拼（abbrPinyin，如 hhhh/hhhhh）、拼音前缀还是叠字连打，
        // 只要用户在【当前完全相同的输入码 t14Input】下亲手选过该词（codeMru > 0），一律按最近选择顺序直接排到第 1 位！
        val promotedMru = result.filter { codeMru(it.word) > 0L }.sortedWith(mruComparator)
        if (promotedMru.isNotEmpty()) {
            val promotedSet = promotedMru.map { it.word }.toHashSet()
            val remaining = result.filterNot { it.word in promotedSet }
            result.clear()
            result.addAll(promotedMru)
            result.addAll(remaining)
        }

        return result
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()

        fun parseAtOffset(startPos: Int): List<String> {
            val words = ArrayList<String>()
            try {
                val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                var pos = startPos
                while (pos + 4 < bytes.size) {
                    val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                    val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                    pos += 4 + pyIdxBytesLen
                    if (samePyCount <= 0 || samePyCount > 2500 || pyIdxBytesLen > 256 || pos >= bytes.size) break
                    for (i in 0 until samePyCount) {
                        if (pos + 2 >= bytes.size) break
                        val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2
                        if (wordByteLen <= 0 || wordByteLen > 128 || pos + wordByteLen > bytes.size) break
                        val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                        pos += wordByteLen
                        if (pos + 2 > bytes.size) break
                        val extLen = buf.getShort(pos).toInt() and 0xFFFF
                        pos += 2 + extLen
                        if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 1..16) {
                            words.add(word)
                        }
                    }
                }
            } catch (_: Exception) {}
            return words
        }

        val primaryOffset = if ((bytes[4].toInt() and 0xFF) == 0x45) 0x26C4 else 0x2628
        val primaryWords = parseAtOffset(primaryOffset)
        if (primaryWords.size >= 5) return primaryWords.distinct()
        val fallbackOffset = if (primaryOffset == 0x2628) 0x26C4 else 0x2628
        val fallbackWords = if (bytes.size > fallbackOffset) parseAtOffset(fallbackOffset) else emptyList()
        return (if (fallbackWords.size > primaryWords.size) fallbackWords else primaryWords).distinct()
    }
}
