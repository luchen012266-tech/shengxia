package com.shengxiaguangnian.ime

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

data class ClipItem(
    val id: Long,
    val content: String,
    val isPinned: Boolean,
    val timestamp: Long
)

data class PhraseItem(
    val id: Long,
    val category: String,
    val content: String,
    val isStarred: Boolean,
    val lastUsed: Long
)

data class ImportedDictPack(
    val packName: String,
    val wordCount: Int,
    val importedAt: Long
)

data class CodeSelectionStat(
    val count: Int,
    val lastUsed: Long
)

data class UserDictRow(
    val id: Long,
    val word: String,
    val wubiCode: String,
    val pinyinCode: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val weight: Int,
    val sourceName: String
)

class ImeDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "shengxia_ime.db", null, 8) {

    companion object {
        const val MAX_CLIPBOARD_ITEMS = 300
        val DEFAULT_CATEGORIES = listOf("收藏", "最近", "邮", "号", "叮", "演", "扮", "模块", "api")
        private val dbExecutor = Executors.newSingleThreadExecutor()
        private val mainHandler = Handler(Looper.getMainLooper())

        private val URL_REGEX = Regex(
            "(?:https?://|www\\.)[a-zA-Z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]+|(?:[a-zA-Z0-9\\-]+\\.)+(?:com|cn|net|org|io|cc|tv|me|xyz|top|vip|co|ai|app|dev|gg|hk|tw|jp|uk|us)(?:/[a-zA-Z0-9\\-._~:/?#\\[\\]@!$&'()*+,;=%]*)?",
            RegexOption.IGNORE_CASE
        )

        private val urlExtractCache = HashMap<Int, List<String>>()

        /**
         * 从任意剪贴板或常用语文本中智能提取纯网址（带高速预检与内存缓存，彻底消除百条长文本正则卡顿）
         */
        fun extractUrls(text: String): List<String> {
            if (text.length < 4 || !text.contains('.')) return emptyList()
            val key = text.hashCode()
            synchronized(urlExtractCache) {
                urlExtractCache[key]?.let { return it }
            }
            val sample = if (text.length > 4000) text.substring(0, 4000) else text
            val lower = sample.lowercase()
            val mightHaveUrl = lower.contains("http://") || lower.contains("https://") || lower.contains("www.") ||
                lower.contains(".com") || lower.contains(".cn") || lower.contains(".net") || lower.contains(".org") ||
                lower.contains(".io") || lower.contains(".cc") || lower.contains(".me") || lower.contains(".top") ||
                lower.contains(".xyz") || lower.contains(".vip") || lower.contains(".co") || lower.contains(".ai") ||
                lower.contains(".app") || lower.contains(".dev") || lower.contains(".gg") || lower.contains(".tv") ||
                lower.contains(".hk") || lower.contains(".tw") || lower.contains(".jp") || lower.contains(".uk") ||
                lower.contains(".us")
            if (!mightHaveUrl) {
                synchronized(urlExtractCache) {
                    if (urlExtractCache.size > 512) urlExtractCache.clear()
                    urlExtractCache[key] = emptyList()
                }
                return emptyList()
            }
            val result = ArrayList<String>()
            val trimChars = charArrayOf('.', ',', ';', ':', '!', '?', ')', ']', '>', '\'', '"', '，', '。', '！', '？', '；', '：', '）', '】', '》', '”', '’')
            for (match in URL_REGEX.findAll(sample)) {
                val cleaned = match.value.trimEnd(*trimChars).trim()
                if (cleaned.length >= 4 && !result.contains(cleaned)) {
                    result.add(cleaned)
                }
            }
            synchronized(urlExtractCache) {
                if (urlExtractCache.size > 512) urlExtractCache.clear()
                urlExtractCache[key] = result
            }
            return result
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS clipboard_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL UNIQUE ON CONFLICT REPLACE,
                is_pinned INTEGER DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrase_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                sort_order INTEGER NOT NULL
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS phrases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                is_starred INTEGER DEFAULT 0,
                last_used INTEGER DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_dict (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                wubi_code TEXT NOT NULL,
                pinyin_code TEXT NOT NULL,
                t14_wubi TEXT NOT NULL,
                t14_pinyin TEXT NOT NULL,
                weight INTEGER DEFAULT 6800,
                source_name TEXT NOT NULL DEFAULT '手动添加'
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_source ON user_dict(source_name)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_word ON user_dict(word)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_wubi ON user_dict(t14_wubi)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_t14_pinyin ON user_dict(t14_pinyin)")

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())

        createV3AndV8Tables(db)

        DEFAULT_CATEGORIES.forEachIndexed { idx, name ->
            val cv = ContentValues().apply {
                put("name", name)
                put("sort_order", idx)
            }
            db.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        }

        val samplePhrases = listOf(
            Triple("演", "### 角色扮演规则指令：《盛夏光年》 **【核心世界观】** 这是一个支持无限字数、零截断的专属常用语模板，点击卡片直接全文上屏，点击右侧箭头可展开或编辑。", 1),
            Triple("模块", "【模块指令模板】可在此分类下存放常用的系统提示词模块与世界观插件，不限字数。", 1),
            Triple("api", "【API 快捷配置】可在此处存放常用的接口地址、模型名称或参数片段。", 0)
        )
        samplePhrases.forEach { (cat, text, starred) ->
            val cv = ContentValues().apply {
                put("category", cat)
                put("content", text)
                put("is_starred", starred)
                put("last_used", System.currentTimeMillis())
            }
            db.insert("phrases", null, cv)
        }
    }

    private fun createV3AndV8Tables(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_freq (
                word TEXT PRIMARY KEY,
                freq INTEGER NOT NULL DEFAULT 1,
                last_used INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_code_mru (
                t14_code TEXT NOT NULL,
                word TEXT NOT NULL,
                sel_count INTEGER NOT NULL DEFAULT 1,
                last_used INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (t14_code, word)
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_bigram (
                prev_word TEXT NOT NULL,
                next_word TEXT NOT NULL,
                freq INTEGER NOT NULL DEFAULT 1,
                PRIMARY KEY (prev_word, next_word)
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS imported_dict_packs (
                pack_name TEXT PRIMARY KEY,
                word_count INTEGER NOT NULL DEFAULT 0,
                imported_at INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS user_auto_phrase_cand (
                phrase TEXT PRIMARY KEY,
                hit_count INTEGER NOT NULL DEFAULT 1,
                last_seen INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        createV3AndV8Tables(db)
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())
        try {
            db.execSQL("ALTER TABLE user_dict ADD COLUMN source_name TEXT NOT NULL DEFAULT '手动添加'")
        } catch (_: Exception) {}
        try {
            db.execSQL("ALTER TABLE user_code_mru ADD COLUMN sel_count INTEGER NOT NULL DEFAULT 1")
        } catch (_: Exception) {}
        try {
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_source ON user_dict(source_name)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_dict_word ON user_dict(word)")
        } catch (_: Exception) {}
        try {
            // 提升旧版过低的 5000 默认词频到统一归一化尺度 (6800)，防止导入词库被内置词库压在最底下
            db.execSQL("UPDATE user_dict SET weight = 6800 WHERE weight = 5000")
            db.execSQL("UPDATE user_dict SET weight = 7200 WHERE weight = 5200")
        } catch (_: Exception) {}
        try {
            db.execSQL("UPDATE user_dict SET source_name = '此前已导入词库汇总' WHERE weight <= 6800 AND source_name = '手动添加'")
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = '此前已导入词库汇总'", null).use { c ->
                if (c.moveToFirst()) {
                    val cnt = c.getInt(0)
                    if (cnt > 0) {
                        val cv = ContentValues().apply {
                            put("pack_name", "此前已导入词库汇总")
                            put("word_count", cnt)
                            put("imported_at", System.currentTimeMillis())
                        }
                        db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                    }
                }
            }
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = '手动添加'", null).use { c ->
                if (c.moveToFirst()) {
                    val cnt = c.getInt(0)
                    if (cnt > 0) {
                        val cv = ContentValues().apply {
                            put("pack_name", "手动添加")
                            put("word_count", cnt)
                            put("imported_at", System.currentTimeMillis())
                        }
                        db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * 记录用户实际候选选择（带按「输入编码 + 候选文本」独立累计次数与防误选自动衰减机制）：
     * - 选中 (t14Code, word) 时：sel_count + 1（上限 50）；
     * - 同时对同一 t14Code 下未选中的其他历史候选执行温和衰减 (sel_count - 1)，
     *   若之前偶尔误点了一次某个错词 (sel_count = 1)，下次正常选回原本的词时，错词的 sel_count 自动归零清除！
     */
    fun recordWordUsageAsync(word: String, prevWord: String?, t14Code: String = "", mruSeq: Long = 0L) {
        dbExecutor.execute {
            try {
                val now = if (mruSeq > 0L) mruSeq else System.currentTimeMillis()
                val db = writableDatabase
                db.execSQL(
                    "INSERT INTO user_freq(word, freq, last_used) VALUES(?, 1, ?) ON CONFLICT(word) DO UPDATE SET freq = MIN(freq + 1, 5000), last_used = ?",
                    arrayOf<Any>(word, now, now)
                )
                if (t14Code.isNotEmpty()) {
                    db.execSQL(
                        """
                        INSERT INTO user_code_mru(t14_code, word, sel_count, last_used)
                        VALUES(?, ?, 1, ?)
                        ON CONFLICT(t14_code, word) DO UPDATE SET
                            sel_count = MIN(sel_count + 1, 50),
                            last_used = ?
                        """.trimIndent(),
                        arrayOf<Any>(t14Code, word, now, now)
                    )
                    // 同编码下未选中的竞争候选温和衰减 1 次，清除偶发误选残留
                    db.execSQL(
                        "UPDATE user_code_mru SET sel_count = MAX(0, sel_count - 1) WHERE t14_code = ? AND word != ? AND sel_count > 0",
                        arrayOf<Any>(t14Code, word)
                    )
                    db.execSQL(
                        "DELETE FROM user_code_mru WHERE t14_code = ? AND sel_count <= 0",
                        arrayOf<Any>(t14Code)
                    )
                }
                if (!prevWord.isNullOrEmpty() && prevWord != word) {
                    db.execSQL(
                        "INSERT INTO user_bigram(prev_word, next_word, freq) VALUES(?, ?, 1) ON CONFLICT(prev_word, next_word) DO UPDATE SET freq = MIN(freq + 1, 1000)",
                        arrayOf<Any>(prevWord, word)
                    )
                }
            } catch (_: Exception) {}
        }
    }

    /**
     * 自动组词计数器：
     * 当用户连续单字输入某个词汇（如先打「吐」再打「槽」组成「吐槽」）达到 threshold（默认 5 次）时，
     * 自动根据 86 五笔词组取码规则合成其五笔编码与拼音并写入 user_dict（来源标记为「自动组词」），立即生效！
     */
    fun recordAutoPhraseHitAndPromoteAsync(
        context: Context,
        phrase: String,
        wubiCode: String,
        pinyinCode: String,
        threshold: Int = 5,
        onAutoPromotedMainThread: ((String, String, String) -> Unit)? = null
    ) {
        if (phrase.length < 2 || (wubiCode.isEmpty() && pinyinCode.isEmpty())) return
        dbExecutor.execute {
            try {
                val db = writableDatabase
                // 检查是否已经在 user_dict 的「自动组词」或「手动添加」中
                var alreadyInUserDict = false
                db.rawQuery(
                    "SELECT COUNT(*) FROM user_dict WHERE word = ? AND source_name IN ('自动组词', '手动添加')",
                    arrayOf(phrase)
                ).use { c ->
                    if (c.moveToFirst() && c.getInt(0) > 0) {
                        alreadyInUserDict = true
                    }
                }
                if (alreadyInUserDict) return@execute

                val now = System.currentTimeMillis()
                db.execSQL(
                    """
                    INSERT INTO user_auto_phrase_cand(phrase, hit_count, last_seen)
                    VALUES(?, 1, ?)
                    ON CONFLICT(phrase) DO UPDATE SET
                        hit_count = hit_count + 1,
                        last_seen = ?
                    """.trimIndent(),
                    arrayOf<Any>(phrase, now, now)
                )

                var curHits = 0
                db.rawQuery(
                    "SELECT hit_count FROM user_auto_phrase_cand WHERE phrase = ?",
                    arrayOf(phrase)
                ).use { c ->
                    if (c.moveToFirst()) {
                        curHits = c.getInt(0)
                    }
                }

                if (curHits >= threshold.coerceAtLeast(2)) {
                    val cleanPy = pinyinCode.replace("'", "")
                    val t14W = T14WubiEngine.letterToT14Code(wubiCode)
                    val t14P = T14WubiEngine.letterToT14Code(cleanPy)

                    db.delete(
                        "user_dict",
                        "word = ? AND source_name = '自动组词'",
                        arrayOf(phrase)
                    )
                    val cv = ContentValues().apply {
                        put("word", phrase)
                        put("wubi_code", wubiCode)
                        put("pinyin_code", pinyinCode)
                        put("t14_wubi", t14W)
                        put("t14_pinyin", t14P)
                        put("weight", 9100)
                        put("source_name", "自动组词")
                    }
                    db.insert("user_dict", null, cv)
                    db.delete("user_auto_phrase_cand", "phrase = ?", arrayOf(phrase))
                    refreshPackCount(db, "自动组词")

                    // 同时为该词的五笔 T14 编码注入初始选择权重，确保下次直接打编码即可排在前面
                    if (t14W.isNotEmpty()) {
                        db.execSQL(
                            """
                            INSERT INTO user_code_mru(t14_code, word, sel_count, last_used)
                            VALUES(?, ?, 2, ?)
                            ON CONFLICT(t14_code, word) DO UPDATE SET
                                sel_count = MAX(sel_count, 2),
                                last_used = ?
                            """.trimIndent(),
                            arrayOf<Any>(t14W, phrase, now, now)
                        )
                    }

                    T14WubiEngine.markUserDictDirty()
                    T14WubiEngine.reloadUserDict(context)
                    T14WubiEngine.reloadUserLearningData(this)

                    if (onAutoPromotedMainThread != null) {
                        mainHandler.post {
                            onAutoPromotedMainThread.invoke(phrase, wubiCode, pinyinCode)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    fun getAutoPhraseCandidateProgress(): List<Pair<String, Int>> {
        val list = ArrayList<Pair<String, Int>>()
        try {
            readableDatabase.rawQuery(
                "SELECT phrase, hit_count FROM user_auto_phrase_cand ORDER BY hit_count DESC, last_seen DESC LIMIT 30",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(c.getString(0) to c.getInt(1))
                }
            }
        } catch (_: Exception) {}
        return list
    }

    /**
     * 一键重置个人高频字词排序为默认出厂排序
     */
    fun resetUserFrequencySorting() {
        try {
            val db = writableDatabase
            db.delete("user_freq", null, null)
            db.delete("user_code_mru", null, null)
            db.delete("user_bigram", null, null)
            db.delete("user_auto_phrase_cand", null, null)
        } catch (_: Exception) {}
    }

    fun loadUserFreqMap(): HashMap<String, Int> {
        val map = HashMap<String, Int>()
        try {
            readableDatabase.rawQuery("SELECT word, freq FROM user_freq", null).use { c ->
                while (c.moveToNext()) {
                    map[c.getString(0)] = c.getInt(1)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserCodeSelMap(): HashMap<String, CodeSelectionStat> {
        val map = HashMap<String, CodeSelectionStat>()
        try {
            readableDatabase.rawQuery(
                "SELECT t14_code, word, sel_count, last_used FROM user_code_mru WHERE sel_count > 0 AND last_used > 0",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val code = c.getString(0) ?: ""
                    val w = c.getString(1) ?: ""
                    val cnt = c.getInt(2).coerceAtLeast(1)
                    val lu = c.getLong(3)
                    if (code.isNotEmpty() && w.isNotEmpty()) {
                        map["$code|$w"] = CodeSelectionStat(cnt, lu)
                    }
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserCodeMruMap(): HashMap<String, Long> {
        val map = HashMap<String, Long>()
        try {
            readableDatabase.rawQuery("SELECT t14_code, word, last_used FROM user_code_mru WHERE last_used > 0", null).use { c ->
                while (c.moveToNext()) {
                    val code = c.getString(0)
                    val w = c.getString(1)
                    val lu = c.getLong(2)
                    if (code.isNotEmpty() && w.isNotEmpty()) {
                        map["$code|$w"] = lu
                    }
                }
            }
        } catch (_: Exception) {}
        return map
    }

    fun loadUserBigramMap(): HashMap<String, MutableList<String>> {
        val map = HashMap<String, MutableList<String>>()
        try {
            readableDatabase.rawQuery(
                "SELECT prev_word, next_word FROM user_bigram ORDER BY freq DESC LIMIT 2000",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val p = c.getString(0)
                    val n = c.getString(1)
                    val list = map.getOrPut(p) { ArrayList() }
                    if (list.size < 10) list.add(n)
                }
            }
        } catch (_: Exception) {}
        return map
    }

    // --- 自定义表情与颜文字增删查 ---
    fun addCustomExpression(typeCategory: String, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        val cv = ContentValues().apply {
            put("category", typeCategory)
            put("text", clean)
        }
        writableDatabase.insertWithOnConflict("custom_kaomoji", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getCustomExpressions(typeCategory: String): List<String> {
        val list = ArrayList<String>()
        try {
            readableDatabase.rawQuery(
                "SELECT text FROM custom_kaomoji WHERE category = ? ORDER BY id DESC",
                arrayOf(typeCategory)
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(c.getString(0))
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteCustomExpression(text: String) {
        writableDatabase.delete("custom_kaomoji", "text = ?", arrayOf(text))
    }

    // --- 剪贴板、常用语、个人词库与个人词频全量导出 / 导入备份 (JSON v8) ---
    fun exportBackupJson(): String {
        val root = JSONObject()
        root.put("app", "盛夏光年")
        root.put("version", 8)

        val catsArr = JSONArray()
        getCategories().forEach { catsArr.put(it) }
        root.put("categories", catsArr)

        val phrasesArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, content, is_starred, last_used FROM phrases ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("content", c.getString(1))
                    put("is_starred", c.getInt(2))
                    put("last_used", c.getLong(3))
                }
                phrasesArr.put(obj)
            }
        }
        root.put("phrases", phrasesArr)

        val clipsArr = JSONArray()
        readableDatabase.rawQuery("SELECT content, is_pinned, created_at FROM clipboard_history ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("content", c.getString(0))
                    put("is_pinned", c.getInt(1))
                    put("created_at", c.getLong(2))
                }
                clipsArr.put(obj)
            }
        }
        root.put("clipboard", clipsArr)

        val kaomojiArr = JSONArray()
        readableDatabase.rawQuery("SELECT category, text FROM custom_kaomoji ORDER BY id ASC", null).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("category", c.getString(0))
                    put("text", c.getString(1))
                }
                kaomojiArr.put(obj)
            }
        }
        root.put("custom_expressions", kaomojiArr)

        // 导出个人词条（手动添加、自动组词、以及导入词条前 10000 条）
        val userDictArr = JSONArray()
        readableDatabase.rawQuery(
            """
            SELECT word, wubi_code, pinyin_code, weight, source_name
            FROM user_dict
            ORDER BY CASE WHEN source_name IN ('手动添加', '自动组词') THEN 0 ELSE 1 END ASC, weight DESC, id DESC
            LIMIT 10000
            """.trimIndent(),
            null
        ).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("word", c.getString(0))
                    put("wubi_code", c.getString(1))
                    put("pinyin_code", c.getString(2))
                    put("weight", c.getInt(3))
                    put("source_name", c.getString(4))
                }
                userDictArr.put(obj)
            }
        }
        root.put("user_dict_entries", userDictArr)

        // 导出个人全局词频 user_freq
        val userFreqArr = JSONArray()
        readableDatabase.rawQuery(
            "SELECT word, freq, last_used FROM user_freq ORDER BY freq DESC LIMIT 5000",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("word", c.getString(0))
                    put("freq", c.getInt(1))
                    put("last_used", c.getLong(2))
                }
                userFreqArr.put(obj)
            }
        }
        root.put("user_freq", userFreqArr)

        // 导出按「编码 + 词条」区分的个人选择记录 user_code_mru
        val codeMruArr = JSONArray()
        readableDatabase.rawQuery(
            "SELECT t14_code, word, sel_count, last_used FROM user_code_mru WHERE sel_count > 0 ORDER BY sel_count DESC, last_used DESC LIMIT 5000",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("t14_code", c.getString(0))
                    put("word", c.getString(1))
                    put("sel_count", c.getInt(2))
                    put("last_used", c.getLong(3))
                }
                codeMruArr.put(obj)
            }
        }
        root.put("user_code_mru", codeMruArr)

        // 导出个人二元上下文联想 user_bigram
        val bigramArr = JSONArray()
        readableDatabase.rawQuery(
            "SELECT prev_word, next_word, freq FROM user_bigram ORDER BY freq DESC LIMIT 3000",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val obj = JSONObject().apply {
                    put("prev_word", c.getString(0))
                    put("next_word", c.getString(1))
                    put("freq", c.getInt(2))
                }
                bigramArr.put(obj)
            }
        }
        root.put("user_bigram", bigramArr)

        return root.toString(2)
    }

    fun importBackupJson(jsonStr: String): Pair<Int, Int> {
        val root = JSONObject(jsonStr)
        var phraseCount = 0
        var clipCount = 0
        val db = writableDatabase
        db.beginTransaction()
        try {
            root.optJSONArray("categories")?.let { arr ->
                for (i in 0 until arr.length()) {
                    addCategory(arr.getString(i))
                }
            }
            root.optJSONArray("phrases")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val cat = obj.optString("category", "演")
                    val content = obj.optString("content", "")
                    val starred = obj.optInt("is_starred", 0) == 1
                    if (content.isNotBlank()) {
                        addCategory(cat)
                        addOrUpdatePhrase(null, cat, content, starred)
                        phraseCount++
                    }
                }
            }
            root.optJSONArray("clipboard")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val content = obj.optString("content", "")
                    val pinned = obj.optInt("is_pinned", 0)
                    val createdAt = obj.optLong("created_at", System.currentTimeMillis())
                    if (content.isNotBlank()) {
                        val cv = ContentValues().apply {
                            put("content", content)
                            put("is_pinned", pinned)
                            put("created_at", createdAt)
                        }
                        db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                        clipCount++
                    }
                }
            }
            root.optJSONArray("custom_expressions")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    addCustomExpression(obj.optString("category", "kaomoji"), obj.optString("text", ""))
                }
            }
            // 恢复个人词条
            val touchedPacks = HashSet<String>()
            root.optJSONArray("user_dict_entries")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val w = obj.optString("word", "").trim()
                    val wc = obj.optString("wubi_code", "").trim().lowercase()
                    val py = obj.optString("pinyin_code", "").trim().lowercase()
                    val wt = obj.optInt("weight", 8500)
                    val src = obj.optString("source_name", "手动添加").trim().ifEmpty { "手动添加" }
                    if (w.isNotEmpty() && (wc.isNotEmpty() || py.isNotEmpty())) {
                        val cleanPy = py.replace("'", "")
                        val t14W = T14WubiEngine.letterToT14Code(wc)
                        val t14P = T14WubiEngine.letterToT14Code(cleanPy)
                        db.delete("user_dict", "word = ? AND wubi_code = ? AND source_name = ?", arrayOf(w, wc, src))
                        val cv = ContentValues().apply {
                            put("word", w)
                            put("wubi_code", wc)
                            put("pinyin_code", py)
                            put("t14_wubi", t14W)
                            put("t14_pinyin", t14P)
                            put("weight", wt)
                            put("source_name", src)
                        }
                        db.insert("user_dict", null, cv)
                        touchedPacks.add(src)
                    }
                }
            }
            for (pk in touchedPacks) {
                refreshPackCount(db, pk)
            }
            // 恢复个人词频 user_freq
            root.optJSONArray("user_freq")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val w = obj.optString("word", "").trim()
                    val fq = obj.optInt("freq", 1).coerceAtLeast(1)
                    val lu = obj.optLong("last_used", System.currentTimeMillis())
                    if (w.isNotEmpty()) {
                        db.execSQL(
                            "INSERT INTO user_freq(word, freq, last_used) VALUES(?, ?, ?) ON CONFLICT(word) DO UPDATE SET freq = MAX(freq, ?), last_used = MAX(last_used, ?)",
                            arrayOf<Any>(w, fq, lu, fq, lu)
                        )
                    }
                }
            }
            // 恢复按编码区分的个人选择记录 user_code_mru
            root.optJSONArray("user_code_mru")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val code = obj.optString("t14_code", "").trim()
                    val w = obj.optString("word", "").trim()
                    val sc = obj.optInt("sel_count", 1).coerceAtLeast(1)
                    val lu = obj.optLong("last_used", System.currentTimeMillis())
                    if (code.isNotEmpty() && w.isNotEmpty()) {
                        db.execSQL(
                            """
                            INSERT INTO user_code_mru(t14_code, word, sel_count, last_used)
                            VALUES(?, ?, ?, ?)
                            ON CONFLICT(t14_code, word) DO UPDATE SET
                                sel_count = MAX(sel_count, ?),
                                last_used = MAX(last_used, ?)
                            """.trimIndent(),
                            arrayOf<Any>(code, w, sc, lu, sc, lu)
                        )
                    }
                }
            }
            // 恢复二元联想 user_bigram
            root.optJSONArray("user_bigram")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val pw = obj.optString("prev_word", "").trim()
                    val nw = obj.optString("next_word", "").trim()
                    val fq = obj.optInt("freq", 1).coerceAtLeast(1)
                    if (pw.isNotEmpty() && nw.isNotEmpty()) {
                        db.execSQL(
                            "INSERT INTO user_bigram(prev_word, next_word, freq) VALUES(?, ?, ?) ON CONFLICT(prev_word, next_word) DO UPDATE SET freq = MAX(freq, ?)",
                            arrayOf<Any>(pw, nw, fq, fq)
                        )
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
            invalidateClipAndCategoryCache()
            T14WubiEngine.markUserDictDirty()
            T14WubiEngine.reloadUserLearningData(this)
        }
        return phraseCount to clipCount
    }

    @Volatile
    private var cachedClipsList: List<ClipItem>? = null

    @Volatile
    private var cachedCategoriesList: List<String>? = null

    fun invalidateClipAndCategoryCache() {
        cachedClipsList = null
        cachedCategoriesList = null
    }

    fun addClip(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        cachedClipsList = null
        dbExecutor.execute {
            try {
                val db = writableDatabase
                db.beginTransaction()
                try {
                    var pinned = 0
                    db.rawQuery(
                        "SELECT is_pinned FROM clipboard_history WHERE content = ? OR TRIM(content) = ?",
                        arrayOf(text, trimmed)
                    ).use { c ->
                        while (c.moveToNext()) {
                            if (c.getInt(0) == 1) pinned = 1
                        }
                    }
                    db.delete(
                        "clipboard_history",
                        "content = ? OR TRIM(content) = ?",
                        arrayOf(text, trimmed)
                    )
                    val cv = ContentValues().apply {
                        put("content", text)
                        put("is_pinned", pinned)
                        put("created_at", System.currentTimeMillis())
                    }
                    db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

                    db.execSQL("""
                        DELETE FROM clipboard_history
                        WHERE is_pinned = 0 AND id NOT IN (
                            SELECT id FROM clipboard_history
                            ORDER BY is_pinned DESC, created_at DESC
                            LIMIT $MAX_CLIPBOARD_ITEMS
                        )
                    """.trimIndent())
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
                cachedClipsList = null
            } catch (_: Exception) {}
        }
    }

    fun getClips(): List<ClipItem> {
        cachedClipsList?.let { return it }
        val list = ArrayList<ClipItem>(MAX_CLIPBOARD_ITEMS)
        val seen = HashSet<String>(MAX_CLIPBOARD_ITEMS)
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history ORDER BY is_pinned DESC, created_at DESC LIMIT $MAX_CLIPBOARD_ITEMS",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val content = c.getString(1)
                val norm = content.trim()
                if (seen.add(norm)) {
                    list.add(ClipItem(id, content, c.getInt(2) == 1, c.getLong(3)))
                }
            }
        }
        cachedClipsList = list
        return list
    }

    fun toggleClipPin(id: Long, currentPinned: Boolean) {
        val cv = ContentValues().apply { put("is_pinned", if (currentPinned) 0 else 1) }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
        cachedClipsList = null
    }

    fun updateClipContent(id: Long, newContent: String) {
        val trimmed = newContent.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("content", newContent)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
        cachedClipsList = null
    }

    fun getClipById(id: Long): ClipItem? {
        cachedClipsList?.firstOrNull { it.id == id }?.let { return it }
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history WHERE id = ?",
            arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                return ClipItem(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getLong(3))
            }
        }
        return null
    }

    fun deleteClip(id: Long) {
        writableDatabase.delete("clipboard_history", "id = ?", arrayOf(id.toString()))
        cachedClipsList = null
    }

    fun clearUnpinnedClips() {
        writableDatabase.delete("clipboard_history", "is_pinned = 0", null)
        cachedClipsList = null
    }

    fun getCategories(): List<String> {
        cachedCategoriesList?.let { return it }
        val list = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM phrase_categories ORDER BY sort_order ASC, id ASC", null).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        if (!list.contains("收藏")) list.add(0, "收藏")
        if (!list.contains("最近")) list.add(1, "最近")
        val res = list.distinct()
        cachedCategoriesList = res
        return res
    }

    fun getAssignableCategories(): List<String> {
        val all = getCategories().filter { it != "最近" }
        return if (all.isEmpty()) listOf("收藏", "邮", "号", "叮", "演", "扮", "模块", "api") else all
    }

    fun addCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("name", trimmed)
            put("sort_order", 99)
        }
        writableDatabase.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
        cachedCategoriesList = null
    }

    fun renameCategory(oldName: String, newName: String): Boolean {
        val cleanOld = oldName.trim()
        val cleanNew = newName.trim()
        if (cleanOld.isEmpty() || cleanNew.isEmpty() || cleanOld == "收藏" || cleanOld == "最近" || cleanNew == "最近") return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            addCategory(cleanNew)
            val cv = ContentValues().apply { put("category", cleanNew) }
            db.update("phrases", cv, "category = ?", arrayOf(cleanOld))
            if (cleanOld != cleanNew) {
                db.delete("phrase_categories", "name = ?", arrayOf(cleanOld))
            }
            db.setTransactionSuccessful()
            cachedCategoriesList = null
            return true
        } catch (_: Exception) {
            return false
        } finally {
            db.endTransaction()
        }
    }

    fun deleteCategory(name: String) {
        if (name == "收藏" || name == "最近") return
        writableDatabase.delete("phrase_categories", "name = ?", arrayOf(name))
        writableDatabase.delete("phrases", "category = ?", arrayOf(name))
        cachedCategoriesList = null
    }

    fun getPhrasesByCategory(category: String): List<PhraseItem> {
        val list = mutableListOf<PhraseItem>()
        val query = when (category) {
            "全部" -> "SELECT id, category, content, is_starred, last_used FROM phrases ORDER BY is_starred DESC, id DESC"
            "收藏" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE is_starred = 1 OR category = '收藏' ORDER BY id DESC"
            "最近" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE last_used > 0 ORDER BY last_used DESC LIMIT 50"
            else -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE category = ? ORDER BY is_starred DESC, id DESC"
        }
        val args = if (category == "全部" || category == "收藏" || category == "最近") null else arrayOf(category)
        readableDatabase.rawQuery(query, args).use { c ->
            while (c.moveToNext()) {
                list.add(PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4)))
            }
        }
        return list
    }

    fun getPhraseById(id: Long): PhraseItem? {
        readableDatabase.rawQuery(
            "SELECT id, category, content, is_starred, last_used FROM phrases WHERE id = ?",
            arrayOf(id.toString())
        ).use { c ->
            if (c.moveToFirst()) {
                return PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4))
            }
        }
        return null
    }

    fun movePhraseToCategory(id: Long, newCategory: String) {
        val cleanCat = newCategory.trim().ifEmpty { "收藏" }
        if (cleanCat != "最近") addCategory(cleanCat)
        val cv = ContentValues().apply {
            put("category", cleanCat)
            if (cleanCat == "收藏") {
                put("is_starred", 1)
            }
        }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun addOrUpdatePhrase(id: Long?, category: String, content: String, isStarred: Boolean) {
        if (content.isBlank()) return
        val targetCat = if (category == "最近" || category.isBlank()) "收藏" else category.trim()
        if (targetCat != "收藏" && targetCat != "最近") {
            addCategory(targetCat)
        }
        val cv = ContentValues().apply {
            put("category", targetCat)
            put("content", content)
            put("is_starred", if (isStarred || targetCat == "收藏") 1 else 0)
            put("last_used", System.currentTimeMillis())
        }
        if (id == null || id <= 0L) {
            writableDatabase.insert("phrases", null, cv)
        } else {
            writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
        }
    }

    fun togglePhraseStar(id: Long, currentStarred: Boolean) {
        val cv = ContentValues().apply { put("is_starred", if (currentStarred) 0 else 1) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun markPhraseUsed(id: Long) {
        val cv = ContentValues().apply { put("last_used", System.currentTimeMillis()) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deletePhrase(id: Long) {
        writableDatabase.delete("phrases", "id = ?", arrayOf(id.toString()))
    }

    fun insertUserWord(
        word: String,
        wubiCode: String,
        pinyinCode: String,
        weight: Int = 9200,
        sourceName: String = "手动添加"
    ) {
        val cleanW = word.trim()
        val cleanWubi = wubiCode.trim().lowercase()
        val cleanPy = pinyinCode.trim().lowercase()
        if (cleanW.isEmpty() || (cleanWubi.isEmpty() && cleanPy.isEmpty())) return
        val rawPy = cleanPy.replace("'", "")
        val t14Wubi = T14WubiEngine.letterToT14Code(cleanWubi)
        val t14Pinyin = T14WubiEngine.letterToT14Code(rawPy)
        val db = writableDatabase
        // 防止同一来源下同一词条+编码重复堆积
        db.delete(
            "user_dict",
            "word = ? AND wubi_code = ? AND source_name = ?",
            arrayOf(cleanW, cleanWubi, sourceName)
        )
        val cv = ContentValues().apply {
            put("word", cleanW)
            put("wubi_code", cleanWubi)
            put("pinyin_code", cleanPy)
            put("t14_wubi", t14Wubi)
            put("t14_pinyin", t14Pinyin)
            put("weight", weight)
            put("source_name", sourceName)
        }
        db.insert("user_dict", null, cv)
        refreshPackCount(db, sourceName)
        T14WubiEngine.markUserDictDirty()
    }

    fun queryUserDictRowsByWord(word: String): List<UserDictRow> {
        val clean = word.trim()
        if (clean.isEmpty()) return emptyList()
        val list = ArrayList<UserDictRow>()
        try {
            readableDatabase.rawQuery(
                "SELECT id, word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight, source_name FROM user_dict WHERE word = ? ORDER BY weight DESC, id DESC",
                arrayOf(clean)
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        UserDictRow(
                            id = c.getLong(0),
                            word = c.getString(1) ?: "",
                            wubiCode = c.getString(2) ?: "",
                            pinyinCode = c.getString(3) ?: "",
                            t14Wubi = c.getString(4) ?: "",
                            t14Pinyin = c.getString(5) ?: "",
                            weight = c.getInt(6),
                            sourceName = c.getString(7) ?: "手动添加"
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun getRecentCustomAndAutoUserWords(limit: Int = 60): List<UserDictRow> {
        val list = ArrayList<UserDictRow>()
        try {
            readableDatabase.rawQuery(
                """
                SELECT id, word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight, source_name
                FROM user_dict
                WHERE source_name IN ('手动添加', '自动组词')
                ORDER BY id DESC
                LIMIT ?
                """.trimIndent(),
                arrayOf(limit.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    list.add(
                        UserDictRow(
                            id = c.getLong(0),
                            word = c.getString(1) ?: "",
                            wubiCode = c.getString(2) ?: "",
                            pinyinCode = c.getString(3) ?: "",
                            t14Wubi = c.getString(4) ?: "",
                            t14Pinyin = c.getString(5) ?: "",
                            weight = c.getInt(6),
                            sourceName = c.getString(7) ?: "手动添加"
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteUserDictRowById(id: Long): Boolean {
        val db = writableDatabase
        var src = ""
        db.rawQuery("SELECT source_name FROM user_dict WHERE id = ?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) src = c.getString(0) ?: ""
        }
        val del = db.delete("user_dict", "id = ?", arrayOf(id.toString()))
        if (src.isNotEmpty()) {
            refreshPackCount(db, src)
        }
        T14WubiEngine.markUserDictDirty()
        return del > 0
    }

    fun importDictionaryBatch(
        packName: String,
        wordsWithCodes: List<Triple<String, String, String>>,
        weight: Int = 7200
    ): Int {
        if (wordsWithCodes.isEmpty()) return 0
        val cleanPack = packName.trim().ifEmpty { "导入词库.scel" }
        val db = writableDatabase
        var inserted = 0
        val seenInBatch = HashSet<String>(wordsWithCodes.size)
        db.beginTransaction()
        try {
            // 若同名词库包重新导入，先清理该包旧记录避免重复膨胀
            db.delete("user_dict", "source_name = ?", arrayOf(cleanPack))
            val stmt = db.compileStatement(
                "INSERT INTO user_dict(word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight, source_name) VALUES(?, ?, ?, ?, ?, ?, ?)"
            )
            for ((rawW, rawWcode, rawPy) in wordsWithCodes) {
                val w = rawW.trim()
                val wcode = rawWcode.trim().lowercase()
                val py = rawPy.trim().lowercase()
                if (w.isEmpty() || (wcode.isEmpty() && py.isEmpty())) continue
                val dedupKey = "$w|$wcode|$py"
                if (!seenInBatch.add(dedupKey)) continue

                val cleanPy = py.replace("'", "")
                val t14W = T14WubiEngine.letterToT14Code(wcode)
                val t14P = T14WubiEngine.letterToT14Code(cleanPy)
                if (t14W.isEmpty() && t14P.isEmpty()) continue

                stmt.clearBindings()
                stmt.bindString(1, w)
                stmt.bindString(2, wcode)
                stmt.bindString(3, py)
                stmt.bindString(4, t14W)
                stmt.bindString(5, t14P)
                stmt.bindLong(6, weight.toLong())
                stmt.bindString(7, cleanPack)
                stmt.executeInsert()
                inserted++
            }
            if (inserted > 0) {
                val cv = ContentValues().apply {
                    put("pack_name", cleanPack)
                    put("word_count", inserted)
                    put("imported_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        T14WubiEngine.markUserDictDirty()
        return inserted
    }

    private fun refreshPackCount(db: SQLiteDatabase, packName: String) {
        try {
            var cnt = 0
            db.rawQuery("SELECT COUNT(*) FROM user_dict WHERE source_name = ?", arrayOf(packName)).use { c ->
                if (c.moveToFirst()) cnt = c.getInt(0)
            }
            if (cnt > 0) {
                val cv = ContentValues().apply {
                    put("pack_name", packName)
                    put("word_count", cnt)
                    put("imported_at", System.currentTimeMillis())
                }
                db.insertWithOnConflict("imported_dict_packs", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
            } else {
                db.delete("imported_dict_packs", "pack_name = ?", arrayOf(packName))
            }
        } catch (_: Exception) {}
    }

    fun getImportedDictPacks(): List<ImportedDictPack> {
        val list = ArrayList<ImportedDictPack>()
        try {
            val db = readableDatabase
            db.rawQuery(
                "SELECT source_name, COUNT(*) as cnt, MAX(id) FROM user_dict GROUP BY source_name ORDER BY MAX(id) DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: "导入词库"
                    val count = c.getInt(1)
                    if (count > 0) {
                        var ts = 0L
                        db.rawQuery("SELECT imported_at FROM imported_dict_packs WHERE pack_name = ?", arrayOf(name)).use { tc ->
                            if (tc.moveToFirst()) ts = tc.getLong(0)
                        }
                        list.add(ImportedDictPack(name, count, ts))
                    }
                }
            }
        } catch (_: Exception) {}
        return list
    }

    fun deleteDictionaryPack(packName: String): Int {
        val db = writableDatabase
        val deleted = db.delete("user_dict", "source_name = ?", arrayOf(packName))
        db.delete("imported_dict_packs", "pack_name = ?", arrayOf(packName))
        T14WubiEngine.markUserDictDirty()
        return deleted
    }

    fun clearAllUserDict(): Int {
        val db = writableDatabase
        val deleted = db.delete("user_dict", null, null)
        db.delete("imported_dict_packs", null, null)
        T14WubiEngine.markUserDictDirty()
        return deleted
    }
}
