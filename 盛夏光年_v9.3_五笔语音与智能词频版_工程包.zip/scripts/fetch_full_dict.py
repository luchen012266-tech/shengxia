#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pre-compiles 86 Wubi + Segmented Pinyin + T14 Codes + Word Associations + English Dictionary at build time.
Fixes weight-scale mismatch between rime-wubi (raw counts up to 169M) and rime-ice / cn_daily_phrases / user_dict:
- Normalizes all dictionary weights onto a calibrated 2,000..14,000 scale.
- Preserves 25 standard 1-key brevity chars (一级简码) at top weight (14,000).
- Reserves dedicated capacity (up to 35,000 entries) for modern rime-ice phrases so everyday words like 吐槽 are never truncated.
- Extracts accurate full 4-letter 86 Wubi codes + stem codes into single_char_wubi.tsv for runtime phrase compounding.
"""
import math
import os
import urllib.request
from collections import defaultdict

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
RIME_ICE_8105_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/8105.dict.yaml"
RIME_ICE_BASE_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/base.dict.yaml"
RIME_ICE_ENG_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/en_dicts/en.dict.yaml"
LUNA_PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"

CHAR_TO_T14 = {
    'q': '1', 'w': '1',
    'e': '2', 'r': '2',
    't': '3', 'y': '3',
    'u': '4', 'i': '4',
    'o': '5', 'p': '5',
    'a': '6', 's': '6',
    'd': '7', 'f': '7',
    'g': '8', 'h': '8',
    'j': '9', 'k': '9',
    'l': '0',
    'z': 'a', 'x': 'a',
    'c': 'b', 'v': 'b',
    'b': 'c', 'n': 'c',
    'm': 'd'
}

LEVEL1_WUBI_MAP = {
    'g': '一', 'f': '地', 'd': '在', 's': '要', 'a': '工',
    'h': '上', 'j': '是', 'k': '中', 'l': '国', 'm': '同',
    't': '和', 'r': '的', 'e': '有', 'w': '人', 'q': '我',
    'y': '主', 'u': '产', 'i': '不', 'o': '为', 'p': '这',
    'n': '民', 'b': '了', 'v': '发', 'c': '以', 'x': '经'
}

def to_t14(s):
    return "".join(CHAR_TO_T14.get(c, "") for c in s.lower())

def to_t14_abbr(seg_py):
    if "'" not in seg_py:
        return ""
    return "".join(CHAR_TO_T14.get(p[0], "") for p in seg_py.split("'") if p)

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def clean_py_syllable(s):
    s = s.strip().lower()
    return "".join(ch for ch in s if 'a' <= ch <= 'z')

def parse_rime_yaml(lines):
    in_body = False
    for line in lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip()
            weight = -1
            stem = ""
            if len(parts) >= 3:
                w_str = parts[2].strip().rstrip("%")
                try:
                    weight = int(float(w_str))
                except ValueError:
                    weight = -1
            if len(parts) >= 4:
                stem = parts[3].strip().lower()
            yield word, code, weight, stem

def normalize_wubi_weight(word, code, raw_weight):
    if len(code) == 1 and LEVEL1_WUBI_MAP.get(code) == word:
        return 14000
    if raw_weight <= 0:
        return 4200 if len(word) <= 2 else 3600
    if raw_weight <= 12000:
        # Already on small scale
        return max(2600, min(9500, int(2600 + math.log10(max(1.0, raw_weight)) * 1650)))
    # Large corpus weight (10,000 .. 170,000,000) -> map log10 (4.0..8.25) smoothly into 4,200..9,700
    lv = math.log10(max(10.0, float(raw_weight)))
    scaled = int(3200 + (lv - 3.5) * 1380)
    if len(word) == 1 and len(code) <= 2:
        scaled += 450
    return max(2800, min(9750, scaled))

def normalize_ice_weight(word, raw_weight):
    if raw_weight <= 0:
        return 5200 if len(word) == 2 else 4600
    lv = math.log10(max(1.0, float(raw_weight)))
    scaled = int(4200 + lv * 1150)
    return max(3800, min(9200, scaled))

def main():
    wubi_lines = download_lines(WUBI_URL)
    ice_8105_lines = download_lines(RIME_ICE_8105_URL)
    ice_base_lines = download_lines(RIME_ICE_BASE_URL)
    ice_eng_lines = download_lines(RIME_ICE_ENG_URL)
    luna_lines = download_lines(LUNA_PINYIN_URL)

    # 1. Compile English dictionary
    eng_words = []
    seen_eng = set()
    curated_en_path = os.path.join(ASSETS_DIR, "en_daily_words.txt")
    if os.path.exists(curated_en_path):
        with open(curated_en_path, "r", encoding="utf-8") as cf:
            for line in cf:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                w = parts[0].strip()
                wt = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 85000
                if w and w not in seen_eng:
                    seen_eng.add(w)
                    seen_eng.add(w.lower())
                    eng_words.append((wt, w))

    if ice_eng_lines:
        for word, code, weight, _ in parse_rime_yaml(ice_eng_lines):
            clean_w = word.strip()
            if 2 <= len(clean_w) <= 20 and clean_w.isalpha() and clean_w.lower() not in seen_eng:
                seen_eng.add(clean_w.lower())
                eff_wt = weight if weight > 0 else max(500, 16000 - len(clean_w) * 700)
                eng_words.append((eff_wt, clean_w))

    eng_words.sort(key=lambda x: (-x[0], len(x[1]), x[1].lower()))
    if eng_words:
        eng_path = os.path.join(ASSETS_DIR, "english_words.tsv")
        with open(eng_path, "w", encoding="utf-8") as ef:
            for wt, w in eng_words[:30000]:
                ef.write(f"{w}\t{wt}\n")
        print(f"Compiled {min(len(eng_words), 30000)} English words!")

    if not wubi_lines:
        print("Offline mode: keeping starter dictionary.")
        return

    single_char_wubi = {}
    single_char_wubi_wt = {}
    single_char_py = {}
    single_char_weight = {}
    word_py_map = {}

    for word, raw_py, weight, _ in parse_rime_yaml(ice_8105_lines):
        wt = weight if weight > 0 else 500
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if len(word) == 1 and syllables:
            if word not in single_char_py or wt > single_char_weight.get(word, 0):
                single_char_py[word] = syllables[0]
                single_char_weight[word] = max(wt, 500)

    for word, raw_py, weight, _ in parse_rime_yaml(luna_lines):
        wt = normalize_ice_weight(word, weight)
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables:
            continue
        seg_py = "'".join(syllables)
        if len(word) == 1 and word not in single_char_py:
            single_char_py[word] = syllables[0]
        if word not in word_py_map:
            word_py_map[word] = (seg_py, wt)

    for word, raw_py, weight, _ in parse_rime_yaml(ice_base_lines):
        wt = normalize_ice_weight(word, weight)
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables or len(word) > 8:
            continue
        seg_py = "'".join(syllables)
        if word not in word_py_map or wt > word_py_map[word][1]:
            word_py_map[word] = (seg_py, wt)

    wubi_entries = []
    seen_pairs = set()
    for word, raw_code, raw_wt, stem in parse_rime_yaml(wubi_lines):
        code = raw_code.strip().lower()
        if not word or not code or not code.isalpha():
            continue
        norm_wt = normalize_wubi_weight(word, code, raw_wt)
        if len(word) == 1:
            candidate_full = stem if (len(stem) >= 2 and stem.isalpha() and len(code) < 2) else code
            prev_code = single_char_wubi.get(word, "")
            prev_wt = single_char_wubi_wt.get(word, -1)
            if (not prev_code) or (len(candidate_full) > len(prev_code)) or (len(candidate_full) == len(prev_code) and raw_wt > prev_wt):
                single_char_wubi[word] = candidate_full
                single_char_wubi_wt[word] = raw_wt
        else:
            py_wt = word_py_map.get(word, ("", 0))[1]
            if py_wt > 0:
                norm_wt = max(norm_wt, int(norm_wt * 0.65 + py_wt * 0.35))
        if (word, code) not in seen_pairs:
            seen_pairs.add((word, code))
            wubi_entries.append((word, code, norm_wt))

    def gen_wubi86(word):
        if len(word) == 1:
            return single_char_wubi.get(word, "")[:4]
        codes = [single_char_wubi.get(ch, "") for ch in word]
        if any(not c for c in codes):
            return ""
        if len(word) == 2:
            return codes[0][:2] + codes[1][:2]
        elif len(word) == 3:
            return codes[0][:1] + codes[1][:1] + codes[2][:2]
        else:
            return codes[0][:1] + codes[1][:1] + codes[2][:1] + codes[-1][:1]

    def gen_seg_pinyin(word):
        if word in word_py_map:
            return word_py_map[word][0]
        syls = [single_char_py.get(ch, "") for ch in word]
        if all(syls):
            return "'".join(syls)
        return ""

    # Inject curated cn_daily_phrases.txt with high priority normalized weight (8,600..9,650)
    curated_cn_path = os.path.join(ASSETS_DIR, "cn_daily_phrases.txt")
    if os.path.exists(curated_cn_path):
        with open(curated_cn_path, "r", encoding="utf-8") as cf:
            daily_wt = 9650
            for line in cf:
                w = line.strip()
                if not w or w.startswith("#"):
                    continue
                seg_py = gen_seg_pinyin(w)
                if seg_py:
                    word_py_map[w] = (seg_py, daily_wt)
                wcode = gen_wubi86(w)
                if wcode and (w, wcode) not in seen_pairs:
                    seen_pairs.add((w, wcode))
                    wubi_entries.append((w, wcode, daily_wt))
                daily_wt = max(8600, daily_wt - 1)

    compiled_rows = []
    seen_words_for_py = set()

    for word, wcode, weight in wubi_entries:
        seg_py = gen_seg_pinyin(word)
        seen_words_for_py.add(word)
        compiled_rows.append((word, wcode, seg_py, weight))

    # Keep top 80,000 standard Wubi entries + up to 35,000 modern rime-ice phrases so modern vocabulary is never truncated!
    compiled_rows.sort(key=lambda x: x[3], reverse=True)
    compiled_rows = compiled_rows[:80000]

    extra_py_candidates = []
    for word, (seg_py, weight) in word_py_map.items():
        if word not in seen_words_for_py and 1 <= len(word) <= 8:
            extra_py_candidates.append((weight, word, seg_py))
    extra_py_candidates.sort(reverse=True)

    for weight, word, seg_py in extra_py_candidates[:35000]:
        wcode = gen_wubi86(word)
        if wcode or seg_py:
            compiled_rows.append((word, wcode, seg_py, weight))
            seen_words_for_py.add(word)

    compiled_rows.sort(key=lambda x: x[3], reverse=True)
    compiled_rows = compiled_rows[:115000]

    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, seg_py, weight in compiled_rows:
            t14_w = to_t14(wcode) if wcode else ""
            t14_p = to_t14(seg_py.replace("'", "")) if seg_py else ""
            t14_a = to_t14_abbr(seg_py)
            f.write(f"{word}\t{wcode}\t{seg_py}\t{t14_w}\t{t14_p}\t{t14_a}\t{weight}\n")

    assoc_map = defaultdict(list)
    for word, _, _, weight in compiled_rows:
        if len(word) >= 2:
            p1 = word[0]
            s1 = word[1:]
            if len(assoc_map[p1]) < 18 and s1 not in assoc_map[p1]:
                assoc_map[p1].append(s1)
            if len(word) >= 3:
                p2 = word[:2]
                s2 = word[2:]
                if len(assoc_map[p2]) < 14 and s2 not in assoc_map[p2]:
                    assoc_map[p2].append(s2)

    assoc_path = os.path.join(ASSETS_DIR, "assoc_dict.tsv")
    with open(assoc_path, "w", encoding="utf-8") as f:
        for prefix, suffixes in assoc_map.items():
            if suffixes:
                f.write(f"{prefix}\t{','.join(suffixes)}\n")

    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    with open(single_path, "w", encoding="utf-8") as f:
        all_chars = set(single_char_wubi.keys()) | set(single_char_py.keys())
        for ch in sorted(all_chars):
            wcode = single_char_wubi.get(ch, "")
            py = single_char_py.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    print(f"Pre-compiled {len(compiled_rows)} entries and {len(assoc_map)} association prefixes!")

if __name__ == "__main__":
    main()
