package com.shengxiaguangnian.ime

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.HapticFeedbackConstants
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewParent
import android.view.WindowManager
import android.widget.*
import kotlin.math.abs

class ShengXiaImeService : InputMethodService() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var prefs: SharedPreferences
    private var skin: SkinConfig = SkinConfig()
    private var lastRenderedEnterText: String = ""

    private val composingT14 = StringBuilder()
    private val composingRawLetters = StringBuilder()
    private val composingEnglish = StringBuilder()

    private var currentCandidates: List<Candidate> = emptyList()
    private var currentAssociations: List<String> = emptyList()
    private var currentEnglishSuggestions: List<String> = emptyList()
    private var lastCommittedWord: String? = null

    private var isEnglishMode = false
    private var isShiftLocked = false
    private var isNumberPadMode = false
    private var isSymbolLocked = false
    private var currentSymbolCategory = "最近"

    private enum class PanelState {
        KEYBOARD,
        CANDIDATE_GRID,
        CLIPBOARD_PHRASE,
        EMOJI_KAOMOJI,
        SYMBOLS,
        QUICK_HEIGHT_SETTINGS,
        VOICE_INPUT
    }
    private var currentPanel = PanelState.KEYBOARD

    private var speechRecognizer: SpeechRecognizer? = null
    private var isVoiceListening: Boolean = false
    private var voiceWaveView: StarlightVoiceWaveView? = null
    private var voiceStatusTv: TextView? = null
    private var voicePreviewTv: TextView? = null
    private var voiceActionBtnTv: TextView? = null
    private var symbolCategoryScrollY: Int = 0
    private var topVoicePreviewTv: TextView? = null
    private var lastPartialVoiceText: String = ""
    private var voiceListenStartElapsedMs: Long = 0L
    private var voiceStartInvokeElapsedMs: Long = 0L
    private var voiceEndOfSpeechSeen: Boolean = false
    private var voiceEndOfSpeechAtSec: Double = -1.0
    private val voiceDebugLogs = ArrayList<String>()
    private val hideVoiceTopPreviewRunnable = Runnable { hideVoiceLiveTextInTopBar() }
    private val voiceTimerRunnable = object : Runnable {
        override fun run() {
            if (isVoiceListening && currentPanel == PanelState.VOICE_INPUT) {
                val sec = ((SystemClock.elapsedRealtime() - voiceListenStartElapsedMs) / 1000L).coerceAtLeast(1L)
                val secStr = if (sec < 10L) "0$sec" else "$sec"
                voiceStatusTv?.text = "聆听中 · ${secStr}s"
                mainHandler.postDelayed(this, 500L)
            }
        }
    } 

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainVerticalLayout: LinearLayout
    private lateinit var topWrapper: FrameLayout
    private var topBarMonetBgView: MonetPaintedBgView? = null
    private var topBarBacklightOverlay: KeyboardBacklightOverlayView? = null
    private lateinit var topIdleBar: LinearLayout
    private lateinit var topCandidateBar: LinearLayout
    private lateinit var topClipboardTipBar: LinearLayout
    private lateinit var topClipboardTipTv: TextView
    private var pendingCopiedText: String = ""
    private var lastCopiedTimestampMs: Long = 0L
    private var lastRenderedCustomBgTs: Long = -1L
    private var lastRenderedBlurLevel: Int = -1
    private var lastRenderedFontTs: Long = -1L
    private var lastRenderedTopIconTs: Long = -1L
    private val topBarIconViews = ArrayList<MinimalistIconView>()
    private var customCoverDrawable: CustomCoverBgDrawable? = null
    private val hideClipboardTipRunnable = Runnable { hideClipboardTipBanner() }

    private lateinit var candidateHScroll: HorizontalScrollView
    private lateinit var candidateScrollContainer: LinearLayout
    private val candidatePoolViews = ArrayList<TextView>(36)
    private lateinit var bodyFrame: FrameLayout

    private var composingPopup: PopupWindow? = null
    private var composingPillTv: TextView? = null
    private var popupWindow: PopupWindow? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
            if (text.isNotBlank()) {
                dbHelper.addClip(text)
                pendingCopiedText = text
                lastCopiedTimestampMs = System.currentTimeMillis()
                showClipboardTipBanner(text)
                if (currentPanel == PanelState.CLIPBOARD_PHRASE && !isPhraseSubTab) {
                    mainHandler.postDelayed({
                        if (currentPanel == PanelState.CLIPBOARD_PHRASE) {
                            showClipboardPhrasePanel()
                        }
                    }, 60L)
                }
            }
        }
    }

    private fun showClipboardTipBanner(copiedText: String) {
        if (!::topClipboardTipBar.isInitialized || !::topClipboardTipTv.isInitialized) return
        val oneLine = copiedText.replace("\n", " ").replace("\r", " ").trim()
        topClipboardTipTv.text = oneLine
        if (::topCandidateBar.isInitialized && topCandidateBar.visibility != View.VISIBLE) {
            topIdleBar.visibility = View.GONE
            topClipboardTipBar.visibility = View.VISIBLE
        }
        mainHandler.removeCallbacks(hideClipboardTipRunnable)
        mainHandler.postDelayed(hideClipboardTipRunnable, 8500L)
    }

    private fun hideClipboardTipBanner() {
        mainHandler.removeCallbacks(hideClipboardTipRunnable)
        if (::topClipboardTipBar.isInitialized) {
            topClipboardTipBar.visibility = View.GONE
        }
        if (::topCandidateBar.isInitialized && ::topIdleBar.isInitialized) {
            if (topCandidateBar.visibility != View.VISIBLE && topVoicePreviewTv?.visibility != View.VISIBLE) {
                topIdleBar.visibility = View.VISIBLE
            }
        }
    }

    private fun showVoiceLiveTextInTopBar(voiceText: String, autoHideMs: Long = 0L) {
        val clean = voiceText.replace("\n", " ").replace("\r", " ").trim()
        if (clean.isEmpty()) return
        val pv = topVoicePreviewTv ?: return
        mainHandler.removeCallbacks(hideVoiceTopPreviewRunnable)
        pv.text = clean
        if (::topClipboardTipBar.isInitialized) topClipboardTipBar.visibility = View.GONE
        if (::topCandidateBar.isInitialized) topCandidateBar.visibility = View.GONE
        if (::topIdleBar.isInitialized) topIdleBar.visibility = View.GONE
        pv.visibility = View.VISIBLE
        if (autoHideMs > 0L) {
            mainHandler.postDelayed(hideVoiceTopPreviewRunnable, autoHideMs)
        }
    }

    private fun hideVoiceLiveTextInTopBar() {
        mainHandler.removeCallbacks(hideVoiceTopPreviewRunnable)
        topVoicePreviewTv?.visibility = View.GONE
        if (::topCandidateBar.isInitialized && ::topIdleBar.isInitialized) {
            if (topCandidateBar.visibility != View.VISIBLE &&
                (!::topClipboardTipBar.isInitialized || topClipboardTipBar.visibility != View.VISIBLE)
            ) {
                topIdleBar.visibility = View.VISIBLE
            }
        }
    }

    private val onDictReadyRefresh: () -> Unit = {
        if (::topCandidateBar.isInitialized) {
            if (composingT14.isNotEmpty()) {
                refreshCandidates()
            } else if (composingEnglish.isNotEmpty()) {
                refreshEnglishCandidates()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        dbHelper = ImeDatabaseHelper(this)
        prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        skin = CssSkinManager.getSkin(this)
        MonetTextureManager.ensureLoaded(this)
        KeySoundManager.ensureInitialized(this)
        T14WubiEngine.ensureInitializedAsync(this, dbHelper, onDictReadyRefresh)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyVoiceRecognizer()
        dismissComposingPopup()
        dismissPopup()
        try {
            clipboardManager.removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {}
    }

    private fun getKeyboardHeightDp(): Int {
        val screenWidthDp = resources.configuration.screenWidthDp
        val defaultDp = if (screenWidthDp >= 600) 330 else 285
        return prefs.getInt("keyboard_height_dp", defaultDp).coerceIn(200, 500)
    }

    private fun setKeyboardHeightDp(newDp: Int) {
        val clamped = newDp.coerceIn(200, 500)
        prefs.edit().putInt("keyboard_height_dp", clamped).apply()
        if (::bodyFrame.isInitialized) {
            val lp = bodyFrame.layoutParams
            lp.height = dp(clamped)
            bodyFrame.layoutParams = lp
        }
    }

    private fun getCustomEnterLabel(): String {
        val custom = prefs.getString("custom_enter_text", "")?.trim() ?: ""
        val raw = if (custom.isNotEmpty()) custom else skin.enterText
        if (raw.contains("\\n")) return raw.replace("\\n", "\n")
        if (raw.contains("\n")) return raw
        if (raw.contains("/")) return raw.replace("/", "\n")
        return when (raw.length) {
            4 -> raw.substring(0, 2) + "\n" + raw.substring(2, 4)
            5 -> raw.substring(0, 3) + "\n" + raw.substring(3, 5)
            6 -> raw.substring(0, 3) + "\n" + raw.substring(3, 6)
            else -> raw
        }
    }

    private fun getKeyFontScale(): Float {
        return prefs.getFloat("key_font_scale", 1.0f).coerceIn(0.45f, 1.5f)
    }

    private fun setKeyFontScale(scale: Float) {
        prefs.edit().putFloat("key_font_scale", scale.coerceIn(0.45f, 1.5f)).apply()
    }

    // 英文 26 键拥有完全独立的字号缩放比例，不与中文 14 键互相牵连！
    private fun getEngKeyFontScale(): Float {
        return prefs.getFloat("eng_key_font_scale", 1.0f).coerceIn(0.55f, 1.6f)
    }

    private fun setEngKeyFontScale(scale: Float) {
        prefs.edit().putFloat("eng_key_font_scale", scale.coerceIn(0.55f, 1.6f)).apply()
    }

    // 底部与两侧功能键（通配、符、123、逗号、句号、空格、中/英、回车/盛夏光年）独立字号缩放（支持 CSS --func-font-scale）
    private fun getFuncKeyFontScale(): Float {
        val userScale = prefs.getFloat("func_key_font_scale", 1.0f).coerceIn(0.6f, 1.8f)
        return (userScale * skin.funcFontScale).coerceIn(0.6f, 2.0f)
    }

    private fun setFuncKeyFontScale(scale: Float) {
        prefs.edit().putFloat("func_key_font_scale", scale.coerceIn(0.6f, 1.8f)).apply()
    }

    // 英文 26 键默认缩放设为 0.86f，搭配 17.5sp 纤细基准字号，使英文字母与中文双字母视觉粗细完美一致
    /**
     * 双层皮肤架构：
     * 仅「莫奈花园」（CSS 含 decor: water-lily）作为唯一自带油画贴图的特殊皮肤；
     * 其余所有皮肤（包括纯色系与自定义 CSS）全部统一采用「纯色与自定义背景图毛玻璃框架」！
     */
    private fun isWaterLilyDecorEnabled(): Boolean {
        return skin.waterLilyDecor
    }

    private fun isCustomBgFrostedEnabled(): Boolean {
        return !isWaterLilyDecorEnabled() && CustomBgManager.hasCustomBg(this)
    }

    private fun isKeyGlowEnabled(): Boolean {
        val mode = prefs.getString("key_glow_mode", "on") ?: "on"
        return when (mode) {
            "on" -> true
            "off" -> false
            else -> skin.keyGlowEnabled
        }
    }

    /**
     * 智能灵动同色系采色算法（兼顾「不荧光」与「绝不发灰变深」）：
     * - 针对浅色键盘（如樱花粉 #FFF5F7、焦糖奶油 #FAF3EB、浅薰衣草 #F3EFFB，明度 v >= 0.80）：
     *   之前降低明度 v 会导致低饱和度浅色直接变成死气沉沉的水泥灰；
     *   现在保持高明度 (0.91~0.96) 并温和提升同色相饱和度 (0.30~0.44)，让浅粉键采出灵动的樱花蜜桃粉 (#F5ABBA)、
     *   浅焦糖键采出温暖的杏仁奶茶色 (#F0CEA8)！
     * - 针对中等/深色按键 (v < 0.80)：保持柔和莫兰迪饱和度 (0.28~0.45) 与温润明度 (0.72~0.86)，绝不刺眼荧光。
     */
    /**
     * 自动提取当前皮肤最具代表性的主题有彩色（用于在黑粉、黑金、暗夜等皮肤中引导低色度深色键的背光色相，绝不串色！）
     */
    private fun resolveSkinThemeTintColor(): Int {
        val spaceBg = skin.resolveKeyStyle(4, "space", false, false).bgTop ?: skin.keyBgTop
        val r1Bg = skin.resolveKeyStyle(1, "qw", false, false).bgTop ?: skin.keyBgTop
        val r2Bg = skin.resolveKeyStyle(2, "df", false, false).bgTop ?: skin.keyBgTop
        val r3Bg = skin.resolveKeyStyle(3, "zx", false, false).bgTop ?: skin.keyBgTop
        val isDark = getColorLuminance(skin.kbBgTop) < 0.35 || getColorLuminance(skin.topBarBgTop) < 0.35
        // 浅色皮肤严禁把深色文字颜色 (topBarText / funcKeyText) 或过暗标点键当成主题流光色，防止浅色背景混入深棕/深灰文字色！
        val pool = if (isDark) {
            listOf(
                r2Bg,
                r1Bg,
                spaceBg,
                skin.candidateHighlight,
                skin.topBarText,
                skin.funcKeyText,
                skin.punctKeyBgTop,
                r3Bg
            )
        } else {
            listOf(
                spaceBg,
                r2Bg,
                r1Bg,
                r3Bg,
                skin.funcKeyBgTop,
                skin.candidateHighlight
            )
        }
        var bestCol = if (isDark) skin.candidateHighlight else spaceBg
        var bestScore = -1f
        val hsv = FloatArray(3)
        for (col in pool) {
            Color.colorToHSV(col, hsv)
            val s = hsv[1]
            val v = hsv[2]
            val minV = if (isDark) 0.22f else 0.52f
            val targetV = if (isDark) 0.72f else 0.88f
            val score = s * (1f - kotlin.math.abs(v - targetV) * 0.55f)
            if (v > minV && s > 0.04f && score > bestScore) {
                bestScore = score
                bestCol = col
            }
        }
        return bestCol
    }

    private fun resolveGlowColorForKey(@Suppress("UNUSED_PARAMETER") keyId: String, finalKeyBg: Int): Int {
        return OklchBacklightExtractor.extractGlowColor(
            finalKeyBgColor = finalKeyBg,
            kbBgColor = skin.kbBgTop,
            themeTintColor = resolveSkinThemeTintColor(),
            explicitCssGlowColor = skin.keyGlowColor
        )
    }

    private fun resolveGlowColorForTopBar(): Int {
        return OklchBacklightExtractor.extractGlowColor(
            finalKeyBgColor = skin.topBarBgTop,
            kbBgColor = skin.kbBgTop,
            themeTintColor = resolveSkinThemeTintColor(),
            explicitCssGlowColor = skin.keyGlowColor
        )
    }

    private fun attachTopBarTouchGlowAndSound(targetView: View) {
        targetView.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    KeySoundManager.playClick(this@ShengXiaImeService)
                    if (isKeyGlowEnabled()) {
                        topBarBacklightOverlay?.triggerKeyDown(
                            v,
                            dp(skin.topBarRadiusDp).toFloat(),
                            resolveGlowColorForTopBar(),
                            skin.topBarBgTop
                        )
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    topBarBacklightOverlay?.triggerKeyUp(v)
                }
            }
            false
        }
    }

    /**
     * 候选词与选字区域仅触发清脆按键音效，不触发背光与星芒光晕，避免快速打字时干扰看字选字！
     */
    private fun attachCandidateTouchSoundOnly(targetView: View) {
        targetView.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                KeySoundManager.playClick(this@ShengXiaImeService)
            }
            false
        }
    }

    /**
     * 智能按键文字与数字角标防隐身保护：
     * 解决当某排按键底色（如黑粉皮肤第2排 #C1A0AB）与全局 hint-color 接近或相同时，右上角/右下角数字 7、8 隐身消失的问题！
     */
    private fun ensureReadableKeyTextColor(fgColor: Int, keyBgColor: Int, refMainTextColor: Int, isHint: Boolean): Int {
        val bgLum = getColorLuminance(keyBgColor)
        // 先确保参考主字色在当前按键底色上绝对清晰
        val safeMainText = if (kotlin.math.abs(getColorLuminance(refMainTextColor) - bgLum) < 0.26 || colorDiffDistance(refMainTextColor, keyBgColor) < 115) {
            if (bgLum >= 0.45) Color.parseColor("#231F26") else Color.parseColor("#F7F2F5")
        } else {
            refMainTextColor
        }
        if (!isHint) return safeMainText

        val fgLum = getColorLuminance(fgColor)
        val lumDiff = kotlin.math.abs(fgLum - bgLum)
        val rgbDist = colorDiffDistance(fgColor, keyBgColor)
        // 若角标颜色与当前键帽背景色过于接近（如 DF 键上的 7 和 GH 键上的 8），自动按主字色 68% + 键帽底色 32% 混合出清晰高级的同系角标色！
        if (lumDiff < 0.21 || rgbDist < 98) {
            return blendColors(keyBgColor, safeMainText, 0.68f)
        }
        return fgColor
    }

    private fun blendColors(c1: Int, c2: Int, ratioC2: Float): Int {
        val f = ratioC2.coerceIn(0f, 1f)
        val r = (Color.red(c1) * (1f - f) + Color.red(c2) * f).toInt().coerceIn(0, 255)
        val g = (Color.green(c1) * (1f - f) + Color.green(c2) * f).toInt().coerceIn(0, 255)
        val b = (Color.blue(c1) * (1f - f) + Color.blue(c2) * f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private fun isSkinDarkTheme(): Boolean {
        return getColorLuminance(skin.kbBgTop) < 0.35 || getColorLuminance(skin.topBarBgTop) < 0.35
    }

    private fun getAdaptivePanelBgColor(): Int {
        return if (isSkinDarkTheme()) {
            blendColors(skin.kbBgTop, skin.topBarBgTop, 0.35f)
        } else {
            blendColors(skin.kbBgTop, Color.parseColor("#F5F6FA"), 0.55f)
        }
    }

    private fun getAdaptivePanelHeaderBgColor(): Int {
        return if (isSkinDarkTheme()) {
            blendColors(skin.topBarBgTop, Color.WHITE, 0.06f)
        } else {
            blendColors(skin.topBarBgTop, Color.parseColor("#E6E8EF"), 0.45f)
        }
    }

    private fun getAdaptiveCardBgColor(highlighted: Boolean = false): Int {
        return if (isSkinDarkTheme()) {
            val baseDark = if (getColorLuminance(skin.topBarBgTop) > getColorLuminance(skin.kbBgTop)) skin.topBarBgTop else skin.funcKeyBgTop
            val lifted = blendColors(baseDark, Color.WHITE, if (highlighted) 0.18f else 0.10f)
            if (kotlin.math.abs(getColorLuminance(lifted) - getColorLuminance(getAdaptivePanelBgColor())) < 0.06) {
                blendColors(getAdaptivePanelBgColor(), Color.WHITE, if (highlighted) 0.20f else 0.12f)
            } else {
                lifted
            }
        } else {
            if (highlighted) blendColors(Color.WHITE, resolveDynamicCandidateHighlightColor(), 0.14f) else Color.WHITE
        }
    }

    private fun getAdaptiveCardStrokeColor(): Int {
        return if (isSkinDarkTheme()) {
            val tint = resolveSkinThemeTintColor()
            Color.argb(65, Color.red(tint), Color.green(tint), Color.blue(tint))
        } else {
            Color.parseColor("#E2E5EC")
        }
    }

    // ==================== 1~3 键和谐随机跳色系统 ====================
    private fun isRandomAccentEnabled(): Boolean {
        return !isWaterLilyDecorEnabled() && prefs.getBoolean("random_accent_enabled", true)
    }

    private fun reshuffleRandomAccentKeys() {
        val newSeed = (System.currentTimeMillis() xor System.nanoTime()).toInt()
        prefs.edit()
            .putInt("random_accent_seed", newSeed)
            .putBoolean("force_shuffle_on_preset_keys", true)
            .apply()
    }

    private fun resolveRandomAccentBg(keyId: String, rowIndex: Int, normalBg: Int): Int? {
        if (!isRandomAccentEnabled()) return null
        val seed = prefs.getInt("random_accent_seed", 20261016)
        val all14 = listOf("qw", "er", "ty", "ui", "op", "as", "df", "gh", "jk", "l", "zx", "cv", "bn", "m")
        val all26 = listOf(
            "q", "w", "e", "r", "t", "y", "u", "i", "o", "p",
            "a", "s", "d", "f", "g", "h", "j", "k", "l",
            "z", "x", "c", "v", "b", "n", "m"
        )
        val clean = keyId.trim().lowercase()
        // 若当前皮肤（如图4 豆沙玫瑰樱花粉）已在 CSS 中专门指定了 4 个及以上按键的固定跳色，且未手动点「换跳色位置」，则直接保持原貌
        val explicit14Count = skin.keyOverrides.keys.count { it in all14 }
        if (explicit14Count >= 4 && !prefs.getBoolean("force_shuffle_on_preset_keys", false)) {
            return null
        }
        // 已在 CSS 中单独指定了颜色的按键不被随机跳色覆盖
        if (skin.keyOverrides[clean]?.bgTop != null) return null
        val rng = java.util.Random(seed.toLong() xor (skin.kbBgTop.toLong() shl 16) xor (skin.funcKeyBgTop.toLong()))
        val count = 2 + (kotlin.math.abs(seed) % 2) // 随机 2~3 个跳色键
        val picked14 = all14.shuffled(rng).take(count)
        val picked26 = all26.shuffled(rng).take(count)

        val idx = when {
            clean in picked14 -> picked14.indexOf(clean)
            clean in picked26 -> picked26.indexOf(clean)
            else -> -1
        }
        if (idx < 0) return null

        val spaceBg = skin.resolveKeyStyle(4, "space", false, false).bgTop ?: skin.keyBgTop
        val r1Bg = skin.resolveKeyStyle(1, "qw", false, false).bgTop ?: skin.keyBgTop
        val r2Bg = skin.resolveKeyStyle(2, "df", false, false).bgTop ?: skin.keyBgTop
        val r3Bg = skin.resolveKeyStyle(3, "zx", false, false).bgTop ?: skin.keyBgTop

        val isDarkTheme = getColorLuminance(skin.kbBgTop) < 0.30 || getColorLuminance(skin.topBarBgTop) < 0.30
        val tintCol = resolveSkinThemeTintColor()
        val hsv = FloatArray(3)
        Color.colorToHSV(tintCol, hsv)
        val themeHue = hsv[0]

        // 构建大胆灵动、同时与整体皮肤协调搭配的撞色池（复刻图3 暗夜黑金的樱花粉 #F5B8C8 + 奶黄金 #F4CE85 大胆撞色质感！）
        val rawCandidates = ArrayList<Int>()
        if (isDarkTheme) {
            if (themeHue in 18f..68f || hsv[1] < 0.15f) {
                // 暗夜黑金 / 黑金帝国主题：复刻图3 经典大胆跳色（樱花蜜桃粉 #F5B8C8 + 奶黄金 #F4CE85 + 流光香槟金 #E5C07A + 曜石黑）
                rawCandidates.add(Color.parseColor("#F5B8C8"))
                rawCandidates.add(Color.parseColor("#F4CE85"))
                rawCandidates.add(Color.parseColor("#E5C07A"))
                rawCandidates.add(spaceBg)
                rawCandidates.add(skin.funcKeyBgTop)
            } else {
                // 暗夜夜樱 / 深色紫粉等暗色主题：柔雾樱粉 + 豆沙玫瑰 + 暖香槟金 + 自身跨排色
                rawCandidates.add(spaceBg)
                rawCandidates.add(if (rowIndex == 1) r2Bg else r1Bg)
                rawCandidates.add(if (rowIndex == 3) r2Bg else r3Bg)
                rawCandidates.add(Color.parseColor("#F5B8C8"))
                rawCandidates.add(Color.parseColor("#C98CA2"))
                rawCandidates.add(Color.parseColor("#F4CE85"))
                rawCandidates.add(skin.funcKeyBgTop)
            }
        } else {
            // 浅色/莫兰迪/马卡龙主题：优先融合自身跨排点睛色 + 与皮肤色相呼应的大胆撞色
            rawCandidates.add(spaceBg)
            rawCandidates.add(if (rowIndex == 1) r2Bg else r1Bg)
            rawCandidates.add(if (rowIndex == 3) r2Bg else r3Bg)
            rawCandidates.add(skin.punctKeyBgTop)
            when {
                themeHue in 120f..242f -> {
                    // 薄荷绿 / 雾霾蓝 / 青蓝系：大胆搭配奶黄金与蜜桃樱粉撞色
                    rawCandidates.add(Color.parseColor("#F4CE85"))
                    rawCandidates.add(Color.parseColor("#F5B8C8"))
                    rawCandidates.add(Color.parseColor("#2CB3B6"))
                }
                themeHue in 242f..315f -> {
                    // 薰衣草紫 / 丁香紫系：大胆搭配樱花粉、暖奶黄与鸢尾紫
                    rawCandidates.add(Color.parseColor("#F7C8D4"))
                    rawCandidates.add(Color.parseColor("#F4CE85"))
                    rawCandidates.add(Color.parseColor("#8B6FC9"))
                }
                themeHue >= 315f || themeHue < 15f -> {
                    // 樱花粉 / 豆沙玫瑰系：大胆搭配树莓红、深玫瑰与暖奶杏
                    rawCandidates.add(Color.parseColor("#C55669"))
                    rawCandidates.add(Color.parseColor("#8B4F5B"))
                    rawCandidates.add(Color.parseColor("#F4CE85"))
                }
                else -> {
                    // 焦糖拿铁 / 暖杏美拉德系：大胆搭配奶泡金、焦糖肉桂与太妃棕
                    rawCandidates.add(Color.parseColor("#F2CCA0"))
                    rawCandidates.add(Color.parseColor("#C87A5B"))
                    rawCandidates.add(Color.parseColor("#F5B8C8"))
                }
            }
            rawCandidates.add(skin.funcKeyBgTop)
        }

        // 去重并过滤掉与当前键底色过于接近的颜色，确保每个跳色键各具鲜明色彩（绝不全部变成同一种灰黑色）
        val distinctPalette = ArrayList<Int>()
        for (col in rawCandidates) {
            if (colorDiffDistance(col, normalBg) > 38 && distinctPalette.none { colorDiffDistance(it, col) < 24 }) {
                distinctPalette.add(col)
            }
        }

        if (distinctPalette.isNotEmpty()) {
            val offset = kotlin.math.abs(seed / 7) % distinctPalette.size
            return distinctPalette[(idx + offset) % distinctPalette.size]
        }
        val fallbackAccent = blendColors(normalBg, tintCol, 0.42f)
        return if (colorDiffDistance(fallbackAccent, normalBg) > 25) fallbackAccent else null
    }

    private fun colorDiffDistance(c1: Int, c2: Int): Int {
        return kotlin.math.abs(Color.red(c1) - Color.red(c2)) +
            kotlin.math.abs(Color.green(c1) - Color.green(c2)) +
            kotlin.math.abs(Color.blue(c1) - Color.blue(c2))
    }

    /**
     * 按键字母 5 位置对齐模式（解锁莫奈花园，所有皮肤均支持自由切换或通过 CSS justify-content + align-items 控制）：
     * 支持："center"(居中)、"top-left"(左上)、"top-right"(右上)、"bottom-left"(左下)、"bottom-right"(右下)
     */
    private fun getKeyAlignMode(): String {
        val userMode = prefs.getString("key_label_align_mode", "auto") ?: "auto"
        return if (userMode == "auto") skin.keyAlign else userMode
    }

    private fun cycleKeyAlignMode(): String {
        val order = listOf("center", "top-left", "top-right", "bottom-left", "bottom-right")
        val cur = getKeyAlignMode()
        val next = order[(order.indexOf(cur).coerceAtLeast(0) + 1) % order.size]
        prefs.edit().putString("key_label_align_mode", next).apply()
        return next
    }

    private fun getKeyAlignDisplayName(mode: String): String {
        return when (mode) {
            "top-left" -> "左上"
            "top-right" -> "右上"
            "bottom-left" -> "左下"
            "bottom-right" -> "右下"
            else -> "居中"
        }
    }

    private fun getColorLuminance(color: Int): Double {
        val r = Color.red(color) / 255.0
        val g = Color.green(color) / 255.0
        val b = Color.blue(color) / 255.0
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    /**
     * 候选词普通文字动态对比度保护（深底自动亮字，浅底自动深字）
     */
    private fun resolveDynamicCandidateTextColor(): Int {
        val barLum = getColorLuminance(skin.topBarBgTop)
        val txtLum = getColorLuminance(skin.candidateText)
        return if (barLum >= 0.45) {
            // 浅色顶栏：普通候选字必须为深色（优先回退到当前皮肤按键深色字，保持同色系）
            if (txtLum > 0.52) {
                if (getColorLuminance(skin.keyText) <= 0.48) skin.keyText else Color.parseColor("#2B3445")
            } else {
                skin.candidateText
            }
        } else {
            // 深色顶栏（如暗夜黑金）：普通候选字必须为亮色
            if (txtLum < 0.48) Color.parseColor("#ECEEF4") else skin.candidateText
        }
    }

    /**
     * 判断当前皮肤本身是否属于蓝色/青蓝色系主题
     */
    private fun isSkinPaletteBlueFamily(): Boolean {
        val checkCols = listOf(
            skin.topBarBgTop,
            skin.candidateText,
            skin.topBarText,
            skin.keyText,
            skin.keyBgTop,
            skin.funcKeyBgTop
        )
        val hsv = FloatArray(3)
        for (c in checkCols) {
            Color.colorToHSV(c, hsv)
            if (hsv[1] >= 0.10f && hsv[0] in 185f..246f) {
                return true
            }
        }
        return false
    }

    /**
     * 首选 1 号字颜色解析（100% 忠于 CSS 原色 + 仅在撞底隐形或 AI 误写时温和回退）：
     * - 彻底解决图1 夜樱绽放等深色皮肤下首选字被强行拉高饱和度变成亮玫粉 (#EB80B4) 的问题！
     * - 深色顶栏 (barLum < 0.45)：只要 CSS 的 highlight-color 明度 >= 0.26（无论是淡樱粉、豆沙粉、香槟金还是纯白），
     *   100% 原样保留 CSS 颜色，绝不篡改饱和度或明度！仅当颜色过黑看不清时回退到普通候选词色。
     * - 浅色顶栏 (barLum >= 0.45)：仅当 DeepSeek 将 highlight-color 设成了纯白/过浅色（导致在浅色顶栏上隐身）
     *   或在非蓝色皮肤里误留了模板蓝色时，自动回退到当前皮肤自身的候选词主文字色，绝不变蓝或变刺眼荧光色！
     */
    private fun resolveDynamicCandidateHighlightColor(): Int {
        val barLum = getColorLuminance(skin.topBarBgTop)
        val hl = skin.candidateHighlight
        val hlLum = getColorLuminance(hl)
        val hsv = FloatArray(3)
        Color.colorToHSV(hl, hsv)

        val isStrayBlueHighlight = (hsv[0] in 192f..242f && hsv[1] >= 0.15f && !isSkinPaletteBlueFamily())
        if (isStrayBlueHighlight) {
            return resolveDynamicCandidateTextColor()
        }

        return if (barLum >= 0.45) {
            // 浅色顶栏：仅当高亮色太浅（如纯白 #FFFFFF 导致与浅底撞色看不清）时，温和回退为当前皮肤候选词深色字
            if (hlLum > 0.68 || kotlin.math.abs(hlLum - barLum) < 0.18) {
                resolveDynamicCandidateTextColor()
            } else {
                hl
            }
        } else {
            // 深色顶栏（如图1 夜樱绽放、暗夜黑金）：只要不是死黑看不清，100% 忠实呈现 CSS 原本设定的颜色！
            if (hlLum < 0.25 || kotlin.math.abs(hlLum - barLum) < 0.15) {
                resolveDynamicCandidateTextColor()
            } else {
                hl
            }
        }
    }

    private fun openSkinSettingsBackend() {
        KeySoundManager.playClick(this)
        try {
            val intent = Intent(this, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("open_tab", "skin_settings")
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    // ==================== 全选 / 剪切 / 复制 / 粘贴 快捷编辑动作 ====================
    private fun performSelectAllAction() {
        KeySoundManager.playClick(this)
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
        }
        currentInputConnection?.performContextMenuAction(android.R.id.selectAll)
        Toast.makeText(this, "已全选", Toast.LENGTH_SHORT).show()
    }

    private fun performCutAction() {
        KeySoundManager.playClick(this)
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
        }
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) {
            dbHelper.addClip(selected)
            ic.performContextMenuAction(android.R.id.cut)
            Toast.makeText(this, "已剪切选中文字", Toast.LENGTH_SHORT).show()
        } else {
            ic.performContextMenuAction(android.R.id.selectAll)
            val allSel = ic.getSelectedText(0)?.toString()
            if (!allSel.isNullOrEmpty()) {
                dbHelper.addClip(allSel)
            }
            ic.performContextMenuAction(android.R.id.cut)
            Toast.makeText(this, "已剪切全部文字", Toast.LENGTH_SHORT).show()
        }
    }

    private fun performCopyAction() {
        KeySoundManager.playClick(this)
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
        }
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) {
            ic.performContextMenuAction(android.R.id.copy)
            dbHelper.addClip(selected)
            pendingCopiedText = selected
            lastCopiedTimestampMs = System.currentTimeMillis()
            showClipboardTipBanner(selected)
            Toast.makeText(this, "已复制选中文字", Toast.LENGTH_SHORT).show()
        } else {
            val before = ic.getTextBeforeCursor(100000, 0)?.toString() ?: ""
            val after = ic.getTextAfterCursor(100000, 0)?.toString() ?: ""
            val full = before + after
            if (full.isNotBlank()) {
                val clip = android.content.ClipData.newPlainText("text", full)
                clipboardManager.setPrimaryClip(clip)
                dbHelper.addClip(full)
                pendingCopiedText = full
                lastCopiedTimestampMs = System.currentTimeMillis()
                showClipboardTipBanner(full)
                Toast.makeText(this, "已复制输入框文字", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun performPasteAction() {
        KeySoundManager.playClick(this)
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
        }
        val sysClip = clipboardManager.primaryClip?.takeIf { it.itemCount > 0 }
            ?.getItemAt(0)?.coerceToText(this)?.toString()
        val textToPaste = if (!sysClip.isNullOrEmpty()) {
            sysClip
        } else {
            dbHelper.getClips().firstOrNull()?.content ?: ""
        }
        if (textToPaste.isNotEmpty()) {
            currentInputConnection?.commitText(textToPaste, 1)
            hideClipboardTipBanner()
        } else {
            Toast.makeText(this, "剪贴板暂无内容", Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== 动态记忆「最近使用符号」 ====================
    private fun recordRecentSymbol(sym: String) {
        if (sym.isEmpty()) return
        val raw = prefs.getString("recent_symbols_mru", "") ?: ""
        val currentList = if (raw.isEmpty()) mutableListOf() else raw.split("|||").toMutableList()
        currentList.remove(sym)
        currentList.add(0, sym)
        val trimmed = currentList.take(40).joinToString("|||")
        prefs.edit().putString("recent_symbols_mru", trimmed).apply()
    }

    private fun getDynamicRecentSymbols(): List<SymbolEntry> {
        val raw = prefs.getString("recent_symbols_mru", "") ?: ""
        val defaultRecents = EmojiKaomojiData.SYMBOL_CATEGORIES["最近"] ?: emptyList()
        if (raw.isEmpty()) return defaultRecents
        val mruStrings = raw.split("|||").filter { it.isNotEmpty() }
        val allKnown = EmojiKaomojiData.SYMBOL_CATEGORIES.values.flatten().associateBy { it.text }
        val result = ArrayList<SymbolEntry>(45)
        val seen = HashSet<String>()
        for (s in mruStrings) {
            if (seen.add(s)) {
                result.add(allKnown[s] ?: SymbolEntry(s, false))
            }
        }
        for (entry in defaultRecents) {
            if (seen.add(entry.text)) {
                result.add(entry)
            }
        }
        return result
    }

    private fun getCandidateFontScale(): Float {
        return prefs.getFloat("candidate_font_scale", 1.0f).coerceIn(0.55f, 1.5f)
    }

    private fun setCandidateFontScale(scale: Float) {
        val clamped = scale.coerceIn(0.55f, 1.5f)
        prefs.edit().putFloat("candidate_font_scale", clamped).apply()
        val candSizeSp = 17f * clamped
        candidatePoolViews.forEach { it.setTextSize(TypedValue.COMPLEX_UNIT_SP, candSizeSp) }
        composingPillTv?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * clamped)
    }

    /**
     * 打通 Android InputMethodService 系统窗口透明通道与实时硬件毛玻璃模糊：
     * 默认情况下，安卓系统的 SoftInputWindow、DecorView 以及内部 inputArea 父容器带有实心白色背景，
     * 会把底下的 App（如拼多多商品图、小红书笔记）挡得严严实实。
     * 这里将系统窗口链路上所有父容器设为全透明，并开启 Android 12+ 实时窗口背景高斯模糊 (FLAG_BLUR_BEHIND + setBackgroundBlurRadius)。
     */
    override fun onCreateInputView(): View {
        skin = CssSkinManager.getSkin(this)
        lastRenderedEnterText = getCustomEnterLabel()
        lastRenderedCustomBgTs = prefs.getLong("custom_bg_ts", 0L)
        lastRenderedBlurLevel = prefs.getInt("custom_bg_blur_level", 25).coerceIn(0, 100)
        lastRenderedFontTs = CustomFontManager.getCombinedTimestamp(this)
        lastRenderedTopIconTs = CustomTopIconManager.getCombinedTimestamp(this)
        T14WubiEngine.ensureInitializedAsync(this, dbHelper, onDictReadyRefresh)

        val customRawBmp = if (isCustomBgFrostedEnabled()) CustomBgManager.getRawBitmap(this) else null
        val customBlurBmp = if (isCustomBgFrostedEnabled()) CustomBgManager.getBlurredBitmap(this) else null
        customCoverDrawable = if (customRawBmp != null) {
            CustomCoverBgDrawable(customRawBmp, customBlurBmp, lastRenderedBlurLevel)
        } else null
        rootContainer = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = customCoverDrawable ?: CssSkinManager.makeGradientDrawable(skin.kbBgTop, skin.kbBgBottom, 0)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        mainVerticalLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(6), dp(6), dp(6), dp(8))
        }

        buildTopBar()
        bodyFrame = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        mainVerticalLayout.addView(bodyFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(getKeyboardHeightDp())
        ))

        rootContainer.addView(mainVerticalLayout)
        showKeyboardPanel()
        return rootContainer
    }

    /**
     * 每次退出或重新唤醒打字界面时，彻底清空上一次残留的联想词、未上屏编码与副面板，直接回到干净的主打字界面
     */
    private fun resetToCleanTypingState() {
        if (isVoiceListening) {
            stopVoiceListening()
        }
        composingT14.clear()
        composingRawLetters.clear()
        composingEnglish.clear()
        currentCandidates = emptyList()
        currentAssociations = emptyList()
        currentEnglishSuggestions = emptyList()
        lastCommittedWord = null
        isNumberPadMode = false
        dismissComposingPopup()
        dismissPopup()
        if (::topCandidateBar.isInitialized && ::topIdleBar.isInitialized) {
            topCandidateBar.visibility = View.GONE
            val showRecentCopy = pendingCopiedText.isNotEmpty() &&
                (System.currentTimeMillis() - lastCopiedTimestampMs < 18000L)
            if (showRecentCopy && ::topClipboardTipBar.isInitialized) {
                showClipboardTipBanner(pendingCopiedText)
            } else {
                if (::topClipboardTipBar.isInitialized) topClipboardTipBar.visibility = View.GONE
                topIdleBar.visibility = View.VISIBLE
            }
            topBarMonetBgView?.textureAlpha = skin.topLilyAlpha
        }
        if (::bodyFrame.isInitialized && currentPanel != PanelState.KEYBOARD) {
            showKeyboardPanel()
        }
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        resetToCleanTypingState()
    }

    override fun onWindowShown() {
        super.onWindowShown()
        T14WubiEngine.ensureInitializedAsync(this, dbHelper, onDictReadyRefresh)
        val latestSkin = CssSkinManager.getSkin(this)
        val latestEnter = getCustomEnterLabel()
        val latestBgTs = prefs.getLong("custom_bg_ts", 0L)
        val latestFontTs = CustomFontManager.getCombinedTimestamp(this)
        val latestTopIconTs = CustomTopIconManager.getCombinedTimestamp(this)
        val latestBlurLv = prefs.getInt("custom_bg_blur_level", 25).coerceIn(0, 100)
        if (latestSkin != skin || latestEnter != lastRenderedEnterText || latestBgTs != lastRenderedCustomBgTs || latestFontTs != lastRenderedFontTs || latestTopIconTs != lastRenderedTopIconTs) {
            skin = latestSkin
            setInputView(onCreateInputView())
            resetToCleanTypingState()
            return
        }
        if (latestBlurLv != lastRenderedBlurLevel) {
            lastRenderedBlurLevel = latestBlurLv
            customCoverDrawable?.blurLevel = latestBlurLv
            rootContainer.invalidate()
        }
        resetToCleanTypingState()
        if (::bodyFrame.isInitialized) {
            val lp = bodyFrame.layoutParams
            lp.height = dp(getKeyboardHeightDp())
            bodyFrame.layoutParams = lp
        }
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        resetToCleanTypingState()
    }

    // ==================== 零跳动悬浮编码窗 + 薰衣草雾透胶囊顶栏 (复刻参考图) ====================
    private fun showOrUpdateComposingPopup(codeText: String) {
        if (!::topWrapper.isInitialized || !topWrapper.isShown) return
        val cScale = getCandidateFontScale()
        if (composingPillTv == null) {
            composingPillTv = TextView(this).apply {
                setPadding(dp(10), dp(3), dp(10), dp(3))
                elevation = dp(4).toFloat()
            }
        }
        // 修复黑金等深色顶栏下打字栏英文字母看不清的问题：严格按胶囊背景明暗自动匹配高对比度亮金/深色字！
        val isPillBgLight = getColorLuminance(skin.topBarBgTop) >= 0.45
        val pillTextCol = if (isPillBgLight) {
            resolveDynamicCandidateTextColor()
        } else {
            resolveDynamicCandidateHighlightColor()
        }
        composingPillTv?.typeface = CustomFontManager.getEngKeyTypeface(this)
        composingPillTv?.paint?.isFakeBoldText = false
        composingPillTv?.setTextColor(pillTextCol)
        composingPillTv?.background = CssSkinManager.makeGradientDrawable(
            skin.topBarBgTop,
            skin.topBarBgBottom,
            dp(10),
            skin.topBarBorder,
            dp(1)
        )
        composingPillTv?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * cScale)
        composingPillTv?.text = "$codeText ✎"

        if (composingPopup == null) {
            composingPopup = PopupWindow(
                composingPillTv,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                false
            ).apply {
                isClippingEnabled = false
                isTouchable = false
            }
        }
        try {
            val yOff = -topWrapper.height - dp(26)
            if (composingPopup?.isShowing == true) {
                composingPopup?.update(topWrapper, dp(4), yOff, -1, -1)
            } else {
                composingPopup?.showAsDropDown(topWrapper, dp(4), yOff)
            }
        } catch (_: Exception) {}
    }

    private fun dismissComposingPopup() {
        try {
            composingPopup?.dismiss()
        } catch (_: Exception) {}
    }

    private fun buildTopBar() {
        val useFrostedTop = isCustomBgFrostedEnabled()
        topWrapper = FrameLayout(this).apply {
            background = if (useFrostedTop) null else CssSkinManager.makeGradientDrawable(
                skin.topBarBgTop,
                skin.topBarBgBottom,
                dp(skin.topBarRadiusDp),
                skin.topBarBorder,
                dp(skin.topBarBorderWidthDp)
            )
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
            lp.bottomMargin = dp(6)
            layoutParams = lp
            elevation = if (isWaterLilyDecorEnabled() || useFrostedTop) 0f else dp(2).toFloat()
        }

        // 未打字时的 4 图标胶囊顶栏（复刻参考图：带优雅竖线分隔与右侧浅紫叶片装饰）
        topIdleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
        }

        val showTopLabels = prefs.getBoolean("show_top_labels", false) // 默认采用纯极简几何图标（无多余文字），可在设置中一键开启小字
        topBarIconViews.clear()
        val curTopIconSizeDp = CustomTopIconManager.getIconSizeDp(this)

        fun makeTopItem(iconType: Int, labelText: String, onClick: () -> Unit): View {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                val isMonetLily = isWaterLilyDecorEnabled()
                val iconView = MinimalistIconView(
                    this@ShengXiaImeService,
                    iconType,
                    skin.topBarText,
                    useBotanicalStyle = isMonetLily
                ).apply {
                    val effectiveDp = if (isMonetLily) maxOf(curTopIconSizeDp, 34) else curTopIconSizeDp
                    val iconH = dp(effectiveDp)
                    val iconW = if (showTopLabels && !isMonetLily) (iconH * 1.22f).toInt() else (iconH * 1.38f).toInt()
                    layoutParams = LinearLayout.LayoutParams(iconW, iconH)
                }
                topBarIconViews.add(iconView)
                addView(iconView)
                if (showTopLabels) {
                    val labelTv = TextView(this@ShengXiaImeService).apply {
                        text = labelText
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                        setTextColor(skin.topBarText)
                        setPadding(dp(4), 0, 0, 0)
                        maxLines = 1
                    }
                    addView(labelTv)
                }
                attachTopBarTouchGlowAndSound(this)
                setOnClickListener { onClick() }
            }
        }

        fun makeDivider(): View {
            return View(this).apply {
                setBackgroundColor(if (skin.showTopDivider) skin.topBarDivider else Color.TRANSPARENT)
                layoutParams = LinearLayout.LayoutParams(dp(1), dp(16))
            }
        }

        if (isWaterLilyDecorEnabled()) {
            // 莫奈花园特殊皮肤专属 4 槽位水彩睡莲状态栏（1:1 复刻图5：盛放睡莲 | 花苞 | 碧绿荷叶 | 盛放睡莲）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_SETTINGS, "设置") {
                if (currentPanel == PanelState.QUICK_HEIGHT_SETTINGS) showKeyboardPanel() else showQuickHeightAndSettingsPanel()
            })
            topIdleBar.addView(makeDivider())
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_EMOJI, "表情") {
                if (currentPanel == PanelState.EMOJI_KAOMOJI) showKeyboardPanel() else showEmojiKaomojiPanel()
            })
            topIdleBar.addView(makeDivider())
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_CLIPBOARD, "常用") {
                if (currentPanel == PanelState.CLIPBOARD_PHRASE) {
                    showKeyboardPanel()
                } else {
                    isPhraseSubTab = false
                    showClipboardPhrasePanel()
                }
            })
            topIdleBar.addView(makeDivider())
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_COLLAPSE, "收起") {
                requestHideSelf(0)
            })
        } else {
            // 1. 设置（镂空小猫头）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_SETTINGS, "设置") {
                if (currentPanel == PanelState.QUICK_HEIGHT_SETTINGS) showKeyboardPanel() else showQuickHeightAndSettingsPanel()
            })
            topIdleBar.addView(makeDivider())
            // 2. 表情（大小双爱心）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_EMOJI, "表情") {
                if (currentPanel == PanelState.EMOJI_KAOMOJI) showKeyboardPanel() else showEmojiKaomojiPanel()
            })
            topIdleBar.addView(makeDivider())
            // 3. 剪贴板（环绕小星球）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_CLIPBOARD, "剪贴") {
                if (currentPanel == PanelState.CLIPBOARD_PHRASE && !isPhraseSubTab) {
                    showKeyboardPanel()
                } else {
                    isPhraseSubTab = false
                    showClipboardPhrasePanel()
                }
            })
            topIdleBar.addView(makeDivider())
            // 4. 收藏/常用语（圆润胖星星）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_FAVORITE, "收藏") {
                if (currentPanel == PanelState.CLIPBOARD_PHRASE && isPhraseSubTab) {
                    showKeyboardPanel()
                } else {
                    isPhraseSubTab = true
                    showClipboardPhrasePanel()
                }
            })
            topIdleBar.addView(makeDivider())
            // 5. 收起键盘（三尖小皇冠）
            topIdleBar.addView(makeTopItem(MinimalistIconView.TYPE_COLLAPSE, "收起") {
                requestHideSelf(0)
            })
        }

        // 候选词栏
        topCandidateBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(10), 0, dp(8), 0)
        }

        candidateHScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }
        candidateScrollContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val candSizeSp = 17f * getCandidateFontScale()
        candidatePoolViews.clear()
        val candTf = CustomFontManager.getCandidateTypeface(this)
        for (i in 0 until 36) {
            val tv = TextView(this).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, candSizeSp)
                typeface = candTf
                paint.isFakeBoldText = false
                setPadding(dp(12), dp(6), dp(12), dp(6))
                visibility = View.GONE
            }
            attachCandidateTouchSoundOnly(tv)
            candidatePoolViews.add(tv)
            candidateScrollContainer.addView(tv)
        }

        candidateHScroll.addView(candidateScrollContainer)
        topCandidateBar.addView(candidateHScroll)

        val expandBtn = TextView(this).apply {
            text = "›"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(skin.topBarText)
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(8), 0)
            attachCandidateTouchSoundOnly(this)
            setOnClickListener {
                if (composingT14.isEmpty() && composingEnglish.isEmpty()) {
                    hideAssociationBar()
                } else if (currentPanel == PanelState.CANDIDATE_GRID) {
                    showKeyboardPanel()
                } else if (composingT14.isNotEmpty()) {
                    showFullCandidateGridPanel()
                }
            }
        }
        topCandidateBar.addView(expandBtn)

        // 复制文字状态栏临时提示条：「已复制：xxx」（点击直接粘贴，右侧 ✕ 关闭）
        topClipboardTipBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(14), 0, dp(10), 0)
        }
        topClipboardTipTv = TextView(this).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(resolveDynamicCandidateHighlightColor())
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener {
                val clipToPaste = pendingCopiedText
                if (clipToPaste.isNotEmpty()) {
                    KeySoundManager.playClick(this@ShengXiaImeService)
                    currentInputConnection?.commitText(clipToPaste, 1)
                    pendingCopiedText = ""
                    hideClipboardTipBanner()
                }
            }
        }
        val pasteActionBadge = TextView(this).apply {
            text = "点击粘贴"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
            setTextColor(Color.WHITE)
            background = roundRect("#5B7FE8", dp(10))
            setPadding(dp(8), dp(3), dp(8), dp(3))
            setOnClickListener {
                val clipToPaste = pendingCopiedText
                if (clipToPaste.isNotEmpty()) {
                    KeySoundManager.playClick(this@ShengXiaImeService)
                    currentInputConnection?.commitText(clipToPaste, 1)
                    pendingCopiedText = ""
                    hideClipboardTipBanner()
                }
            }
        }
        val closeTipBtn = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(skin.topBarText)
            setPadding(dp(10), dp(4), dp(6), dp(4))
            setOnClickListener {
                pendingCopiedText = ""
                hideClipboardTipBanner()
            }
        }
        topClipboardTipBar.addView(topClipboardTipTv)
        topClipboardTipBar.addView(pasteActionBadge)
        topClipboardTipBar.addView(closeTipBtn)

        topBarMonetBgView = null
        if (isWaterLilyDecorEnabled()) {
            MonetTextureManager.getTopBarBitmap(this)?.let { tbBmp ->
                val bgView = MonetPaintedBgView(
                    this,
                    tbBmp,
                    dp(skin.topBarRadiusDp).toFloat(),
                    initialAlpha = skin.topLilyAlpha
                )
                topBarMonetBgView = bgView
                topWrapper.addView(
                    bgView,
                    FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
            }
        } else if (useFrostedTop) {
            val frostedTopBg = MonetPaintedBgView(
                this,
                null,
                dp(skin.topBarRadiusDp).toFloat(),
                fallbackBgTop = skin.topBarBgTop,
                useFrostedCustomBg = true
            )
            topWrapper.addView(
                frostedTopBg,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        topBarBacklightOverlay = KeyboardBacklightOverlayView(
            this,
            renderLayerMode = KeyboardBacklightOverlayView.LAYER_FULL_COMBINED,
            clipCornerRadiusPx = dp(skin.topBarRadiusDp).toFloat(),
            keyboardSurfaceBgColor = skin.topBarBgTop
        )
        topWrapper.addView(
            topBarBacklightOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        topWrapper.addView(
            topIdleBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        topWrapper.addView(
            topClipboardTipBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        topWrapper.addView(
            topCandidateBar,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        val voicePv = TextView(this).apply {
            text = ""
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setTextColor(resolveDynamicCandidateHighlightColor())
            typeface = CustomFontManager.getCandidateTypeface(this@ShengXiaImeService)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.START
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0)
            visibility = View.GONE
        }
        topVoicePreviewTv = voicePv
        topWrapper.addView(
            voicePv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        mainVerticalLayout.addView(topWrapper)
    }

    // ==================== 主键盘面板：中文 14 键 vs 英文标准 26 键 ====================
    private fun showKeyboardPanel() {
        currentPanel = PanelState.KEYBOARD
        bodyFrame.removeAllViews()

        // 关键层级：先将背光层添加在 bodyFrame 最底层（index = 0，即键盘下方！），
        // 再把键盘按键层叠加在背光层上方（index = 1），让光晕只在按键底部的缝隙中闪烁，绝不染色键帽表面！
        if (isKeyGlowEnabled()) {
            val underGlowLayer = KeyboardBacklightOverlayView(
                this,
                renderLayerMode = KeyboardBacklightOverlayView.LAYER_UNDER_GLOW,
                keyboardSurfaceBgColor = skin.kbBgTop
            ).apply {
                elevation = 0f
            }
            bodyFrame.addView(
                underGlowLayer,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }

        val kbView = when {
            isNumberPadMode -> buildNumberPadView()
            isEnglishMode -> buildEnglish26KeyboardView()
            else -> buildChinese14KeyboardView()
        }.apply {
            elevation = dp(1).toFloat()
            outlineProvider = null
        }
        bodyFrame.addView(kbView)

        if (isKeyGlowEnabled()) {
            val overSparkleLayer = KeyboardBacklightOverlayView(
                this,
                renderLayerMode = KeyboardBacklightOverlayView.LAYER_OVER_SPARKLE,
                keyboardSurfaceBgColor = skin.kbBgTop
            ).apply {
                elevation = dp(2).toFloat()
            }
            bodyFrame.addView(
                overSparkleLayer,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
        }
    }

    private fun buildChinese14KeyboardView(): View {
        val kbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 第一行（rowIndex = 1）
        val row1 = makeRow()
        row1.addView(makeDualKey("Q", "W", "1", "1", "1", isLeftEdge = true, rowIndex = 1))
        row1.addView(makeDualKey("E", "R", "2", "2", "2", rowIndex = 1))
        row1.addView(makeDualKey("T", "Y", "3", "3", "3", rowIndex = 1))
        row1.addView(makeDualKey("U", "I", "4", "4", "4", rowIndex = 1))
        row1.addView(makeDualKey("O", "P", "5", "5", "5", rowIndex = 1))
        kbLayout.addView(row1)

        // 第二行（rowIndex = 2）
        val row2 = makeRow()
        row2.addView(makeDualKey("A", "S", "6", "6", "6", isLeftEdge = true, rowIndex = 2))
        row2.addView(makeDualKey("D", "F", "7", "7", "7", rowIndex = 2))
        row2.addView(makeDualKey("G", "H", "8", "8", "8", rowIndex = 2))
        row2.addView(makeDualKey("J", "K", "9", "9", "9", rowIndex = 2))
        row2.addView(makeDualKey("L", "", "0", "0", "0", rowIndex = 2))
        kbLayout.addView(row2)

        // 第三行（rowIndex = 3）：通配（支持上滑/下滑快捷呼出皮肤设置后台！） | ZX(!) | CV(:) | BN(;) | M(?) | 退格
        val row3 = makeRow()
        row3.addView(makeFuncKey(
            label = "通配",
            weight = 0.85f,
            rowIndex = 3,
            keyId = "wildcard",
            onSwipeVertical = { openSkinSettingsBackend() }
        ) {
            appendT14Input("a", "z")
        })
        row3.addView(makeDualKey("Z", "X", "!", "！", "a", isLeftEdge = true, rowIndex = 3))
        row3.addView(makeDualKey("C", "V", ":", "：", "b", rowIndex = 3))
        row3.addView(makeDualKey("B", "N", ";", "；", "c", rowIndex = 3))
        row3.addView(makeDualKey("M", "", "?", "？", "d", rowIndex = 3))
        row3.addView(makeBackspaceKey(weight = 0.95f, rowIndex = 3))
        kbLayout.addView(row3)

        // 第四行（1:1 复刻参考图：窄 123 | 宽大逗号(上滑顿号) | 🌿 空格 | 宽大句号(上滑省略号) | 窄 中/英 | 盛夏光年✦）
        kbLayout.addView(buildBottomRow(isEng = false))
        return kbLayout
    }

    private fun buildEnglish26KeyboardView(): View {
        val kbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val row1 = makeRow()
        val r1Keys = listOf(
            "q" to "1", "w" to "2", "e" to "3", "r" to "4", "t" to "5",
            "y" to "6", "u" to "7", "i" to "8", "o" to "9", "p" to "0"
        )
        r1Keys.forEach { (letter, hint) ->
            row1.addView(makeSingle26Key(letter, hint, rowIndex = 1))
        }
        kbLayout.addView(row1)

        val row2 = makeRow().apply {
            setPadding(dp(14), 0, dp(14), 0)
        }
        val r2Keys = listOf(
            "a" to "!", "s" to "@", "d" to "#", "f" to "$", "g" to "%",
            "h" to "&", "j" to "*", "k" to "(", "l" to ")"
        )
        r2Keys.forEach { (letter, hint) ->
            row2.addView(makeSingle26Key(letter, hint, rowIndex = 2))
        }
        kbLayout.addView(row2)

        val row3 = makeRow()
        row3.addView(makeFuncKey(if (isShiftLocked) "▲" else "△", weight = 1.25f, rowIndex = 3, keyId = "shift") {
            isShiftLocked = !isShiftLocked
            showKeyboardPanel()
        })
        val r3Keys = listOf(
            "z" to "'", "x" to "/", "c" to "-", "v" to "_",
            "b" to ":", "n" to ";", "m" to "?"
        )
        r3Keys.forEach { (letter, hint) ->
            row3.addView(makeSingle26Key(letter, hint, rowIndex = 3))
        }
        row3.addView(makeBackspaceKey(weight = 1.25f, rowIndex = 3))
        kbLayout.addView(row3)

        kbLayout.addView(buildBottomRow(isEng = true))
        return kbLayout
    }

    /**
     * 第四行布局（严格对照参考图 1000127658_9dc946.png 与用户要求 1、2、3）：
     * - 数字键只写 "123"，宽度缩小 (weight = 0.68f)；轻点开数字小键盘，上滑直接开符号面板！
     * - 逗号（，）与句号（。）按键加大加宽 (weight = 1.15f)，居中显示中文符号，带薰衣草柔光边框；
     *   逗号上滑输出顿号 "、"，句号上滑输出省略号 "……"！
     * - 中/英切换键缩小 (weight = 0.68f)，写 "中/英"
     */
    private fun buildBottomRow(isEng: Boolean): LinearLayout {
        val row4 = makeRow()

        // 1. 最左下角：独立的 "符" 键 (keyId = "sym")，点击默认直接打开动态记忆的「最近」符号列表
        row4.addView(makeFuncKey("符", smallText = false, weight = 0.72f, rowIndex = 4, keyId = "sym") {
            currentSymbolCategory = "最近"
            showSymbolsPanel()
        })

        // 2. 窄版 "123" 键 (keyId = "num")
        row4.addView(makeFuncKey("123", smallText = true, weight = 0.65f, rowIndex = 4, keyId = "num") {
            isNumberPadMode = true
            showKeyboardPanel()
        })

        // 3. 加大中文逗号键 "，" (keyId = "comma")
        row4.addView(makeSwipeableFuncKey(
            mainLabel = "，",
            topHint = "、",
            weight = 0.90f,
            isPunctHighlight = true,
            largeLabel = true,
            rowIndex = 4,
            keyId = "comma",
            onTap = { commitOrSelectFirst(if (isEng) "," else "，") },
            onSwipeUp = { commitOrSelectFirst("、") }
        ))

        // 4. 空格键 (keyId = "space")
        row4.addView(makeSpaceKey(weight = 1.65f, rowIndex = 4))

        // 5. 加大中文句号键 "。" (keyId = "period")
        row4.addView(makeSwipeableFuncKey(
            mainLabel = "。",
            topHint = "…",
            weight = 0.90f,
            isPunctHighlight = true,
            largeLabel = true,
            rowIndex = 4,
            keyId = "period",
            onTap = { commitOrSelectFirst(if (isEng) "." else "。") },
            onSwipeUp = { commitOrSelectFirst("……") }
        ))

        // 6. 窄版 "中/英" 切换键 (keyId = "lang")
        val modeLabel = if (isEng) "英/中" else "中/英"
        row4.addView(makeFuncKey(modeLabel, smallText = true, weight = 0.65f, rowIndex = 4, keyId = "lang") {
            if (composingEnglish.isNotEmpty()) {
                currentInputConnection?.commitText(composingEnglish.toString(), 1)
            }
            clearComposing()
            hideAssociationBar()
            isEnglishMode = !isEnglishMode
            showKeyboardPanel()
        })

        // 7. 专属回车键 (keyId = "enter")
        row4.addView(makeFuncKey(getCustomEnterLabel(), smallText = true, weight = 0.85f, rowIndex = 4, keyId = "enter") {
            handleEnterKey()
        })
        return row4
    }

    private fun makeSwipeableFuncKey(
        mainLabel: String,
        topHint: String,
        weight: Float,
        isPunctHighlight: Boolean,
        largeLabel: Boolean = false,
        rowIndex: Int = 4,
        keyId: String = "",
        onTap: () -> Unit,
        onSwipeUp: () -> Unit
    ): View {
        val scale = getFuncKeyFontScale()
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = keyId.ifEmpty { mainLabel },
            isFuncKey = !isPunctHighlight,
            isPunctKey = isPunctHighlight
        )
        val bgTop = style.bgTop ?: if (isPunctHighlight) skin.punctKeyBgTop else skin.funcKeyBgTop
        val bgBottom = style.bgBottom ?: if (isPunctHighlight) skin.punctKeyBgBottom else skin.funcKeyBgBottom
        val pressedCol = style.pressedBg ?: skin.keyPressedBg
        val borderCol = style.borderColor ?: if (isPunctHighlight) skin.punctKeyBorder else skin.funcKeyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val rawTxtCol = style.textColor ?: if (isPunctHighlight) (skin.punctKeyText ?: skin.keyText) else skin.funcKeyText
        val txtCol = ensureReadableKeyTextColor(rawTxtCol, bgTop, rawTxtCol, isHint = false)
        val rawHCol = style.hintColor ?: if (isPunctHighlight) (skin.punctKeyHint ?: txtCol) else skin.keyHint
        val hCol = ensureReadableKeyTextColor(rawHCol, bgTop, txtCol, isHint = true)

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val kIdForGlow = keyId.ifEmpty { mainLabel }
        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, kIdForGlow) else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey(kIdForGlow, bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val hintTv = TextView(this).apply {
            text = topHint
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f * scale)
            setTextColor(hCol)
            gravity = Gravity.END or Gravity.TOP
            setPadding(0, dp(2), dp(6), 0)
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val mainTv = TextView(this).apply {
            text = mainLabel
            setTextSize(TypedValue.COMPLEX_UNIT_SP, (if (largeLabel) 20f else 13.5f) * scale)
            setTextColor(txtCol)
            gravity = Gravity.CENTER
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        var downX = 0f
        var downY = 0f
        var swipedUp = false

        container.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    swipedUp = false
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = true
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            pressedCol, pressedCol, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - downY
                    val dx = ev.rawX - downX
                    if (!swipedUp && dy < -dp(18) && abs(dy) > abs(dx) * 0.8f) {
                        swipedUp = true
                        hintTv.setTextColor(resolveDynamicCandidateHighlightColor())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = false
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    hintTv.setTextColor(hCol)
                    if (ev.actionMasked == MotionEvent.ACTION_UP) {
                        val totalDy = ev.rawY - downY
                        val totalDx = ev.rawX - downX
                        if (swipedUp || (totalDy < -dp(18) && abs(totalDy) > abs(totalDx) * 0.8f)) {
                            onSwipeUp()
                        } else {
                            onTap()
                        }
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }

    private fun makeRow(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
    }

    private fun makeSingle26Key(letterLower: String, topHint: String, rowIndex: Int = 1): View {
        val scale = getEngKeyFontScale()
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = letterLower,
            isFuncKey = false,
            isPunctKey = false,
            lettersOnKey = letterLower
        )
        val baseBgTop = style.bgTop ?: skin.keyBgTop
        val accentBg = resolveRandomAccentBg(letterLower, rowIndex, baseBgTop)
        val bgTop = accentBg ?: baseBgTop
        val bgBottom = accentBg ?: (style.bgBottom ?: skin.keyBgBottom)
        val pressedCol = style.pressedBg ?: skin.keyPressedBg
        val borderCol = style.borderColor ?: skin.keyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val isPinkLotusKey = isWaterLilyDecorEnabled() && (letterLower == "t" || letterLower == "y")
        val rawTxtCol = when {
            accentBg != null -> if (isColorLight(accentBg)) (style.textColor ?: Color.parseColor("#283040")) else Color.WHITE
            isPinkLotusKey && isColorLight(style.textColor ?: skin.keyText) -> Color.parseColor("#4D5E7C")
            isWaterLilyDecorEnabled() && !isPinkLotusKey -> style.textColor ?: Color.WHITE
            else -> style.textColor ?: skin.keyText
        }
        val txtCol = ensureReadableKeyTextColor(rawTxtCol, bgTop, rawTxtCol, isHint = false)
        val rawHCol = when {
            accentBg != null -> if (isColorLight(accentBg)) Color.parseColor("#5C6880") else Color.parseColor("#DCE4F2")
            isPinkLotusKey && isColorLight(style.hintColor ?: skin.keyHint) -> Color.parseColor("#6B7E9E")
            else -> style.hintColor ?: skin.keyHint
        }
        val hCol = ensureReadableKeyTextColor(rawHCol, bgTop, txtCol, isHint = true)

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(10), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, letterLower) else null
            MonetPaintedBgView(
                this, bmp, dp(10).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey(letterLower, bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val engTf = CustomFontManager.getEngKeyTypeface(this)
        val alignMode = getKeyAlignMode()
        val hintTv = TextView(this).apply {
            text = topHint
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f * scale)
            setTextColor(hCol)
            typeface = engTf
            paint.isFakeBoldText = false
            gravity = when (alignMode) {
                "top-left" -> Gravity.END or Gravity.BOTTOM
                "top-right" -> Gravity.START or Gravity.BOTTOM
                "bottom-left" -> Gravity.END or Gravity.TOP
                "bottom-right" -> Gravity.START or Gravity.TOP
                else -> Gravity.END or Gravity.TOP
            }
            setPadding(dp(4), dp(2), dp(4), dp(2))
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val displayChar = if (isShiftLocked) letterLower.uppercase() else letterLower
        val mainTv = TextView(this).apply {
            text = displayChar
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f * scale)
            setTextColor(txtCol)
            typeface = engTf
            paint.isFakeBoldText = false
            gravity = when (alignMode) {
                "top-left" -> Gravity.START or Gravity.TOP
                "top-right" -> Gravity.END or Gravity.TOP
                "bottom-left" -> Gravity.START or Gravity.BOTTOM
                "bottom-right" -> Gravity.END or Gravity.BOTTOM
                else -> Gravity.CENTER
            }
            setPadding(dp(5), dp(4), dp(5), dp(4))
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        var downX = 0f
        var downY = 0f
        var swipedUp = false

        container.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    swipedUp = false
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = true
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            pressedCol, pressedCol, dp(10), borderCol, borderW
                        )
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - downY
                    val dx = event.rawX - downX
                    if (!swipedUp && dy < -dp(18) && abs(dy) > abs(dx) * 0.8f) {
                        swipedUp = true
                        hintTv.setTextColor(resolveDynamicCandidateHighlightColor())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = false
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            bgTop, bgBottom, dp(10), borderCol, borderW
                        )
                    }
                    hintTv.setTextColor(hCol)
                    if (event.actionMasked == MotionEvent.ACTION_UP) {
                        if (swipedUp || (event.rawY - downY < -dp(18))) {
                            commitDirectString(topHint)
                        } else {
                            appendEnglishInput(displayChar)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }

    /**
     * 中文 14 键双字母按键（继承手机默认字体 + 修复最左列 QW/AS 长按滑选不到 Q/A 的问题）：
     * - 对于最左侧按键 (isLeftEdge = true)，长按时默认选中索引设为 0 或采用超灵敏左移阈值 (-8dp)，
     *   往左微移或原地即可选 Q/A，往右滑选 W / q / w，彻底告别手指撞屏幕左边框！
     */
    private fun makeDualKey(
        leftUpper: String,
        rightUpper: String,
        topHintDisplay: String,
        swipeUpCommitText: String,
        t14Code: String,
        isLeftEdge: Boolean = false,
        rowIndex: Int = 1
    ): View {
        val scale = getKeyFontScale()
        val rawPair = (leftUpper + rightUpper).lowercase()
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = rawPair,
            isFuncKey = false,
            isPunctKey = false,
            lettersOnKey = rawPair
        )
        val baseBgTop = style.bgTop ?: skin.keyBgTop
        val accentBg = resolveRandomAccentBg(rawPair, rowIndex, baseBgTop)
        val bgTop = accentBg ?: baseBgTop
        val bgBottom = accentBg ?: (style.bgBottom ?: skin.keyBgBottom)
        val pressedCol = style.pressedBg ?: skin.keyPressedBg
        val borderCol = style.borderColor ?: skin.keyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val rawTxtCol = if (accentBg != null) {
            if (isColorLight(accentBg)) (style.textColor ?: Color.parseColor("#242C3A")) else Color.WHITE
        } else {
            style.textColor ?: skin.keyText
        }
        val txtCol = ensureReadableKeyTextColor(rawTxtCol, bgTop, rawTxtCol, isHint = false)
        val rawHCol = if (accentBg != null) {
            if (isColorLight(accentBg)) Color.parseColor("#5C687D") else Color.parseColor("#DCE5F2")
        } else {
            style.hintColor ?: skin.keyHint
        }
        val hCol = ensureReadableKeyTextColor(rawHCol, bgTop, txtCol, isHint = true)

        // 第三排 4 个字母键（ZX、CV、BN、M）下滑功能：全选、剪切、复制、粘贴（复刻 1000128622.jpg）
        val swipeDownActionLabel = when (rawPair) {
            "zx" -> "全选"
            "cv" -> "剪切"
            "bn" -> "复制"
            "m" -> "粘贴"
            else -> null
        }
        val alignMode = getKeyAlignMode()
        val engTf = CustomFontManager.getEngKeyTypeface(this)
        val candTf = CustomFontManager.getCandidateTypeface(this)

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, rawPair) else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey(rawPair, bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val hintTv = TextView(this).apply {
            text = topHintDisplay
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f * scale)
            setTextColor(hCol)
            typeface = engTf
            paint.isFakeBoldText = false
            gravity = when (alignMode) {
                "top-left" -> Gravity.END or Gravity.BOTTOM
                "top-right" -> Gravity.START or Gravity.BOTTOM
                "bottom-left" -> Gravity.END or Gravity.TOP
                "bottom-right" -> Gravity.START or Gravity.TOP
                else -> Gravity.END or Gravity.TOP
            }
            setPadding(dp(7), dp(3), dp(7), dp(4))
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val mainLabel = if (rightUpper.isEmpty()) leftUpper else "$leftUpper $rightUpper"
        val mainTv = TextView(this).apply {
            text = mainLabel
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * scale)
            setTextColor(txtCol)
            typeface = engTf
            paint.isFakeBoldText = false
            when (alignMode) {
                "top-left" -> {
                    gravity = Gravity.START or Gravity.TOP
                    setPadding(dp(9), dp(6), 0, 0)
                }
                "top-right" -> {
                    gravity = Gravity.END or Gravity.TOP
                    setPadding(0, dp(6), dp(9), 0)
                }
                "bottom-left" -> {
                    gravity = Gravity.START or Gravity.BOTTOM
                    setPadding(dp(9), 0, 0, dp(5))
                }
                "bottom-right" -> {
                    gravity = Gravity.END or Gravity.BOTTOM
                    setPadding(0, 0, dp(9), dp(5))
                }
                else -> {
                    gravity = Gravity.CENTER
                    if (swipeDownActionLabel != null) {
                        setPadding(0, 0, 0, dp(6))
                    }
                }
            }
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val subActionTv = if (swipeDownActionLabel != null && prefs.getBoolean("show_edit_sub_labels", true)) {
            TextView(this).apply {
                text = swipeDownActionLabel
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.8f * scale)
                setTextColor(hCol)
                typeface = candTf
                paint.isFakeBoldText = false
                alpha = 0.86f
                gravity = when (alignMode) {
                    "top-left" -> Gravity.START or Gravity.BOTTOM
                    "top-right" -> Gravity.END or Gravity.BOTTOM
                    "bottom-left" -> Gravity.START or Gravity.TOP
                    "bottom-right" -> Gravity.END or Gravity.TOP
                    else -> Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                }
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }.also { subTv ->
                container.addView(subTv, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                ))
            }
        } else null

        val popupOptions = if (rightUpper.isNotEmpty()) {
            listOf(leftUpper, rightUpper, leftUpper.lowercase(), rightUpper.lowercase())
        } else {
            listOf(leftUpper, leftUpper.lowercase())
        }
        val defaultIdx = if (isLeftEdge) 0 else 1

        var isLongPressActive = false
        var isSwipeUpActive = false
        var isSwipeDownActive = false
        var selectedIdx = defaultIdx
        var downX = 0f
        var downY = 0f
        val optionViews = mutableListOf<TextView>()

        val longPressRunnable = Runnable {
            if (!isSwipeUpActive && !isSwipeDownActive) {
                isLongPressActive = true
                optionViews.clear()
                selectedIdx = defaultIdx
                showFiveChoicePopup(container, popupOptions, defaultIdx, optionViews, isLeftEdge)
            }
        }

        container.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    isLongPressActive = false
                    isSwipeUpActive = false
                    isSwipeDownActive = false
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = true
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            pressedCol, pressedCol, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    mainHandler.postDelayed(longPressRunnable, 210L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - downY
                    val dx = event.rawX - downX
                    if (!isLongPressActive && !isSwipeUpActive && !isSwipeDownActive && dy < -dp(18) && abs(dy) > abs(dx) * 0.8f) {
                        isSwipeUpActive = true
                        mainHandler.removeCallbacks(longPressRunnable)
                        hintTv.setTextColor(resolveDynamicCandidateHighlightColor())
                    } else if (!isLongPressActive && !isSwipeUpActive && !isSwipeDownActive && swipeDownActionLabel != null && dy > dp(18) && abs(dy) > abs(dx) * 0.8f) {
                        isSwipeDownActive = true
                        mainHandler.removeCallbacks(longPressRunnable)
                        subActionTv?.setTextColor(resolveDynamicCandidateHighlightColor())
                    } else if (isLongPressActive && optionViews.isNotEmpty()) {
                        val stepPx = dp(20).toFloat()
                        val offsetSteps = if (dx >= 0) (dx / stepPx).toInt() else -((-dx + dp(8)) / stepPx).toInt()
                        val newIdx = (defaultIdx + offsetSteps).coerceIn(0, popupOptions.lastIndex)
                        if (newIdx != selectedIdx) {
                            selectedIdx = newIdx
                            updatePopupHighlight(optionViews, selectedIdx)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = false
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    hintTv.setTextColor(hCol)
                    subActionTv?.setTextColor(hCol)

                    if (isLongPressActive) {
                        dismissPopup()
                        if (event.actionMasked == MotionEvent.ACTION_UP) {
                            val chosen = popupOptions[selectedIdx]
                            commitDirectString(chosen)
                        }
                        isLongPressActive = false
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        val totalDy = event.rawY - downY
                        val totalDx = event.rawX - downX
                        if (isSwipeUpActive || (totalDy < -dp(18) && abs(totalDy) > abs(totalDx) * 0.8f)) {
                            commitOrSelectFirst(swipeUpCommitText)
                        } else if (swipeDownActionLabel != null && (isSwipeDownActive || (totalDy > dp(18) && abs(totalDy) > abs(totalDx) * 0.8f))) {
                            when (rawPair) {
                                "zx" -> performSelectAllAction()
                                "cv" -> performCutAction()
                                "bn" -> performCopyAction()
                                "m" -> performPasteAction()
                            }
                        } else {
                            appendT14Input(t14Code, leftUpper.lowercase())
                        }
                    }
                    isSwipeUpActive = false
                    isSwipeDownActive = false
                    true
                }
                else -> false
            }
        }

        return container
    }

    private fun showFiveChoicePopup(
        anchor: View,
        options: List<String>,
        activeIndex: Int,
        outViews: MutableList<TextView>,
        isLeftEdge: Boolean = false
    ) {
        dismissPopup()
        // 全皮肤自适应半透明毛玻璃长按气泡（深色皮肤自动呈现暗夜柔雾毛玻璃，浅色皮肤呈现奶雾毛玻璃，告别写死莫奈冰蓝！）
        val isDark = isSkinDarkTheme()
        val glassBaseTop = if (isDark) {
            blendColors(skin.topBarBgTop, Color.WHITE, 0.10f)
        } else {
            blendColors(skin.topBarBgTop, Color.WHITE, 0.45f)
        }
        val glassBaseBottom = if (isDark) {
            blendColors(skin.kbBgTop, skin.topBarBgTop, 0.65f)
        } else {
            blendColors(skin.keyBgTop, Color.WHITE, 0.35f)
        }
        val tintCol = resolveSkinThemeTintColor()
        val borderCol = if (isDark) {
            Color.argb(135, Color.red(tintCol), Color.green(tintCol), Color.blue(tintCol))
        } else {
            Color.argb(230, 255, 255, 255)
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = CssSkinManager.makeGradientDrawable(
                Color.argb(222, Color.red(glassBaseTop), Color.green(glassBaseTop), Color.blue(glassBaseTop)),
                Color.argb(212, Color.red(glassBaseBottom), Color.green(glassBaseBottom), Color.blue(glassBaseBottom)),
                dp(15),
                borderCol,
                dp(1)
            )
            setPadding(dp(8), dp(6), dp(8), dp(6))
            elevation = dp(6).toFloat()
        }

        val engTf = CustomFontManager.getEngKeyTypeface(this)
        options.forEach { label ->
            val tv = TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = engTf
                paint.isFakeBoldText = false
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(40))
            }
            outViews.add(tv)
            row.addView(tv)
        }
        updatePopupHighlight(outViews, activeIndex)

        popupWindow = PopupWindow(
            row,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            false
        ).apply {
            isClippingEnabled = false
            val popupWidth = dp(36 * options.size + 16)
            val xOff = if (isLeftEdge) 0 else (anchor.width - popupWidth) / 2
            val yOff = -anchor.height - dp(50)
            showAsDropDown(anchor, xOff, yOff)
        }
    }

    private fun updatePopupHighlight(views: List<TextView>, activeIdx: Int) {
        val isDark = isSkinDarkTheme()
        val glassBg = if (isDark) {
            blendColors(skin.topBarBgTop, Color.WHITE, 0.10f)
        } else {
            blendColors(skin.topBarBgTop, Color.WHITE, 0.45f)
        }
        // 气泡文字颜色完全跟随当前皮肤配色，并自动保障在毛玻璃底上的清晰对比度
        val rawSkinText = if (isDark) skin.candidateText else skin.keyText
        val normalTextCol = ensureReadableKeyTextColor(rawSkinText, glassBg, resolveDynamicCandidateTextColor(), isHint = false)
        val activeHighlightCol = resolveDynamicCandidateHighlightColor()
        val pillTint = resolveSkinThemeTintColor()
        val engTf = CustomFontManager.getEngKeyTypeface(this)

        views.forEachIndexed { idx, tv ->
            tv.typeface = engTf
            tv.paint.isFakeBoldText = false
            if (idx == activeIdx) {
                val pillFillAlpha = if (isDark) 95 else 68
                val pillStrokeAlpha = if (isDark) 175 else 155
                tv.background = CssSkinManager.makeGradientDrawable(
                    Color.argb(pillFillAlpha, Color.red(pillTint), Color.green(pillTint), Color.blue(pillTint)),
                    Color.argb(pillFillAlpha, Color.red(activeHighlightCol), Color.green(activeHighlightCol), Color.blue(activeHighlightCol)),
                    dp(10),
                    Color.argb(pillStrokeAlpha, Color.red(activeHighlightCol), Color.green(activeHighlightCol), Color.blue(activeHighlightCol)),
                    dp(1)
                )
                tv.setTextColor(activeHighlightCol)
            } else {
                tv.background = null
                tv.setTextColor(normalTextCol)
            }
        }
    }

    private fun dismissPopup() {
        try {
            popupWindow?.dismiss()
        } catch (_: Exception) {}
        popupWindow = null
    }

    private fun makeFuncKey(
        label: String,
        smallText: Boolean = false,
        weight: Float = 1f,
        rowIndex: Int = 4,
        keyId: String = "",
        onSwipeVertical: (() -> Unit)? = null,
        onClick: () -> Unit
    ): View {
        val scale = getFuncKeyFontScale()
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = keyId.ifEmpty { label },
            isFuncKey = true,
            isPunctKey = false
        )
        val bgTop = style.bgTop ?: skin.funcKeyBgTop
        val bgBottom = style.bgBottom ?: skin.funcKeyBgBottom
        val borderCol = style.borderColor ?: skin.funcKeyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val txtCol = style.textColor ?: skin.funcKeyText

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, keyId) else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey(keyId, bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        var downX = 0f
        var downY = 0f
        var swipedVert = false
        var movedTooFar = false
        if (monetBgView != null) {
            container.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.rawX
                        downY = ev.rawY
                        swipedVert = false
                        movedTooFar = false
                        // 绝不在 ACTION_DOWN 强行锁死父级 ScrollView，允许快捷设置面板顺滑上下滚动防误触
                        monetBgView.isKeyPressedState = true
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = abs(ev.rawX - downX)
                        val dy = abs(ev.rawY - downY)
                        if (onSwipeVertical != null && !swipedVert && dy > dp(18)) {
                            swipedVert = true
                            monetBgView.isKeyPressedState = false
                            onSwipeVertical.invoke()
                        } else if (onSwipeVertical == null && !movedTooFar && (dy > dp(10) || dx > dp(14))) {
                            // 手指正在上下滑动菜单：立即取消按钮按下态并交还滚动权给 ScrollView，绝不误触按钮！
                            movedTooFar = true
                            monetBgView.isKeyPressedState = false
                            v.parent?.requestDisallowInterceptTouchEvent(false)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        monetBgView.isKeyPressedState = false
                        val dx = abs(ev.rawX - downX)
                        val dy = abs(ev.rawY - downY)
                        if (!swipedVert && !movedTooFar && dx < dp(14) && dy < dp(12)) {
                            onClick()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        // ScrollView 接管纵向滑动时会触发 ACTION_CANCEL，此时绝不可触发 onClick()！
                        monetBgView.isKeyPressedState = false
                        true
                    }
                    else -> false
                }
            }
        } else {
            container.setOnClickListener { onClick() }
        }

        val funcTypeface = when {
            keyId == "enter" -> CustomFontManager.getEnterKeyTypeface(this)
            keyId == "num" -> CustomFontManager.getEngKeyTypeface(this)
            else -> CustomFontManager.getCandidateTypeface(this)
        }
        if (keyId == "wildcard" && WildcardCuteIconView.getWildcardIconStyle(this) != WildcardCuteIconView.STYLE_TEXT_LABEL) {
            val wildcardIcon = WildcardCuteIconView(this, txtCol, scale)
            container.addView(wildcardIcon, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            val tv = TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, (if (smallText) 12f else 14f) * scale)
                setTextColor(txtCol)
                typeface = funcTypeface
                paint.isFakeBoldText = false
                gravity = Gravity.CENTER
            }
            container.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        return container
    }

    private fun makeBackspaceKey(weight: Float, rowIndex: Int = 3): View {
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = "backspace",
            isFuncKey = true,
            isPunctKey = false
        )
        val bgTop = style.bgTop ?: skin.funcKeyBgTop
        val bgBottom = style.bgBottom ?: skin.funcKeyBgBottom
        val pressedCol = style.pressedBg ?: skin.keyPressedBg
        val borderCol = style.borderColor ?: skin.funcKeyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val txtCol = style.textColor ?: skin.funcKeyText

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, "backspace") else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey("backspace", bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val bsIconView = BackspaceIconView(this, txtCol)
        container.addView(bsIconView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        var downY = 0f
        var swipedGestureTriggered = false
        var repeatTriggered = false
        val repeatDelete = object : Runnable {
            override fun run() {
                if (!swipedGestureTriggered) {
                    repeatTriggered = true
                    handleBackspace()
                    mainHandler.postDelayed(this, 65L)
                }
            }
        }
        container.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = ev.rawY
                    swipedGestureTriggered = false
                    repeatTriggered = false
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = true
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            pressedCol, pressedCol, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    mainHandler.postDelayed(repeatDelete, 350L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - downY
                    if (!swipedGestureTriggered && dy < -dp(22)) {
                        // 上滑删除键：一键删除光标【前面】的所有文字
                        swipedGestureTriggered = true
                        mainHandler.removeCallbacks(repeatDelete)
                        deleteAllTextBeforeCursor()
                    } else if (!swipedGestureTriggered && dy > dp(22)) {
                        // 下滑删除键：一键删除光标【后面】的所有文字（与上滑刚好相反！）
                        swipedGestureTriggered = true
                        mainHandler.removeCallbacks(repeatDelete)
                        deleteAllTextAfterCursor()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(repeatDelete)
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = false
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    if (!swipedGestureTriggered && !repeatTriggered && ev.actionMasked == MotionEvent.ACTION_UP) {
                        handleBackspace()
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }

    private fun deleteAllTextBeforeCursor() {
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
            return
        }
        hideAssociationBar()
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(100000, 0)
        if (!before.isNullOrEmpty()) {
            val str = before.toString()
            dbHelper.addClip(str)
            ic.deleteSurroundingText(str.length, 0)
        }
    }

    private fun deleteAllTextAfterCursor() {
        if (composingT14.isNotEmpty() || composingEnglish.isNotEmpty()) {
            clearComposing()
            return
        }
        hideAssociationBar()
        val ic = currentInputConnection ?: return
        val after = ic.getTextAfterCursor(100000, 0)
        if (!after.isNullOrEmpty()) {
            val str = after.toString()
            dbHelper.addClip(str)
            ic.deleteSurroundingText(0, str.length)
        }
    }

    private fun makeSpaceKey(weight: Float, rowIndex: Int = 4): View {
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = "space",
            isFuncKey = false,
            isPunctKey = false
        )
        val bgTop = style.bgTop ?: skin.keyBgTop
        val bgBottom = style.bgBottom ?: skin.keyBgBottom
        val borderCol = style.borderColor ?: skin.keyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val txtCol = style.textColor ?: skin.keyText

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, "space") else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey("space", bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val centerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (isWaterLilyDecorEnabled()) {
            MonetTextureManager.getSpaceLotusIcon(this)?.let { lotusBmp ->
                val iv = ImageView(this).apply {
                    setImageBitmap(lotusBmp)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    val iconSize = dp(20)
                    layoutParams = LinearLayout.LayoutParams(iconSize, iconSize).apply {
                        rightMargin = dp(4)
                    }
                }
                centerRow.addView(iv)
            }
        }
        val tv = TextView(this).apply {
            text = skin.spaceText
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * getFuncKeyFontScale())
            setTextColor(txtCol)
            typeface = CustomFontManager.getCandidateTypeface(this@ShengXiaImeService)
            paint.isFakeBoldText = false
            gravity = Gravity.CENTER
        }
        centerRow.addView(tv)

        // 迷你精致镂空小话筒图标：位于文字右侧（或莫奈睡莲右侧），随皮肤文字颜色自动染色，提示「长按空格语音输入」
        val miniMicIcon = SpaceHollowMicIconView(this, txtCol).apply {
            val mw = dp(11)
            val mh = dp(13)
            layoutParams = LinearLayout.LayoutParams(mw, mh).apply {
                leftMargin = dp(4)
            }
        }
        centerRow.addView(miniMicIcon)

        container.addView(centerRow, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        var startX = 0f
        var startY = 0f
        var downTimeMs = 0L
        var movedCursor = false
        var swipedUpPaste = false
        var longPressVoiceTriggered = false

        val longPressVoiceRunnable = Runnable {
            if (!movedCursor && !swipedUpPaste && currentPanel == PanelState.KEYBOARD) {
                longPressVoiceTriggered = true
                monetBgView?.isKeyPressedState = false
                try {
                    container.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                } catch (_: Exception) {}
                if (composingT14.isNotEmpty()) {
                    val first = currentCandidates.firstOrNull()
                    if (first != null) selectCandidate(first) else clearComposing()
                } else if (composingEnglish.isNotEmpty()) {
                    currentInputConnection?.commitText(composingEnglish.toString(), 1)
                    clearComposing()
                }
                showEmbeddedVoiceInputPanel()
            }
        }

        container.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = ev.rawX
                    startY = ev.rawY
                    downTimeMs = SystemClock.uptimeMillis()
                    movedCursor = false
                    swipedUpPaste = false
                    longPressVoiceTriggered = false
                    monetBgView?.isKeyPressedState = true
                    mainHandler.removeCallbacks(longPressVoiceRunnable)
                    mainHandler.postDelayed(longPressVoiceRunnable, 280L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - startX
                    val dy = ev.rawY - startY
                    if (abs(dx) > dp(12) || abs(dy) > dp(12)) {
                        mainHandler.removeCallbacks(longPressVoiceRunnable)
                    }
                    if (!longPressVoiceTriggered) {
                        if (!movedCursor && !swipedUpPaste && dy < -dp(22) && abs(dy) > abs(dx) * 1.2f) {
                            swipedUpPaste = true
                            performPasteAction()
                        } else if (!swipedUpPaste && abs(dx) > dp(18)) {
                            val keyCode = if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
                            currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
                            startX = ev.rawX
                            movedCursor = true
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressVoiceRunnable)
                    monetBgView?.isKeyPressedState = false
                    if (longPressVoiceTriggered) {
                        return@setOnTouchListener true
                    }
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !movedCursor && !swipedUpPaste) {
                        if (composingEnglish.isNotEmpty()) {
                            val rawEng = composingEnglish.toString()
                            currentInputConnection?.commitText("$rawEng ", 1)
                            T14WubiEngine.onEnglishWordCommitted(rawEng, rawEng, dbHelper)
                            clearComposing()
                        } else if (composingT14.isNotEmpty()) {
                            val first = currentCandidates.firstOrNull()
                            if (first != null) {
                                selectCandidate(first)
                            } else {
                                commitWordWithAssociation(composingRawLetters.toString())
                            }
                        } else {
                            hideAssociationBar()
                            currentInputConnection?.commitText(" ", 1)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }

    // ==================== 26 键英文单词联想 ====================
    private fun appendEnglishInput(ch: String) {
        currentAssociations = emptyList()
        composingEnglish.append(ch)
        refreshEnglishCandidates()
    }

    private fun refreshEnglishCandidates() {
        if (composingEnglish.isEmpty()) {
            dismissComposingPopup()
            currentEnglishSuggestions = emptyList()
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
            topBarMonetBgView?.textureAlpha = skin.topLilyAlpha
            return
        }

        topIdleBar.visibility = View.GONE
        if (::topClipboardTipBar.isInitialized) topClipboardTipBar.visibility = View.GONE
        topBarBacklightOverlay?.clearAllOrbs()
        topCandidateBar.visibility = View.VISIBLE
        topBarMonetBgView?.textureAlpha = (skin.topLilyAlpha * 0.62f).toInt().coerceAtLeast(45)
        showOrUpdateComposingPopup(composingEnglish.toString())

        currentEnglishSuggestions = T14WubiEngine.queryEnglishCandidates(composingEnglish.toString(), 28)
        val countToShow = minOf(currentEnglishSuggestions.size, candidatePoolViews.size)
        for (i in 0 until candidatePoolViews.size) {
            val tv = candidatePoolViews[i]
            if (i < countToShow) {
                val word = currentEnglishSuggestions[i]
                tv.text = word
                tv.setTextColor(if (i == 0) resolveDynamicCandidateHighlightColor() else resolveDynamicCandidateTextColor())
                tv.typeface = CustomFontManager.getCandidateTypeface(this)
                tv.paint.isFakeBoldText = false
                tv.visibility = View.VISIBLE
                tv.setOnClickListener {
                    val rawPref = composingEnglish.toString()
                    currentInputConnection?.commitText(word, 1)
                    T14WubiEngine.onEnglishWordCommitted(word, rawPref, dbHelper)
                    composingEnglish.clear()
                    refreshEnglishCandidates()
                }
            } else {
                tv.visibility = View.GONE
            }
        }
        candidateHScroll.scrollTo(0, 0)
    }

    // ==================== 中文 14 键候选词刷新 ====================
    private fun appendT14Input(t14Key: String, displayHint: String) {
        currentAssociations = emptyList()
        composingT14.append(t14Key)
        composingRawLetters.append(displayHint)
        refreshCandidates()
    }

    private fun refreshCandidates() {
        if (composingT14.isEmpty()) {
            dismissComposingPopup()
            currentCandidates = emptyList()
            if (currentPanel == PanelState.CANDIDATE_GRID) showKeyboardPanel()
            if (currentAssociations.isNotEmpty()) {
                renderAssociationBar()
            } else {
                topCandidateBar.visibility = View.GONE
                topIdleBar.visibility = View.VISIBLE
            }
            return
        }

        topIdleBar.visibility = View.GONE
        if (::topClipboardTipBar.isInitialized) topClipboardTipBar.visibility = View.GONE
        topBarBacklightOverlay?.clearAllOrbs()
        topCandidateBar.visibility = View.VISIBLE
        topBarMonetBgView?.textureAlpha = (skin.topLilyAlpha * 0.62f).toInt().coerceAtLeast(45)

        if (!T14WubiEngine.isEngineLoaded()) {
            T14WubiEngine.ensureInitializedAsync(this, dbHelper, onDictReadyRefresh)
        }

        currentCandidates = T14WubiEngine.queryCandidates(
            composingT14.toString(),
            composingRawLetters.toString(),
            90
        )

        val topDisplayCode = currentCandidates.firstOrNull()?.displayCode?.ifEmpty { null }
            ?: T14WubiEngine.segmentT14ToPinyinDisplay(composingT14.toString(), composingRawLetters.toString())
        showOrUpdateComposingPopup(topDisplayCode)

        val countToShow = minOf(currentCandidates.size, candidatePoolViews.size)
        if (countToShow == 0) {
            // 兜底保护：若刚切换输入法词库尚在后台加载中，或当前编码无匹配，绝不让顶栏变成空白条！
            val fallbackText = composingRawLetters.toString().ifEmpty { composingT14.toString() }
            val firstTv = candidatePoolViews[0]
            firstTv.text = fallbackText
            firstTv.setTextColor(resolveDynamicCandidateHighlightColor())
            firstTv.typeface = CustomFontManager.getCandidateTypeface(this)
            firstTv.paint.isFakeBoldText = false
            firstTv.visibility = View.VISIBLE
            firstTv.setOnClickListener {
                commitWordWithAssociation(fallbackText, composingT14.toString())
            }
            for (i in 1 until candidatePoolViews.size) {
                candidatePoolViews[i].visibility = View.GONE
            }
        } else {
            for (i in 0 until candidatePoolViews.size) {
                val tv = candidatePoolViews[i]
                if (i < countToShow) {
                    val cand = currentCandidates[i]
                    val label = if (!cand.isWubiMatch && !cand.wubiHint.isNullOrEmpty()) {
                        "${cand.word}(${cand.wubiHint})"
                    } else {
                        cand.word
                    }
                    tv.text = label
                    tv.setTextColor(if (i == 0) resolveDynamicCandidateHighlightColor() else resolveDynamicCandidateTextColor())
                    tv.typeface = CustomFontManager.getCandidateTypeface(this)
                    tv.paint.isFakeBoldText = false
                    tv.visibility = View.VISIBLE
                    tv.setOnClickListener { selectCandidate(cand) }
                } else {
                    tv.visibility = View.GONE
                }
            }
        }
        candidateScrollContainer.requestLayout()
        candidateHScroll.requestLayout()
        topCandidateBar.requestLayout()
        candidateHScroll.scrollTo(0, 0)

        if (currentPanel == PanelState.CANDIDATE_GRID) {
            showFullCandidateGridPanel()
        }
    }

    private fun renderAssociationBar() {
        dismissComposingPopup()
        if (currentAssociations.isEmpty()) {
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
            topBarMonetBgView?.textureAlpha = skin.topLilyAlpha
            return
        }
        topIdleBar.visibility = View.GONE
        if (::topClipboardTipBar.isInitialized) topClipboardTipBar.visibility = View.GONE
        topBarBacklightOverlay?.clearAllOrbs()
        topCandidateBar.visibility = View.VISIBLE
        topBarMonetBgView?.textureAlpha = (skin.topLilyAlpha * 0.62f).toInt().coerceAtLeast(45)

        val countToShow = minOf(currentAssociations.size, candidatePoolViews.size)
        for (i in 0 until candidatePoolViews.size) {
            val tv = candidatePoolViews[i]
            if (i < countToShow) {
                val assocWord = currentAssociations[i]
                tv.text = assocWord
                tv.setTextColor(resolveDynamicCandidateTextColor())
                tv.typeface = CustomFontManager.getCandidateTypeface(this)
                tv.paint.isFakeBoldText = false
                tv.visibility = View.VISIBLE
                tv.setOnClickListener {
                    commitWordWithAssociation(assocWord)
                }
            } else {
                tv.visibility = View.GONE
            }
        }
        candidateHScroll.scrollTo(0, 0)
    }

    private fun hideAssociationBar() {
        currentAssociations = emptyList()
        if (composingT14.isEmpty() && composingEnglish.isEmpty()) {
            dismissComposingPopup()
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
            topBarMonetBgView?.textureAlpha = skin.topLilyAlpha
        }
    }

    private fun selectCandidate(cand: Candidate) {
        val usedCode = if (cand.consumedKeys > 0 && cand.consumedKeys <= composingT14.length) {
            composingT14.substring(0, cand.consumedKeys)
        } else {
            composingT14.toString()
        }
        currentInputConnection?.commitText(cand.word, 1)
        T14WubiEngine.onWordCommitted(
            word = cand.word,
            prevWord = lastCommittedWord,
            dbHelper = dbHelper,
            usedT14Code = usedCode,
            context = this
        ) { learnedPhrase, learnedWubi, _ ->
            val hintCode = if (learnedWubi.isNotEmpty()) " (五笔: $learnedWubi)" else ""
            Toast.makeText(
                this@ShengXiaImeService,
                "✨ 已自动组词收录：「$learnedPhrase」$hintCode",
                Toast.LENGTH_SHORT
            ).show()
        }
        lastCommittedWord = cand.word

        if (cand.consumedKeys > 0 && cand.consumedKeys < composingT14.length) {
            composingT14.delete(0, cand.consumedKeys)
            val rawDel = cand.consumedKeys.coerceAtMost(composingRawLetters.length)
            composingRawLetters.delete(0, rawDel)
            refreshCandidates()
        } else {
            composingT14.clear()
            composingRawLetters.clear()
            currentAssociations = T14WubiEngine.getAssociations(cand.word)
            if (currentPanel == PanelState.CANDIDATE_GRID) {
                showKeyboardPanel()
            }
            refreshCandidates()
        }
    }

    private fun commitWordWithAssociation(word: String, usedCode: String = "") {
        currentInputConnection?.commitText(word, 1)
        T14WubiEngine.onWordCommitted(
            word = word,
            prevWord = lastCommittedWord,
            dbHelper = dbHelper,
            usedT14Code = usedCode,
            context = this
        ) { learnedPhrase, learnedWubi, _ ->
            val hintCode = if (learnedWubi.isNotEmpty()) " (五笔: $learnedWubi)" else ""
            Toast.makeText(
                this@ShengXiaImeService,
                "✨ 已自动组词收录：「$learnedPhrase」$hintCode",
                Toast.LENGTH_SHORT
            ).show()
        }
        lastCommittedWord = word
        composingT14.clear()
        composingRawLetters.clear()
        currentAssociations = T14WubiEngine.getAssociations(word)
        refreshCandidates()
    }

    private fun showFullCandidateGridPanel() {
        currentPanel = PanelState.CANDIDATE_GRID
        bodyFrame.removeAllViews()
        val panelBg = getAdaptivePanelBgColor()
        val cardBg = getAdaptiveCardBgColor(false)
        val firstCardBg = getAdaptiveCardBgColor(true)
        val cardStroke = getAdaptiveCardStrokeColor()
        val normalTxtCol = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), cardBg, resolveDynamicCandidateTextColor(), isHint = false)
        val firstTxtCol = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), firstCardBg, normalTxtCol, isHint = false)
        val candTf = CustomFontManager.getCandidateTypeface(this)

        val scroll = ScrollView(this).apply {
            background = CssSkinManager.makeGradientDrawable(panelBg, panelBg, dp(14), cardStroke, dp(1))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        fun attachGridCandTouch(cardView: View) {
            cardView.setOnTouchListener { _, ev ->
                if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                    KeySoundManager.playClick(this@ShengXiaImeService)
                }
                false
            }
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        if (composingEnglish.isNotEmpty() && currentEnglishSuggestions.isNotEmpty()) {
            var engIdx = 0
            currentEnglishSuggestions.chunked(3).forEach { rowWords ->
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowWords.forEach { w ->
                    val isFirst = (engIdx == 0)
                    engIdx++
                    val bgCol = if (isFirst) firstCardBg else cardBg
                    val tv = TextView(this).apply {
                        text = w
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * getCandidateFontScale())
                        setTextColor(if (isFirst) firstTxtCol else normalTxtCol)
                        typeface = CustomFontManager.getEngKeyTypeface(this@ShengXiaImeService)
                        paint.isFakeBoldText = false
                        gravity = Gravity.CENTER
                        background = CssSkinManager.makeGradientDrawable(bgCol, bgCol, dp(10), cardStroke, dp(1))
                        val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                        val gap = dp(skin.keyGapDp); lp.setMargins(gap, gap, gap, gap)
                        layoutParams = lp
                        attachGridCandTouch(this)
                        setOnClickListener {
                            val rawPref = composingEnglish.toString()
                            currentInputConnection?.commitText(w, 1)
                            T14WubiEngine.onEnglishWordCommitted(w, rawPref, dbHelper)
                            composingEnglish.clear()
                            showKeyboardPanel()
                            refreshEnglishCandidates()
                        }
                    }
                    r.addView(tv)
                }
                for (i in 0 until (3 - rowWords.size)) {
                    r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f) })
                }
                container.addView(r)
            }
            scroll.addView(container)
            bodyFrame.addView(scroll)
            return
        }

        var globalIdx = 0
        currentCandidates.chunked(3).forEach { rowCands ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowCands.forEach { cand ->
                val isFirst = (globalIdx == 0)
                globalIdx++
                val label = if (!cand.isWubiMatch && !cand.wubiHint.isNullOrEmpty()) {
                    "${cand.word}(${cand.wubiHint})"
                } else {
                    cand.word
                }
                val bgCol = if (isFirst) firstCardBg else cardBg
                val tv = TextView(this).apply {
                    text = label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * getCandidateFontScale())
                    setTextColor(if (isFirst) firstTxtCol else normalTxtCol)
                    typeface = candTf
                    paint.isFakeBoldText = false
                    gravity = Gravity.CENTER
                    background = CssSkinManager.makeGradientDrawable(bgCol, bgCol, dp(10), cardStroke, dp(1))
                    val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                    val gap = dp(skin.keyGapDp); lp.setMargins(gap, gap, gap, gap)
                    layoutParams = lp
                    attachGridCandTouch(this)
                    setOnClickListener { selectCandidate(cand) }
                }
                r.addView(tv)
            }
            for (i in 0 until (3 - rowCands.size)) {
                r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f) })
            }
            container.addView(r)
        }
        scroll.addView(container)
        bodyFrame.addView(scroll)
    }

    private fun commitDirectString(str: String) {
        if (composingEnglish.isNotEmpty()) {
            currentInputConnection?.commitText(composingEnglish.toString(), 1)
            composingEnglish.clear()
        }
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        hideAssociationBar()
        currentInputConnection?.commitText(str, 1)
    }

    private fun commitOrSelectFirst(punct: String) {
        if (composingEnglish.isNotEmpty()) {
            currentInputConnection?.commitText(composingEnglish.toString(), 1)
            composingEnglish.clear()
        }
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        hideAssociationBar()
        currentInputConnection?.commitText(punct, 1)
    }

    private fun clearComposing() {
        composingT14.clear()
        composingRawLetters.clear()
        composingEnglish.clear()
        currentAssociations = emptyList()
        dismissComposingPopup()
        refreshCandidates()
    }

    private fun handleBackspace() {
        if (composingEnglish.isNotEmpty()) {
            composingEnglish.deleteCharAt(composingEnglish.length - 1)
            refreshEnglishCandidates()
        } else if (composingT14.isNotEmpty()) {
            composingT14.deleteCharAt(composingT14.length - 1)
            if (composingRawLetters.isNotEmpty()) {
                composingRawLetters.deleteCharAt(composingRawLetters.length - 1)
            }
            refreshCandidates()
        } else {
            hideAssociationBar()
            performSmartBackspace()
        }
    }

    /**
     * 智能退格删除：完整识别 UTF-16 高低代理对（Emoji 表情、生僻字、特殊符号）、变体选择符与字素簇，
     * 彻底杜绝 deleteSurroundingText(1, 0) 只删掉半个代理对导致出现黑色方块问号 (0xFFFD) 的问题！
     */
    private fun performSmartBackspace() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val before = ic.getTextBeforeCursor(32, 0)
        if (before.isNullOrEmpty()) {
            ic.deleteSurroundingText(1, 0)
            return
        }
        val str = before.toString()
        val len = str.length
        val bi = java.text.BreakIterator.getCharacterInstance()
        bi.setText(str)
        var cutIndex = bi.preceding(len)
        if (cutIndex == java.text.BreakIterator.DONE || cutIndex < 0 || cutIndex >= len) {
            cutIndex = len - 1
        }
        // 若末尾是变体选择符 (0xFE00..0xFE0F) 或键帽组合符 (0x20E3)，连同前方基础字符一并删掉
        if (cutIndex == len - 1 && (str[cutIndex].code in 0xFE00..0xFE0F || str[cutIndex].code == 0x20E3) && cutIndex > 0) {
            cutIndex--
        }
        // 严防把 UTF-16 高低代理对从中间劈开，并顺手清理紧邻的变体选择符、零宽连字符 (0x200D) 或已残留的孤立代理/乱码符 (0xFFFD)
        while (cutIndex > 0) {
            val chAtCut = str[cutIndex]
            val chBefore = str[cutIndex - 1]
            if (Character.isLowSurrogate(chAtCut) && Character.isHighSurrogate(chBefore)) {
                cutIndex--
            } else if (chBefore.code in 0xFE00..0xFE0F || chBefore.code == 0x200D) {
                cutIndex--
            } else if ((Character.isHighSurrogate(chBefore) && !Character.isLowSurrogate(chAtCut)) || chBefore.code == 0xFFFD) {
                cutIndex--
            } else {
                break
            }
        }
        if (cutIndex > 0 && (Character.isHighSurrogate(str[cutIndex - 1]) || str[cutIndex - 1].code == 0xFFFD)) {
            cutIndex--
        }
        val deleteCount = (len - cutIndex).coerceAtLeast(1)
        ic.deleteSurroundingText(deleteCount, 0)
    }

    private fun handleEnterKey() {
        if (composingEnglish.isNotEmpty()) {
            val rawEng = composingEnglish.toString()
            currentInputConnection?.commitText(rawEng, 1)
            T14WubiEngine.onEnglishWordCommitted(rawEng, rawEng, dbHelper)
            clearComposing()
            return
        }
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()
            if (first != null) {
                selectCandidate(first)
            } else {
                commitWordWithAssociation(composingRawLetters.toString(), "")
            }
            return
        }
        hideAssociationBar()
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        if (editorInfo != null && (editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            val action = editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_MASK_ACTION
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_NONE &&
                action != android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        ic.commitText("\n", 1)
    }

    // ==================== 图 2 同款丰富符号面板（左侧标题栏原地停留不跳回顶部） ====================
    private fun showSymbolsPanel() {
        currentPanel = PanelState.SYMBOLS
        bodyFrame.removeAllViews()

        val outerVertical = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val upperHorizontal = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val symPanelBg = getAdaptivePanelBgColor()
        val symCardBg = getAdaptiveCardBgColor(false)
        val symActiveBg = getAdaptiveCardBgColor(true)
        val symStroke = getAdaptiveCardStrokeColor()
        val readableDarkText = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), symCardBg, resolveDynamicCandidateTextColor(), isHint = false)
        val symHighlightText = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), symActiveBg, readableDarkText, isHint = false)

        val leftCatScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            background = CssSkinManager.makeGradientDrawable(symPanelBg, symPanelBg, dp(14), symStroke, dp(1))
            val lp = LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.MATCH_PARENT)
            lp.rightMargin = dp(6)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            viewTreeObserver.addOnScrollChangedListener {
                symbolCategoryScrollY = scrollY
            }
        }
        val leftCatCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        val rightGridScroll = ScrollView(this).apply {
            background = CssSkinManager.makeGradientDrawable(symCardBg, symCardBg, dp(16), symStroke, dp(1))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }
        val rightGridCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        val catTvMap = LinkedHashMap<String, TextView>()

        fun refreshCategoryHighlightVisuals() {
            catTvMap.forEach { (name, itemTv) ->
                val active = (name == currentSymbolCategory)
                itemTv.setTextColor(if (active) symHighlightText else readableDarkText)
                itemTv.typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                itemTv.background = if (active) CssSkinManager.makeGradientDrawable(symActiveBg, symActiveBg, dp(12), symStroke, dp(1)) else null
            }
        }

        fun rebuildSymbolRightGrid() {
            rightGridCol.removeAllViews()
            val symList = if (currentSymbolCategory == "最近") {
                getDynamicRecentSymbols()
            } else {
                EmojiKaomojiData.SYMBOL_CATEGORIES[currentSymbolCategory] ?: emptyList()
            }
            symList.chunked(5).forEach { rowSyms ->
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
                }
                rowSyms.forEach { entry ->
                    val cell = FrameLayout(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                        setOnClickListener {
                            KeySoundManager.playClick(this@ShengXiaImeService)
                            recordRecentSymbol(entry.text)
                            commitOrSelectFirst(entry.text)
                            if (!isSymbolLocked) {
                                showKeyboardPanel()
                            } else if (currentSymbolCategory == "最近") {
                                rebuildSymbolRightGrid()
                            }
                        }
                    }
                    if (entry.isEnglish) {
                        val engBadge = TextView(this).apply {
                            text = "英"
                            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
                            setTextColor(Color.parseColor("#9AA0A6"))
                            gravity = Gravity.END or Gravity.TOP
                            setPadding(0, dp(3), dp(6), 0)
                        }
                        cell.addView(engBadge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    }
                    val symFontSp = when {
                        entry.text.length > 8 -> 10.5f
                        entry.text.length > 4 -> 12.5f
                        entry.text.length > 2 -> 14.5f
                        else -> 17f
                    }
                    val symTv = TextView(this).apply {
                        text = entry.text
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, symFontSp)
                        setTextColor(readableDarkText)
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                        gravity = Gravity.CENTER
                    }
                    cell.addView(symTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    r.addView(cell)
                }
                for (i in 0 until (5 - rowSyms.size)) {
                    r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f) })
                }
                rightGridCol.addView(r)
            }
        }

        EmojiKaomojiData.SYMBOL_CATEGORIES.keys.forEach { catName ->
            val tv = TextView(this).apply {
                text = catName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
                setOnClickListener {
                    KeySoundManager.playClick(this@ShengXiaImeService)
                    currentSymbolCategory = catName
                    refreshCategoryHighlightVisuals()
                    rebuildSymbolRightGrid()
                    rightGridScroll.scrollTo(0, 0)
                }
            }
            catTvMap[catName] = tv
            leftCatCol.addView(tv)
        }
        refreshCategoryHighlightVisuals()
        rebuildSymbolRightGrid()

        leftCatScroll.addView(leftCatCol)
        if (symbolCategoryScrollY > 0) {
            leftCatScroll.post { leftCatScroll.scrollTo(0, symbolCategoryScrollY) }
        }
        upperHorizontal.addView(leftCatScroll)

        rightGridScroll.addView(rightGridCol)
        upperHorizontal.addView(rightGridScroll)
        outerVertical.addView(upperHorizontal)

        val bottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        }
        bottomRow.addView(makeFuncKey("返回", weight = 0.85f, keyId = "sym") { showKeyboardPanel() })
        bottomRow.addView(makeFuncKey("△", weight = 1.1f, keyId = "zx") {
            rightGridScroll.smoothScrollBy(0, -dp(140))
        })
        bottomRow.addView(makeFuncKey("▽", weight = 1.1f, keyId = "cv") {
            rightGridScroll.smoothScrollBy(0, dp(140))
        })
        var lockBtnRef: View? = null
        lockBtnRef = makeFuncKey(if (isSymbolLocked) "🔒已锁" else "🔓不锁", weight = 1.1f, keyId = "bn") {
            isSymbolLocked = !isSymbolLocked
            (lockBtnRef as? ViewGroup)?.let { vg ->
                for (i in 0 until vg.childCount) {
                    val ch = vg.getChildAt(i)
                    if (ch is TextView) {
                        ch.text = if (isSymbolLocked) "🔒已锁" else "🔓不锁"
                    }
                }
            }
        }
        bottomRow.addView(lockBtnRef)
        bottomRow.addView(makeBackspaceKey(weight = 0.95f))
        outerVertical.addView(bottomRow)

        bodyFrame.addView(outerVertical)
    }

    // ==================== 键盘内快捷设置：高度、按键字号、候选框字号、重置高频排序 ====================
    private fun showQuickHeightAndSettingsPanel() {
        currentPanel = PanelState.QUICK_HEIGHT_SETTINGS
        bodyFrame.removeAllViews()

        val qsPanelBg = getAdaptivePanelBgColor()
        val qsStroke = getAdaptiveCardStrokeColor()
        val panelLabelColor = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), qsPanelBg, resolveDynamicCandidateTextColor(), isHint = false)
        val qsHighlightColor = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), qsPanelBg, panelLabelColor, isHint = false)

        val scroll = ScrollView(this).apply {
            background = CssSkinManager.makeGradientDrawable(qsPanelBg, qsPanelBg, dp(14), qsStroke, dp(1))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = TextView(this).apply {
            text = "‹ 返回键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setTextColor(qsHighlightColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(4), dp(14), dp(4))
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                showKeyboardPanel()
            }
        }
        val headerSpacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        val moreSettingsBtn = TextView(this).apply {
            text = "更多设置 ›"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setTextColor(qsHighlightColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(4), dp(4), dp(4))
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(intent)
            }
        }
        header.addView(backBtn)
        header.addView(headerSpacer)
        header.addView(moreSettingsBtn)
        root.addView(header)

        // 1. 面板高度实时调节
        val heightLabel = TextView(this).apply {
            text = "面板高度：${getKeyboardHeightDp()} dp"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(heightLabel)

        val heightBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        heightBtnRow.addView(makeFuncKey("➖调矮", smallText = true) {
            setKeyboardHeightDp(getKeyboardHeightDp() - 15)
            heightLabel.text = "面板高度：${getKeyboardHeightDp()} dp"
        })
        heightBtnRow.addView(makeFuncKey("标准(285)", smallText = true) {
            setKeyboardHeightDp(285)
            heightLabel.text = "面板高度：285 dp"
        })
        heightBtnRow.addView(makeFuncKey("平板(345)", smallText = true) {
            setKeyboardHeightDp(345)
            heightLabel.text = "面板高度：345 dp"
        })
        heightBtnRow.addView(makeFuncKey("➕加高", smallText = true) {
            setKeyboardHeightDp(getKeyboardHeightDp() + 15)
            heightLabel.text = "面板高度：${getKeyboardHeightDp()} dp"
        })
        root.addView(heightBtnRow)

        // 方案B 防误触滑块锁：
        // 1) 支持一键「🔒锁定滑块 / 🔓解锁调节」；
        // 2) 即使在解锁状态下，手指上下滑动菜单也绝不触发滑块跳变（仅当明确横向拖动 dx > dy * 1.35 时才调节滑块）！
        var isSliderLocked = KeyboardBacklightOverlayView.isQuickSliderLocked(this)
        val trackedSeekBars = ArrayList<SeekBar>(6)
        var lockBtnTvRef: TextView? = null

        fun updateSliderLockVisuals() {
            val alphaVal = if (isSliderLocked) 0.52f else 1.0f
            for (sb in trackedSeekBars) {
                sb.alpha = alphaVal
            }
            lockBtnTvRef?.text = if (isSliderLocked) "🔒滑块已锁(防误触)" else "🔓滑块已解锁(可拖动)"
        }

        fun attachSafeSeekBarTouch(seekBar: SeekBar, onUserChange: (Int, Boolean) -> Unit) {
            trackedSeekBars.add(seekBar)
            seekBar.alpha = if (isSliderLocked) 0.52f else 1.0f
            var downRawX = 0f
            var downRawY = 0f
            var gestureMode = 0 // 0=未决, 1=确认横向拖动滑块, 2=确认纵向滚动菜单
            var downProgress = 0

            seekBar.setOnTouchListener { v, ev ->
                if (isSliderLocked) {
                    // 锁定状态下：100% 放行给外层 ScrollView 上下滑动，绝不响应滑块触摸
                    v.parent?.requestDisallowInterceptTouchEvent(false)
                    return@setOnTouchListener true
                }
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = ev.rawX
                        downRawY = ev.rawY
                        gestureMode = 0
                        downProgress = seekBar.progress
                        // 绝不在 ACTION_DOWN 拦截 ScrollView 或改变进度，防止点按滑动时误触跳变
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = ev.rawX - downRawX
                        val dy = ev.rawY - downRawY
                        val absDx = abs(dx)
                        val absDy = abs(dy)
                        if (gestureMode == 0) {
                            if (absDy > dp(6) && absDy >= absDx * 0.85f) {
                                gestureMode = 2
                                v.parent?.requestDisallowInterceptTouchEvent(false)
                                return@setOnTouchListener false
                            } else if (absDx > dp(8) && absDx > absDy * 1.35f) {
                                gestureMode = 1
                                v.parent?.requestDisallowInterceptTouchEvent(true)
                            }
                        }
                        if (gestureMode == 1) {
                            val usableW = (seekBar.width - seekBar.paddingLeft - seekBar.paddingRight).coerceAtLeast(1)
                            val deltaProg = ((dx / usableW.toFloat()) * seekBar.max).toInt()
                            val nextProg = (downProgress + deltaProg).coerceIn(0, seekBar.max)
                            if (nextProg != seekBar.progress) {
                                seekBar.progress = nextProg
                                onUserChange(nextProg, false)
                            }
                            true
                        } else {
                            false
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (gestureMode == 1) {
                            onUserChange(seekBar.progress, true)
                        }
                        gestureMode = 0
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        gestureMode = 0
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                        true
                    }
                    else -> false
                }
            }
        }

        // 顶部显式「🔒 滑块防误触锁」快捷开关条
        val sliderLockBarRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
            setPadding(0, dp(4), 0, dp(2))
        }
        val sliderLockHintTv = TextView(this).apply {
            text = "🛡️ 下滑菜单防误触保护："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), 0, dp(4), 0)
        }
        sliderLockBarRow.addView(sliderLockHintTv)
        val lockToggleBtn = makeFuncKey(
            if (isSliderLocked) "🔒滑块已锁(防误触)" else "🔓滑块已解锁(可拖动)",
            smallText = true,
            weight = 1f
        ) {
            isSliderLocked = !isSliderLocked
            KeyboardBacklightOverlayView.setQuickSliderLocked(this@ShengXiaImeService, isSliderLocked)
            updateSliderLockVisuals()
            Toast.makeText(
                this@ShengXiaImeService,
                if (isSliderLocked) "已锁定菜单滑块，上下滑动绝不误触！" else "已解锁滑块，横向拖动即可调节参数",
                Toast.LENGTH_SHORT
            ).show()
        }
        lockBtnTvRef = (lockToggleBtn as? ViewGroup)?.let { vg ->
            (0 until vg.childCount).map { vg.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull()
        }
        sliderLockBarRow.addView(lockToggleBtn)
        root.addView(sliderLockBarRow)

        // 1.2 顶部状态栏图标大小（14dp ~ 34dp）无级实时调节 + 自定义图标上传快捷入口
        fun applyLiveTopIconSize(newDp: Int) {
            val clamped = newDp.coerceIn(CustomTopIconManager.MIN_ICON_SIZE_DP, CustomTopIconManager.MAX_ICON_SIZE_DP)
            CustomTopIconManager.setIconSizeDp(this@ShengXiaImeService, clamped)
            lastRenderedTopIconTs = CustomTopIconManager.getCombinedTimestamp(this@ShengXiaImeService)
            val showLbl = prefs.getBoolean("show_top_labels", false)
            val iH = dp(clamped)
            val iW = if (showLbl) (iH * 1.22f).toInt() else (iH * 1.38f).toInt()
            for (iv in topBarIconViews) {
                val lp = iv.layoutParams
                if (lp != null) {
                    lp.width = iW
                    lp.height = iH
                    iv.layoutParams = lp
                }
                iv.invalidate()
            }
            if (::topIdleBar.isInitialized) {
                topIdleBar.requestLayout()
                topIdleBar.invalidate()
            }
        }

        val initIconDp = CustomTopIconManager.getIconSizeDp(this)
        val iconSizeQuickLabel = TextView(this).apply {
            text = "🐱 顶栏图标大小实时调节：$initIconDp dp（范围 14~34 dp，解锁后横向拖动或点下方按钮调节）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(iconSizeQuickLabel)

        val iconSizeSeek = SeekBar(this).apply {
            max = CustomTopIconManager.MAX_ICON_SIZE_DP - CustomTopIconManager.MIN_ICON_SIZE_DP
            progress = initIconDp - CustomTopIconManager.MIN_ICON_SIZE_DP
        }
        attachSafeSeekBarTouch(iconSizeSeek) { prog, _ ->
            val targetDp = CustomTopIconManager.MIN_ICON_SIZE_DP + prog
            iconSizeQuickLabel.text = "🐱 顶栏图标大小实时调节：$targetDp dp（范围 14~34 dp，解锁后横向拖动或点下方按钮调节）"
            applyLiveTopIconSize(targetDp)
        }
        root.addView(iconSizeSeek)

        val iconQuickBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        iconQuickBtnRow.addView(makeFuncKey("图标➖", smallText = true) {
            val nextDp = (CustomTopIconManager.getIconSizeDp(this@ShengXiaImeService) - 1).coerceAtLeast(CustomTopIconManager.MIN_ICON_SIZE_DP)
            iconSizeSeek.progress = nextDp - CustomTopIconManager.MIN_ICON_SIZE_DP
            iconSizeQuickLabel.text = "🐱 顶栏图标大小实时调节：$nextDp dp（范围 14~34 dp，解锁后横向拖动或点下方按钮调节）"
            applyLiveTopIconSize(nextDp)
        })
        iconQuickBtnRow.addView(makeFuncKey("精致(22dp)", smallText = true) {
            iconSizeSeek.progress = 22 - CustomTopIconManager.MIN_ICON_SIZE_DP
            iconSizeQuickLabel.text = "🐱 顶栏图标大小实时调节：22 dp（范围 14~34 dp，解锁后横向拖动或点下方按钮调节）"
            applyLiveTopIconSize(22)
        })
        iconQuickBtnRow.addView(makeFuncKey("图标➕", smallText = true) {
            val nextDp = (CustomTopIconManager.getIconSizeDp(this@ShengXiaImeService) + 1).coerceAtMost(CustomTopIconManager.MAX_ICON_SIZE_DP)
            iconSizeSeek.progress = nextDp - CustomTopIconManager.MIN_ICON_SIZE_DP
            iconSizeQuickLabel.text = "🐱 顶栏图标大小实时调节：$nextDp dp（范围 14~34 dp，解锁后横向拖动或点下方按钮调节）"
            applyLiveTopIconSize(nextDp)
        })
        iconQuickBtnRow.addView(makeFuncKey("🎨换顶栏图标", smallText = true) {
            val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("open_tab", "top_icon_settings")
            }
            startActivity(intent)
        })
        root.addView(iconQuickBtnRow)

        // 1.5 自定义背景图毛玻璃程度（0 ~ 100）实时调节
        val curBlurLv = prefs.getInt("custom_bg_blur_level", 25).coerceIn(0, 100)
        val blurQuickLabel = TextView(this).apply {
            text = "背景图毛玻璃程度：$curBlurLv / 100（0为高清原图，100为满级柔焦毛玻璃）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(blurQuickLabel)

        val blurQuickSeek = SeekBar(this).apply {
            max = 100
            progress = curBlurLv
        }
        attachSafeSeekBarTouch(blurQuickSeek) { prog, _ ->
            val lv = prog.coerceIn(0, 100)
            prefs.edit().putInt("custom_bg_blur_level", lv).apply()
            lastRenderedBlurLevel = lv
            blurQuickLabel.text = "背景图毛玻璃程度：$lv / 100（0为高清原图，100为满级柔焦毛玻璃）"
            customCoverDrawable?.blurLevel = lv
            rootContainer.invalidate()
        }
        root.addView(blurQuickSeek)

        // 2. 中文14键、英文26键、底部功能键、候选框 四大字号完全独立调节！
        fun buildFontSummaryText(): String {
            return "中文:${(getKeyFontScale() * 100).toInt()}% | 英文:${(getEngKeyFontScale() * 100).toInt()}% | 功能键:${(getFuncKeyFontScale() * 100).toInt()}% | 候选:${(getCandidateFontScale() * 100).toInt()}%"
        }
        val fontLabel = TextView(this).apply {
            text = buildFontSummaryText()
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(fontLabel)

        val fontBtnRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        fontBtnRow1.addView(makeFuncKey("中文➖", smallText = true) {
            setKeyFontScale(getKeyFontScale() - 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow1.addView(makeFuncKey("中文➕", smallText = true) {
            setKeyFontScale(getKeyFontScale() + 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow1.addView(makeFuncKey("英文➖", smallText = true) {
            setEngKeyFontScale(getEngKeyFontScale() - 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow1.addView(makeFuncKey("英文➕", smallText = true) {
            setEngKeyFontScale(getEngKeyFontScale() + 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        root.addView(fontBtnRow1)

        val fontBtnRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        fontBtnRow2.addView(makeFuncKey("功能➖", smallText = true) {
            setFuncKeyFontScale(prefs.getFloat("func_key_font_scale", 1.0f) - 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow2.addView(makeFuncKey("功能➕", smallText = true) {
            setFuncKeyFontScale(prefs.getFloat("func_key_font_scale", 1.0f) + 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow2.addView(makeFuncKey("候选➖", smallText = true) {
            setCandidateFontScale(getCandidateFontScale() - 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        fontBtnRow2.addView(makeFuncKey("候选➕", smallText = true) {
            setCandidateFontScale(getCandidateFontScale() + 0.05f)
            fontLabel.text = buildFontSummaryText()
        })
        root.addView(fontBtnRow2)

        // 一键切换预设皮肤 & 莫奈睡莲图案开关
        val skinQuickLabel = TextView(this).apply {
            text = "一键切换主题与开关："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(skinQuickLabel)

        val skinQuickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        fun applyQuickSkin(cssText: String) {
            CssSkinManager.saveCustomCss(this@ShengXiaImeService, cssText)
            skin = CssSkinManager.getSkin(this@ShengXiaImeService)
            setInputView(onCreateInputView())
        }
        skinQuickRow.addView(makeFuncKey("樱花粉", smallText = true) {
            prefs.edit().putBoolean("force_shuffle_on_preset_keys", false).apply()
            applyQuickSkin(CssSkinManager.SAKURA_PINK_CSS)
        })
        skinQuickRow.addView(makeFuncKey("莫奈花园", smallText = true) {
            applyQuickSkin(CssSkinManager.MONET_WATER_LILY_CSS)
        })
        skinQuickRow.addView(makeFuncKey("薄荷奶黄", smallText = true) {
            reshuffleRandomAccentKeys()
            applyQuickSkin(CssSkinManager.DEFAULT_GRAY_CSS)
        })
        skinQuickRow.addView(makeFuncKey("暗夜黑金", smallText = true) {
            reshuffleRandomAccentKeys()
            applyQuickSkin(CssSkinManager.DARK_MODE_CSS)
        })
        val soundActive = prefs.getBoolean("key_sound_enabled", true)
        skinQuickRow.addView(makeFuncKey(if (soundActive) "音效:开" else "音效:关", smallText = true) {
            prefs.edit().putBoolean("key_sound_enabled", !soundActive).apply()
            setInputView(onCreateInputView())
        })
        val glowActive = isKeyGlowEnabled()
        skinQuickRow.addView(makeFuncKey(if (glowActive) "背光:开" else "背光:关", smallText = true) {
            prefs.edit().putString("key_glow_mode", if (glowActive) "off" else "on").apply()
            setInputView(onCreateInputView())
        })
        root.addView(skinQuickRow)

        val styleQuickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        val accentOn = prefs.getBoolean("random_accent_enabled", true)
        styleQuickRow.addView(makeFuncKey(if (accentOn) "跳色:开" else "跳色:关", smallText = true) {
            prefs.edit().putBoolean("random_accent_enabled", !accentOn).apply()
            setInputView(onCreateInputView())
        })
        styleQuickRow.addView(makeFuncKey("换跳色位置", smallText = true) {
            prefs.edit().putBoolean("random_accent_enabled", true).apply()
            reshuffleRandomAccentKeys()
            setInputView(onCreateInputView())
        })
        val curAlignName = getKeyAlignDisplayName(getKeyAlignMode())
        styleQuickRow.addView(makeFuncKey("字位:$curAlignName", smallText = true) {
            cycleKeyAlignMode()
            setInputView(onCreateInputView())
        })
        val showEditSub = prefs.getBoolean("show_edit_sub_labels", true)
        styleQuickRow.addView(makeFuncKey(if (showEditSub) "编辑标:显" else "编辑标:隐", smallText = true) {
            prefs.edit().putBoolean("show_edit_sub_labels", !showEditSub).apply()
            setInputView(onCreateInputView())
        })
        root.addView(styleQuickRow)

        // 2.2 ☄️ 键盘下星点与光线迸发（键底陨石星爆：密度 / 速度 / 范围 三项独立调节，带防误触锁）
        //     注：原「键盘上表面星点」已按要求移至「更多设置 ›」主菜单中独立保留！
        val qsSparkleOverlay = KeyboardBacklightOverlayView(
            this,
            renderLayerMode = KeyboardBacklightOverlayView.LAYER_FULL_COMBINED,
            clipCornerRadiusPx = dp(14).toFloat(),
            keyboardSurfaceBgColor = qsPanelBg
        ).apply {
            elevation = dp(2).toFloat()
        }

        fun buildUnderBurstHeaderText(): String {
            val ubOn = KeyboardBacklightOverlayView.isUnderBurstEnabled(this@ShengXiaImeService)
            val dLv = KeyboardBacklightOverlayView.getUnderBurstDensity(this@ShengXiaImeService)
            val sLv = KeyboardBacklightOverlayView.getUnderBurstSpeed(this@ShengXiaImeService)
            val rLv = KeyboardBacklightOverlayView.getUnderBurstRange(this@ShengXiaImeService)
            val st = if (ubOn) "已开启 (密度$dLv% · 速度$sLv% · 范围$rLv%)" else "已关闭"
            return "🌙 键下流光细丝与星点：$st"
        }

        val underBurstHeaderLabel = TextView(this).apply {
            text = buildUnderBurstHeaderText()
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(qsHighlightColor)
            setPadding(dp(4), dp(8), dp(4), dp(2))
        }
        root.addView(underBurstHeaderLabel)

        val initDensity = KeyboardBacklightOverlayView.getUnderBurstDensity(this)
        val densityLabel = TextView(this).apply {
            text = "✨ 星点与流光丝疏密：$initDensity%（控制不规则弧形流光丝与星点簇的疏密留白）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(2), dp(4), dp(1))
        }
        root.addView(densityLabel)
        val densitySeek = SeekBar(this).apply {
            max = 90 // 10..100
            progress = (initDensity - 10).coerceIn(0, 90)
        }
        attachSafeSeekBarTouch(densitySeek) { prog, isUp ->
            val lv = (10 + prog).coerceIn(10, 100)
            KeyboardBacklightOverlayView.setUnderBurstDensity(this@ShengXiaImeService, lv)
            KeyboardBacklightOverlayView.setUnderBurstEnabled(this@ShengXiaImeService, true)
            prefs.edit().putString("key_glow_mode", "on").apply()
            densityLabel.text = "✨ 星点与流光丝疏密：$lv%（控制不规则弧形流光丝与星点簇的疏密留白）"
            underBurstHeaderLabel.text = buildUnderBurstHeaderText()
            if (isUp) {
                qsSparkleOverlay.triggerPreviewBurst(resolveGlowColorForTopBar(), qsPanelBg)
            }
        }
        root.addView(densitySeek)

        val initSpeed = KeyboardBacklightOverlayView.getUnderBurstSpeed(this)
        val speedLabel = TextView(this).apply {
            text = "⚡ 绽放与余韵速度：$initSpeed%（控制流光漾开与末尾小星闪烁消融的快慢）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(2), dp(4), dp(1))
        }
        root.addView(speedLabel)
        val speedSeek = SeekBar(this).apply {
            max = 90 // 10..100
            progress = (initSpeed - 10).coerceIn(0, 90)
        }
        attachSafeSeekBarTouch(speedSeek) { prog, isUp ->
            val lv = (10 + prog).coerceIn(10, 100)
            KeyboardBacklightOverlayView.setUnderBurstSpeed(this@ShengXiaImeService, lv)
            KeyboardBacklightOverlayView.setUnderBurstEnabled(this@ShengXiaImeService, true)
            prefs.edit().putString("key_glow_mode", "on").apply()
            speedLabel.text = "⚡ 绽放与余韵速度：$lv%（控制流光漾开与末尾小星闪烁消融的快慢）"
            underBurstHeaderLabel.text = buildUnderBurstHeaderText()
            if (isUp) {
                qsSparkleOverlay.triggerPreviewBurst(resolveGlowColorForTopBar(), qsPanelBg)
            }
        }
        root.addView(speedSeek)

        val initRange = KeyboardBacklightOverlayView.getUnderBurstRange(this)
        val rangeLabel = TextView(this).apply {
            text = "🎯 星点散开距离：$initRange%（控制流光丝与小星芒浮出键帽边缘的远近）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(2), dp(4), dp(1))
        }
        root.addView(rangeLabel)
        val rangeSeek = SeekBar(this).apply {
            max = 90 // 10..100
            progress = (initRange - 10).coerceIn(0, 90)
        }
        attachSafeSeekBarTouch(rangeSeek) { prog, isUp ->
            val lv = (10 + prog).coerceIn(10, 100)
            KeyboardBacklightOverlayView.setUnderBurstRange(this@ShengXiaImeService, lv)
            KeyboardBacklightOverlayView.setUnderBurstEnabled(this@ShengXiaImeService, true)
            prefs.edit().putString("key_glow_mode", "on").apply()
            rangeLabel.text = "🎯 星点散开距离：$lv%（控制流光丝与小星芒浮出键帽边缘的远近）"
            underBurstHeaderLabel.text = buildUnderBurstHeaderText()
            if (isUp) {
                qsSparkleOverlay.triggerPreviewBurst(resolveGlowColorForTopBar(), qsPanelBg)
            }
        }
        root.addView(rangeSeek)

        var ubToggleTvRef: TextView? = null
        var surfToggleTvRef: TextView? = null

        fun refreshUnderBurstButtons() {
            val ubOn = KeyboardBacklightOverlayView.isUnderBurstEnabled(this@ShengXiaImeService)
            val surfOn = KeyboardBacklightOverlayView.isSparkleEnabled(this@ShengXiaImeService)
            ubToggleTvRef?.text = if (ubOn) "☄️键下:开" else "☄️键下:关"
            surfToggleTvRef?.text = if (surfOn) "✨键上:开" else "✨键上:关"
            underBurstHeaderLabel.text = buildUnderBurstHeaderText()
        }

        fun applyUnderBurstPreset(d: Int, s: Int, r: Int, anchorView: View?) {
            KeyboardBacklightOverlayView.setUnderBurstDensity(this@ShengXiaImeService, d)
            KeyboardBacklightOverlayView.setUnderBurstSpeed(this@ShengXiaImeService, s)
            KeyboardBacklightOverlayView.setUnderBurstRange(this@ShengXiaImeService, r)
            KeyboardBacklightOverlayView.setUnderBurstEnabled(this@ShengXiaImeService, true)
            prefs.edit().putString("key_glow_mode", "on").apply()
            densitySeek.progress = (d - 10).coerceIn(0, 90)
            speedSeek.progress = (s - 10).coerceIn(0, 90)
            rangeSeek.progress = (r - 10).coerceIn(0, 90)
            densityLabel.text = "✨ 星点与流光丝疏密：$d%（控制不规则弧形流光丝与星点簇的疏密留白）"
            speedLabel.text = "⚡ 绽放与余韵速度：$s%（控制流光漾开与末尾小星闪烁消融的快慢）"
            rangeLabel.text = "🎯 星点散开距离：$r%（控制流光丝与小星芒浮出键帽边缘的远近）"
            refreshUnderBurstButtons()
            if (anchorView != null) {
                qsSparkleOverlay.triggerKeyDown(anchorView, dp(10).toFloat(), resolveGlowColorForTopBar(), qsPanelBg)
                qsSparkleOverlay.triggerKeyUp(anchorView)
            } else {
                qsSparkleOverlay.triggerPreviewBurst(resolveGlowColorForTopBar(), qsPanelBg)
            }
        }

        val burstPresetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        val ubToggleKey = makeFuncKey(
            if (KeyboardBacklightOverlayView.isUnderBurstEnabled(this)) "☄️键下:开" else "☄️键下:关",
            smallText = true
        ) {
            val nextOn = !KeyboardBacklightOverlayView.isUnderBurstEnabled(this@ShengXiaImeService)
            KeyboardBacklightOverlayView.setUnderBurstEnabled(this@ShengXiaImeService, nextOn)
            if (nextOn) {
                prefs.edit().putString("key_glow_mode", "on").apply()
                qsSparkleOverlay.triggerPreviewBurst(resolveGlowColorForTopBar(), qsPanelBg)
            }
            refreshUnderBurstButtons()
        }
        ubToggleTvRef = (ubToggleKey as? ViewGroup)?.let { vg ->
            (0 until vg.childCount).map { vg.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull()
        }
        burstPresetRow.addView(ubToggleKey)

        var compactPresetRef: View? = null
        compactPresetRef = makeFuncKey("清透留白", smallText = true) {
            applyUnderBurstPreset(38, 62, 36, compactPresetRef)
        }
        burstPresetRow.addView(compactPresetRef)

        var stdPresetRef: View? = null
        stdPresetRef = makeFuncKey("默认星语", smallText = true) {
            applyUnderBurstPreset(65, 60, 48, stdPresetRef)
        }
        burstPresetRow.addView(stdPresetRef)

        var richPresetRef: View? = null
        richPresetRef = makeFuncKey("唯美流光", smallText = true) {
            applyUnderBurstPreset(88, 52, 64, richPresetRef)
        }
        burstPresetRow.addView(richPresetRef)

        val surfToggleKey = makeFuncKey(
            if (KeyboardBacklightOverlayView.isSparkleEnabled(this)) "✨键上:开" else "✨键上:关",
            smallText = true
        ) {
            val nextSurf = !KeyboardBacklightOverlayView.isSparkleEnabled(this@ShengXiaImeService)
            KeyboardBacklightOverlayView.setSparkleEnabled(this@ShengXiaImeService, nextSurf)
            refreshUnderBurstButtons()
            Toast.makeText(
                this@ShengXiaImeService,
                if (nextSurf) "已同时开启键盘上表面星点（详细调节在更多设置）" else "已关闭键盘上表面星点，仅保留键下星爆",
                Toast.LENGTH_SHORT
            ).show()
        }
        surfToggleTvRef = (surfToggleKey as? ViewGroup)?.let { vg ->
            (0 until vg.childCount).map { vg.getChildAt(it) }.filterIsInstance<TextView>().firstOrNull()
        }
        burstPresetRow.addView(surfToggleKey)
        root.addView(burstPresetRow)

        // 2.5 右下角回车键文字快捷修改（支持直接粘贴剪贴板最新文字，或跳转后台输入任意文字）
        val curEnterRaw = (prefs.getString("custom_enter_text", "")?.trim() ?: "").ifEmpty { "盛夏光年" }
        val enterCustomLabel = TextView(this).apply {
            text = "右下角按键文字：当前为「${curEnterRaw.replace("\n", "/")}」"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(enterCustomLabel)

        val enterCustomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
        }
        enterCustomRow.addView(makeFuncKey("✏️ 去设置输入新文字", smallText = true, weight = 1.15f) {
            val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra("open_tab", "enter_text")
            }
            startActivity(intent)
        })
        enterCustomRow.addView(makeFuncKey("📋 用刚复制的字替换", smallText = true, weight = 1.15f) {
            val clipText = clipboardManager.primaryClip?.takeIf { it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(this@ShengXiaImeService)?.toString()?.trim()
                ?: dbHelper.getClips().firstOrNull()?.content?.trim() ?: ""
            val clean = clipText.replace("\r", "").trim()
            if (clean.isEmpty()) {
                Toast.makeText(this@ShengXiaImeService, "请先复制你想换上的文字（建议 1~6 个字）", Toast.LENGTH_SHORT).show()
            } else {
                val clipped = if (clean.length > 8) clean.take(8) else clean
                prefs.edit().putString("custom_enter_text", clipped).apply()
                Toast.makeText(this@ShengXiaImeService, "右下角已换为「$clipped」！", Toast.LENGTH_SHORT).show()
                setInputView(onCreateInputView())
            }
        })
        enterCustomRow.addView(makeFuncKey("恢复盛夏光年", smallText = true, weight = 0.9f) {
            prefs.edit().remove("custom_enter_text").apply()
            Toast.makeText(this@ShengXiaImeService, "已恢复为「盛夏光年」！", Toast.LENGTH_SHORT).show()
            setInputView(onCreateInputView())
        })
        root.addView(enterCustomRow)

        // 2.6 状态栏 5 图标与通配键大小同步调节 + 15 款图 5 同款可爱图标一键换装
        val curIconDp = CustomTopIconManager.getIconSizeDp(this)
        val iconSizeSyncLabel = TextView(this).apply {
            text = "状态栏与通配键图标大小（同步联动）：当前 $curIconDp dp"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(panelLabelColor)
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(iconSizeSyncLabel)

        fun applySyncedIconSizeDp(newDp: Int) {
            val clamped = newDp.coerceIn(CustomTopIconManager.MIN_ICON_SIZE_DP, CustomTopIconManager.MAX_ICON_SIZE_DP)
            CustomTopIconManager.setIconSizeDp(this@ShengXiaImeService, clamped)
            iconSizeSyncLabel.text = "状态栏与通配键图标大小（同步联动）：当前 $clamped dp"
            val isMonetLily = isWaterLilyDecorEnabled()
            val showTopLabels = prefs.getBoolean("show_top_labels", false)
            topBarIconViews.forEach { iv ->
                val effectiveDp = if (isMonetLily) maxOf(clamped, 34) else clamped
                val iconH = dp(effectiveDp)
                val iconW = if (showTopLabels && !isMonetLily) (iconH * 1.22f).toInt() else (iconH * 1.38f).toInt()
                iv.layoutParams = LinearLayout.LayoutParams(iconW, iconH)
                iv.requestLayout()
                iv.invalidate()
            }
        }

        val iconSizeSyncRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
        }
        iconSizeSyncRow.addView(makeFuncKey("➖调小", smallText = true) {
            applySyncedIconSizeDp(CustomTopIconManager.getIconSizeDp(this@ShengXiaImeService) - 2)
        })
        iconSizeSyncRow.addView(makeFuncKey("精致(20)", smallText = true) {
            applySyncedIconSizeDp(20)
        })
        iconSizeSyncRow.addView(makeFuncKey("标准(22)", smallText = true) {
            applySyncedIconSizeDp(22)
        })
        iconSizeSyncRow.addView(makeFuncKey("➕调大", smallText = true) {
            applySyncedIconSizeDp(CustomTopIconManager.getIconSizeDp(this@ShengXiaImeService) + 2)
        })
        root.addView(iconSizeSyncRow)

        // 选择要更换图标的位置：-1 代表「通配键」，0..4 代表顶栏 5 个图标槽位
        var selectedIconTargetSlot = -1
        fun getTargetSummaryText(): String {
            return if (selectedIconTargetSlot == -1) {
                val curSt = WildcardCuteIconView.getWildcardIconStyle(this@ShengXiaImeService)
                "点选下方可爱图标更换 ->【通配键】（当前：${WildcardCuteIconView.getStyleDisplayName(curSt)}）"
            } else {
                val slotNames = mapOf(
                    MinimalistIconView.TYPE_SETTINGS to "顶栏1(设置)",
                    MinimalistIconView.TYPE_EMOJI to "顶栏2(表情)",
                    MinimalistIconView.TYPE_CLIPBOARD to "顶栏3(剪贴)",
                    MinimalistIconView.TYPE_FAVORITE to "顶栏4(收藏)",
                    MinimalistIconView.TYPE_COLLAPSE to "顶栏5(收起)"
                )
                val curPreset = CustomTopIconManager.getSlotPresetIconId(this@ShengXiaImeService, selectedIconTargetSlot)
                "点选下方可爱图标更换 ->【${slotNames[selectedIconTargetSlot]}】（当前：${MinimalistIconView.getPresetIconName(curPreset)}）"
            }
        }

        val wcLabel = TextView(this).apply {
            text = getTargetSummaryText()
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(qsHighlightColor)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(6), dp(4), dp(2))
        }
        root.addView(wcLabel)

        val targetSelectRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
        }
        listOf(
            "通配键" to -1,
            "顶栏1" to MinimalistIconView.TYPE_SETTINGS,
            "顶栏2" to MinimalistIconView.TYPE_EMOJI,
            "顶栏3" to MinimalistIconView.TYPE_CLIPBOARD,
            "顶栏4" to MinimalistIconView.TYPE_FAVORITE,
            "顶栏5" to MinimalistIconView.TYPE_COLLAPSE
        ).forEach { (tName, tSlot) ->
            targetSelectRow.addView(makeFuncKey(tName, smallText = true, weight = 1f) {
                selectedIconTargetSlot = tSlot
                wcLabel.text = getTargetSummaryText()
            })
        }
        root.addView(targetSelectRow)

        val allCuteChoices = listOf(
            Triple("🎀蝴蝶结", WildcardCuteIconView.STYLE_CUTE_BOW, MinimalistIconView.ICON_BOW),
            Triple("🌸小樱花", WildcardCuteIconView.STYLE_SAKURA, MinimalistIconView.ICON_FLOWER),
            Triple("✨双星芒", WildcardCuteIconView.STYLE_SPARKLES, MinimalistIconView.ICON_SPARKLES),
            Triple("🍀四叶草", WildcardCuteIconView.STYLE_CLOVER, MinimalistIconView.ICON_CLOVER),
            Triple("☘️幸运草", WildcardCuteIconView.STYLE_LUCKY_CLOVER, MinimalistIconView.ICON_LUCKY_CLOVER),
            Triple("🌠许愿星", WildcardCuteIconView.STYLE_METEOR, MinimalistIconView.ICON_METEOR),
            Triple("❄️小雪花", WildcardCuteIconView.STYLE_SNOWFLAKE, MinimalistIconView.ICON_SNOWFLAKE),
            Triple("📖小书本", WildcardCuteIconView.STYLE_BOOK, MinimalistIconView.ICON_BOOK),
            Triple("🌙星月", WildcardCuteIconView.STYLE_STAR_MOON, MinimalistIconView.ICON_STAR_MOON),
            Triple("🪄星杖", WildcardCuteIconView.STYLE_MAGIC_WAND, MinimalistIconView.ICON_MAGIC_WAND),
            Triple("🐱猫猫头", WildcardCuteIconView.STYLE_CAT, MinimalistIconView.TYPE_SETTINGS),
            Triple("💕双爱心", WildcardCuteIconView.STYLE_HEART, MinimalistIconView.TYPE_EMOJI),
            Triple("🪐小星球", WildcardCuteIconView.STYLE_PLANET, MinimalistIconView.TYPE_CLIPBOARD),
            Triple("⭐胖星星", WildcardCuteIconView.STYLE_STAR, MinimalistIconView.TYPE_FAVORITE),
            Triple("👑小皇冠", WildcardCuteIconView.STYLE_CROWN, MinimalistIconView.TYPE_COLLAPSE),
            Triple("🔤文字", WildcardCuteIconView.STYLE_TEXT_LABEL, -1)
        )

        allCuteChoices.chunked(4).forEach { rowItems ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36))
            }
            rowItems.forEach { (btnName, wcStyle, topPresetId) ->
                r.addView(makeFuncKey(btnName, smallText = true, weight = 1f) {
                    if (selectedIconTargetSlot == -1) {
                        WildcardCuteIconView.setWildcardIconStyle(this@ShengXiaImeService, wcStyle)
                        wcLabel.text = getTargetSummaryText()
                        Toast.makeText(this@ShengXiaImeService, "通配键已换为：$btnName", Toast.LENGTH_SHORT).show()
                    } else {
                        if (topPresetId == -1) {
                            Toast.makeText(this@ShengXiaImeService, "顶栏为纯图标槽位，请点选其他 15 款可爱图标～", Toast.LENGTH_SHORT).show()
                        } else {
                            CustomTopIconManager.setSlotPresetIconId(this@ShengXiaImeService, selectedIconTargetSlot, topPresetId)
                            topBarIconViews.forEach { it.invalidate() }
                            wcLabel.text = getTargetSummaryText()
                            Toast.makeText(this@ShengXiaImeService, "已将该顶栏图标换为：$btnName", Toast.LENGTH_SHORT).show()
                        }
                    }
                })
            }
            root.addView(r)
        }

        // 3. 一键重置文字默认排序 & 打开完整管理后台（常用语导出导入、CSS皮肤、添加颜文字、词库导入）
        val bottomActionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
            lp.topMargin = dp(8)
            layoutParams = lp
        }
        bottomActionRow.addView(makeFuncKey("🔄 重置文字默认排序", smallText = true, weight = 1f) {
            T14WubiEngine.resetUserFrequency(dbHelper)
            Toast.makeText(this@ShengXiaImeService, "已重置个人高频排序，恢复默认词库顺序！", Toast.LENGTH_SHORT).show()
        })
        bottomActionRow.addView(makeFuncKey("📂 词库/导出/CSS皮肤后台", smallText = true, weight = 1.2f) {
            val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        })
        root.addView(bottomActionRow)

        scroll.addView(root)
        bodyFrame.addView(scroll)
        bodyFrame.addView(
            qsSparkleOverlay,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    // ==================== 剪贴板(300条无上限·含智能网址提取) + 多分类常用语面板 ====================
    private var isPhraseSubTab = true
    private var currentPhraseCategory = "收藏"
    private var currentClipFilter = "全部" // "全部" | "链接" | "置顶"

    private fun openDedicatedClipboardPhraseEditor(
        mode: String = if (isPhraseSubTab) "phrases" else "clips",
        editPhraseId: Long = -1L,
        editClipId: Long = -1L
    ) {
        try {
            val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("open_tab", "dedicated_phrase_clip_editor")
                putExtra("editor_sub_mode", mode)
                putExtra("default_category", currentPhraseCategory)
                if (editPhraseId > 0L) putExtra("edit_phrase_id", editPhraseId)
                if (editClipId > 0L) putExtra("edit_clip_id", editClipId)
            }
            startActivity(intent)
        } catch (_: Exception) {}
    }

    private fun showClipboardPhrasePanel() {
        currentPanel = PanelState.CLIPBOARD_PHRASE
        bodyFrame.removeAllViews()

        val cpPanelBg = getAdaptivePanelBgColor()
        val cpHeaderBg = getAdaptivePanelHeaderBgColor()
        val cpCardBg = getAdaptiveCardBgColor(false)
        val cpActiveCardBg = getAdaptiveCardBgColor(true)
        val cpStroke = getAdaptiveCardStrokeColor()
        val cpMainText = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), cpPanelBg, resolveDynamicCandidateTextColor(), isHint = false)
        val cpHighlight = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), cpCardBg, cpMainText, isHint = false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(cpPanelBg, cpPanelBg, dp(12), cpStroke, dp(1))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(cpHeaderBg)
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(cpMainText)
            setPadding(dp(8), dp(6), dp(10), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        // 彻底将「剪贴板」与「收藏/常用语」拆分为两个完全独立的专属面板：
        // 点开剪贴板就只有剪贴板，点开收藏就只有收藏，顶栏不再把二者混在一起！
        val currentPanelTitleTv = TextView(this).apply {
            text = if (isPhraseSubTab) "收藏 / 常用语" else "剪贴板"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(cpHighlight)
            typeface = Typeface.DEFAULT_BOLD
            background = CssSkinManager.makeGradientDrawable(cpCardBg, cpCardBg, dp(8), cpStroke, dp(1))
            setPadding(dp(12), dp(5), dp(12), dp(5))
        }
        header.addView(currentPanelTitleTv)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        header.addView(spacer)

        val dedicatedEditorBtn = TextView(this).apply {
            text = if (isPhraseSubTab) "✎ 收藏编辑/搬家页" else "✎ 剪贴板编辑页"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(cpHighlight)
            typeface = Typeface.DEFAULT_BOLD
            background = CssSkinManager.makeGradientDrawable(cpCardBg, cpCardBg, dp(8), cpStroke, dp(1))
            setPadding(dp(9), dp(5), dp(9), dp(5))
            setOnClickListener {
                openDedicatedClipboardPhraseEditor(if (isPhraseSubTab) "phrases" else "clips")
            }
        }
        header.addView(dedicatedEditorBtn)
        root.addView(header)

        if (isPhraseSubTab) {
            val catScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                setBackgroundColor(cpCardBg)
            }
            val catRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(5), dp(8), dp(5))
            }
            val categories = dbHelper.getCategories()
            if (!categories.contains(currentPhraseCategory)) {
                currentPhraseCategory = categories.firstOrNull() ?: "收藏"
            }
            categories.forEach { cat ->
                val active = (cat == currentPhraseCategory)
                val tv = TextView(this).apply {
                    text = cat
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
                    setTextColor(if (active) cpHighlight else cpMainText)
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    background = if (active) CssSkinManager.makeGradientDrawable(cpActiveCardBg, cpActiveCardBg, dp(8), cpStroke, dp(1)) else null
                    setPadding(dp(11), dp(4), dp(11), dp(4))
                    setOnClickListener {
                        currentPhraseCategory = cat
                        showClipboardPhrasePanel()
                    }
                }
                catRow.addView(tv)
            }
            val manageCatBtn = TextView(this).apply {
                text = "⚙️整理/新建目录"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                setTextColor(cpHighlight)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                setOnClickListener {
                    openDedicatedClipboardPhraseEditor("phrases")
                }
            }
            catRow.addView(manageCatBtn)
            catScroll.addView(catRow)
            root.addView(catScroll)

            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val cardList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            val phrases = dbHelper.getPhrasesByCategory(currentPhraseCategory)
            if (phrases.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = "当前「$currentPhraseCategory」目录暂无内容\n可点击任意收藏卡片右侧 ⌄ 展开「归类到目录」，或点击右上角「✎ 收藏编辑/搬家页」批量管理！"
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTextColor(cpMainText)
                    alpha = 0.75f
                    setPadding(dp(16), dp(32), dp(16), dp(32))
                }
                cardList.addView(emptyTv)
            } else {
                var renderedPhraseCount = 0
                fun renderMorePhrases(batchSize: Int) {
                    val end = (renderedPhraseCount + batchSize).coerceAtMost(phrases.size)
                    while (renderedPhraseCount < end) {
                        cardList.addView(buildPhraseCard(phrases[renderedPhraseCount], cpCardBg, cpActiveCardBg, cpStroke, cpMainText, cpHighlight))
                        renderedPhraseCount++
                    }
                }
                renderMorePhrases(22)
                if (phrases.size > 22) {
                    vScroll.viewTreeObserver.addOnScrollChangedListener {
                        if (renderedPhraseCount < phrases.size) {
                            val child = vScroll.getChildAt(0)
                            if (child != null && vScroll.scrollY + vScroll.height >= child.height - dp(260)) {
                                renderMorePhrases(25)
                            }
                        }
                    }
                }
            }
            vScroll.addView(cardList)
            root.addView(vScroll)
        } else {
            val allClips = dbHelper.getClips()
            val filterBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(cpCardBg)
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }
            listOf("全部" to "全部", "链接" to "🔗 链接", "置顶" to "📌 已置顶").forEach { (key, label) ->
                val active = (currentClipFilter == key)
                val tabTv = TextView(this).apply {
                    text = label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    setTextColor(if (active) cpHighlight else cpMainText)
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    isSingleLine = true
                    background = if (active) CssSkinManager.makeGradientDrawable(cpActiveCardBg, cpActiveCardBg, dp(8), cpStroke, dp(1)) else null
                    setPadding(dp(8), dp(4), dp(8), dp(4))
                    setOnClickListener {
                        currentClipFilter = key
                        showClipboardPhrasePanel()
                    }
                }
                filterBar.addView(tabTv)
            }
            filterBar.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
            val countTv = TextView(this).apply {
                text = "${allClips.size}/300"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setTextColor(cpMainText)
                alpha = 0.7f
                setPadding(dp(4), 0, dp(8), 0)
            }
            filterBar.addView(countTv)
            val clearBtn = TextView(this).apply {
                text = "清空未置顶"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(cpHighlight)
                setPadding(dp(6), dp(3), dp(6), dp(3))
                setOnClickListener {
                    dbHelper.clearUnpinnedClips()
                    showClipboardPhrasePanel()
                }
            }
            filterBar.addView(clearBtn)
            root.addView(filterBar)

            val filteredClips = when (currentClipFilter) {
                "链接" -> allClips.filter { ImeDatabaseHelper.extractUrls(it.content).isNotEmpty() }
                "置顶" -> allClips.filter { it.isPinned }
                else -> allClips
            }

            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val clipList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            if (filteredClips.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = if (currentClipFilter == "链接") "当前剪贴板中没有包含网址的记录" else "剪贴板暂无记录（自动保留最近 300 条，无字数上限）"
                    gravity = Gravity.CENTER
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                    setTextColor(cpMainText)
                    alpha = 0.75f
                    setPadding(dp(16), dp(36), dp(16), dp(36))
                }
                clipList.addView(emptyTv)
            } else {
                // 首屏瞬时渲染前 22 条（耗时 < 2ms），向下滑动时无感增量加载后续卡片，彻底根治百条长文本一次性排版卡顿！
                var renderedClipCount = 0
                fun renderMoreClips(batchSize: Int) {
                    val end = (renderedClipCount + batchSize).coerceAtMost(filteredClips.size)
                    while (renderedClipCount < end) {
                        clipList.addView(buildClipCard(filteredClips[renderedClipCount], cpCardBg, cpActiveCardBg, cpStroke, cpMainText, cpHighlight))
                        renderedClipCount++
                    }
                }
                renderMoreClips(22)
                if (filteredClips.size > 22) {
                    vScroll.viewTreeObserver.addOnScrollChangedListener {
                        if (renderedClipCount < filteredClips.size) {
                            val child = vScroll.getChildAt(0)
                            if (child != null && vScroll.scrollY + vScroll.height >= child.height - dp(260)) {
                                renderMoreClips(25)
                            }
                        }
                    }
                }
            }
            vScroll.addView(clipList)
            root.addView(vScroll)
        }

        bodyFrame.addView(root)
    }

    /**
     * 高性能「收藏/常用语」卡片：
     * - 初始仅构建轻量级顶栏（4个View，预览截断为前160字），点击右侧 ⌄ 时才按需懒加载底部操作区与目录芯片！
     */
    private fun buildPhraseCard(
        item: PhraseItem,
        cardBg: Int = getAdaptiveCardBgColor(false),
        activeBg: Int = getAdaptiveCardBgColor(true),
        cardStroke: Int = getAdaptiveCardStrokeColor(),
        cardTxt: Int = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), cardBg, resolveDynamicCandidateTextColor(), isHint = false),
        highlightTxt: Int = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), cardBg, cardTxt, isHint = false)
    ): View {
        var expanded = false
        val urls = ImeDatabaseHelper.extractUrls(item.content)
        val collapsedPreview = if (item.content.length > 160) item.content.substring(0, 160) + "…" else item.content
        val expandedPreview = if (item.content.length > 320) item.content.substring(0, 320) + "…" else item.content

        val outerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(cardBg, cardBg, dp(10), cardStroke, dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }

        val starTv = TextView(this).apply {
            text = if (item.isStarred) "★" else "☆"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (item.isStarred) Color.parseColor("#F5A623") else Color.parseColor("#999999"))
            setPadding(dp(4), dp(2), dp(6), dp(4))
            setOnClickListener {
                dbHelper.togglePhraseStar(item.id, item.isStarred)
                showClipboardPhrasePanel()
            }
        }
        topRow.addView(starTv)

        val contentCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        if (currentPhraseCategory == "收藏" || currentPhraseCategory == "最近") {
            val catBadge = TextView(this).apply {
                text = "📁 目录：${item.category}"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                setTextColor(highlightTxt)
                setPadding(0, 0, 0, dp(2))
            }
            contentCol.addView(catBadge)
        }
        val contentTv = TextView(this).apply {
            text = collapsedPreview
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(cardTxt)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                dbHelper.markPhraseUsed(item.id)
                currentInputConnection?.commitText(item.content, 1)
                showKeyboardPanel()
            }
        }
        contentCol.addView(contentTv)
        topRow.addView(contentCol)

        if (urls.isNotEmpty()) {
            val quickUrlBtn = TextView(this).apply {
                text = "粘贴网址"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                setTextColor(highlightTxt)
                typeface = Typeface.DEFAULT_BOLD
                background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(6), cardStroke, dp(1))
                setPadding(dp(7), dp(3), dp(7), dp(3))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.leftMargin = dp(4)
                layoutParams = lp
                setOnClickListener {
                    currentInputConnection?.commitText(urls.first(), 1)
                    Toast.makeText(this@ShengXiaImeService, "已提取并粘贴网址：${urls.first()}", Toast.LENGTH_SHORT).show()
                }
            }
            topRow.addView(quickUrlBtn)
        }

        var actionContainer: LinearLayout? = null

        fun ensurePhraseActionContainer(): LinearLayout {
            actionContainer?.let { return it }
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(6), dp(4), dp(2))
            }
            if (item.content.length > 60 || item.content.count { it == '\n' } >= 3) {
                val moreEditTv = TextView(this).apply {
                    text = "…查看更多（点击直接进入编辑全文）"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setTextColor(highlightTxt)
                    setPadding(0, 0, 0, dp(6))
                    setOnClickListener {
                        openDedicatedClipboardPhraseEditor("phrases", editPhraseId = item.id)
                    }
                }
                container.addView(moreEditTv)
            }

            val inlineCategoryRow = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                visibility = View.GONE
                setPadding(0, dp(4), 0, dp(4))
            }
            var categoriesPopulated = false
            fun populateCategoryChipsIfNeeded() {
                if (categoriesPopulated) return
                categoriesPopulated = true
                val inlineCatLinear = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val catHintTv = TextView(this).apply {
                    text = "点选目标目录："
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    setTextColor(cardTxt)
                    setPadding(0, 0, dp(4), 0)
                }
                inlineCatLinear.addView(catHintTv)
                dbHelper.getAssignableCategories().forEach { targetCat ->
                    val isCur = (targetCat == item.category)
                    val chip = TextView(this).apply {
                        text = if (isCur) "✓ $targetCat" else targetCat
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setTextColor(if (isCur) highlightTxt else cardTxt)
                        typeface = if (isCur) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        background = CssSkinManager.makeGradientDrawable(if (isCur) activeBg else cpPanelBgColorFallback(), if (isCur) activeBg else cpPanelBgColorFallback(), dp(8), cardStroke, dp(1))
                        setPadding(dp(10), dp(4), dp(10), dp(4))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.rightMargin = dp(6)
                        layoutParams = lp
                        setOnClickListener {
                            dbHelper.movePhraseToCategory(item.id, targetCat)
                            Toast.makeText(this@ShengXiaImeService, "已将该条收藏归类到「$targetCat」目录！", Toast.LENGTH_SHORT).show()
                            showClipboardPhrasePanel()
                        }
                    }
                    inlineCatLinear.addView(chip)
                }
                inlineCategoryRow.addView(inlineCatLinear)
            }

            val btnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            fun makeActionChip(label: String, textColor: Int = cardTxt, onClick: () -> Unit): TextView {
                return TextView(this).apply {
                    text = label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    setTextColor(textColor)
                    gravity = Gravity.CENTER
                    background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(8), cardStroke, dp(1))
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.rightMargin = dp(8)
                    layoutParams = lp
                    setOnClickListener { onClick() }
                }
            }

            btnRow.addView(makeActionChip("✎ 编辑", highlightTxt) {
                openDedicatedClipboardPhraseEditor("phrases", editPhraseId = item.id)
            })
            btnRow.addView(makeActionChip("🗑 删除", Color.parseColor("#E05246")) {
                dbHelper.deletePhrase(item.id)
                Toast.makeText(this@ShengXiaImeService, "已删除该条常用语", Toast.LENGTH_SHORT).show()
                showClipboardPhrasePanel()
            })
            btnRow.addView(makeActionChip("📁 归类(${item.category})", highlightTxt) {
                if (inlineCategoryRow.visibility == View.VISIBLE) {
                    inlineCategoryRow.visibility = View.GONE
                } else {
                    populateCategoryChipsIfNeeded()
                    inlineCategoryRow.visibility = View.VISIBLE
                }
            })
            if (urls.isNotEmpty()) {
                btnRow.addView(makeActionChip("🔗 粘贴网址", highlightTxt) {
                    currentInputConnection?.commitText(urls.first(), 1)
                    Toast.makeText(this@ShengXiaImeService, "已直接粘贴网址：${urls.first()}", Toast.LENGTH_SHORT).show()
                })
            }

            container.addView(btnRow)
            container.addView(inlineCategoryRow)
            outerCard.addView(container)
            actionContainer = container
            return container
        }

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(cardTxt)
            setPadding(dp(10), dp(2), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.text = if (expanded) expandedPreview else collapsedPreview
                contentTv.maxLines = if (expanded) 4 else 2
                contentTv.ellipsize = TextUtils.TruncateAt.END
                val container = ensurePhraseActionContainer()
                container.visibility = if (expanded) View.VISIBLE else View.GONE
                text = if (expanded) "∧" else "⌄"
            }
        }
        topRow.addView(expandTv)

        outerCard.addView(topRow)
        return outerCard
    }

    private fun cpPanelBgColorFallback(): Int = getAdaptivePanelBgColor()

    /**
     * 零卡顿高性能「剪贴板」卡片：
     * - 彻底消除此前每张卡片初始化时同步查询 SQLite 目录 + 预建 18 个隐藏子 View + 全量超长文本排版的三大性能瓶颈！
     * - 初始状态仅构建轻量级 1 行顶栏（仅 4 个子 View，文本预览截断为前 160 字），点开 ⌄ 时才按需懒加载操作按钮与目录芯片。
     */
    private fun buildClipCard(
        clip: ClipItem,
        cardBg: Int = getAdaptiveCardBgColor(false),
        activeBg: Int = getAdaptiveCardBgColor(true),
        cardStroke: Int = getAdaptiveCardStrokeColor(),
        cardTxt: Int = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), cardBg, resolveDynamicCandidateTextColor(), isHint = false),
        highlightTxt: Int = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), cardBg, cardTxt, isHint = false)
    ): View {
        var expanded = false
        val urls = ImeDatabaseHelper.extractUrls(clip.content)
        val collapsedPreview = if (clip.content.length > 160) clip.content.substring(0, 160) + "…" else clip.content
        val expandedPreview = if (clip.content.length > 320) clip.content.substring(0, 320) + "…" else clip.content

        val outerCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(cardBg, cardBg, dp(10), cardStroke, dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }

        val pinTv = TextView(this).apply {
            text = if (clip.isPinned) "📌" else "○"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(cardTxt)
            setPadding(dp(4), dp(2), dp(6), dp(4))
            setOnClickListener {
                dbHelper.toggleClipPin(clip.id, clip.isPinned)
                showClipboardPhrasePanel()
            }
        }
        topRow.addView(pinTv)

        val contentTv = TextView(this).apply {
            text = collapsedPreview
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(cardTxt)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                currentInputConnection?.commitText(clip.content, 1)
                showKeyboardPanel()
            }
        }
        topRow.addView(contentTv)

        if (urls.isNotEmpty()) {
            val pasteUrlBtn = TextView(this).apply {
                text = "粘贴网址"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTextColor(highlightTxt)
                typeface = Typeface.DEFAULT_BOLD
                background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(6), cardStroke, dp(1))
                setPadding(dp(8), dp(3), dp(8), dp(3))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.leftMargin = dp(4)
                layoutParams = lp
                setOnClickListener {
                    currentInputConnection?.commitText(urls.first(), 1)
                    Toast.makeText(this@ShengXiaImeService, "已提取并直接粘贴网址：${urls.first()}", Toast.LENGTH_SHORT).show()
                }
            }
            topRow.addView(pasteUrlBtn)
        }

        var actionContainer: LinearLayout? = null

        fun ensureClipActionContainer(): LinearLayout {
            actionContainer?.let { return it }
            val container = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(6), dp(4), dp(2))
            }

            if (clip.content.length > 60 || clip.content.count { it == '\n' } >= 3) {
                val moreEditTv = TextView(this).apply {
                    text = "…查看更多（点击直接进入编辑全文）"
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                    setTextColor(highlightTxt)
                    setPadding(0, 0, 0, dp(6))
                    setOnClickListener {
                        openDedicatedClipboardPhraseEditor("clips", editClipId = clip.id)
                    }
                }
                container.addView(moreEditTv)
            }

            if (urls.isNotEmpty()) {
                urls.forEach { u ->
                    val urlChip = TextView(this).apply {
                        text = "🔗 点击直接粘贴网址：$u"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setTextColor(highlightTxt)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                        background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(7), cardStroke, dp(1))
                        setPadding(dp(10), dp(5), dp(10), dp(5))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.bottomMargin = dp(6)
                        layoutParams = lp
                        setOnClickListener {
                            currentInputConnection?.commitText(u, 1)
                            Toast.makeText(this@ShengXiaImeService, "已粘贴网址：$u", Toast.LENGTH_SHORT).show()
                        }
                    }
                    container.addView(urlChip)
                }
            }

            val inlineSaveCatRow = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                visibility = View.GONE
                setPadding(0, dp(4), 0, dp(4))
            }
            var saveCatsPopulated = false
            fun populateSaveCatsIfNeeded() {
                if (saveCatsPopulated) return
                saveCatsPopulated = true
                val inlineSaveLinear = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                }
                val saveHintTv = TextView(this).apply {
                    text = "存入哪个目录："
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f)
                    setTextColor(cardTxt)
                    setPadding(0, 0, dp(4), 0)
                }
                inlineSaveLinear.addView(saveHintTv)
                dbHelper.getAssignableCategories().forEach { targetCat ->
                    val chip = TextView(this).apply {
                        text = "＋$targetCat"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                        setTextColor(highlightTxt)
                        background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(8), cardStroke, dp(1))
                        setPadding(dp(10), dp(4), dp(10), dp(4))
                        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        lp.rightMargin = dp(6)
                        layoutParams = lp
                        setOnClickListener {
                            dbHelper.addOrUpdatePhrase(null, targetCat, clip.content, true)
                            Toast.makeText(this@ShengXiaImeService, "已收藏并归类到「$targetCat」目录！", Toast.LENGTH_SHORT).show()
                            inlineSaveCatRow.visibility = View.GONE
                        }
                    }
                    inlineSaveLinear.addView(chip)
                }
                inlineSaveCatRow.addView(inlineSaveLinear)
            }

            val btnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            fun makeClipChip(label: String, textColor: Int = cardTxt, onClick: () -> Unit): TextView {
                return TextView(this).apply {
                    text = label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                    setTextColor(textColor)
                    gravity = Gravity.CENTER
                    background = CssSkinManager.makeGradientDrawable(activeBg, activeBg, dp(8), cardStroke, dp(1))
                    setPadding(dp(12), dp(6), dp(12), dp(6))
                    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    lp.rightMargin = dp(8)
                    layoutParams = lp
                    setOnClickListener { onClick() }
                }
            }

            btnRow.addView(makeClipChip("✎ 编辑", highlightTxt) {
                openDedicatedClipboardPhraseEditor("clips", editClipId = clip.id)
            })
            btnRow.addView(makeClipChip("🗑 删除", Color.parseColor("#E05246")) {
                dbHelper.deleteClip(clip.id)
                showClipboardPhrasePanel()
            })
            btnRow.addView(makeClipChip("☆ 收藏(选目录)", highlightTxt) {
                if (inlineSaveCatRow.visibility == View.VISIBLE) {
                    inlineSaveCatRow.visibility = View.GONE
                } else {
                    populateSaveCatsIfNeeded()
                    inlineSaveCatRow.visibility = View.VISIBLE
                }
            })
            if (urls.isNotEmpty()) {
                btnRow.addView(makeClipChip("🔗 提取网址", highlightTxt) {
                    currentInputConnection?.commitText(urls.first(), 1)
                    Toast.makeText(this@ShengXiaImeService, "已直接粘贴网址：${urls.first()}", Toast.LENGTH_SHORT).show()
                })
            }

            container.addView(btnRow)
            container.addView(inlineSaveCatRow)
            outerCard.addView(container)
            actionContainer = container
            return container
        }

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTextColor(cardTxt)
            setPadding(dp(10), dp(2), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.text = if (expanded) expandedPreview else collapsedPreview
                contentTv.maxLines = if (expanded) 4 else 2
                contentTv.ellipsize = TextUtils.TruncateAt.END
                val container = ensureClipActionContainer()
                container.visibility = if (expanded) View.VISIBLE else View.GONE
                text = if (expanded) "∧" else "⌄"
            }
        }
        topRow.addView(expandTv)

        outerCard.addView(topRow)
        return outerCard
    }

    // ==================== Emoji & 颜文字双标签面板（含自定义表情/颜文字添加与长按删除） ====================
    private var isKaomojiSubTab = false
    private var currentEmojiCat = "笑脸"
    private var currentKaomojiCat = "经典"

    private fun showEmojiKaomojiPanel() {
        currentPanel = PanelState.EMOJI_KAOMOJI
        bodyFrame.removeAllViews()
        val emPanelBg = getAdaptivePanelBgColor()
        val emHeaderBg = getAdaptivePanelHeaderBgColor()
        val emCardBg = getAdaptiveCardBgColor(false)
        val emActiveCardBg = getAdaptiveCardBgColor(true)
        val emStroke = getAdaptiveCardStrokeColor()
        val emMainTxt = ensureReadableKeyTextColor(resolveDynamicCandidateTextColor(), emPanelBg, resolveDynamicCandidateTextColor(), isHint = false)
        val emHighlight = ensureReadableKeyTextColor(resolveDynamicCandidateHighlightColor(), emPanelBg, emMainTxt, isHint = false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(emPanelBg, emPanelBg, dp(12), emStroke, dp(1))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(emHeaderBg)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(emMainTxt)
            setPadding(dp(10), dp(6), dp(14), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        val emojiTab = TextView(this).apply {
            text = "Emoji"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (!isKaomojiSubTab) emHighlight else emMainTxt)
            typeface = if (!isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isKaomojiSubTab = false
                showEmojiKaomojiPanel()
            }
        }
        header.addView(emojiTab)

        val kaomojiTab = TextView(this).apply {
            text = "颜文字"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (isKaomojiSubTab) emHighlight else emMainTxt)
            typeface = if (isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isKaomojiSubTab = true
                showEmojiKaomojiPanel()
            }
        }
        header.addView(kaomojiTab)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        header.addView(spacer)

        val addCustomBtn = TextView(this).apply {
            text = "＋添加自定义"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(resolveDynamicCandidateHighlightColor())
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener {
                val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    putExtra("open_tab", "custom_kaomoji")
                }
                startActivity(intent)
            }
        }
        header.addView(addCustomBtn)
        root.addView(header)

        val vScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val gridContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        if (!isKaomojiSubTab) {
            val customEmojis = dbHelper.getCustomExpressions("emoji")
            val baseEmojis = EmojiKaomojiData.EMOJI_CATEGORIES[currentEmojiCat] ?: emptyList()
            val emojis = if (currentEmojiCat == "笑脸") (customEmojis + baseEmojis).distinct() else baseEmojis
            val cols = 8
            emojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { em ->
                    val tv = TextView(this).apply {
                        text = em
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
                        setOnClickListener {
                            KeySoundManager.playClick(this@ShengXiaImeService)
                            // 小表情（🤣🤔😘😂🥺）选完后留在表情窗口，方便连续输入多个表情；仅颜文字选完自动回主键盘
                            currentInputConnection?.commitText(em, 1)
                        }
                        if (customEmojis.contains(em)) {
                            setOnLongClickListener {
                                dbHelper.deleteCustomExpression(em)
                                Toast.makeText(this@ShengXiaImeService, "已删除自定义表情：$em", Toast.LENGTH_SHORT).show()
                                showEmojiKaomojiPanel()
                                true
                            }
                        }
                    }
                    row.addView(tv)
                }
                for (i in 0 until (cols - rowItems.size)) {
                    row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f) })
                }
                gridContainer.addView(row)
            }
        } else {
            val customKaomojis = dbHelper.getCustomExpressions("kaomoji")
            val baseKaomojis = EmojiKaomojiData.KAOMOJI_CATEGORIES[currentKaomojiCat] ?: emptyList()
            val kaomojis = if (currentKaomojiCat == "经典") (customKaomojis + baseKaomojis).distinct() else baseKaomojis
            val cols = 3
            kaomojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { km ->
                    val kmBg = if (customKaomojis.contains(km)) emActiveCardBg else emCardBg
                    val tv = TextView(this).apply {
                        text = km
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        setTextColor(emMainTxt)
                        gravity = Gravity.CENTER
                        background = CssSkinManager.makeGradientDrawable(kmBg, kmBg, dp(8), emStroke, dp(1))
                        val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                        val gap = dp(skin.keyGapDp); lp.setMargins(gap, gap, gap, gap)
                        layoutParams = lp
                        setOnClickListener {
                            KeySoundManager.playClick(this@ShengXiaImeService)
                            currentInputConnection?.commitText(km, 1)
                            showKeyboardPanel()
                        }
                        if (customKaomojis.contains(km)) {
                            setOnLongClickListener {
                                dbHelper.deleteCustomExpression(km)
                                Toast.makeText(this@ShengXiaImeService, "已删除自定义颜文字：$km", Toast.LENGTH_SHORT).show()
                                showEmojiKaomojiPanel()
                                true
                            }
                        }
                    }
                    row.addView(tv)
                }
                gridContainer.addView(row)
            }
        }
        vScroll.addView(gridContainer)
        root.addView(vScroll)

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(emHeaderBg)
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        val catNames = if (!isKaomojiSubTab) EmojiKaomojiData.EMOJI_CATEGORIES.keys else EmojiKaomojiData.KAOMOJI_CATEGORIES.keys
        catNames.forEach { cName ->
            val active = if (!isKaomojiSubTab) (cName == currentEmojiCat) else (cName == currentKaomojiCat)
            val tv = TextView(this).apply {
                text = cName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(if (active) emHighlight else emMainTxt)
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                background = if (active) CssSkinManager.makeGradientDrawable(emCardBg, emCardBg, dp(6), emStroke, dp(1)) else null
                layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f)
                setOnClickListener {
                    if (!isKaomojiSubTab) currentEmojiCat = cName else currentKaomojiCat = cName
                    showEmojiKaomojiPanel()
                }
            }
            bottomBar.addView(tv)
        }
        val delBtn = TextView(this).apply {
            text = "⌫"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = roundRect("#D5D7DD", dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(34))
            setOnClickListener { handleBackspace() }
        }
        bottomBar.addView(delBtn)
        root.addView(bottomBar)

        bodyFrame.addView(root)
    }

    private fun makeNumberPadDigitKey(digit: String, rowIndex: Int, textureKeyId: String): View {
        val scale = getKeyFontScale()
        val isFuncStyle = (digit == "+" || digit == "-")
        val style = skin.resolveKeyStyle(
            rowIndex = rowIndex,
            keyId = textureKeyId,
            isFuncKey = isFuncStyle,
            isPunctKey = false
        )
        val bgTop = style.bgTop ?: if (isFuncStyle) skin.funcKeyBgTop else skin.keyBgTop
        val bgBottom = style.bgBottom ?: if (isFuncStyle) skin.funcKeyBgBottom else skin.keyBgBottom
        val pressedCol = style.pressedBg ?: skin.keyPressedBg
        val borderCol = style.borderColor ?: if (isFuncStyle) skin.funcKeyBorder else skin.keyBorder
        val borderW = dp(style.borderWidthDp ?: skin.keyBorderWidthDp)
        val txtCol = style.textColor ?: if (isFuncStyle) skin.funcKeyText else skin.keyText

        val useCustomBg = true
        val container = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
            background = if (useCustomBg) null else CssSkinManager.makeGradientDrawable(
                bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
            )
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            val gap = dp(skin.keyGapDp)
            lp.setMargins(gap, gap, gap, gap)
            layoutParams = lp
            elevation = if (useCustomBg) 0f else dp(skin.keyElevationDp).toFloat()
        }

        val monetBgView = if (useCustomBg) {
            val bmp = if (isWaterLilyDecorEnabled()) MonetTextureManager.getKeyBitmap(this, textureKeyId) else null
            MonetPaintedBgView(
                this, bmp, dp(skin.keyRadiusDp).toFloat(),
                enableGlow = isKeyGlowEnabled(),
                glowColor = resolveGlowColorForKey(textureKeyId, bgTop),
                fallbackBgTop = bgTop,
                fallbackBgBottom = bgBottom,
                useFrostedCustomBg = isCustomBgFrostedEnabled()
            ).also { view ->
                container.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            }
        } else null

        val finalDigitColor = if (isWaterLilyDecorEnabled()) {
            if (textureKeyId == "ty" || textureKeyId == "space") Color.parseColor("#4D5E7C") else Color.WHITE
        } else {
            txtCol
        }

        val tv = TextView(this).apply {
            text = digit
            // 数字键保持纤细不加粗，字号适中 (18sp * scale)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * scale.coerceAtLeast(0.82f))
            setTextColor(finalDigitColor)
            typeface = Typeface.DEFAULT
            paint.isFakeBoldText = false
            gravity = Gravity.CENTER
        }
        container.addView(tv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        container.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = true
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            pressedCol, pressedCol, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (monetBgView != null) {
                        monetBgView.isKeyPressedState = false
                    } else {
                        v.background = CssSkinManager.makeGradientDrawable(
                            bgTop, bgBottom, dp(skin.keyRadiusDp), borderCol, borderW
                        )
                    }
                    if (ev.actionMasked == MotionEvent.ACTION_UP) {
                        commitDirectString(digit)
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }


    // ==================== 空格键长按：极简语音界面 + 顶栏流光字幕 + 长句不断连 ====================
    private fun showEmbeddedVoiceInputPanel() {
        currentPanel = PanelState.VOICE_INPUT
        bodyFrame.removeAllViews()

        val cpPanelBg = getAdaptivePanelBgColor()
        val cpCardBg = getAdaptiveCardBgColor(false)
        val cpStroke = getAdaptiveCardStrokeColor()
        val mainTxtCol = ensureReadableKeyTextColor(
            resolveDynamicCandidateTextColor(),
            cpPanelBg,
            resolveDynamicCandidateTextColor(),
            isHint = false
        )
        val hiCol = ensureReadableKeyTextColor(
            resolveDynamicCandidateHighlightColor(),
            cpCardBg,
            mainTxtCol,
            isHint = false
        )
        val glowCol = resolveGlowColorForKey("space", skin.keyBgTop)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = CssSkinManager.makeGradientDrawable(cpPanelBg, cpPanelBg, dp(14), cpStroke, dp(1))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 1. 顶部极简状态与返回栏（去掉话筒小图标与冗长教学提示，单行清爽不拥挤）
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = TextView(this).apply {
            text = "‹ 返回五笔"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f)
            setTextColor(hiCol)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(4), dp(12), dp(4))
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                stopVoiceListening(cancelImmediate = true)
                hideVoiceLiveTextInTopBar()
                showKeyboardPanel()
            }
        }
        val statusTv = TextView(this).apply {
            text = "轻点说话"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            setTextColor(mainTxtCol)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                if (voiceDebugLogs.isNotEmpty()) {
                    val dump = voiceDebugLogs.joinToString("\n")
                    try {
                        clipboardManager.setPrimaryClip(ClipData.newPlainText("VoiceDebug", dump))
                        dbHelper.addClip(dump)
                    } catch (_: Exception) {}
                    Toast.makeText(this@ShengXiaImeService, "📋 已复制 VoiceDebug 诊断日志到剪贴板，可直接粘贴发送！", Toast.LENGTH_LONG).show()
                }
            }
        }
        voiceStatusTv = statusTv

        val permOrPopupBtn = TextView(this).apply {
            val hasPerm = hasRecordAudioPermission()
            text = if (hasPerm) "系统语音窗" else "授权麦克风"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(hiCol)
            background = CssSkinManager.makeGradientDrawable(cpCardBg, cpCardBg, dp(8), cpStroke, dp(1))
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener {
                KeySoundManager.playClick(this@ShengXiaImeService)
                stopVoiceListening(cancelImmediate = true)
                hideVoiceLiveTextInTopBar()
                try {
                    val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("open_tab", if (hasRecordAudioPermission()) "system_voice_popup" else "voice_permission")
                    }
                    startActivity(intent)
                } catch (_: Exception) {}
            }
        }
        header.addView(backBtn)
        header.addView(statusTv)
        header.addView(permOrPopupBtn)
        root.addView(header)

        // 2. 中央星光麦克风 + 旋转星轨圈圈 + 夏以昼流光星芒光晕交互区
        val waveView = StarlightVoiceWaveView(
            context = this,
            glowColor = glowCol,
            surfaceBgColor = cpPanelBg,
            keyboardSurfaceBgColor = skin.kbBgTop
        ).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        voiceWaveView = waveView

        var downTimeMs = 0L
        waveView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downTimeMs = System.currentTimeMillis()
                    waveView.triggerTapSparkle()
                    if (!isVoiceListening) {
                        startVoiceListening()
                    } else {
                        // 说完轻点一下结束：调用 stopListening() 完成识别并上屏，绝不调用 cancel() 丢弃长句！
                        finishVoiceListeningAndCommit()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val heldMs = System.currentTimeMillis() - downTimeMs
                    // 仅当用户长按超过 1.5 秒作为对讲机按住模式时，松手才触发完成识别；普通轻点绝不截断长句！
                    if (heldMs > 1500L && isVoiceListening) {
                        finishVoiceListeningAndCommit()
                    }
                    true
                }
                else -> false
            }
        }
        root.addView(waveView)

        // 3. 底部快捷标点与退格/回车栏（， 。 ？ ！ ⌫ 盛夏光年）
        val bottomRow = makeRow().apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
        }
        bottomRow.addView(makeFuncKey("，", weight = 1f, rowIndex = 4) { commitOrSelectFirst("，") })
        bottomRow.addView(makeFuncKey("。", weight = 1f, rowIndex = 4) { commitOrSelectFirst("。") })
        bottomRow.addView(makeFuncKey("？", weight = 1f, rowIndex = 4) { commitOrSelectFirst("？") })
        bottomRow.addView(makeFuncKey("！", weight = 1f, rowIndex = 4) { commitOrSelectFirst("！") })
        bottomRow.addView(makeBackspaceKey(weight = 1.1f, rowIndex = 4))
        bottomRow.addView(makeFuncKey(getCustomEnterLabel(), smallText = true, weight = 1.1f, rowIndex = 4, keyId = "enter") {
            handleEnterKey()
        })
        root.addView(bottomRow)

        bodyFrame.addView(root)
    }

    private fun hasRecordAudioPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun commitVoiceRecognizedText(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        // 直接把语音文字上屏到输入框，不触发五笔联想词条覆盖顶栏，并在顶部圆角栏优雅展示纯文字（无「已上屏：」前缀），2.2 秒后自动恢复 5 个可爱图标
        currentInputConnection?.commitText(clean, 1)
        showVoiceLiveTextInTopBar(clean, autoHideMs = 2200L)
        voiceStatusTv?.text = "轻点继续说话"
    }

    private fun formatVoiceDebugTime(): String {
        val sdf = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
        return sdf.format(java.util.Date())
    }

    private fun voiceElapsedSecFromStart(): Double {
        if (voiceStartInvokeElapsedMs <= 0L) return 0.0
        return (SystemClock.elapsedRealtime() - voiceStartInvokeElapsedMs).coerceAtLeast(0L) / 1000.0
    }

    private fun voiceErrorCodeToString(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "1:ERROR_NETWORK_TIMEOUT(网络超时)"
        SpeechRecognizer.ERROR_NETWORK -> "2:ERROR_NETWORK(网络错误)"
        SpeechRecognizer.ERROR_AUDIO -> "3:ERROR_AUDIO(音频录制错误/麦克风被占用)"
        SpeechRecognizer.ERROR_SERVER -> "4:ERROR_SERVER(服务端错误)"
        SpeechRecognizer.ERROR_CLIENT -> "5:ERROR_CLIENT(客户端调用错误)"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "6:ERROR_SPEECH_TIMEOUT(未检测到语音输入超时)"
        SpeechRecognizer.ERROR_NO_MATCH -> "7:ERROR_NO_MATCH(无匹配识别结果)"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "8:ERROR_RECOGNIZER_BUSY(识别服务正忙)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "9:ERROR_INSUFFICIENT_PERMISSIONS(麦克风权限不足)"
        10 -> "10:ERROR_TOO_MANY_REQUESTS(请求过于频繁)"
        11 -> "11:ERROR_SERVER_DISCONNECTED(识别服务连接断开)"
        12 -> "12:ERROR_LANGUAGE_NOT_SUPPORTED(不支持该语言)"
        13 -> "13:ERROR_LANGUAGE_UNAVAILABLE(语言包不可用)"
        else -> "$error:UNKNOWN_ERROR(未知错误码)"
    }

    private fun logVoiceDebug(callbackName: String, detail: String, isError: Boolean = false) {
        val ts = formatVoiceDebugTime()
        val elapsedStr = String.format(java.util.Locale.US, "%.2fs", voiceElapsedSecFromStart())
        val line = "[$ts] [+$elapsedStr] $callbackName | $detail"
        synchronized(voiceDebugLogs) {
            voiceDebugLogs.add(line)
            while (voiceDebugLogs.size > 60) {
                voiceDebugLogs.removeAt(0)
            }
        }
        if (isError) {
            Log.e("VoiceDebug", line)
        } else {
            Log.d("VoiceDebug", line)
        }
    }

    private fun startVoiceListening() {
        if (!hasRecordAudioPermission()) {
            isVoiceListening = false
            voiceWaveView?.setListening(false)
            voiceStatusTv?.text = "请点右上角授权麦克风"
            logVoiceDebug("startVoiceListening", "aborted: no RECORD_AUDIO permission", isError = true)
            try {
                val intent = Intent(this, SettingsActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("open_tab", "voice_permission")
                }
                startActivity(intent)
            } catch (_: Exception) {}
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            }
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isVoiceListening = true
                    lastPartialVoiceText = ""
                    voiceListenStartElapsedMs = SystemClock.elapsedRealtime()
                    voiceWaveView?.setListening(true)
                    voiceStatusTv?.text = "聆听中 · 01s"
                    mainHandler.removeCallbacks(voiceTimerRunnable)
                    mainHandler.postDelayed(voiceTimerRunnable, 500L)
                    logVoiceDebug(
                        "onReadyForSpeech",
                        "ready=true, endOfSpeechSeen=$voiceEndOfSpeechSeen"
                    )
                }

                override fun onBeginningOfSpeech() {
                    logVoiceDebug(
                        "onBeginningOfSpeech",
                        "speechStarted=true, endOfSpeechSeen=$voiceEndOfSpeechSeen"
                    )
                }

                override fun onRmsChanged(rmsdB: Float) {
                    voiceWaveView?.updateRmsDb(rmsdB)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    voiceEndOfSpeechSeen = true
                    voiceEndOfSpeechAtSec = voiceElapsedSecFromStart()
                    mainHandler.removeCallbacks(voiceTimerRunnable)
                    voiceWaveView?.setListening(false)
                    voiceStatusTv?.text = "识别中…"
                    logVoiceDebug(
                        "onEndOfSpeech",
                        "endOfSpeechSeen=true, endOfSpeechAt=${String.format(java.util.Locale.US, "%.2fs", voiceEndOfSpeechAtSec)}, partialLenSoFar=${lastPartialVoiceText.length}"
                    )
                }

                override fun onError(error: Int) {
                    val errDesc = voiceErrorCodeToString(error)
                    val endAtStr = if (voiceEndOfSpeechSeen) String.format(java.util.Locale.US, "%.2fs", voiceEndOfSpeechAtSec) else "N/A"
                    logVoiceDebug(
                        "onError",
                        "code=$error, meaning=$errDesc, endOfSpeechBeforeError=$voiceEndOfSpeechSeen, endOfSpeechAt=$endAtStr, partialHasText=${lastPartialVoiceText.isNotBlank()}, partialLen=${lastPartialVoiceText.length}",
                        isError = true
                    )
                    mainHandler.removeCallbacks(voiceTimerRunnable)
                    isVoiceListening = false
                    voiceWaveView?.setListening(false)
                    if (lastPartialVoiceText.isNotBlank()) {
                        val fallbackText = lastPartialVoiceText.trim()
                        lastPartialVoiceText = ""
                        commitVoiceRecognizedText(fallbackText)
                    } else {
                        hideVoiceLiveTextInTopBar()
                        val elStr = String.format(java.util.Locale.US, "%.1fs", voiceElapsedSecFromStart())
                        voiceStatusTv?.text = "未听清(码$error·$elStr) 点此复制日志"
                    }
                }

                override fun onResults(results: Bundle?) {
                    mainHandler.removeCallbacks(voiceTimerRunnable)
                    isVoiceListening = false
                    voiceWaveView?.setListening(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val bestText = (matches?.firstOrNull()?.trim() ?: "").ifEmpty { lastPartialVoiceText.trim() }
                    val endAtStr = if (voiceEndOfSpeechSeen) String.format(java.util.Locale.US, "%.2fs", voiceEndOfSpeechAtSec) else "N/A"
                    logVoiceDebug(
                        "onResults",
                        "hasText=${bestText.isNotEmpty()}, textLen=${bestText.length}, endOfSpeechBeforeResults=$voiceEndOfSpeechSeen, endOfSpeechAt=$endAtStr"
                    )
                    lastPartialVoiceText = ""
                    if (bestText.isNotEmpty()) {
                        commitVoiceRecognizedText(bestText)
                    } else {
                        hideVoiceLiveTextInTopBar()
                        voiceStatusTv?.text = "未听清，轻点重试(点此复制日志)"
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        ?.trim()
                    val hasTxt = !partial.isNullOrBlank()
                    val len = partial?.length ?: 0
                    logVoiceDebug(
                        "onPartialResults",
                        "hasText=$hasTxt, textLen=$len, endOfSpeechSeen=$voiceEndOfSpeechSeen"
                    )
                    if (hasTxt && partial != null) {
                        lastPartialVoiceText = partial
                        // 实时识别的文字显示在最上方通栏气泡中（无前缀、不挤压中央麦克风）
                        showVoiceLiveTextInTopBar(partial, autoHideMs = 0L)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "zh-CN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 20000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2800L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2200L)
            }
            lastPartialVoiceText = ""
            isVoiceListening = true
            voiceStartInvokeElapsedMs = SystemClock.elapsedRealtime()
            voiceListenStartElapsedMs = voiceStartInvokeElapsedMs
            voiceEndOfSpeechSeen = false
            voiceEndOfSpeechAtSec = -1.0
            logVoiceDebug("startListening", "invoking SpeechRecognizer.startListening(recIntent)")
            voiceWaveView?.setListening(true)
            voiceStatusTv?.text = "聆听中 · 01s"
            mainHandler.removeCallbacks(voiceTimerRunnable)
            mainHandler.postDelayed(voiceTimerRunnable, 500L)
            KeySoundManager.playClick(this@ShengXiaImeService)
            speechRecognizer?.cancel()
            speechRecognizer?.startListening(recIntent)
        } catch (e: Exception) {
            logVoiceDebug("startVoiceListening_Exception", "exception=${e.javaClass.simpleName}:${e.message}", isError = true)
            mainHandler.removeCallbacks(voiceTimerRunnable)
            isVoiceListening = false
            voiceWaveView?.setListening(false)
            voiceStatusTv?.text = "请点右上角系统语音窗"
        }
    }

    private fun finishVoiceListeningAndCommit() {
        logVoiceDebug("finishVoiceListeningAndCommit", "manual stopListening() triggered by user")
        mainHandler.removeCallbacks(voiceTimerRunnable)
        isVoiceListening = false
        voiceWaveView?.setListening(false)
        voiceStatusTv?.text = "识别中…"
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
            if (lastPartialVoiceText.isNotBlank()) {
                val fallback = lastPartialVoiceText.trim()
                lastPartialVoiceText = ""
                commitVoiceRecognizedText(fallback)
            } else {
                voiceStatusTv?.text = "轻点说话"
            }
        }
    }

    private fun stopVoiceListening(cancelImmediate: Boolean = false) {
        logVoiceDebug("stopVoiceListening", "cancelImmediate=$cancelImmediate, isVoiceListening=$isVoiceListening")
        mainHandler.removeCallbacks(voiceTimerRunnable)
        try {
            if (cancelImmediate) {
                speechRecognizer?.cancel()
            } else if (isVoiceListening) {
                speechRecognizer?.stopListening()
            }
        } catch (_: Exception) {}
        isVoiceListening = false
        voiceWaveView?.setListening(false)
    }

    private fun destroyVoiceRecognizer() {
        mainHandler.removeCallbacks(voiceTimerRunnable)
        mainHandler.removeCallbacks(hideVoiceTopPreviewRunnable)
        isVoiceListening = false
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
    }

    private fun buildNumberPadView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        // 让数字小键盘每一排都自动匹配对应排的莫奈油画睡莲键帽与配色！
        val r1 = makeRow().apply {
            addView(makeNumberPadDigitKey("1", rowIndex = 1, textureKeyId = "qw"))
            addView(makeNumberPadDigitKey("2", rowIndex = 1, textureKeyId = "ty"))
            addView(makeNumberPadDigitKey("3", rowIndex = 1, textureKeyId = "op"))
            addView(makeNumberPadDigitKey("+", rowIndex = 1, textureKeyId = "wildcard"))
        }
        val r2 = makeRow().apply {
            addView(makeNumberPadDigitKey("4", rowIndex = 2, textureKeyId = "as"))
            addView(makeNumberPadDigitKey("5", rowIndex = 2, textureKeyId = "gh"))
            addView(makeNumberPadDigitKey("6", rowIndex = 2, textureKeyId = "jk"))
            addView(makeNumberPadDigitKey("-", rowIndex = 2, textureKeyId = "bn"))
        }
        val r3 = makeRow().apply {
            addView(makeNumberPadDigitKey("7", rowIndex = 3, textureKeyId = "zx"))
            addView(makeNumberPadDigitKey("8", rowIndex = 3, textureKeyId = "cv"))
            addView(makeNumberPadDigitKey("9", rowIndex = 3, textureKeyId = "m"))
            addView(makeBackspaceKey(1f, rowIndex = 3))
        }
        val r4 = makeRow().apply {
            addView(makeFuncKey("返回", rowIndex = 4, keyId = "sym") {
                isNumberPadMode = false
                showKeyboardPanel()
            })
            addView(makeNumberPadDigitKey("0", rowIndex = 4, textureKeyId = "space"))
            addView(makeFuncKey("符号", rowIndex = 4, keyId = "lang") {
                isNumberPadMode = false
                showSymbolsPanel()
            })
            addView(makeFuncKey(getCustomEnterLabel(), smallText = true, rowIndex = 4, keyId = "enter") {
                handleEnterKey()
            })
        }
        root.addView(r1)
        root.addView(r2)
        root.addView(r3)
        root.addView(r4)
        return root
    }

    private fun isColorLight(color: Int): Boolean {
        val r = Color.red(color) / 255.0
        val g = Color.green(color) / 255.0
        val b = Color.blue(color) / 255.0
        val lum = 0.299 * r + 0.587 * g + 0.114 * b
        return lum > 0.72
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun roundRect(fillHex: String, radiusPx: Int, strokeColor: String? = null, strokeWidth: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.parseColor(fillHex))
            if (strokeColor != null && strokeWidth > 0) {
                setStroke(strokeWidth, Color.parseColor(strokeColor))
            }
        }
    }
}
