package com.shengxiaguangnian.ime

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * 深空星盘 · 第一颗星（DeepStarFx 1:1 原画级矢量 + 智能皮肤取色引擎）
 *
 * 严格逐帧复刻「深空特效.mp4」第 1 颗星（沈星回·星轨罗盘五角星）的 4 层精密视觉结构与两段式消散时序：
 *   ① 第 1 层（星心八芒星轨罗盘）：四长四短非对称八芒星 + 内层实线星盘环 + 左上/右下对角双行星点 + 外圈双弧微光刻度点阵；
 *   ② 第 2 层（大圆角胖五角星柔雾轮廓）：0.58 饱满内径比 + 0.38 二次贝塞尔圆角曲率，五处星尖高光增强、五处内凹柔和隐入星云；
 *   ③ 第 3 层（双星轨彗星流光丝带 + 四芒星领航）：右上与左下两条环绕彗星流光丝带（两端渐隐收尖）+ 伴生微光点阵虚线 + 顶端实心四芒星（✦）领航；
 *   ④ 第 4 层（左上斜弯月 + 右下空心四芒星 + 星珠呼吸）：左上凹槽外侧斜弯月（🌙）、右下空心四芒星（✧）与星角高光星珠；
 *   ⑤ 两段式消散时序：前 60% 全星盘绽放，后 40% 中心八芒星罗盘与左上弯月先一步温柔隐去，留下外圈胖五角星轮廓与双彗星流光丝带继续微扩化作星尘消散。
 *   ⑥ 智能皮肤取色（模式 B）：自动提取当前按键/皮肤主题色相，深色皮肤呈现星河白芯+柔雾辉光，浅色皮肤采用高显色宝石柔光色阶（零黑灰脏影），纯白/纯灰/纯黑无色相皮肤自动回退经典深空星河紫（272°）。
 */
object DeepStarFx {
    const val EMBLEM = "deep_star"
    const val DURATION_MS = 580

    private const val PI_F = 3.1415927f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val octPath = Path()
    private val innerOctPath = Path()
    private val moonOuterPath = Path()
    private val moonCutPath = Path()
    private val sparklePath = Path()
    private val segPath = Path()
    private val rectF = RectF()
    private val hsvBuf1 = FloatArray(3)
    private val hsvBuf2 = FloatArray(3)

    // 预分配五角星 10 个顶点坐标缓存（0,2,4,6,8 为五个圆润外星尖）
    private val starVx = FloatArray(10)
    private val starVy = FloatArray(10)

    // 预分配丝带采样点缓存（零 GC）
    private const val RIBBON_STEPS = 20
    private val rib1X = FloatArray(RIBBON_STEPS + 1)
    private val rib1Y = FloatArray(RIBBON_STEPS + 1)
    private val rib2X = FloatArray(RIBBON_STEPS + 1)
    private val rib2Y = FloatArray(RIBBON_STEPS + 1)

    // 5 层高斯钟形柔光描边权重（在硬件加速 Canvas 上无伪影模拟 Spine 高斯羽化辉光）
    private val GAUSS_WIDTH_MULTS = floatArrayOf(2.60f, 1.75f, 1.15f, 0.72f, 0.38f)
    private val GAUSS_ALPHA_MULTS = floatArrayOf(0.055f, 0.11f, 0.20f, 0.34f, 0.62f)

    // 星角与丝带交汇处的 11 颗原画级高光星珠：(x/R, y/R, radius/R, phase)
    private val PEARLS = floatArrayOf(
        -0.20f, -0.68f, 0.015f, 0.10f,
        -0.15f, -0.64f, 0.017f, 0.25f,
         0.15f, -0.64f, 0.017f, 0.40f,
         0.35f, -0.58f, 0.015f, 0.55f,
         0.78f, -0.20f, 0.032f, 0.15f, // 右侧丝带交汇处主星珠
         0.74f, -0.04f, 0.023f, 0.35f,
         0.70f,  0.06f, 0.018f, 0.50f,
         0.62f,  0.18f, 0.015f, 0.70f,
         0.12f,  0.68f, 0.016f, 0.30f,
         0.18f,  0.70f, 0.013f, 0.65f,
        -0.62f, -0.32f, 0.014f, 0.80f
    )

    // 外围伴生微光小四芒星（随疏密滑杆动态增减）：(x/R, y/R, size/R, phase)
    private val EXTRA_SPARKLES = floatArrayOf(
        -0.96f, -0.18f, 0.052f, 0.22f,
         0.28f, -0.94f, 0.048f, 0.48f,
        -0.46f,  0.92f, 0.050f, 0.64f,
         0.94f,  0.12f, 0.045f, 0.14f,
        -0.82f,  0.74f, 0.042f, 0.78f,
         0.52f,  0.86f, 0.044f, 0.36f
    )

    private data class CelestialPalette(
        val isLight: Boolean,
        val coreColor: Int,
        val rimColor: Int,
        val glowColor: Int,
        val hazeColor: Int,
        val specularWhite: Int
    )

    private fun resolvePalette(surfaceBg: Int?, accentGlow: Int?): CelestialPalette {
        val bg = surfaceBg ?: 0xFF1E1F26.toInt()
        val lum = (0.299f * Color.red(bg) + 0.587f * Color.green(bg) + 0.114f * Color.blue(bg)) / 255f
        val isLight = lum > 0.58f

        Color.colorToHSV(bg, hsvBuf1)
        val s1 = hsvBuf1[1]
        val h1 = hsvBuf1[0]

        var h2 = h1
        var s2 = 0f
        if (accentGlow != null) {
            Color.colorToHSV(accentGlow, hsvBuf2)
            h2 = hsvBuf2[0]
            s2 = hsvBuf2[1]
        }

        // 若当前按键与背光均为无色相的纯白/纯灰/纯黑（饱和度 < 0.07），自动采用沈星回经典深空星河紫（272°）
        val hue: Float = when {
            max(s1, s2) < 0.07f -> 272f
            s2 >= 0.07f && s2 >= s1 * 0.75f -> h2
            else -> h1
        }

        return if (!isLight) {
            CelestialPalette(
                isLight = false,
                coreColor = hsvC(hue, 0.11f, 1.00f),
                rimColor = hsvC(hue, 0.33f, 1.00f),
                glowColor = hsvC(hue, 0.56f, 0.97f),
                hazeColor = hsvC((hue + 8f) % 360f, 0.62f, 0.88f),
                specularWhite = Color.WHITE
            )
        } else {
            // 浅色皮肤专属宝石柔光色阶：避免暖黄皮肤发灰变暗，保持清透梦幻感
            val effHue = if (hue in 34f..62f) 34f else hue
            CelestialPalette(
                isLight = true,
                coreColor = hsvC(effHue, 0.72f, 0.66f),
                rimColor = hsvC(effHue, 0.60f, 0.80f),
                glowColor = hsvC(effHue, 0.46f, 0.92f),
                hazeColor = hsvC(effHue, 0.34f, 0.96f),
                specularWhite = Color.WHITE
            )
        }
    }

    /**
     * 绘制 1:1 复刻的「深空星盘 · 第一颗星」
     * @param rect       按键可绘制区域（含四周外扩边距）
     * @param t          0..1 归一化动画进度
     * @param surfaceBg  按键表面背景色（用于判定深浅底与基礎色相）
     * @param accentGlow 智能采色引擎提取的按键/皮肤主题流光色（可选）
     * @param density    疏密滑杆（0..1，控制星尘与星珠丰满度）
     * @param range      范围滑杆（0..1，控制星盘绽放尺寸与扩散半径）
     */
    fun draw(
        canvas: Canvas,
        rect: RectF,
        t: Float,
        surfaceBg: Int?,
        accentGlow: Int? = null,
        density: Float = 0.65f,
        range: Float = 0.65f
    ) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX()
        val cy = rect.centerY()
        val rangeScale = 0.84f + 0.36f * range.coerceIn(0f, 1f)
        val R = min(rect.width(), rect.height()) * 0.40f * rangeScale
        if (R <= 2f) return

        // ---- 时序曲线：0..0.15 轻盈弹出，0.15..1.00 舒展绽放与两段式消散 ----
        val inT = (t / 0.15f).coerceIn(0f, 1f)
        val spreadT = ((t - 0.15f) / 0.85f).coerceIn(0f, 1f)
        val pop = 0.38f + 0.64f * easeOutBack(inT) + 0.12f * easeOutCube(spreadT)
        val driftY = -R * 0.08f * spreadT

        // 总体外框与彗星丝带透明度（维持到后半段慢慢化作星尘）
        val outerFade = smooth(0.54f, 1.00f, t)
        val outerAlpha = (inT * (1f - outerFade)).coerceIn(0f, 1f)
        if (outerAlpha <= 0.01f) return

        // 星心八芒星罗盘与左上弯月透明度（60% 后先一步温柔隐去，严格还原原片第 19~23 帧）
        val dialFade = smooth(0.42f, 0.76f, t)
        val dialAlpha = (inT * (1f - dialFade)).coerceIn(0f, 1f)

        val pal = resolvePalette(surfaceBg, accentGlow)
        val denBoost = (0.75f + 0.45f * density.coerceIn(0f, 1f))

        canvas.save()
        canvas.translate(cx, cy + driftY)
        canvas.rotate(-2.2f + 4.8f * t)
        canvas.scale(pop, pop)

        val starCy = -R * 0.03f
        buildRoundedStarPath(starPath, 0f, starCy, R, R * 0.58f, 5, -91.5f, 0.38f)

        // ====================================================================
        // 1. 底层深空星云呼吸光晕（RadialGradient 大范围柔和底衬）
        // ====================================================================
        p.style = Paint.Style.FILL
        val auraRadius = R * (1.35f + 0.25f * spreadT)
        val auraPeakA = if (pal.isLight) 0.30f else 0.24f
        p.shader = RadialGradient(
            0f, starCy, auraRadius,
            intArrayOf(
                withA(pal.glowColor, (outerAlpha * auraPeakA * 255f).toInt()),
                withA(pal.glowColor, (outerAlpha * auraPeakA * 0.42f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, starCy, auraRadius, p)
        p.shader = null

        // 五角星内部半透明星云底色
        canvas.save()
        canvas.clipPath(starPath)
        val innerFillA = if (pal.isLight) 0.28f else 0.20f
        p.shader = RadialGradient(
            0f, starCy, R * 1.02f,
            intArrayOf(
                withA(pal.hazeColor, (outerAlpha * innerFillA * 255f).toInt()),
                withA(pal.hazeColor, (outerAlpha * innerFillA * 0.55f * 255f).toInt()),
                withA(pal.hazeColor, (outerAlpha * innerFillA * 0.18f * 255f).toInt())
            ),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(-R * 1.2f, -R * 1.2f, R * 1.2f, R * 1.2f, p)
        p.shader = null
        canvas.restore()

        // ====================================================================
        // 2. 大圆角胖五角星柔雾轮廓（5 层高斯辉光 + 五处圆润星尖高光增强）
        // ====================================================================
        drawGaussianStrokePath(
            canvas, starPath, R * 0.095f,
            pal.glowColor, pal.rimColor, outerAlpha * (if (pal.isLight) 1.05f else 0.92f)
        )

        // 五角星的 5 个圆润外星尖（顶点 0, 2, 4, 6, 8）叠加星尖聚光高光，还原原片「星尖亮、内凹柔」的呼吸感
        p.style = Paint.Style.FILL
        for (idx in 0 until 10 step 2) {
            val vx = starVx[idx]
            val vy = starVy[idx]
            val tipR = R * 0.34f
            p.shader = RadialGradient(
                vx, vy, tipR,
                intArrayOf(
                    withA(pal.coreColor, (outerAlpha * 0.50f * 255f).toInt()),
                    withA(pal.rimColor, (outerAlpha * 0.20f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.48f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(vx, vy, tipR, p)
        }
        p.shader = null

        // ====================================================================
        // 3. 双星轨彗星流光丝带 + 伴生微光点阵虚线 + 领航实心四芒星（✦）
        // ====================================================================
        val gw = 1f + 0.14f * spreadT
        // 右上环绕流光丝带（从右上✦星延伸，环绕右上星角并向内掠过右侧星角）
        sampleCubicBezier(
            0.42f * R * gw, -0.72f * R * gw,
            0.94f * R * gw, -0.64f * R * gw,
            0.86f * R * gw, -0.04f * R * gw,
            0.44f * R * gw,  0.32f * R * gw,
            rib1X, rib1Y
        )
        // 左下环绕流光丝带（从左下✦星出发，环绕左下星角底部并向内收尾）
        sampleCubicBezier(
            -0.88f * R * gw, 0.32f * R * gw,
            -0.88f * R * gw, 0.82f * R * gw,
            -0.38f * R * gw, 0.78f * R * gw,
             0.05f * R * gw, 0.60f * R * gw,
            rib2X, rib2Y
        )

        drawTaperedCometRibbon(canvas, rib1X, rib1Y, R, pal, outerAlpha, isArch = true)
        drawTaperedCometRibbon(canvas, rib2X, rib2Y, R, pal, outerAlpha, isArch = false)

        // 伴生微光点阵虚线（沿着两条彗星丝带内侧平行排列的精细星轨点）
        drawCubicDottedTrail(
            canvas,
            0.46f * R * gw, -0.69f * R * gw,
            0.90f * R * gw, -0.60f * R * gw,
            0.81f * R * gw, -0.02f * R * gw,
            0.40f * R * gw,  0.30f * R * gw,
            steps = 18, dotR = R * 0.010f, color = pal.coreColor, alpha = outerAlpha * 0.78f
        )
        drawCubicDottedTrail(
            canvas,
            -0.84f * R * gw, 0.35f * R * gw,
            -0.83f * R * gw, 0.77f * R * gw,
            -0.35f * R * gw, 0.73f * R * gw,
             0.04f * R * gw, 0.57f * R * gw,
            steps = 18, dotR = R * 0.010f, color = pal.coreColor, alpha = outerAlpha * 0.78f
        )

        // 右上丝带领航大四芒星（✦）与左下丝带领航小四芒星（✦）
        drawSolidSparkle4(
            canvas,
            cx = 0.58f * R * gw,
            cy = -0.68f * R * gw,
            r = R * 0.138f,
            waistK = 0.19f,
            rotDeg = -6f,
            alpha = outerAlpha,
            pal = pal
        )
        drawSolidSparkle4(
            canvas,
            cx = -0.88f * R * gw,
            cy = 0.32f * R * gw,
            r = R * 0.082f,
            waistK = 0.21f,
            rotDeg = 0f,
            alpha = outerAlpha * 0.95f,
            pal = pal
        )

        // ====================================================================
        // 4. 右下空心四芒星（✧）
        // ====================================================================
        drawHollowSparkle4(
            canvas,
            cx = 0.74f * R * gw,
            cy = 0.42f * R * gw,
            r = R * 0.106f,
            waistK = 0.28f,
            rotDeg = 4f,
            alpha = outerAlpha * 0.92f,
            pal = pal
        )

        // ====================================================================
        // 5. 左上斜弯月（🌙，随第一阶段星盘同步隐去）
        // ====================================================================
        if (dialAlpha > 0.02f) {
            drawCrescentMoon(
                canvas,
                mcx = -0.68f * R * (1f + 0.06f * spreadT),
                mcy = -0.52f * R * (1f + 0.06f * spreadT),
                outerR = R * 0.136f,
                cutR = R * 0.116f,
                offset = R * 0.050f,
                openAngleDeg = -48f,
                alpha = dialAlpha,
                pal = pal
            )
        }

        // ====================================================================
        // 6. 星心八芒星轨罗盘（中心柔光 + 内星轨环 + 四长四短八芒星 + 对角双行星 + 外圈双弧刻度点阵）
        // ====================================================================
        if (dialAlpha > 0.02f) {
            val dialScale = 1f + 0.08f * spreadT
            val rRing = R * 0.236f * dialScale

            // (a) 星心柔光放射底衬
            p.style = Paint.Style.FILL
            val centerGlowR = R * 0.46f * dialScale
            val cGlowA = if (pal.isLight) 0.42f else 0.38f
            p.shader = RadialGradient(
                0f, 0f, centerGlowR,
                intArrayOf(
                    withA(pal.glowColor, (dialAlpha * cGlowA * 255f).toInt()),
                    withA(pal.glowColor, (dialAlpha * cGlowA * 0.45f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, centerGlowR, p)
            p.shader = null

            // (b) 内层实线星盘圆环（带柔光晕染）
            p.style = Paint.Style.STROKE
            p.strokeWidth = R * 0.062f
            p.color = withA(pal.glowColor, (dialAlpha * 0.26f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)
            p.strokeWidth = R * 0.022f
            p.color = withA(pal.coreColor, (dialAlpha * 0.90f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)

            // (c) 四长四短非对称八芒星（主十字星芒突破星环，四隅副星芒恰好抵住星环）
            buildOctagramPath(
                octPath,
                cx = 0f,
                cy = 0f,
                rMajor = R * 0.365f * dialScale,
                rMinor = R * 0.246f * dialScale,
                rWaist = R * 0.118f * dialScale
            )
            // 八芒星外围柔光羽化层
            p.style = Paint.Style.STROKE
            p.strokeJoin = Paint.Join.ROUND
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = R * 0.075f
            p.color = withA(pal.glowColor, (dialAlpha * 0.24f * 255f).toInt())
            canvas.drawPath(octPath, p)
            p.strokeWidth = R * 0.032f
            p.color = withA(pal.rimColor, (dialAlpha * 0.48f * 255f).toInt())
            canvas.drawPath(octPath, p)

            // 八芒星实心主体
            p.style = Paint.Style.FILL
            p.color = withA(pal.coreColor, (dialAlpha * 0.96f * 255f).toInt())
            canvas.drawPath(octPath, p)

            // 浅色皮肤下在八芒星中心叠加一层微白星芯高光，赋予宝石通透感
            if (pal.isLight) {
                buildOctagramPath(
                    innerOctPath,
                    cx = 0f,
                    cy = 0f,
                    rMajor = R * 0.21f * dialScale,
                    rMinor = R * 0.14f * dialScale,
                    rWaist = R * 0.065f * dialScale
                )
                p.color = withA(pal.specularWhite, (dialAlpha * 0.55f * 255f).toInt())
                canvas.drawPath(innerOctPath, p)
            }

            // (d) 左上 (-132°) 与右下 (+48°) 对角双行星圆点
            val planetOrbitR = R * 0.296f * dialScale
            val planetR = R * 0.030f
            for (deg in intArrayOf(-132, 48)) {
                val rad = Math.toRadians(deg.toDouble())
                val px = (planetOrbitR * cos(rad)).toFloat()
                val py = (planetOrbitR * sin(rad)).toFloat()
                p.style = Paint.Style.FILL
                p.color = withA(pal.glowColor, (dialAlpha * 0.35f * 255f).toInt())
                canvas.drawCircle(px, py, planetR * 2.1f, p)
                p.color = withA(pal.coreColor, (dialAlpha * 0.95f * 255f).toInt())
                canvas.drawCircle(px, py, planetR, p)
            }

            // (e) 外圈双弧微光刻度点阵（r = 0.445 * R）
            val rDots = R * 0.445f * dialScale
            val dotRadius = R * 0.0105f
            p.style = Paint.Style.FILL
            p.color = withA(pal.coreColor, (dialAlpha * 0.74f * 255f).toInt())
            var deg = -82
            while (deg <= 68) {
                val rad = Math.toRadians(deg.toDouble())
                canvas.drawCircle(
                    (rDots * cos(rad)).toFloat(),
                    (rDots * sin(rad)).toFloat(),
                    dotRadius,
                    p
                )
                deg += 6
            }
            p.color = withA(pal.coreColor, (dialAlpha * 0.46f * 255f).toInt())
            deg = 118
            while (deg <= 232) {
                val rad = Math.toRadians(deg.toDouble())
                canvas.drawCircle(
                    (rDots * cos(rad)).toFloat(),
                    (rDots * sin(rad)).toFloat(),
                    dotRadius * 0.88f,
                    p
                )
                deg += 7
            }
        }

        // ====================================================================
        // 7. 原画级星角高光星珠与呼吸星尘（受疏密滑杆调节）
        // ====================================================================
        p.style = Paint.Style.FILL
        var i = 0
        while (i + 3 < PEARLS.size) {
            val px = PEARLS[i] * R * gw
            val py = PEARLS[i + 1] * R * gw
            val pr = PEARLS[i + 2] * R * denBoost.coerceIn(0.8f, 1.25f)
            val ph = PEARLS[i + 3]
            val tw = 0.65f + 0.35f * ((sin((spreadT * 1.5f + ph) * 2f * PI_F) + 1f) * 0.5f)
            p.color = withA(pal.glowColor, (outerAlpha * tw * 0.32f * 255f).toInt())
            canvas.drawCircle(px, py, pr * 2.2f, p)
            p.color = withA(pal.coreColor, (outerAlpha * tw * 0.92f * 255f).toInt())
            canvas.drawCircle(px, py, pr, p)
            i += 4
        }

        // 外围呼吸小四芒星（根据 density 疏密滑杆决定显示数量）
        val totalExtra = EXTRA_SPARKLES.size / 4
        val activeExtra = (totalExtra * density.coerceIn(0.15f, 1f)).toInt().coerceIn(1, totalExtra)
        val fly = 0.88f + 0.28f * easeOutCube(spreadT)
        for (idx in 0 until activeExtra) {
            val base = idx * 4
            val sx = EXTRA_SPARKLES[base] * R * fly
            val sy = EXTRA_SPARKLES[base + 1] * R * fly
            val sr = EXTRA_SPARKLES[base + 2] * R * denBoost
            val ph = EXTRA_SPARKLES[base + 3]
            val tw = 0.45f + 0.55f * ((sin((spreadT * 1.4f + ph) * 2f * PI_F) + 1f) * 0.5f)
            drawSolidSparkle4(
                canvas,
                cx = sx,
                cy = sy,
                r = sr * (0.65f + 0.35f * tw),
                waistK = 0.22f,
                rotDeg = 0f,
                alpha = outerAlpha * tw * 0.85f,
                pal = pal
            )
        }

        canvas.restore()
    }

    /**
     * 5 层高斯钟形柔光描边：彻底消除生硬细白线，还原 Spine 柔焦发光质感
     */
    private fun drawGaussianStrokePath(
        canvas: Canvas,
        path: Path,
        baseWidth: Float,
        glowColor: Int,
        coreColor: Int,
        alpha: Float
    ) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        for (k in 0 until GAUSS_WIDTH_MULTS.size) {
            p.strokeWidth = baseWidth * GAUSS_WIDTH_MULTS[k]
            val col = if (k < 3) glowColor else coreColor
            val layerA = (alpha * GAUSS_ALPHA_MULTS[k] * 255f).toInt()
            p.color = withA(col, layerA)
            canvas.drawPath(path, p)
        }
    }

    /**
     * 绘制两端自然收尖渐隐的彗星流光丝带
     */
    private fun drawTaperedCometRibbon(
        canvas: Canvas,
        xs: FloatArray,
        ys: FloatArray,
        R: Float,
        pal: CelestialPalette,
        alpha: Float,
        isArch: Boolean
    ) {
        // 先画整条丝带的外围柔雾辉光
        segPath.reset()
        segPath.moveTo(xs[0], ys[0])
        for (i in 1..RIBBON_STEPS) {
            segPath.lineTo(xs[i], ys[i])
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = R * 0.095f
        p.color = withA(pal.glowColor, (alpha * 0.16f * 255f).toInt())
        canvas.drawPath(segPath, p)
        p.strokeWidth = R * 0.048f
        p.color = withA(pal.rimColor, (alpha * 0.28f * 255f).toInt())
        canvas.drawPath(segPath, p)

        // 分段绘制收尖亮芯
        for (i in 0 until RIBBON_STEPS) {
            val u = i.toFloat() / RIBBON_STEPS.toFloat()
            val env = if (isArch) {
                sin(u * PI_F).pow(0.65f)
            } else {
                (1f - 0.72f * u) * min(1f, u * 5.5f)
            }
            if (env <= 0.04f) continue
            p.strokeWidth = max(1f, R * 0.026f * env)
            p.color = withA(pal.coreColor, (alpha * 0.78f * env * 255f).toInt())
            canvas.drawLine(xs[i], ys[i], xs[i + 1], ys[i + 1], p)
        }
    }

    private fun sampleCubicBezier(
        x0: Float, y0: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        outX: FloatArray,
        outY: FloatArray
    ) {
        for (s in 0..RIBBON_STEPS) {
            val u = s.toFloat() / RIBBON_STEPS.toFloat()
            val inv = 1f - u
            val b0 = inv * inv * inv
            val b1 = 3f * inv * inv * u
            val b2 = 3f * inv * u * u
            val b3 = u * u * u
            outX[s] = b0 * x0 + b1 * x1 + b2 * x2 + b3 * x3
            outY[s] = b0 * y0 + b1 * y1 + b2 * y2 + b3 * y3
        }
    }

    private fun drawCubicDottedTrail(
        canvas: Canvas,
        x0: Float, y0: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        steps: Int,
        dotR: Float,
        color: Int,
        alpha: Float
    ) {
        p.style = Paint.Style.FILL
        for (s in 0..steps) {
            val u = s.toFloat() / steps.toFloat()
            val inv = 1f - u
            val dx = inv * inv * inv * x0 + 3f * inv * inv * u * x1 + 3f * inv * u * u * x2 + u * u * u * x3
            val dy = inv * inv * inv * y0 + 3f * inv * inv * u * y1 + 3f * inv * u * u * y2 + u * u * u * y3
            val fade = (1f - 0.65f * u).coerceIn(0.15f, 1f)
            p.color = withA(color, (alpha * fade * 255f).toInt())
            canvas.drawCircle(dx, dy, dotR, p)
        }
    }

    /**
     * 实心凹边四芒星（✦）+ 柔光晕
     */
    private fun drawSolidSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: CelestialPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, r * 1.55f,
            intArrayOf(
                withA(pal.glowColor, (alpha * 0.42f * 255f).toInt()),
                withA(pal.glowColor, (alpha * 0.14f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.55f, p)
        p.shader = null

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.35f
        p.color = withA(pal.rimColor, (alpha * 0.36f * 255f).toInt())
        canvas.drawPath(sparklePath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.coreColor, (alpha * 0.98f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    /**
     * 空心凹边四芒星（✧）+ 柔光描边
     */
    private fun drawHollowSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: CelestialPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.52f
        p.color = withA(pal.glowColor, (alpha * 0.25f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
        p.strokeWidth = max(1.5f, r * 0.22f)
        p.color = withA(pal.coreColor, (alpha * 0.90f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    /**
     * 左上斜弯月（🌙）：外圆减内偏移圆 + 三层柔焦光晕
     */
    private fun drawCrescentMoon(
        canvas: Canvas,
        mcx: Float,
        mcy: Float,
        outerR: Float,
        cutR: Float,
        offset: Float,
        openAngleDeg: Float,
        alpha: Float,
        pal: CelestialPalette
    ) {
        val rad = Math.toRadians(openAngleDeg.toDouble())
        val cutX = mcx + (offset * cos(rad)).toFloat()
        val cutY = mcy + (offset * sin(rad)).toFloat()

        moonOuterPath.reset()
        moonOuterPath.addCircle(mcx, mcy, outerR, Path.Direction.CW)
        moonCutPath.reset()
        moonCutPath.addCircle(cutX, cutY, cutR, Path.Direction.CW)
        moonOuterPath.op(moonCutPath, Path.Op.DIFFERENCE)

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = outerR * 0.45f
        p.color = withA(pal.glowColor, (alpha * 0.24f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)
        p.strokeWidth = outerR * 0.20f
        p.color = withA(pal.rimColor, (alpha * 0.42f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.coreColor, (alpha * 0.94f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)
    }

    /**
     * 构建四长四短非对称八芒星路径
     */
    private fun buildOctagramPath(
        out: Path,
        cx: Float,
        cy: Float,
        rMajor: Float,
        rMinor: Float,
        rWaist: Float
    ) {
        out.reset()
        for (i in 0 until 16) {
            val ang = Math.toRadians(-90.0 + i * 22.5)
            val r = when {
                i % 4 == 0 -> rMajor * (if (i == 0 || i == 8) 1.06f else 1.02f)
                i % 2 == 0 -> rMinor
                else -> rWaist
            }
            val x = cx + (r * cos(ang)).toFloat()
            val y = cy + (r * sin(ang)).toFloat()
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }

    /**
     * 构建带旋转角度的凹边四芒星路径
     */
    private fun buildSparkle4Path(
        out: Path,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float
    ) {
        out.reset()
        for (i in 0 until 4) {
            val a0 = Math.toRadians((rotDeg + i * 90f - 90f).toDouble())
            val a1 = Math.toRadians((rotDeg + (i + 1) * 90f - 90f).toDouble())
            val amid = Math.toRadians((rotDeg + i * 90f - 45f).toDouble())
            val x0 = cx + (r * cos(a0)).toFloat()
            val y0 = cy + (r * sin(a0)).toFloat()
            val xm = cx + (r * waistK * cos(amid)).toFloat()
            val ym = cy + (r * waistK * sin(amid)).toFloat()
            val x1 = cx + (r * cos(a1)).toFloat()
            val y1 = cy + (r * sin(a1)).toFloat()
            if (i == 0) out.moveTo(x0, y0)
            out.quadTo(xm, ym, x1, y1)
        }
        out.close()
    }

    /**
     * 构建大圆角胖五角星路径，并同步记录 10 个顶点到 starVx/starVy
     */
    private fun buildRoundedStarPath(
        out: Path,
        cx: Float,
        cy: Float,
        outer: Float,
        inner: Float,
        points: Int,
        rotDeg: Float,
        k: Float
    ) {
        out.reset()
        val n = points * 2
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians(rotDeg + i * 180.0 / points)
            starVx[i] = cx + (r * cos(a)).toFloat()
            starVy[i] = cy + (r * sin(a)).toFloat()
        }
        var first = true
        for (i in 0 until n) {
            val pv = (i - 1 + n) % n
            val nv = (i + 1) % n
            val px = starVx[i] + (starVx[pv] - starVx[i]) * k
            val py = starVy[i] + (starVy[pv] - starVy[i]) * k
            val qx = starVx[i] + (starVx[nv] - starVx[i]) * k
            val qy = starVy[i] + (starVy[nv] - starVy[i]) * k
            if (first) {
                out.moveTo(px, py)
                first = false
            } else {
                out.lineTo(px, py)
            }
            out.quadTo(starVx[i], starVy[i], qx, qy)
        }
        out.close()
    }

    private fun hsvC(h: Float, s: Float, v: Float): Int =
        Color.HSVToColor(floatArrayOf((h % 360f + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun easeOutCube(x: Float): Float {
        val d = 1f - x
        return 1f - d * d * d
    }

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.55f
        val d = x - 1f
        return 1f + (c1 + 1f) * d * d * d + c1 * d * d
    }

    private fun withA(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
