package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.LinearGradient
import android.graphics.RadialGradient
import android.widget.TextView
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt



/**
 * 三大字体模块独立导入与缓存管理器：
 * 1. SLOT_ENG ("font_eng.ttf")：按键英文字母与数字字体
 * 2. SLOT_CAND ("font_cand.ttf")：中文候选词与状态栏字体
 * 3. SLOT_ENTER ("font_enter.ttf")：右下角自定义文字（如“盛夏光年”）专属字体
 */
object CustomFontManager {
    const val SLOT_ENG = "eng"
    const val SLOT_CAND = "cand"
    const val SLOT_ENTER = "enter"

    private var cachedEngTs: Long = -1L
    private var cachedCandTs: Long = -1L
    private var cachedEnterTs: Long = -1L

    private var engTypeface: Typeface? = null
    private var candTypeface: Typeface? = null
    private var enterTypeface: Typeface? = null

    fun getFontFile(context: Context, slot: String): File {
        return File(context.filesDir, "custom_font_$slot.ttf")
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_eng", 0L) xor
            (prefs.getLong("font_ts_cand", 0L) shl 1) xor
            (prefs.getLong("font_ts_enter", 0L) shl 2)
    }

    fun hasCustomFont(context: Context, slot: String): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_$slot", 0L) > 0L && getFontFile(context, slot).exists()
    }

    fun getCustomFontName(context: Context, slot: String): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("font_name_$slot", "未导入（使用系统默认）") ?: "未导入（使用系统默认）"
    }

    fun clearCustomFont(context: Context, slot: String) {
        try {
            getFontFile(context, slot).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("font_ts_$slot", 0L)
            .remove("font_name_$slot")
            .apply()
        synchronized(this) {
            when (slot) {
                SLOT_ENG -> { cachedEngTs = 0L; engTypeface = null }
                SLOT_CAND -> { cachedCandTs = 0L; candTypeface = null }
                SLOT_ENTER -> { cachedEnterTs = 0L; enterTypeface = null }
            }
        }
    }

    fun getEngKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_eng", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedEngTs && engTypeface != null) return engTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENG)
            if (f.exists()) {
                try {
                    engTypeface = Typeface.createFromFile(f)
                    cachedEngTs = ts
                    return engTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getCandidateTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_cand", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedCandTs && candTypeface != null) return candTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_CAND)
            if (f.exists()) {
                try {
                    candTypeface = Typeface.createFromFile(f)
                    cachedCandTs = ts
                    return candTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getEnterKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_enter", 0L)
        if (ts <= 0L) return getCandidateTypeface(context)
        if (ts == cachedEnterTs && enterTypeface != null) return enterTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENTER)
            if (f.exists()) {
                try {
                    enterTypeface = Typeface.createFromFile(f)
                    cachedEnterTs = ts
                    return enterTypeface!!
                } catch (_: Exception) {}
            }
            return getCandidateTypeface(context)
        }
    }
}


/**
 * 基于 OKLCH 感知均匀色彩空间的按键背光自动取色器：
 * - 完全独立于现有的 KeyboardBacklightOverlayView 光晕动画与双层渐变绘制；
 * - 直接根据单键最终生效的背景色（含按排配色、单键独立配色、随机跳色）计算背光色；
 * - 不设死板的统一饱和度下限，采用「比例温和增益 + 软上限压缩（Soft-Knee）」，保留浅色系的呼吸层次感；
 * - 针对人眼最敏感的绿/黄绿波段（Hue 100°~165°）施加平滑色度阻尼，根治荧光绿，同时绝不压低明度 L 导致浅粉/焦糖变灰；
 * - 自动区分浅色皮肤与深色皮肤（如暗夜黑金）：当检测到深色按键或深黑底板时，自动开启「暗底逆向提亮 + 暖珀流金」模式。
 */
object OklchBacklightExtractor {

    fun extractGlowColor(
        finalKeyBgColor: Int,
        kbBgColor: Int = Color.WHITE,
        themeTintColor: Int = Color.WHITE,
        explicitCssGlowColor: Int? = null
    ): Int {
        explicitCssGlowColor?.let { return it }

        val r = Color.red(finalKeyBgColor) / 255.0
        val g = Color.green(finalKeyBgColor) / 255.0
        val b = Color.blue(finalKeyBgColor) / 255.0

        val kr = Color.red(kbBgColor) / 255.0
        val kg = Color.green(kbBgColor) / 255.0
        val kb = Color.blue(kbBgColor) / 255.0

        val tr = Color.red(themeTintColor) / 255.0
        val tg = Color.green(themeTintColor) / 255.0
        val tb = Color.blue(themeTintColor) / 255.0

        val (l, c, hDeg) = srgbToOklch(r, g, b)
        val (kbL, _, _) = srgbToOklch(kr, kg, kb)
        val (_, themeC, themeHDeg) = srgbToOklch(tr, tg, tb)
        val isLightKb = kbL >= 0.48

        // 1. 深色按键 (L < 0.45，如芋泥紫/黑粉皮肤的深紫灰功能键 #3D3244，或暗夜黑金的深黑功能键)：
        //    严格保持莫兰迪低色度柔雾感，绝不把色度拉高到 0.072~0.110 造成刺眼荧光！
        if (l < 0.45) {
            val effectiveHue = when {
                c < 0.022 && themeC >= 0.014 -> themeHDeg
                c < 0.034 && themeC >= 0.018 -> blendHueDegrees(hDeg, themeHDeg, 0.30)
                else -> hDeg
            }
            return if (isLightKb) {
                val liftedL = (l + 0.36).coerceIn(0.66, 0.75)
                val baseC = max(c, min(themeC, 0.052) * 0.82)
                val liftedC = (baseC * 1.08 + 0.006).coerceIn(0.028, 0.054)
                oklchToSrgbColor(liftedL, liftedC, effectiveHue)
            } else {
                val liftedL = (l + 0.40).coerceIn(0.74, 0.82)
                val baseC = max(c, min(themeC, 0.072) * 0.80)
                val liftedC = (baseC * 1.15 + 0.012).coerceIn(0.038, 0.074)
                oklchToSrgbColor(liftedL, liftedC, effectiveHue)
            }
        }

        // 2. 极低色度纯白/纯灰键 (C < 0.010)：轻柔借用皮肤主题色相的莫兰迪微光
        if (c < 0.010) {
            if (themeC >= 0.014) {
                val borrowedC = (themeC * 0.92 + 0.008).coerceIn(0.026, 0.052)
                val targetL = if (isLightKb) 0.80 else 0.82
                return oklchToSrgbColor(targetL, borrowedC, themeHDeg)
            }
            return Color.parseColor("#C8D4E6")
        }

        // 3. 荧光敏感波段色度阻尼：
        //    不仅绿/黄绿波段 (100°~175°) 易荧光，紫/粉紫/香芋紫波段 (275°~350°) 在高明度下色度稍高就会产生「芭比粉紫荧光」！
        val hueDamping = when {
            hDeg in 100.0..175.0 -> {
                val dist = kotlin.math.abs(hDeg - 138.0) / 37.5
                0.72 + 0.20 * dist.coerceIn(0.0, 1.0)
            }
            hDeg in 275.0..350.0 -> {
                val dist = kotlin.math.abs(hDeg - 318.0) / 37.5
                0.70 + 0.18 * dist.coerceIn(0.0, 1.0)
            }
            else -> 1.0
        }

        // 4. 忠实于键帽自身莫兰迪灰度的同系取色：
        //    彻底废除原先 `c * 1.95 + 0.036` 强行拔高饱和度、以及 `l * 1.04` 拔高明度导致 #D1BAD4 变成荧光粉紫 #F2B3FB 的问题！
        val boostedC: Double
        val targetL: Double
        if (isLightKb) {
            val rawC: Double
            val capC: Double
            if (l >= 0.88) {
                // 极浅键（如第一排 #EADEEA、#DCECE7、#FAF3EB）：仅做温和同色相晕染加深
                rawC = c * 1.24 + 0.009
                capC = max(c * 1.42 + 0.010, min(0.052, themeC * 0.92)) * hueDamping
                targetL = (l - 0.065).coerceIn(0.79, 0.85)
            } else if (l >= 0.74) {
                // 中浅莫兰迪键（如第二排芋泥灰紫 #D1BAD4、跳色键 #C4ADC9、薄荷 #A9D4C9、拿铁 #D7B493）：
                // 键帽本身已有完美莫兰迪色度，背光色度与键帽保持近乎 1:1，明度微沉半阶形成温润同系水彩晕染，绝不提亮发荧光！
                rawC = c * 1.05 + 0.003
                capC = max(c * 1.14, 0.064 * hueDamping)
                targetL = (l - 0.035).coerceIn(0.75, 0.81)
            } else {
                // 中深色键（如第三排 #877BA3、#5B9E98、#A47251）：在浅色底板上略微柔化雾化
                rawC = c * 0.95
                capC = max(c, 0.068 * hueDamping)
                targetL = (l * 0.65 + kbL * 0.35).coerceIn(0.69, 0.77)
            }
            boostedC = softKneeCompress(rawC, capC * 0.85, capC)
        } else {
            // 深色键盘底板（如豆沙玫瑰暗底 #261F23、暗夜黑金 #14161D）：
            val rawC = c * 1.14 + 0.007
            val capC = max(c * 1.24, 0.076 * hueDamping)
            boostedC = softKneeCompress(rawC, capC * 0.85, capC)
            targetL = when {
                l >= 0.85 -> (l - 0.04).coerceIn(0.80, 0.86)
                l >= 0.65 -> (l + 0.02).coerceIn(0.75, 0.82)
                else -> (l + 0.14).coerceIn(0.72, 0.79)
            }
        }

        val rawRgb = oklchToSrgbColor(targetL, boostedC, hDeg)

        // 5. 终极 sRGB/HSV 防荧光物理护栏：
        //    确保背光色的 HSV 饱和度 S 与明度 V 严格受限于键帽自身莫兰迪质感，在浅色键盘上绝不允许 V 超过键帽本身！
        val keyHsv = FloatArray(3)
        val glowHsv = FloatArray(3)
        Color.colorToHSV(finalKeyBgColor, keyHsv)
        Color.colorToHSV(rawRgb, glowHsv)
        val ks = keyHsv[1]
        val kv = keyHsv[2]

        val maxAllowedS = if (ks < 0.32f) {
            max(ks * 1.26f + 0.035f, min(ks + 0.075f, 0.23f)).coerceAtMost(0.85f)
        } else {
            (ks * 1.08f + 0.02f).coerceAtMost(0.85f)
        }
        var maxAllowedV = if (isLightKb) min(0.90f, kv + 0.01f) else min(0.92f, max(kv, 0.85f))
        if (isLightKb && kv >= 0.76f) {
            maxAllowedV = min(kv - 0.025f, 0.85f)
        }
        glowHsv[1] = min(glowHsv[1], maxAllowedS)
        glowHsv[2] = min(glowHsv[2], maxAllowedV)
        return Color.HSVToColor(glowHsv)
    }

    private fun blendHueDegrees(h1: Double, h2: Double, ratioH2: Double): Double {
        val r1 = Math.toRadians(h1)
        val r2 = Math.toRadians(h2)
        val x = (1.0 - ratioH2) * cos(r1) + ratioH2 * cos(r2)
        val y = (1.0 - ratioH2) * sin(r1) + ratioH2 * sin(r2)
        var deg = Math.toDegrees(atan2(y, x))
        if (deg < 0.0) deg += 360.0
        return deg
    }

    private fun softKneeCompress(x: Double, knee: Double, maxVal: Double): Double {
        if (x <= knee) return x
        val excess = x - knee
        val span = (maxVal - knee).coerceAtLeast(0.005)
        return knee + span * (excess / (excess + span))
    }

    private fun srgbToLinear(v: Double): Double {
        return if (v <= 0.04045) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun linearToSrgb(v: Double): Double {
        val clamped = v.coerceIn(0.0, 1.0)
        return if (clamped <= 0.0031308) 12.92 * clamped else 1.055 * clamped.pow(1.0 / 2.4) - 0.055
    }

    private fun srgbToOklch(r: Double, g: Double, b: Double): Triple<Double, Double, Double> {
        val lr = srgbToLinear(r)
        val lg = srgbToLinear(g)
        val lb = srgbToLinear(b)

        val l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb)
        val m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb)
        val s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb)

        val okL = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
        val okA = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
        val okB = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s

        val c = hypot(okA, okB)
        var h = Math.toDegrees(atan2(okB, okA))
        if (h < 0.0) h += 360.0
        return Triple(okL, c, h)
    }

    private fun oklchToSrgbColor(l: Double, c: Double, hDeg: Double): Int {
        val hRad = Math.toRadians(hDeg)
        val okA = c * cos(hRad)
        val okB = c * sin(hRad)

        val l_ = l + 0.3963377774 * okA + 0.2158037573 * okB
        val m_ = l - 0.1055613458 * okA - 0.0638541728 * okB
        val s_ = l - 0.0894841775 * okA - 1.2914855480 * okB

        val lCube = l_ * l_ * l_
        val mCube = m_ * m_ * m_
        val sCube = s_ * s_ * s_

        val lr = +4.0767416621 * lCube - 3.3077115913 * mCube + 0.2309699292 * sCube
        val lg = -1.2684380046 * lCube + 2.6097574011 * mCube - 0.3413193965 * sCube
        val lb = -0.0041960863 * lCube - 0.7034186147 * mCube + 1.7076147010 * sCube

        val sr = (linearToSrgb(lr) * 255.0).toInt().coerceIn(0, 255)
        val sg = (linearToSrgb(lg) * 255.0).toInt().coerceIn(0, 255)
        val sb = (linearToSrgb(lb) * 255.0).toInt().coerceIn(0, 255)
        return Color.rgb(sr, sg, sb)
    }
}


/**
 * 零延迟按键敲击音效管理器（内置用户提供的清脆敲击音 key_click.wav，支持设置页 Switch 自由开关）
 */
object KeySoundManager {
    private const val CUSTOM_SOUND_FILE = "custom_key_sound.dat"
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    @Volatile
    private var loaded = false
    @Volatile
    private var loadedSoundTs: Long = -1L
    @Volatile
    private var cachedSoundEnabled: Boolean? = null
    @Volatile
    private var cachedCustomSoundTs: Long = -1L
    private val soundExecutor = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "ShengXia-KeySound").apply { isDaemon = true }
    }

    fun syncSoundPrefs(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        cachedSoundEnabled = prefs.getBoolean("key_sound_enabled", true)
        cachedCustomSoundTs = prefs.getLong("custom_sound_ts", 0L)
    }

    fun setSoundEnabledCached(enabled: Boolean) {
        cachedSoundEnabled = enabled
    }

    fun getCustomSoundFile(context: Context): File = File(context.filesDir, CUSTOM_SOUND_FILE)

    fun hasCustomSound(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_sound_ts", 0L) > 0L && getCustomSoundFile(context).exists()
    }

    fun getCustomSoundName(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("custom_sound_name", "自定义音效") ?: "自定义音效"
    }

    fun clearCustomSound(context: Context) {
        try {
            getCustomSoundFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_sound_ts", 0L)
            .remove("custom_sound_name")
            .apply()
        reloadSound(context)
    }

    fun reloadSound(context: Context) {
        synchronized(this) {
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            soundPool = null
            clickSoundId = 0
            loaded = false
            loadedSoundTs = -1L
            ensureInitialized(context)
        }
    }

    fun ensureInitialized(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val curTs = prefs.getLong("custom_sound_ts", 0L)
        if (soundPool != null && curTs == loadedSoundTs) return
        synchronized(this) {
            if (soundPool != null && curTs == loadedSoundTs) return
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            loaded = false
            clickSoundId = 0
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val sp = SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(attrs)
                    .build()
                sp.setOnLoadCompleteListener { pool, sampleId, status ->
                    if (status == 0 && sampleId == clickSoundId) {
                        loaded = true
                        if (pendingPreviewPlay) {
                            pendingPreviewPlay = false
                            pool.play(clickSoundId, 0.90f, 0.90f, 1, 0, 1.0f)
                        }
                    }
                }
                val customFile = getCustomSoundFile(context)
                clickSoundId = if (curTs > 0L && customFile.exists()) {
                    sp.load(customFile.absolutePath, 1)
                } else {
                    context.assets.openFd("key_click.wav").use { afd ->
                        sp.load(afd, 1)
                    }
                }
                soundPool = sp
                loadedSoundTs = curTs
            } catch (_: Exception) {}
        }
    }

    @Volatile
    private var pendingPreviewPlay = false

    fun playClick(context: Context, forcePreview: Boolean = false) {
        try {
            val enabled = cachedSoundEnabled ?: run {
                syncSoundPrefs(context)
                cachedSoundEnabled ?: true
            }
            if (!forcePreview && !enabled) return
            val sp = soundPool
            val sid = clickSoundId
            if (sp != null && loaded && sid != 0 && cachedCustomSoundTs == loadedSoundTs) {
                soundExecutor.execute {
                    try {
                        sp.play(sid, 0.88f, 0.88f, 1, 0, 1.0f)
                    } catch (_: Exception) {}
                }
                return
            }
            val appCtx = context.applicationContext
            soundExecutor.execute {
                try {
                    ensureInitialized(appCtx)
                    val pool = soundPool ?: return@execute
                    if (loaded && clickSoundId != 0) {
                        pool.play(clickSoundId, 0.88f, 0.88f, 1, 0, 1.0f)
                    } else if (forcePreview) {
                        pendingPreviewPlay = true
                    }
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }
}

/**
 * 纯色框架下的「自定义键盘背景图 + 实时高斯模糊底图采样」管理器：
 * - 当用户从相册上传背景图后，自动按 background-size: cover 铺满键盘底板；
 * - 同时预计算高平滑度高斯模糊底图 (blurredBitmap)，供所有半透明毛玻璃按键与顶栏实时读取并模糊对应坐标处的底图！
 */
object CustomBgManager {
    private const val FILE_NAME = "custom_kb_bg.png"
    private var cachedTimestamp: Long = -1L
    private var rawBitmap: Bitmap? = null
    private var blurredBitmap: Bitmap? = null

    fun getBgFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun hasCustomBg(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        return ts > 0L && getBgFile(context).exists()
    }

    fun clearCustomBg(context: Context) {
        try {
            getBgFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_bg_ts", 0L)
            .apply()
        synchronized(this) {
            cachedTimestamp = 0L
            rawBitmap = null
            blurredBitmap = null
        }
    }

    private fun ensureLoaded(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        if (ts <= 0L) {
            rawBitmap = null
            blurredBitmap = null
            cachedTimestamp = 0L
            return
        }
        if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
        synchronized(this) {
            if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
            val file = getBgFile(context)
            if (!file.exists()) {
                rawBitmap = null
                blurredBitmap = null
                cachedTimestamp = 0L
                return
            }
            try {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) {
                    rawBitmap = bmp
                    blurredBitmap = createGaussianBlurredBitmap(bmp)
                    cachedTimestamp = ts
                }
            } catch (_: Exception) {}
        }
    }

    fun getRawBitmap(context: Context): Bitmap? {
        if (cachedTimestamp >= 0L) return rawBitmap
        ensureLoaded(context)
        return rawBitmap
    }

    fun getBlurredBitmap(context: Context): Bitmap? {
        if (cachedTimestamp >= 0L) return blurredBitmap
        ensureLoaded(context)
        return blurredBitmap
    }

    fun invalidateBgCache() {
        cachedTimestamp = -1L
    }

    /**
     * 通过 1/4 下采样 + 3 遍可分离均值滤波（中心极限定理等效高半径高斯模糊）生成柔焦毛玻璃底图
     */
    private fun createGaussianBlurredBitmap(src: Bitmap): Bitmap {
        val sw = (src.width / 4).coerceAtLeast(64)
        val sh = (src.height / 4).coerceAtLeast(48)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        val tmp = IntArray(sw * sh)
        val radius = 6

        repeat(3) {
            // Horizontal pass
            for (y in 0 until sh) {
                val rowOff = y * sw
                for (x in 0 until sw) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val x0 = max(0, x - radius)
                    val x1 = min(sw - 1, x + radius)
                    for (ix in x0..x1) {
                        val c = pixels[rowOff + ix]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    tmp[rowOff + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
            // Vertical pass
            for (x in 0 until sw) {
                for (y in 0 until sh) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val y0 = max(0, y - radius)
                    val y1 = min(sh - 1, y + radius)
                    for (iy in y0..y1) {
                        val c = tmp[iy * sw + x]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    pixels[y * sw + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
        }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        return out
    }
}

/**
 * 自定义背景图的 background-size: cover + 可调节（0~100）背景毛玻璃程度渲染 Drawable：
 * - blurLevel = 0 时：100% 清晰显示用户上传的原图；
 * - blurLevel = 1..100 时：按比例平滑混合高清原图与柔焦高斯模糊底图，并叠加清透毛玻璃雾面光泽！
 */
class CustomCoverBgDrawable(
    private val rawBitmap: Bitmap,
    private val blurredBitmap: Bitmap?,
    var blurLevel: Int = 25
) : Drawable() {
    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val frostVeilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val matrix = Matrix()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val bw = b.width().toFloat()
        val bh = b.height().toFloat()
        if (bw <= 0f || bh <= 0f || rawBitmap.width <= 0 || rawBitmap.height <= 0) return

        val lv = blurLevel.coerceIn(0, 100)
        val save = canvas.save()
        canvas.clipRect(b)

        // 1. 绘制原图（当 blurLevel < 100 时作为清晰基底）
        if (lv < 100 || blurredBitmap == null) {
            val scale = max(bw / rawBitmap.width.toFloat(), bh / rawBitmap.height.toFloat())
            val dx = b.left + (bw - rawBitmap.width * scale) * 0.5f
            val dy = b.top + (bh - rawBitmap.height * scale) * 0.5f
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(dx, dy)
            canvas.drawBitmap(rawBitmap, matrix, rawPaint)
        }

        // 2. 按 0~100 程度叠加背景毛玻璃模糊层与轻柔雾面光泽
        if (lv > 0 && blurredBitmap != null && blurredBitmap.width > 0 && blurredBitmap.height > 0) {
            val bScale = max(bw / blurredBitmap.width.toFloat(), bh / blurredBitmap.height.toFloat())
            val bDx = b.left + (bw - blurredBitmap.width * bScale) * 0.5f
            val bDy = b.top + (bh - blurredBitmap.height * bScale) * 0.5f
            matrix.reset()
            matrix.setScale(bScale, bScale)
            matrix.postTranslate(bDx, bDy)
            blurPaint.alpha = (lv * 2.55f).toInt().coerceIn(0, 255)
            canvas.drawBitmap(blurredBitmap, matrix, blurPaint)

            // 随毛玻璃程度增加一点点清透雾白柔光感（最高约 22% 雾面感，不遮挡画面色彩）
            val veilAlpha = (lv * 0.56f).toInt().coerceIn(0, 56)
            if (veilAlpha > 0) {
                frostVeilPaint.color = Color.argb(veilAlpha, 255, 255, 255)
                canvas.drawRect(b, frostVeilPaint)
            }
        }
        canvas.restoreToCount(save)
    }

    private val paint = rawPaint

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private val loadedFolders = HashSet<String>()

    fun ensureLoaded(context: Context, folder: String = "monet") {
        if (loadedFolders.contains(folder)) return
        synchronized(this) {
            if (loadedFolders.contains(folder)) return
            val names = listOf(
                "kb_frosted_bg", "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "bear_popup_0", "bear_popup_1", "bear_popup_2", "bear_popup_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("$folder/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache["$folder/$n"] = bmp
                    }
                } catch (_: Exception) {}
            }
            loadedFolders.add(folder)
        }
    }

    fun getKbBgBitmap(context: Context, folder: String = "monet"): Bitmap? {
        ensureLoaded(context, folder)
        return cache["$folder/kb_frosted_bg"]
    }

    fun getTopBarBitmap(context: Context, folder: String = "monet"): Bitmap? {
        ensureLoaded(context, folder)
        return cache["$folder/top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int, folder: String = "monet"): Bitmap? {
        ensureLoaded(context, folder)
        return cache["$folder/top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context, "monet")
        return cache["monet/space_lotus_icon"]
    }

    fun getBreadPopupBearBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context, "bread_light")
        return cache["bread_light/bear_popup_${(index and 3)}"]
    }

    fun getKeyBitmap(context: Context, keyId: String, folder: String = "monet"): Bitmap? {
        val clean = keyId.trim().lowercase()
        if (clean.isEmpty()) return null
        ensureLoaded(context, folder)
        val isBread = folder.startsWith("bread")
        val mapped = if (isBread) {
            when (clean) {
                "qw", "er", "ty", "ui", "op",
                "as", "df", "gh", "jk", "l",
                "wildcard", "zx", "cv", "bn", "m", "backspace",
                "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
                "q" -> "key_qw"
                "w" -> "key_er"
                "e" -> "key_df"
                "r" -> "key_ui"
                "t", "y" -> "key_ty"
                "u" -> "key_m"
                "i", "o" -> "key_zx"
                "p" -> "key_op"
                "a" -> "key_as"
                "s", "d" -> "key_ty"
                "f" -> "key_jk"
                "g" -> "key_gh"
                "h" -> "key_op"
                "j" -> "key_df"
                "k" -> "key_l"
                "shift", "▲", "△", "通配" -> "key_wildcard"
                "z" -> "key_zx"
                "x" -> "key_jk"
                "c", "b" -> "key_df"
                "v" -> "key_cv"
                "n" -> "key_bn"
                "⌫" -> "key_backspace"
                "符", "符号", "返回" -> "key_sym"
                "123" -> "key_num"
                "，", "," -> "key_comma"
                "。", "." -> "key_period"
                "中", "英", "中/英", "英/中" -> "key_lang"
                "enter", "回车" -> "key_enter"
                else -> return null
            }
        } else {
            when (clean) {
                "qw", "er", "ty", "ui", "op",
                "as", "df", "gh", "jk", "l",
                "wildcard", "zx", "cv", "bn", "m", "backspace",
                "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
                "q", "u" -> "key_qw"
                "w", "i" -> "key_er"
                "t", "y" -> "key_ty"
                "e", "o" -> "key_ui"
                "r", "p" -> "key_op"
                "a", "h" -> "key_as"
                "s", "j" -> "key_df"
                "d", "k" -> "key_gh"
                "f" -> "key_jk"
                "g" -> "key_l"
                "shift", "▲", "△", "通配" -> "key_wildcard"
                "z", "n" -> "key_zx"
                "x" -> "key_cv"
                "v", "b" -> "key_bn"
                "c" -> "key_m"
                "⌫" -> "key_backspace"
                "符", "符号", "返回" -> "key_sym"
                "123" -> "key_num"
                "，", "," -> "key_comma"
                "。", "." -> "key_period"
                "中", "英", "中/英", "英/中" -> "key_lang"
                "enter", "回车" -> "key_enter"
                else -> return null
            }
        }
        return cache["$folder/$mapped"]
    }
}

/**
 * 位于键盘最底层的「中心浓郁加深、四周柔和减淡」双层半透明背光层：
 * - 彻底摒弃刺眼的荧光亮色；
 * - 内层核心（innerGrad）自动比外层柔雾（outerGrad）再加深 22%，让按键中心位置呈现出浓郁温润的深睡莲绿/同色系深色核心，
 *   越往周围扩散越浅、越半透明，与莫奈花园及所有纯色皮肤完美融合。
 */
/**
 * 独立星河色彩适配器（与粒子几何形状、星芒绘制逻辑完全解耦）：
 * - 星芒核心恒定采用纯净高亮白 (#FFFFFF) 与近白星光色；
 * - 外围柔光继承当前皮肤主色相，但自动降低饱和度，彻底杜绝刺眼荧光色与深色背景下的「黄色烟雾感」；
 * - 同时自动适配深色背景与浅色背景，不将任何固定颜色写死到皮肤中。
 */
object StarlightColorAdapter {

    class StarlightPalette(
        val coreWhite: Int,
        val rayNearWhite: Int,
        val softHaloColor: Int,
        val ambientGlowColor: Int,
        val lightContrastShadowColor: Int,
        val meteorPrimaryTint: Int,
        val meteorAccent1: Int,
        val meteorAccent2: Int,
        val meteorLightHaloColor: Int,
        val isLightSurface: Boolean,
        val ambientAlphaScale: Float
    )

    private fun computeColorLum(c: Int): Float {
        return 0.2126f * (Color.red(c) / 255f) +
            0.7152f * (Color.green(c) / 255f) +
            0.0722f * (Color.blue(c) / 255f)
    }

    fun resolvePalette(
        rawGlowColor: Int,
        surfaceBgColor: Int? = null,
        keyboardBgColor: Int? = null
    ): StarlightPalette {
        val hsv = FloatArray(3)
        Color.colorToHSV(rawGlowColor, hsv)
        val rawH = hsv[0]
        val rawS = hsv[1]
        val rawV = hsv[2]

        // 综合判断键盘底板亮度与按键表面亮度：
        // 1) 若键盘底板本身是深色（如暗夜黑金 #14161D、深色黑粉 #18141A，kbLum < 0.38），哪怕字母键是暖白键，键下流光依然绽放在深黑缝隙上，严格采用深色高亮流光策略；
        // 2) 若键盘底板是浅色（如浅粉 #FAF2F3、奶白拿铁 #F5EFEA、莫奈浅蓝 #E4EDF7、薄荷奶黄 #F5F1EB），即便按到深酒红/深咖跳色键，键下流光也绽放在浅色底板上，严格采用浅色清透流光策略！
        val hasKbBg = keyboardBgColor != null && Color.alpha(keyboardBgColor) > 40
        val hasKeyBg = surfaceBgColor != null && Color.alpha(surfaceBgColor) > 40
        val surfaceLum = when {
            hasKbBg -> {
                val kbLum = computeColorLum(keyboardBgColor!!)
                if (kbLum < 0.38f) {
                    kbLum
                } else if (hasKeyBg) {
                    kbLum * 0.70f + computeColorLum(surfaceBgColor!!) * 0.30f
                } else {
                    kbLum
                }
            }
            hasKeyBg -> computeColorLum(surfaceBgColor!!)
            else -> computeColorLum(rawGlowColor)
        }
        val isLightSurface = surfaceLum >= 0.52f

        // 1. 针对偏黄/暖金波段 (Hue 26°~76°)，大幅降低外围光晕饱和度并向清冷月光香槟白偏移，彻底消除深色底上的“黄色烟雾”
        val isYellowWarmBand = rawH in 26f..76f
        val isGreenBand = rawH in 90f..168f

        // 2. 星芒近白过渡色（90% 纯白 + 10% 低饱和皮肤色相）
        val nearWhiteHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.0f else (rawS * 0.22f).coerceIn(0.04f, if (isYellowWarmBand) 0.10f else 0.15f),
            0.99f
        )
        val rayNearWhite = Color.HSVToColor(nearWhiteHsv)

        // 3. 星芒外围柔光色（继承皮肤色相但显著降低饱和度，清爽通透）
        val haloSatCap = when {
            rawS < 0.05f -> 0.08f
            isYellowWarmBand -> if (isLightSurface) 0.24f else 0.16f
            isGreenBand -> 0.25f
            else -> if (isLightSurface) 0.34f else 0.26f
        }
        val haloHsv = floatArrayOf(
            rawH,
            (rawS * 0.58f).coerceIn(0.08f, haloSatCap),
            if (isLightSurface) rawV.coerceIn(0.84f, 0.94f) else rawV.coerceIn(0.86f, 0.96f)
        )
        val softHaloColor = Color.HSVToColor(haloHsv)

        // 4. 底层环境背光晕颜色
        val ambientSatCap = when {
            rawS < 0.05f -> 0.10f
            isYellowWarmBand -> if (isLightSurface) 0.28f else 0.18f
            isGreenBand -> 0.28f
            else -> if (isLightSurface) 0.38f else 0.30f
        }
        val ambientHsv = floatArrayOf(
            rawH,
            (rawS * 0.65f).coerceIn(0.08f, ambientSatCap),
            if (isLightSurface) rawV.coerceIn(0.84f, 0.94f) else rawV.coerceIn(0.78f, 0.90f)
        )
        val ambientGlowColor = Color.HSVToColor(ambientHsv)

        // 5. 浅色背景专属柔和星影衬底色
        val contrastHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.14f else (rawS * 0.62f + 0.08f).coerceIn(0.20f, if (isYellowWarmBand) 0.30f else 0.38f),
            if (isLightSurface) 0.82f else 0.86f
        )
        val lightContrastShadowColor = Color.HSVToColor(contrastHsv)

        // 6. 🌙 键下不规则弧形流光细丝 & 簇状星语配色：
        //    - 深色皮肤 (!isLightSurface)：完全保留 v7.27 备受好评的高亮流光、主题染色与柔和光晕；
        //    - 浅色皮肤 (isLightSurface)：彻底根除以往 V=0.48~0.60 低明度 + 高饱和度造成的「发棕、发黑、浓重泥色团块」！
        //      采用高明度 (V=0.92~0.98) + 与皮肤协调的中等清透饱和度 (S=0.30~0.50)，并按浅粉/奶白暖金/薄荷绿/浅蓝分色带精准调校邻近色相。
        val baseHue = if (rawS < 0.05f) 215f else rawH

        val meteorPrimaryTint: Int
        val meteorAccent1: Int
        val meteorAccent2: Int
        val meteorLightHaloColor: Int

        if (isLightSurface) {
            // 浅色/莫兰迪皮肤：100% 忠实继承 OklchBacklightExtractor 已校准的莫兰迪饱和度与温润明度，
            // 严禁强行将 S 拉到 0.40~0.52 或将 V 拉到 0.94~0.98 导致芋泥紫/豆沙粉变成刺眼芭比荧光色！
            val pSat = (rawS * 1.04f + 0.01f).coerceIn(0.08f, 0.34f)
            val pVal = rawV.coerceIn(0.72f, 0.86f)
            val accH1 = (baseHue + 5f) % 360f
            val accH2 = (baseHue + 355f) % 360f
            meteorPrimaryTint = Color.HSVToColor(floatArrayOf(baseHue, pSat, pVal))
            meteorAccent1 = Color.HSVToColor(floatArrayOf(accH1, (pSat * 0.95f).coerceIn(0.07f, 0.32f), (pVal + 0.02f).coerceIn(0.72f, 0.87f)))
            meteorAccent2 = Color.HSVToColor(floatArrayOf(accH2, (pSat * 0.92f).coerceIn(0.07f, 0.32f), pVal))
            meteorLightHaloColor = Color.HSVToColor(floatArrayOf(baseHue, (pSat * 0.75f).coerceIn(0.05f, 0.24f), (pVal + 0.04f).coerceIn(0.76f, 0.89f)))
        } else {
            // 深色皮肤（黑粉、暗夜黑金等）：温润月光与同系柔雾流光，避免高饱和荧光串色
            val pSat = (rawS * 0.85f + 0.03f).coerceIn(0.12f, 0.34f)
            val pVal = rawV.coerceIn(0.80f, 0.92f)
            val accentHue1 = (baseHue + 6f) % 360f
            val accentHue2 = (baseHue + 354f) % 360f
            meteorPrimaryTint = Color.HSVToColor(floatArrayOf(baseHue, pSat, pVal))
            meteorAccent1 = Color.HSVToColor(floatArrayOf(accentHue1, (pSat * 0.92f).coerceIn(0.10f, 0.32f), pVal))
            meteorAccent2 = Color.HSVToColor(floatArrayOf(accentHue2, (pSat * 0.90f).coerceIn(0.10f, 0.32f), pVal))
            meteorLightHaloColor = meteorPrimaryTint
        }

        val ambientAlphaScale = if (isLightSurface) 0.86f else if (isYellowWarmBand) 0.56f else 0.68f

        return StarlightPalette(
            coreWhite = Color.rgb(255, 255, 255),
            rayNearWhite = rayNearWhite,
            softHaloColor = softHaloColor,
            ambientGlowColor = ambientGlowColor,
            lightContrastShadowColor = lightContrastShadowColor,
            meteorPrimaryTint = meteorPrimaryTint,
            meteorAccent1 = meteorAccent1,
            meteorAccent2 = meteorAccent2,
            meteorLightHaloColor = meteorLightHaloColor,
            isLightSurface = isLightSurface,
            ambientAlphaScale = ambientAlphaScale
        )
    }
}

class KeyboardBacklightOverlayView(
    context: Context,
    val renderLayerMode: Int = LAYER_UNDER_GLOW,
    val clipCornerRadiusPx: Float = 0f,
    var keyboardSurfaceBgColor: Int? = null
) : View(context) {

    companion object {
        const val LAYER_UNDER_GLOW = 0
        const val LAYER_OVER_SPARKLE = 1
        const val LAYER_FULL_COMBINED = 2

        // 粒子形状枚举（复刻参考视频2：实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光微圆圈 ° + 明暗碎星尘 ·）
        const val SHAPE_SOLID_STAR4 = 0
        const val SHAPE_HOLLOW_STAR4 = 1
        const val SHAPE_SOFT_RING_PEARL = 2
        const val SHAPE_TWINKLE_DUST = 3

        // 1. 键盘上表面星点（移至「更多设置」独立保留）
        const val PREF_SPARKLE_ENABLED = "backlight_sparkle_enabled"
        const val PREF_SPARKLE_INTENSITY = "backlight_sparkle_intensity"
        const val DEFAULT_SPARKLE_INTENSITY = 82

        // 2. ☄️ 键盘下唯美星语（不规则弧形流光细丝 + 簇状星点：支持疏密、速度、距离三项独立调节）
        const val PREF_UNDER_BURST_ENABLED = "under_key_meteor_burst_enabled"
        const val PREF_UNDER_BURST_DENSITY = "under_key_burst_density"
        const val PREF_UNDER_BURST_SPEED = "under_key_burst_speed"
        const val PREF_UNDER_BURST_RANGE = "under_key_burst_range"
        const val PREF_QUICK_SLIDER_LOCK = "quick_panel_slider_lock"

        const val DEFAULT_UNDER_BURST_DENSITY = 65
        const val DEFAULT_UNDER_BURST_SPEED = 60
        const val DEFAULT_UNDER_BURST_RANGE = 48

        // 3. 💧 水纹落雨：浅层水波微漾（Liquid Ripple，独立开关 + 密度/速度/范围 三项调节）
        const val PREF_RIPPLE_ENABLED = "surface_liquid_ripple_enabled"
        const val PREF_RIPPLE_DENSITY = "surface_liquid_ripple_density"
        const val PREF_RIPPLE_SPEED = "surface_liquid_ripple_speed"
        const val PREF_RIPPLE_RANGE = "surface_liquid_ripple_range"

        const val DEFAULT_RIPPLE_DENSITY = 62
        const val DEFAULT_RIPPLE_SPEED = 55
        const val DEFAULT_RIPPLE_RANGE = 58

        // 4. ✦ 暗夜微尘 / 幽夜流星：极细碎闪与星屑沉落（Stardust Fall，独立开关 + 密度/速度/范围 三项调节，保留在更多设置）
        const val PREF_STARDUST_ENABLED = "surface_stardust_fall_enabled"
        const val PREF_STARDUST_DENSITY = "surface_stardust_fall_density"
        const val PREF_STARDUST_SPEED = "surface_stardust_fall_speed"
        const val PREF_STARDUST_RANGE = "surface_stardust_fall_range"

        const val DEFAULT_STARDUST_DENSITY = 64
        const val DEFAULT_STARDUST_SPEED = 56
        const val DEFAULT_STARDUST_RANGE = 55

        // 5. 🌀 键廓流光涡旋（复刻参考视频1第1排第2款「旋流弯月光环」+ 第1款「星泡萌爪」，贴合键帽圆角矩形形状 & 智能取色适配所有浅色皮肤！）
        const val PREF_CONTOUR_VORTEX_ENABLED = "surface_key_contour_vortex_enabled"
        const val PREF_CONTOUR_VORTEX_STYLE = "surface_key_contour_vortex_style"
        const val PREF_CONTOUR_VORTEX_DENSITY = "surface_key_contour_vortex_density"
        const val PREF_CONTOUR_VORTEX_SPEED = "surface_key_contour_vortex_speed"
        const val PREF_CONTOUR_VORTEX_RANGE = "surface_key_contour_vortex_range"

        const val STYLE_PAW_STAR_BUBBLE = 1 // 视频1第1排第1个：键廓星泡萌爪
        const val STYLE_VORTEX_RING = 2     // 视频1第1排第2个（默认推荐）：键廓旋流弯月光环
        const val STYLE_BOTH_COMBINED = 3   // 第1款 + 第2款融合叠加

        const val DEFAULT_CONTOUR_VORTEX_DENSITY = 68
        const val DEFAULT_CONTOUR_VORTEX_SPEED = 58
        const val DEFAULT_CONTOUR_VORTEX_RANGE = 60

        // 6. 🌸 视频2同款「按键上面变色 + 下面同色光晕显示（此刻心动）」特效（独立开关 + 款式 + 浓度/速度/范围 三项调节）
        const val PREF_KEY_BLUSH_HALO_ENABLED = "surface_key_blush_halo_enabled"
        const val PREF_KEY_BLUSH_HALO_STYLE = "surface_key_blush_halo_style"
        const val PREF_KEY_BLUSH_HALO_DENSITY = "surface_key_blush_halo_density"
        const val PREF_KEY_BLUSH_HALO_SPEED = "surface_key_blush_halo_speed"
        const val PREF_KEY_BLUSH_HALO_RANGE = "surface_key_blush_halo_range"

        const val STYLE_BLUSH_HALO_SPARKLE = 1 // 视频1:1完整同款：按键上面变色 + 下面同色光晕 + 键面微光小烟花
        const val STYLE_BLUSH_HALO_CLEAN = 2   // 纯净柔雾款：按键上面变色 + 下面同色光晕（无小烟花粒子）
        const val STYLE_HALO_ONLY = 3          // 仅底部同色光晕（按键表面不变色）

        const val DEFAULT_KEY_BLUSH_HALO_DENSITY = 76
        const val DEFAULT_KEY_BLUSH_HALO_SPEED = 55
        const val DEFAULT_KEY_BLUSH_HALO_RANGE = 66
        private const val PREF_BREAD_BEAR_POPUP_ENABLED = "bread_bear_popup_enabled"

        private var orbSeedCounter: Long = 1L

        @Volatile private var cachedSparkleEnabled: Boolean? = null
        @Volatile private var cachedSparkleIntensity: Int? = null
        @Volatile private var cachedUnderBurstEnabled: Boolean? = null
        @Volatile private var cachedUnderBurstDensity: Int? = null
        @Volatile private var cachedUnderBurstSpeed: Int? = null
        @Volatile private var cachedUnderBurstRange: Int? = null
        @Volatile private var cachedRippleEnabled: Boolean? = null
        @Volatile private var cachedRippleDensity: Int? = null
        @Volatile private var cachedRippleSpeed: Int? = null
        @Volatile private var cachedRippleRange: Int? = null
        @Volatile private var cachedStardustEnabled: Boolean? = null
        @Volatile private var cachedStardustDensity: Int? = null
        @Volatile private var cachedStardustSpeed: Int? = null
        @Volatile private var cachedStardustRange: Int? = null
        @Volatile private var cachedContourVortexEnabled: Boolean? = null
        @Volatile private var cachedContourVortexStyle: Int? = null
        @Volatile private var cachedContourVortexDensity: Int? = null
        @Volatile private var cachedContourVortexSpeed: Int? = null
        @Volatile private var cachedContourVortexRange: Int? = null
        @Volatile private var cachedKeyBlushHaloEnabled: Boolean? = null
        @Volatile private var cachedKeyBlushHaloStyle: Int? = null
        @Volatile private var cachedKeyBlushHaloDensity: Int? = null
        @Volatile private var cachedKeyBlushHaloSpeed: Int? = null
        @Volatile private var cachedKeyBlushHaloRange: Int? = null
        @Volatile private var cachedBreadBearPopupEnabled: Boolean? = null
        @Volatile private var cachedQuickSliderLocked: Boolean? = null

        fun syncCachedPrefs(context: Context) {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            cachedSparkleEnabled = prefs.getBoolean(PREF_SPARKLE_ENABLED, false)
            cachedSparkleIntensity = prefs.getInt(PREF_SPARKLE_INTENSITY, DEFAULT_SPARKLE_INTENSITY).coerceIn(10, 100)
            cachedUnderBurstEnabled = prefs.getBoolean(PREF_UNDER_BURST_ENABLED, true)
            cachedUnderBurstDensity = prefs.getInt(PREF_UNDER_BURST_DENSITY, DEFAULT_UNDER_BURST_DENSITY).coerceIn(10, 100)
            cachedUnderBurstSpeed = prefs.getInt(PREF_UNDER_BURST_SPEED, DEFAULT_UNDER_BURST_SPEED).coerceIn(10, 100)
            cachedUnderBurstRange = prefs.getInt(PREF_UNDER_BURST_RANGE, DEFAULT_UNDER_BURST_RANGE).coerceIn(10, 100)
            cachedRippleEnabled = prefs.getBoolean(PREF_RIPPLE_ENABLED, false)
            cachedRippleDensity = prefs.getInt(PREF_RIPPLE_DENSITY, DEFAULT_RIPPLE_DENSITY).coerceIn(10, 100)
            cachedRippleSpeed = prefs.getInt(PREF_RIPPLE_SPEED, DEFAULT_RIPPLE_SPEED).coerceIn(10, 100)
            cachedRippleRange = prefs.getInt(PREF_RIPPLE_RANGE, DEFAULT_RIPPLE_RANGE).coerceIn(10, 100)
            cachedStardustEnabled = prefs.getBoolean(PREF_STARDUST_ENABLED, false)
            cachedStardustDensity = prefs.getInt(PREF_STARDUST_DENSITY, DEFAULT_STARDUST_DENSITY).coerceIn(10, 100)
            cachedStardustSpeed = prefs.getInt(PREF_STARDUST_SPEED, DEFAULT_STARDUST_SPEED).coerceIn(10, 100)
            cachedStardustRange = prefs.getInt(PREF_STARDUST_RANGE, DEFAULT_STARDUST_RANGE).coerceIn(10, 100)
            cachedContourVortexEnabled = prefs.getBoolean(PREF_CONTOUR_VORTEX_ENABLED, false)
            cachedContourVortexStyle = prefs.getInt(PREF_CONTOUR_VORTEX_STYLE, STYLE_VORTEX_RING).coerceIn(1, 3)
            cachedContourVortexDensity = prefs.getInt(PREF_CONTOUR_VORTEX_DENSITY, DEFAULT_CONTOUR_VORTEX_DENSITY).coerceIn(10, 100)
            cachedContourVortexSpeed = prefs.getInt(PREF_CONTOUR_VORTEX_SPEED, DEFAULT_CONTOUR_VORTEX_SPEED).coerceIn(10, 100)
            cachedContourVortexRange = prefs.getInt(PREF_CONTOUR_VORTEX_RANGE, DEFAULT_CONTOUR_VORTEX_RANGE).coerceIn(10, 100)
            cachedKeyBlushHaloEnabled = prefs.getBoolean(PREF_KEY_BLUSH_HALO_ENABLED, true)
            cachedKeyBlushHaloStyle = prefs.getInt(PREF_KEY_BLUSH_HALO_STYLE, STYLE_BLUSH_HALO_SPARKLE).coerceIn(1, 3)
            cachedKeyBlushHaloDensity = prefs.getInt(PREF_KEY_BLUSH_HALO_DENSITY, DEFAULT_KEY_BLUSH_HALO_DENSITY).coerceIn(10, 100)
            cachedKeyBlushHaloSpeed = prefs.getInt(PREF_KEY_BLUSH_HALO_SPEED, DEFAULT_KEY_BLUSH_HALO_SPEED).coerceIn(10, 100)
            cachedKeyBlushHaloRange = prefs.getInt(PREF_KEY_BLUSH_HALO_RANGE, DEFAULT_KEY_BLUSH_HALO_RANGE).coerceIn(10, 100)
            cachedBreadBearPopupEnabled = prefs.getBoolean(PREF_BREAD_BEAR_POPUP_ENABLED, false)
            cachedQuickSliderLocked = prefs.getBoolean(PREF_QUICK_SLIDER_LOCK, true)
        }

        // --- 键帽表面星点（键盘上）开关与强度 ---
        fun isSparkleEnabled(context: Context): Boolean {
            cachedSparkleEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_SPARKLE_ENABLED, false).also { cachedSparkleEnabled = it }
        }

        fun setSparkleEnabled(context: Context, enabled: Boolean) {
            cachedSparkleEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_SPARKLE_ENABLED, enabled)
                .apply()
        }

        fun getSparkleIntensity(context: Context): Int {
            cachedSparkleIntensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_SPARKLE_INTENSITY, DEFAULT_SPARKLE_INTENSITY).coerceIn(10, 100).also { cachedSparkleIntensity = it }
        }

        fun setSparkleIntensity(context: Context, intensity: Int) {
            val clamped = intensity.coerceIn(10, 100)
            cachedSparkleIntensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_SPARKLE_INTENSITY, clamped)
                .apply()
        }

        fun getIntensityTierName(intensity: Int): String {
            return when {
                intensity < 42 -> "轻柔星尘"
                intensity < 75 -> "柔美星光"
                else -> "璀璨星河"
            }
        }

        // --- ☄️ 键盘下唯美弧形流光与星点开关及三项参数 ---
        fun isUnderBurstEnabled(context: Context): Boolean {
            cachedUnderBurstEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_UNDER_BURST_ENABLED, true).also { cachedUnderBurstEnabled = it }
        }

        fun setUnderBurstEnabled(context: Context, enabled: Boolean) {
            cachedUnderBurstEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_UNDER_BURST_ENABLED, enabled)
                .apply()
        }

        fun getUnderBurstDensity(context: Context): Int {
            cachedUnderBurstDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_DENSITY, DEFAULT_UNDER_BURST_DENSITY).coerceIn(10, 100).also { cachedUnderBurstDensity = it }
        }

        fun setUnderBurstDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedUnderBurstDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_DENSITY, clamped)
                .apply()
        }

        fun getUnderBurstSpeed(context: Context): Int {
            cachedUnderBurstSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_SPEED, DEFAULT_UNDER_BURST_SPEED).coerceIn(10, 100).also { cachedUnderBurstSpeed = it }
        }

        fun setUnderBurstSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedUnderBurstSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_SPEED, clamped)
                .apply()
        }

        fun getUnderBurstRange(context: Context): Int {
            cachedUnderBurstRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_UNDER_BURST_RANGE, DEFAULT_UNDER_BURST_RANGE).coerceIn(10, 100).also { cachedUnderBurstRange = it }
        }

        fun setUnderBurstRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedUnderBurstRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_UNDER_BURST_RANGE, clamped)
                .apply()
        }

        fun isQuickSliderLocked(context: Context): Boolean {
            cachedQuickSliderLocked?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_QUICK_SLIDER_LOCK, true).also { cachedQuickSliderLocked = it }
        }

        fun setQuickSliderLocked(context: Context, locked: Boolean) {
            cachedQuickSliderLocked = locked
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_QUICK_SLIDER_LOCK, locked)
                .apply()
        }

        // --- 💧 水纹落雨（Liquid Ripple）独立开关与三项参数 ---
        fun isLiquidRippleEnabled(context: Context): Boolean {
            cachedRippleEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_RIPPLE_ENABLED, false).also { cachedRippleEnabled = it }
        }

        fun setLiquidRippleEnabled(context: Context, enabled: Boolean) {
            cachedRippleEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_RIPPLE_ENABLED, enabled)
                .apply()
        }

        fun getLiquidRippleDensity(context: Context): Int {
            cachedRippleDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_RIPPLE_DENSITY, DEFAULT_RIPPLE_DENSITY).coerceIn(10, 100).also { cachedRippleDensity = it }
        }

        fun setLiquidRippleDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedRippleDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_RIPPLE_DENSITY, clamped)
                .apply()
        }

        fun getLiquidRippleSpeed(context: Context): Int {
            cachedRippleSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_RIPPLE_SPEED, DEFAULT_RIPPLE_SPEED).coerceIn(10, 100).also { cachedRippleSpeed = it }
        }

        fun setLiquidRippleSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedRippleSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_RIPPLE_SPEED, clamped)
                .apply()
        }

        fun getLiquidRippleRange(context: Context): Int {
            cachedRippleRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_RIPPLE_RANGE, DEFAULT_RIPPLE_RANGE).coerceIn(10, 100).also { cachedRippleRange = it }
        }

        fun setLiquidRippleRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedRippleRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_RIPPLE_RANGE, clamped)
                .apply()
        }

        // --- ✦ 暗夜微尘 / 幽夜流星（Stardust Fall）独立开关与三项参数 ---
        fun isStardustFallEnabled(context: Context): Boolean {
            cachedStardustEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_STARDUST_ENABLED, false).also { cachedStardustEnabled = it }
        }

        fun setStardustFallEnabled(context: Context, enabled: Boolean) {
            cachedStardustEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_STARDUST_ENABLED, enabled)
                .apply()
        }

        fun getStardustFallDensity(context: Context): Int {
            cachedStardustDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_STARDUST_DENSITY, DEFAULT_STARDUST_DENSITY).coerceIn(10, 100).also { cachedStardustDensity = it }
        }

        fun setStardustFallDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedStardustDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_STARDUST_DENSITY, clamped)
                .apply()
        }

        fun getStardustFallSpeed(context: Context): Int {
            cachedStardustSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_STARDUST_SPEED, DEFAULT_STARDUST_SPEED).coerceIn(10, 100).also { cachedStardustSpeed = it }
        }

        fun setStardustFallSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedStardustSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_STARDUST_SPEED, clamped)
                .apply()
        }

        fun getStardustFallRange(context: Context): Int {
            cachedStardustRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_STARDUST_RANGE, DEFAULT_STARDUST_RANGE).coerceIn(10, 100).also { cachedStardustRange = it }
        }

        fun setStardustFallRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedStardustRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_STARDUST_RANGE, clamped)
                .apply()
        }

        // --- 🌀 键廓流光涡旋（Key-Contour Vortex & Star-Bubble）独立开关、样式与三项参数 ---
        fun isContourVortexEnabled(context: Context): Boolean {
            cachedContourVortexEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_CONTOUR_VORTEX_ENABLED, false).also { cachedContourVortexEnabled = it }
        }

        fun setContourVortexEnabled(context: Context, enabled: Boolean) {
            cachedContourVortexEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_CONTOUR_VORTEX_ENABLED, enabled)
                .apply()
        }

        fun getContourVortexStyle(context: Context): Int {
            cachedContourVortexStyle?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_CONTOUR_VORTEX_STYLE, STYLE_VORTEX_RING).coerceIn(1, 3).also { cachedContourVortexStyle = it }
        }

        fun setContourVortexStyle(context: Context, style: Int) {
            val clamped = style.coerceIn(1, 3)
            cachedContourVortexStyle = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_CONTOUR_VORTEX_STYLE, clamped)
                .apply()
        }

        fun getContourVortexStyleName(style: Int): String {
            return when (style) {
                STYLE_PAW_STAR_BUBBLE -> "🐾第1款·键廓星泡"
                STYLE_BOTH_COMBINED -> "✨第1+2款·双效融合"
                else -> "🌀第2款·键廓旋流"
            }
        }

        fun getContourVortexDensity(context: Context): Int {
            cachedContourVortexDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_CONTOUR_VORTEX_DENSITY, DEFAULT_CONTOUR_VORTEX_DENSITY).coerceIn(10, 100).also { cachedContourVortexDensity = it }
        }

        fun setContourVortexDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedContourVortexDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_CONTOUR_VORTEX_DENSITY, clamped)
                .apply()
        }

        fun getContourVortexSpeed(context: Context): Int {
            cachedContourVortexSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_CONTOUR_VORTEX_SPEED, DEFAULT_CONTOUR_VORTEX_SPEED).coerceIn(10, 100).also { cachedContourVortexSpeed = it }
        }

        fun setContourVortexSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedContourVortexSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_CONTOUR_VORTEX_SPEED, clamped)
                .apply()
        }

        fun getContourVortexRange(context: Context): Int {
            cachedContourVortexRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_CONTOUR_VORTEX_RANGE, DEFAULT_CONTOUR_VORTEX_RANGE).coerceIn(10, 100).also { cachedContourVortexRange = it }
        }

        fun setContourVortexRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedContourVortexRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_CONTOUR_VORTEX_RANGE, clamped)
                .apply()
        }

        // --- 🌸 键面变色 + 键底同色光晕（视频2同款 · 此刻心动）独立开关、款式、三项参数与四皮肤自适应取色 ---
        fun isKeyBlushHaloEnabled(context: Context): Boolean {
            cachedKeyBlushHaloEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_KEY_BLUSH_HALO_ENABLED, true).also { cachedKeyBlushHaloEnabled = it }
        }

        fun setKeyBlushHaloEnabled(context: Context, enabled: Boolean) {
            cachedKeyBlushHaloEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_KEY_BLUSH_HALO_ENABLED, enabled)
                .apply()
        }

        fun getKeyBlushHaloStyle(context: Context): Int {
            cachedKeyBlushHaloStyle?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_KEY_BLUSH_HALO_STYLE, STYLE_BLUSH_HALO_SPARKLE).coerceIn(1, 3).also { cachedKeyBlushHaloStyle = it }
        }

        fun setKeyBlushHaloStyle(context: Context, style: Int) {
            val clamped = style.coerceIn(1, 3)
            cachedKeyBlushHaloStyle = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_KEY_BLUSH_HALO_STYLE, clamped)
                .apply()
        }

        fun getKeyBlushHaloStyleName(style: Int): String {
            return when (style) {
                STYLE_BLUSH_HALO_CLEAN -> "🎨纯变色+光晕"
                STYLE_HALO_ONLY -> "💡仅底部光晕"
                else -> "🌸变色+光晕+小烟花"
            }
        }

        fun getKeyBlushHaloDensity(context: Context): Int {
            cachedKeyBlushHaloDensity?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_KEY_BLUSH_HALO_DENSITY, DEFAULT_KEY_BLUSH_HALO_DENSITY).coerceIn(10, 100).also { cachedKeyBlushHaloDensity = it }
        }

        fun setKeyBlushHaloDensity(context: Context, density: Int) {
            val clamped = density.coerceIn(10, 100)
            cachedKeyBlushHaloDensity = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_KEY_BLUSH_HALO_DENSITY, clamped)
                .apply()
        }

        fun getKeyBlushHaloSpeed(context: Context): Int {
            cachedKeyBlushHaloSpeed?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_KEY_BLUSH_HALO_SPEED, DEFAULT_KEY_BLUSH_HALO_SPEED).coerceIn(10, 100).also { cachedKeyBlushHaloSpeed = it }
        }

        fun setKeyBlushHaloSpeed(context: Context, speed: Int) {
            val clamped = speed.coerceIn(10, 100)
            cachedKeyBlushHaloSpeed = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_KEY_BLUSH_HALO_SPEED, clamped)
                .apply()
        }

        fun getKeyBlushHaloRange(context: Context): Int {
            cachedKeyBlushHaloRange?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_KEY_BLUSH_HALO_RANGE, DEFAULT_KEY_BLUSH_HALO_RANGE).coerceIn(10, 100).also { cachedKeyBlushHaloRange = it }
        }

        fun setKeyBlushHaloRange(context: Context, range: Int) {
            val clamped = range.coerceIn(10, 100)
            cachedKeyBlushHaloRange = clamped
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_KEY_BLUSH_HALO_RANGE, clamped)
                .apply()
        }

        /**
         * 针对图2的四套常用浅色皮肤（天蓝樱粉、紫雾星辰、焦糖拿铁、夜樱初绽）及全部自定义皮肤，
         * 实时解算「按键上面变色 (blushTop, blushBottom) + 按键下面同色光晕 (haloColor)」三元组：
         * - outColors[0] = blushTopCol（键面顶部主晕染色）
         * - outColors[1] = blushBotCol（键面底部柔润过渡色）
         * - outColors[2] = haloCol（键底与四周同色柔雾大光晕色）
         */
        fun resolveKeyBlushAndHaloColors(
            keyBgColor: Int,
            kbBgColor: Int,
            glowColor: Int,
            outColors: IntArray
        ) {
            val keyHsv = FloatArray(3)
            val kbHsv = FloatArray(3)
            val glowHsv = FloatArray(3)
            Color.colorToHSV(keyBgColor, keyHsv)
            Color.colorToHSV(kbBgColor, kbHsv)
            Color.colorToHSV(glowColor, glowHsv)

            val ks = keyHsv[1]
            val ts = glowHsv[1]
            val bs = kbHsv[1]
            val thDeg = glowHsv[0]

            // 🐻 面包脑袋专属「智能双色炫彩光晕」：开心果抹茶绿 (#8CC265) & 黄油杏子琥珀金 (#F7B543)
            if (thDeg in 72f..155f && ts >= 0.35f) {
                outColors[0] = Color.parseColor("#92C86A")
                outColors[1] = Color.parseColor("#A7D682")
                outColors[2] = Color.parseColor("#8CC265")
                return
            } else if (thDeg in 34f..52f && ts >= 0.65f) {
                outColors[0] = Color.parseColor("#F8BC4E")
                outColors[1] = Color.parseColor("#FAD074")
                outColors[2] = Color.parseColor("#F7B543")
                return
            }

            var hue = when {
                ks >= 0.13f -> keyHsv[0]
                ts >= 0.08f -> glowHsv[0]
                bs >= 0.05f -> kbHsv[0]
                ks >= 0.03f -> keyHsv[0]
                else -> 347f
            }

            // 针对四套主力浅色皮肤精细校准色相：
            if (hue in 18f..46f) {
                // 皮肤3：焦糖拿铁 / 燕麦奶泡 (#F7EBDD / #E7D2BD / #F5CFB0 / #9B6D4B) -> 暖融蜜糖琥珀杏色 (23.5°)
                hue = 23.5f
            } else if (hue in 260f..322f) {
                // 区分皮肤1（天蓝樱粉中的樱花粉跳色键 #F7D0EF）与皮肤2（紫雾星辰 #F0DFEF / #D7BAD6 / #4B3C5B）
                if (thDeg in 190f..255f && hue >= 300f) {
                    hue = 336f // 甜心樱花粉 (#E5699B)
                } else {
                    hue = 282f // 紫雾星辰温润香芋丁香紫 (#AC6FC6)
                }
            } else if (hue >= 322f || hue < 18f) {
                // 皮肤4：夜樱初绽 / 粉白跳酒红 (#FFF0F7 / #EBC7D1 / #8B4D5A) -> 视频1:1同款「此刻心动」蜜桃玫瑰色 (347°)
                hue = 347f
            }

            val topS: Float
            val topV: Float
            val botS: Float
            val botV: Float
            val haloS: Float
            val haloV: Float

            if (hue in 260f..320f) {
                // 皮肤2：紫雾星辰（香芋丁香紫）
                topS = 0.44f; topV = 0.78f
                botS = 0.31f; botV = 0.87f
                haloS = 0.39f; haloV = 0.83f
            } else if (hue in 190f..260f) {
                // 皮肤1：天蓝樱粉（晴空矢车菊蓝 / 雏菊紫蓝）
                topS = 0.54f; topV = 0.91f
                botS = 0.36f; botV = 0.96f
                haloS = 0.47f; haloV = 0.94f
            } else if (hue in 15f..48f) {
                // 皮肤3：焦糖拿铁（暖杏焦糖玛奇朵）
                topS = 0.57f; topV = 0.88f
                botS = 0.40f; botV = 0.94f
                haloS = 0.50f; haloV = 0.91f
            } else {
                // 皮肤4 & 皮肤1樱花粉键：视频1:1同款「此刻心动」玫瑰珊瑚粉 (#E56984 -> #F296AA)
                topS = 0.54f; topV = 0.90f
                botS = 0.38f; botV = 0.95f
                haloS = 0.48f; haloV = 0.93f
            }

            outColors[0] = Color.HSVToColor(floatArrayOf(hue, topS, topV))
            outColors[1] = Color.HSVToColor(floatArrayOf(hue, botS, botV))
            outColors[2] = Color.HSVToColor(floatArrayOf(hue, haloS, haloV))
        }

        fun isBreadBearPopupEnabled(context: Context): Boolean {
            cachedBreadBearPopupEnabled?.let { return it }
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_BREAD_BEAR_POPUP_ENABLED, false).also { cachedBreadBearPopupEnabled = it }
        }

        fun setBreadBearPopupEnabled(context: Context, enabled: Boolean) {
            cachedBreadBearPopupEnabled = enabled
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_BREAD_BEAR_POPUP_ENABLED, enabled)
                .apply()
        }

        fun isAnyOverLayerEffectEnabled(context: Context): Boolean {
            return isKeyBlushHaloEnabled(context) ||
                isBreadBearPopupEnabled(context) ||
                isContourVortexEnabled(context) ||
                isLiquidRippleEnabled(context) ||
                isStardustFallEnabled(context) ||
                isUnderBurstEnabled(context) ||
                isSparkleEnabled(context)
        }
    }

    /**
     * 🌙 键下唯美光效 · 层级 1：不规则弧形流光细丝 (GossamerFlowRibbon)
     * - 彻底摒弃向外直刺的烟花直线！
     * - 采用贴合键帽转角与柔光边缘的弯弯流光游丝（两头如发丝般极细渐隐、中间柔亮微拱），
     *   随点击沿着弧线优雅滑过并自然消融，前端可伴随一颗微小四芒星点缀。
     */
    private class GossamerFlowRibbon(
        val startAngleRad: Float,
        val sweepAngleRad: Float,
        val angularDriftRad: Float,
        val baseOffsetPx: Float,
        val swellOutPx: Float,
        val maxHalfWidthPx: Float,
        val rippleWavePx: Float,
        val ripplePhase: Float,
        val brightness: Float,
        val colorVariant: Int,
        val hasTipStarlet: Boolean
    )

    /**
     * ✦ 键下唯美光效 · 层级 2：不对称簇状星点 (EtherealStarletParticle)
     * - 仅在按键周围随机 2~3 个不对称局部方位成簇绽放，保留 60% 以上呼吸留白；
     * - 形态包含：实心纤细小四芒星 (✦)、空心细线小四芒星 (✧)、柔光空心小光圈 (°)、明暗碎星尘 (·)；
     * - 轨迹采用「微弧度轻盈漾开 + 尾韵悬停闪烁微飘」，在主光晕变淡后依然温柔闪烁一下再化开。
     */
    private class EtherealStarletParticle(
        val shapeType: Int,
        val baseAngleRad: Float,
        val edgeDistPx: Float,
        val startOffsetPx: Float,
        val bloomReachPx: Float,
        val arcCurveDriftRad: Float,
        val afterglowFloatDx: Float,
        val afterglowFloatDy: Float,
        val sizePx: Float,
        val rotationDeg: Float,
        val spinDeg: Float,
        val brightness: Float,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleFreq: Float,
        val lingerBoost: Float
    )

    // 键帽表面星芒 · 第 1 层级：微小星尘
    private class MicroStardustParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 键帽表面星芒 · 第 2 层级：普通星点
    private class StarPointParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val haloRadiusPx: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 键帽表面星芒 · 第 3 层级：少量柔焦星云光斑
    private class SoftNebulaSpotParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val radiusPx: Float,
        val baseAlpha: Float
    )

    // 键帽表面星芒 · 第 4 层级：细长锐利的四角/六角星芒
    private class CelestialStarFlareParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val primaryRayPx: Float,
        val orthogonalRayPx: Float,
        val diagRayPx: Float,
        val baseHalfWidthPx: Float,
        val rotationDeg: Float,
        val isSixPointed: Boolean,
        val isHeroFlare: Boolean,
        val baseAlpha: Float,
        val twinklePhase: Float
    )

    /**
     * 💧 键盘上表面浅色/全皮肤特效 1：「水纹落雨 · 浅层水波微漾」(LiquidRippleWave)
     * - 敲击瞬间以触点/键心为圆心，向外缓缓荡开 1~3 圈极细、极柔的半透明纯白水波峰 + 同色系暮色折光水影槽；
     * - 依靠「亮白波峰 + 微暗同色折光环」的双重光学边缘对比，在最浅的奶白/芋泥紫/樱花粉键帽上依然清澈灵动！
     */
    private class LiquidRippleWave(
        val delayRatio: Float,
        val startRadiusPx: Float,
        val maxRadiusPx: Float,
        val strokeWidthPx: Float,
        val contrastAlpha: Float,
        val hasMicroDrops: Boolean,
        val dropBaseAngle: Float
    )

    /**
     * ✦ 键盘上表面浅色/全皮肤特效 2：「暗夜微尘 / 幽夜流星 · 星屑沉落」(FallingStardustParticle)
     * - 敲击瞬间在按键边缘与四角轻盈迸出 2~10 颗极细微的四芒星尘 (✦/✧，直径约 2~3.2dp)，
     *   带着微弱初速向上/向外微漾后，顺着重力微微下沉并闪烁消融（持续约 0.5~0.65 秒）。
     */
    private class FallingStardustParticle(
        val isHollowStar: Boolean,
        val spawnXOffsetPx: Float,
        val spawnYOffsetPx: Float,
        val vxPx: Float,
        val vyInitPx: Float,
        val gravityPx: Float,
        val starRadiusPx: Float,
        val rotationDeg: Float,
        val spinDeg: Float,
        val useDarkInkStyle: Boolean,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleFreq: Float,
        val lifeRatio: Float
    )

    /**
     * 🌀 视频1第1排第2款（改成贴合键盘圆角矩形形状）：「键廓旋流弯月丝带」(KeyContourSwirlRibbon)
     * - 沿着键帽的圆角矩形轮廓线（4条直边 + 4个圆角）顺时针/逆时针回旋滑行并向外轻柔舒展；
     * - 头部饱满、尾部纤细渐隐，内嵌纯白高光脊线与键帽同色系莫兰迪流光体。
     */
    private class KeyContourSwirlRibbon(
        val isOuterTrack: Boolean,
        val startPerimeterU: Float,
        val arcLengthU: Float,
        val travelSpeedU: Float,
        val startScale: Float,
        val endScale: Float,
        val maxThicknessPx: Float,
        val radialWavePx: Float,
        val useAccentTint: Boolean,
        val delayRatio: Float,
        val lifeRatio: Float
    )

    /**
     * 🌀 视频1第1排第2款初段：「梭形流光叶瓣」(KeyContourSpindlePetal)
     * - 敲击瞬间从键心向键帽四周圆角轮廓放射迸出的梭形光针/花瓣（中间饱满、两头尖细）。
     */
    private class KeyContourSpindlePetal(
        val angleRad: Float,
        val startScale: Float,
        val endScale: Float,
        val lengthPx: Float,
        val halfWidthPx: Float,
        val useAccentTint: Boolean,
        val lifeRatio: Float
    )

    /**
     * 🌀/🐾 视频1第1排第2款 & 第1款伴生：「键廓星芒与气泡粒子」(KeyContourSparkAndBubble)
     * - kind: 0 = 十字四芒星闪(✦, 第2款主力), 1 = 伴生微光露珠(•), 2 = 圆润五角萌星(★, 第1款主力), 3 = 幻彩微气泡(○)
     */
    private class KeyContourSparkAndBubble(
        val kind: Int,
        val perimeterU: Float,
        val driftU: Float,
        val startScale: Float,
        val endScale: Float,
        val sizePx: Float,
        val rotationDeg: Float,
        val spinDeg: Float,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleFreq: Float,
        val delayRatio: Float,
        val lifeRatio: Float
    )

    private class SpotlightOrb(
        val sourceView: View?,
        val keyRect: RectF,
        val keyCornerRadiusPx: Float,
        val surfaceKeyBgColor: Int,
        val glowColor: Int,
        val palette: StarlightColorAdapter.StarlightPalette,
        val spawnTime: Long,
        var releaseTime: Long = 0L,
        val intensityNorm: Float,
        val burstSpeedNorm: Float,
        val rippleSpeedNorm: Float,
        val stardustSpeedNorm: Float,
        val keyBlushHaloEnabled: Boolean,
        val keyBlushHaloStyle: Int,
        val keyBlushHaloDensityNorm: Float,
        val keyBlushHaloSpeedNorm: Float,
        val keyBlushHaloRangeNorm: Float,
        val blushTopColor: Int,
        val blushBotColor: Int,
        val blushHaloColor: Int,
        val breadBearPopupEnabled: Boolean = false,
        val bearStickerIndex: Int = 0,
        val contourVortexStyle: Int,
        val contourVortexSpeedNorm: Float,
        val contourVortexRangeNorm: Float,
        val contourSwirlRibbons: List<KeyContourSwirlRibbon>,
        val contourSpindlePetals: List<KeyContourSpindlePetal>,
        val contourSparksAndBubbles: List<KeyContourSparkAndBubble>,
        val liquidRipples: List<LiquidRippleWave>,
        val fallingStardusts: List<FallingStardustParticle>,
        val flowRibbons: List<GossamerFlowRibbon>,
        val etherealStarlets: List<EtherealStarletParticle>,
        val stardustList: List<MicroStardustParticle>,
        val starPoints: List<StarPointParticle>,
        val nebulaSpots: List<SoftNebulaSpotParticle>,
        val starFlares: List<CelestialStarFlareParticle>
    ) {
        private val effectiveUnderCol = if (keyBlushHaloEnabled) blushHaloColor else glowColor
        private val rGlow = Color.red(effectiveUnderCol)
        private val gGlow = Color.green(effectiveUnderCol)
        private val bGlow = Color.blue(effectiveUnderCol)

        val unitOuterGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            if (keyBlushHaloEnabled) {
                intArrayOf(
                    Color.argb(225, rGlow, gGlow, bGlow),
                    Color.argb(180, rGlow, gGlow, bGlow),
                    Color.argb(122, rGlow, gGlow, bGlow),
                    Color.argb(62, rGlow, gGlow, bGlow),
                    Color.argb(20, rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                )
            } else {
                intArrayOf(
                    Color.argb(120, rGlow, gGlow, bGlow),
                    Color.argb(96, rGlow, gGlow, bGlow),
                    Color.argb(60, rGlow, gGlow, bGlow),
                    Color.argb(28, rGlow, gGlow, bGlow),
                    Color.argb(9, rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                )
            },
            floatArrayOf(0f, 0.34f, 0.54f, 0.72f, 0.86f, 1.0f),
            Shader.TileMode.CLAMP
        )

        val unitInnerGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            if (keyBlushHaloEnabled) {
                intArrayOf(
                    Color.argb(242, rGlow, gGlow, bGlow),
                    Color.argb(198, rGlow, gGlow, bGlow),
                    Color.argb(132, rGlow, gGlow, bGlow),
                    Color.argb(48, rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                )
            } else {
                intArrayOf(
                    Color.argb(145, rGlow, gGlow, bGlow),
                    Color.argb(115, rGlow, gGlow, bGlow),
                    Color.argb(68, rGlow, gGlow, bGlow),
                    Color.argb(22, rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                )
            },
            floatArrayOf(0f, 0.42f, 0.65f, 0.85f, 1.0f),
            Shader.TileMode.CLAMP
        )

        val unitVeilGrad: RadialGradient = RadialGradient(
            0f, 0f, 100f,
            intArrayOf(
                Color.argb(56, rGlow, gGlow, bGlow),
                Color.argb(38, rGlow, gGlow, bGlow),
                Color.argb(14, rGlow, gGlow, bGlow),
                Color.argb(0, rGlow, gGlow, bGlow)
            ),
            floatArrayOf(0f, 0.48f, 0.78f, 1.0f),
            Shader.TileMode.CLAMP
        )
    }

    private val orbs = ArrayList<SpotlightOrb>(12)

    // ★ 通用笔刷特效引擎：把原来"平淡"的 4 款效果升级成笔刷粒子叠加
    private val brushField = BrushBurstField()

    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val starPath = Path()
    private val ribbonPath = Path()
    private val contourPtOut = FloatArray(6) // [px, py, tx, ty, nx, ny]
    private val clipBoundsPath = Path()
    private val keyHoleClipPath = Path()
    private val shaderMatrix = Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    private fun computeKeyEdgeDist(hw: Float, hh: Float, angleRad: Float): Float {
        val ux = cos(angleRad)
        val uy = sin(angleRad)
        val rawEdge = min(hw / max(abs(ux), 0.001f), hh / max(abs(uy), 0.001f))
        val cornerFactor = 1f - 0.16f * min(abs(ux), abs(uy))
        return rawEdge * cornerFactor
    }

    private fun buildRandomOrb(
        sourceView: View?,
        rect: RectF,
        glowColor: Int,
        surfaceBgColor: Int? = null,
        keyCornerRadiusPx: Float = dpF(12f)
    ): SpotlightOrb {
        val shouldSpawnSurfaceParticles = (renderLayerMode != LAYER_UNDER_GLOW) && isSparkleEnabled(context)
        // 仅在顶层精确镂空层 (LAYER_OVER_SPARKLE) 或完整预览层 (LAYER_FULL_COMBINED) 生成流光细丝与星团，
        // 避免底层与顶层在 3~4dp 按键缝隙中双重叠加绘制导致浅色底流光变浓发暗！
        val shouldSpawnUnderMeteor = (renderLayerMode != LAYER_UNDER_GLOW) && isUnderBurstEnabled(context)
        val shouldSpawnLiquidRipple = (renderLayerMode != LAYER_UNDER_GLOW) && isLiquidRippleEnabled(context)
        val shouldSpawnStardustFall = (renderLayerMode != LAYER_UNDER_GLOW) && isStardustFallEnabled(context)
        val shouldSpawnContourVortex = (renderLayerMode != LAYER_UNDER_GLOW) && isContourVortexEnabled(context)

        val rawIntensity = getSparkleIntensity(context)
        val normI = ((rawIntensity - 10f) / 90f).coerceIn(0f, 1f)

        val densityNorm = ((getUnderBurstDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val speedNorm = ((getUnderBurstSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val rangeNorm = ((getUnderBurstRange(context) - 10f) / 90f).coerceIn(0f, 1f)

        val rippleDensityNorm = ((getLiquidRippleDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val rippleSpeedNorm = ((getLiquidRippleSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val rippleRangeNorm = ((getLiquidRippleRange(context) - 10f) / 90f).coerceIn(0f, 1f)

        val sdDensityNorm = ((getStardustFallDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val sdSpeedNorm = ((getStardustFallSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val sdRangeNorm = ((getStardustFallRange(context) - 10f) / 90f).coerceIn(0f, 1f)

        val cvStyle = getContourVortexStyle(context)
        val cvDensityNorm = ((getContourVortexDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val cvSpeedNorm = ((getContourVortexSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val cvRangeNorm = ((getContourVortexRange(context) - 10f) / 90f).coerceIn(0f, 1f)
        val resolvedSurfaceKeyBg: Int = surfaceBgColor ?: keyboardSurfaceBgColor ?: glowColor

        val bhEnabled = isKeyBlushHaloEnabled(context)
        val bhStyle = getKeyBlushHaloStyle(context)
        val bhDensityNorm = ((getKeyBlushHaloDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val bhSpeedNorm = ((getKeyBlushHaloSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val bhRangeNorm = ((getKeyBlushHaloRange(context) - 10f) / 90f).coerceIn(0f, 1f)
        val bhColors = IntArray(3)
        resolveKeyBlushAndHaloColors(
            keyBgColor = resolvedSurfaceKeyBg,
            kbBgColor = keyboardSurfaceBgColor ?: resolvedSurfaceKeyBg,
            glowColor = glowColor,
            outColors = bhColors
        )

        val palette = StarlightColorAdapter.resolvePalette(glowColor, surfaceBgColor, keyboardSurfaceBgColor)
        val now = SystemClock.uptimeMillis()

        val seed = System.nanoTime() xor
            ((sourceView?.hashCode()?.toLong() ?: 0x5A17L) shl 17) xor
            (orbSeedCounter++ * -7046029254386353131L)
        val rng = java.util.Random(seed)
        val twoPi = (Math.PI * 2.0).toFloat()

        // =========================================================================
        // A. 生成键盘下「唯美不规则弧形流光细丝 + 不对称簇状星群」（复刻参考视频2）
        // =========================================================================
        val flowRibbons: List<GossamerFlowRibbon>
        val etherealStarlets: List<EtherealStarletParticle>
        if (shouldSpawnUnderMeteor) {
            val hw = (rect.width() * 0.5f).coerceAtLeast(dpF(14f))
            val hh = (rect.height() * 0.5f).coerceAtLeast(dpF(14f))
            // 散开距离：10% 约 6dp（紧贴键缝），默认 48% 约 13dp（轻巧浮出键沿，绝不糊成一片），100% 约 23dp
            val maxBloomExtraPx = dpF(6.0f + rangeNorm * 17.5f)

            // 1. 选定 2~3 个不对称簇状主方位（留出大面积空白，绝不 360° 均匀撒满！）
            val clusterCount = when {
                densityNorm < 0.28f -> 2
                densityNorm < 0.78f -> if (rng.nextFloat() < 0.65f) 2 else 3
                else -> 3
            }
            val baseMainAng = rng.nextFloat() * twoPi
            val clusterAngles = FloatArray(clusterCount)
            clusterAngles[0] = baseMainAng
            if (clusterCount >= 2) {
                // 第二簇位于斜对角偏转 125°~195° 处，形成自然的不对称美感
                clusterAngles[1] = baseMainAng + (2.18f + rng.nextFloat() * 1.22f)
            }
            if (clusterCount >= 3) {
                clusterAngles[2] = baseMainAng + (4.25f + rng.nextFloat() * 0.85f)
            }

            // 2. 生成 1~3 缕「不规则弧形流光细丝」(GossamerFlowRibbons)
            //    贴着簇状方位所在的键帽边角柔和掠过，两头尖细渐隐、中间柔亮微拱
            val ribbonCount = when {
                densityNorm < 0.32f -> 1
                densityNorm < 0.76f -> 2
                else -> 3
            }
            val rList = ArrayList<GossamerFlowRibbon>(ribbonCount)
            for (rIdx in 0 until ribbonCount) {
                val anchorAng = clusterAngles[rIdx % clusterCount] + (rng.nextFloat() - 0.5f) * 0.35f
                val dirSign = if (rIdx % 2 == 0) 1f else -1f
                // 主流光丝跨度约 52°~82°，伴生流光丝跨度约 36°~56°
                val sweepMag = if (rIdx == 0) {
                    0.92f + rng.nextFloat() * 0.48f
                } else {
                    0.64f + rng.nextFloat() * 0.38f
                }
                val sweepRad = sweepMag * dirSign
                val startRad = anchorAng - sweepRad * 0.45f
                val driftRad = dirSign * (0.20f + rng.nextFloat() * 0.16f)
                val baseOff = dpF(0.6f + rng.nextFloat() * 1.8f)
                val swellOut = maxBloomExtraPx * (if (rIdx == 0) (0.48f + rng.nextFloat() * 0.26f) else (0.32f + rng.nextFloat() * 0.22f))
                val maxHalfW = dpF(if (rIdx == 0) (0.68f + rng.nextFloat() * 0.26f) else (0.48f + rng.nextFloat() * 0.20f))
                val wavePx = dpF(0.8f + rng.nextFloat() * 1.6f) * (if (rng.nextBoolean()) 1f else -1f)
                val colorVar = if (rIdx == 0) 0 else if (rIdx == 1) 1 else 2

                rList.add(
                    GossamerFlowRibbon(
                        startAngleRad = startRad,
                        sweepAngleRad = sweepRad,
                        angularDriftRad = driftRad,
                        baseOffsetPx = baseOff,
                        swellOutPx = swellOut,
                        maxHalfWidthPx = maxHalfW,
                        rippleWavePx = wavePx,
                        ripplePhase = rng.nextFloat() * twoPi,
                        brightness = if (rIdx == 0) 0.92f else 0.72f,
                        colorVariant = colorVar,
                        hasTipStarlet = (rIdx == 0)
                    )
                )
            }
            flowRibbons = rList

            // 3. 在每个不对称簇周围生成错落有致的星点群 (EtherealStarlets)
            //    包含：实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光微圆圈 ° + 明暗碎星尘 ·
            val totalParticlesTarget = (7 + (densityNorm * 16f).toInt() + rng.nextInt(3)).coerceIn(6, 25)
            val sList = ArrayList<EtherealStarletParticle>(totalParticlesTarget)

            for (cIdx in 0 until clusterCount) {
                val cCenterAng = clusterAngles[cIdx]
                val countInCluster = if (cIdx == 0) {
                    ((totalParticlesTarget * 0.46f).toInt()).coerceAtLeast(3)
                } else if (clusterCount == 2) {
                    (totalParticlesTarget - sList.size).coerceAtLeast(3)
                } else if (cIdx == 1) {
                    ((totalParticlesTarget * 0.32f).toInt()).coerceAtLeast(2)
                } else {
                    (totalParticlesTarget - sList.size).coerceAtLeast(2)
                }

                for (pIdx in 0 until countInCluster) {
                    // 簇内角度自然散落（中心紧凑、外围微散，只占约 ±26° 扇面，保留其余大片留白）
                    val angleSpread = (rng.nextFloat() + rng.nextFloat() - 1f) * 0.48f
                    val pAng = cCenterAng + angleSpread
                    val edgeDist = computeKeyEdgeDist(hw, hh, pAng)

                    // 形状分配：每簇必有 1 颗实心小四芒星 ✦、1 颗空心小星 ✧ 或柔光小光圈 °，其余为明暗碎星尘 ·
                    val shapeType = when {
                        pIdx == 0 -> SHAPE_SOLID_STAR4
                        pIdx == 1 -> if (cIdx == 0 || rng.nextFloat() < 0.62f) SHAPE_HOLLOW_STAR4 else SHAPE_SOFT_RING_PEARL
                        pIdx == 2 && countInCluster >= 5 -> if (rng.nextFloat() < 0.48f) SHAPE_SOFT_RING_PEARL else SHAPE_SOLID_STAR4
                        pIdx == 3 && countInCluster >= 7 && rng.nextFloat() < 0.45f -> SHAPE_HOLLOW_STAR4
                        else -> SHAPE_TWINKLE_DUST
                    }

                    val sizePx = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> dpF(if (pIdx == 0 && cIdx == 0) (3.4f + rng.nextFloat() * 1.3f) else (2.4f + rng.nextFloat() * 1.1f))
                        SHAPE_HOLLOW_STAR4 -> dpF(2.8f + rng.nextFloat() * 1.2f)
                        SHAPE_SOFT_RING_PEARL -> dpF(1.35f + rng.nextFloat() * 0.85f)
                        else -> dpF(0.45f + rng.nextFloat() * 0.62f) // 极细碎星尘
                    }

                    val distRatio = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> 0.38f + rng.nextFloat() * 0.52f
                        SHAPE_HOLLOW_STAR4 -> 0.45f + rng.nextFloat() * 0.55f
                        SHAPE_SOFT_RING_PEARL -> 0.30f + rng.nextFloat() * 0.58f
                        else -> 0.18f + rng.nextFloat() * 0.88f
                    }
                    val startOff = dpF(0.4f + rng.nextFloat() * 1.6f)
                    val bloomReach = maxBloomExtraPx * distRatio

                    // 微弧度曲线漂移 + 尾韵缓慢微飘（复刻视频2末尾小星星在空中轻轻闪烁漂浮的余韵）
                    val arcSign = if (cIdx % 2 == 0) 1f else -1f
                    val arcDrift = arcSign * (0.10f + rng.nextFloat() * 0.18f)
                    val floatAng = pAng + arcSign * (0.45f + rng.nextFloat() * 0.55f)
                    val floatDist = dpF(2.2f + rng.nextFloat() * 3.8f) * (0.75f + rangeNorm * 0.45f)

                    val bright = when (shapeType) {
                        SHAPE_SOLID_STAR4 -> 0.88f + rng.nextFloat() * 0.12f
                        SHAPE_HOLLOW_STAR4 -> 0.82f + rng.nextFloat() * 0.16f
                        SHAPE_SOFT_RING_PEARL -> 0.65f + rng.nextFloat() * 0.25f
                        else -> if (rng.nextFloat() < 0.45f) (0.72f + rng.nextFloat() * 0.26f) else (0.28f + rng.nextFloat() * 0.32f)
                    }

                    val cvRoll = rng.nextFloat()
                    val colorVar = if (cvRoll < 0.58f) 0 else if (cvRoll < 0.80f) 1 else 2

                    sList.add(
                        EtherealStarletParticle(
                            shapeType = shapeType,
                            baseAngleRad = pAng,
                            edgeDistPx = edgeDist,
                            startOffsetPx = startOff,
                            bloomReachPx = bloomReach,
                            arcCurveDriftRad = arcDrift,
                            afterglowFloatDx = cos(floatAng) * floatDist,
                            afterglowFloatDy = sin(floatAng) * floatDist + dpF(1.2f), // 微带一丝轻盈垂落感
                            sizePx = sizePx,
                            rotationDeg = (rng.nextFloat() - 0.5f) * 36f,
                            spinDeg = (rng.nextFloat() - 0.5f) * 28f,
                            brightness = bright,
                            colorVariant = colorVar,
                            twinklePhase = rng.nextFloat() * twoPi,
                            twinkleFreq = 0.015f + rng.nextFloat() * 0.016f,
                            lingerBoost = if (shapeType != SHAPE_TWINKLE_DUST) 0.58f else 0.72f
                        )
                    )
                }
            }
            etherealStarlets = sList
        } else {
            flowRibbons = emptyList()
            etherealStarlets = emptyList()
        }

        // =========================================================================
        // A2. 生成键盘上「💧 水纹落雨：浅层水波微漾」(LiquidRippleWave)
        // =========================================================================
        val liquidRipples: List<LiquidRippleWave>
        if (shouldSpawnLiquidRipple) {
            val ringCount = when {
                rippleDensityNorm < 0.34f -> 1
                rippleDensityNorm < 0.72f -> 2
                else -> 3
            }
            val baseKeyR = (min(rect.width(), rect.height()) * 0.5f).coerceAtLeast(dpF(18f))
            val maxReachBase = baseKeyR * (0.84f + rippleRangeNorm * 0.98f)
            val wList = ArrayList<LiquidRippleWave>(ringCount)
            for (wIdx in 0 until ringCount) {
                val delay = when (wIdx) {
                    0 -> 0f
                    1 -> 0.18f
                    else -> 0.35f
                }
                val reachScale = when (wIdx) {
                    0 -> 1.0f
                    1 -> 0.86f
                    else -> 0.72f
                }
                val strokeDp = when (wIdx) {
                    0 -> 1.15f + rippleDensityNorm * 0.25f
                    1 -> 0.92f + rippleDensityNorm * 0.20f
                    else -> 0.76f + rippleDensityNorm * 0.16f
                }
                val contrast = (0.76f + rippleDensityNorm * 0.24f) * (1f - wIdx * 0.16f)
                wList.add(
                    LiquidRippleWave(
                        delayRatio = delay,
                        startRadiusPx = dpF(3.2f + wIdx * 1.4f),
                        maxRadiusPx = maxReachBase * reachScale,
                        strokeWidthPx = dpF(strokeDp),
                        contrastAlpha = contrast.coerceIn(0.45f, 1.0f),
                        hasMicroDrops = (wIdx == 0 && rippleDensityNorm >= 0.42f),
                        dropBaseAngle = rng.nextFloat() * twoPi
                    )
                )
            }
            liquidRipples = wList
        } else {
            liquidRipples = emptyList()
        }

        // =========================================================================
        // A3. 生成键盘上「✦ 暗夜微尘 / 幽夜流星：极细碎闪与星屑沉落」(FallingStardustParticle)
        // =========================================================================
        val fallingStardusts: List<FallingStardustParticle>
        if (shouldSpawnStardustFall) {
            val hw = (rect.width() * 0.5f).coerceAtLeast(dpF(14f))
            val hh = (rect.height() * 0.5f).coerceAtLeast(dpF(14f))
            val starCount = (2 + (sdDensityNorm * 8.5f).toInt() + rng.nextInt(2)).coerceIn(2, 12)
            val rangeScale = 0.62f + sdRangeNorm * 0.85f
            val fList = ArrayList<FallingStardustParticle>(starCount)
            for (sIdx in 0 until starCount) {
                // 优先分布在按键左右上角与侧沿，轻微向外弹出后顺着重力优雅下沉
                val sideSign = if (sIdx % 2 == 0) 1f else -1f
                val edgeSpreadX = sideSign * hw * (0.42f + rng.nextFloat() * 0.58f)
                val edgeSpreadY = hh * (-0.78f + rng.nextFloat() * 1.18f)
                val vx = sideSign * dpF(3.5f + rng.nextFloat() * 9.5f) * rangeScale
                val vyInit = -dpF(2.5f + rng.nextFloat() * 4.5f) * (0.75f + sdRangeNorm * 0.4f)
                val gravitySink = dpF(12.5f + rng.nextFloat() * 11.5f) * (0.70f + sdRangeNorm * 0.85f)
                // 直径约 2~3.2dp -> 半径约 1.35~2.35dp
                val starRadDp = if (sIdx < 2) (1.75f + rng.nextFloat() * 0.65f) else (1.25f + rng.nextFloat() * 0.58f)
                val isHollow = (sIdx % 3 == 1)
                // 浅色皮肤下交替采用「深暮紫/同色深墨四芒星 + 珍珠白芯」与「珍珠白四芒星 + 深色折光边」
                val useDarkInk = (sIdx % 3 != 2)
                fList.add(
                    FallingStardustParticle(
                        isHollowStar = isHollow,
                        spawnXOffsetPx = edgeSpreadX,
                        spawnYOffsetPx = edgeSpreadY,
                        vxPx = vx,
                        vyInitPx = vyInit,
                        gravityPx = gravitySink,
                        starRadiusPx = dpF(starRadDp),
                        rotationDeg = (rng.nextFloat() - 0.5f) * 40f,
                        spinDeg = sideSign * (18f + rng.nextFloat() * 34f),
                        useDarkInkStyle = useDarkInk,
                        colorVariant = sIdx % 3,
                        twinklePhase = rng.nextFloat() * twoPi,
                        twinkleFreq = 0.018f + rng.nextFloat() * 0.016f,
                        lifeRatio = 0.82f + rng.nextFloat() * 0.26f
                    )
                )
            }
            fallingStardusts = fList
        } else {
            fallingStardusts = emptyList()
        }

        // =========================================================================
        // A4. 生成浅色皮肤专属「🌀 键廓流光涡旋（视频1第2款）+ 🐾 键廓星泡萌爪（视频1第1款）」
        //     完全贴合键帽圆角矩形形状，根据按键颜色自适应取色！
        // =========================================================================
        val contourSwirlRibbons: List<KeyContourSwirlRibbon>
        val contourSpindlePetals: List<KeyContourSpindlePetal>
        val contourSparksAndBubbles: List<KeyContourSparkAndBubble>
        if (shouldSpawnContourVortex) {
            val hasVortex = (cvStyle == STYLE_VORTEX_RING || cvStyle == STYLE_BOTH_COMBINED)
            val hasPawBubble = (cvStyle == STYLE_PAW_STAR_BUBBLE || cvStyle == STYLE_BOTH_COMBINED)
            val maxScaleReach = 1.04f + cvRangeNorm * 0.34f // 1.04x (贴合键沿) ~ 1.38x (向外舒展)

            if (hasVortex) {
                // 1) 双层键廓旋流弯月丝带（内圈紧贴键廓回旋 + 外圈向外舒展掠过圆角）
                val innerCount = if (cvDensityNorm < 0.35f) 2 else 3
                val outerCount = when {
                    cvDensityNorm < 0.30f -> 1
                    cvDensityNorm < 0.72f -> 2
                    else -> 3
                }
                val totalRibbons = innerCount + outerCount
                val swList = ArrayList<KeyContourSwirlRibbon>(totalRibbons)
                val baseU0 = rng.nextFloat()
                for (i in 0 until innerCount) {
                    val u0 = (baseU0 + i.toFloat() / innerCount + (rng.nextFloat() - 0.5f) * 0.06f) % 1.0f
                    swList.add(
                        KeyContourSwirlRibbon(
                            isOuterTrack = false,
                            startPerimeterU = if (u0 < 0f) u0 + 1f else u0,
                            arcLengthU = 0.24f + cvDensityNorm * 0.10f + rng.nextFloat() * 0.04f,
                            travelSpeedU = 0.36f + rng.nextFloat() * 0.14f,
                            startScale = 0.66f + (i % 2) * 0.05f,
                            endScale = 0.96f + cvRangeNorm * 0.12f,
                            maxThicknessPx = dpF(2.1f + cvDensityNorm * 0.85f),
                            radialWavePx = dpF(1.2f + rng.nextFloat() * 1.4f),
                            useAccentTint = (i % 2 == 1),
                            delayRatio = 0.04f * i,
                            lifeRatio = 0.86f + rng.nextFloat() * 0.14f
                        )
                    )
                }
                val outerBaseU = (baseU0 + 0.17f) % 1.0f
                for (i in 0 until outerCount) {
                    val u0 = (outerBaseU + i.toFloat() / outerCount + (rng.nextFloat() - 0.5f) * 0.07f) % 1.0f
                    swList.add(
                        KeyContourSwirlRibbon(
                            isOuterTrack = true,
                            startPerimeterU = if (u0 < 0f) u0 + 1f else u0,
                            arcLengthU = 0.20f + cvDensityNorm * 0.09f + rng.nextFloat() * 0.04f,
                            travelSpeedU = 0.42f + rng.nextFloat() * 0.16f,
                            startScale = 0.88f,
                            endScale = maxScaleReach,
                            maxThicknessPx = dpF(1.75f + cvDensityNorm * 0.70f),
                            radialWavePx = dpF(1.5f + rng.nextFloat() * 1.6f),
                            useAccentTint = (i % 2 == 0),
                            delayRatio = 0.08f + 0.05f * i,
                            lifeRatio = 0.92f + rng.nextFloat() * 0.08f
                        )
                    )
                }
                contourSwirlRibbons = swList

                // 2) 初段向外迸射的「梭形流光叶瓣」(Radial Spindle Petals，复刻视频第2款前4帧的花瓣状放射光针)
                val petalCount = (5 + (cvDensityNorm * 6f).toInt()).coerceIn(5, 11)
                val pList = ArrayList<KeyContourSpindlePetal>(petalCount)
                val basePetalAng = rng.nextFloat() * twoPi
                for (pIdx in 0 until petalCount) {
                    val ang = basePetalAng + pIdx * (twoPi / petalCount) + (rng.nextFloat() - 0.5f) * 0.22f
                    pList.add(
                        KeyContourSpindlePetal(
                            angleRad = ang,
                            startScale = 0.26f + rng.nextFloat() * 0.12f,
                            endScale = 0.95f + cvRangeNorm * 0.28f + rng.nextFloat() * 0.10f,
                            lengthPx = dpF(7.5f + cvRangeNorm * 5.0f + rng.nextFloat() * 3.0f),
                            halfWidthPx = dpF(1.35f + cvDensityNorm * 0.45f),
                            useAccentTint = (pIdx % 2 == 1),
                            lifeRatio = 0.42f + rng.nextFloat() * 0.12f
                        )
                    )
                }
                contourSpindlePetals = pList
            } else {
                contourSwirlRibbons = emptyList()
                contourSpindlePetals = emptyList()
            }

            // 3) 环绕圆角键廓的「十字四芒星闪 ✦ / 微光露珠 • / 五角萌星 ★ / 幻彩小气泡 ○」
            val sparkCount = (6 + (cvDensityNorm * 10f).toInt()).coerceIn(6, 16)
            val spList = ArrayList<KeyContourSparkAndBubble>(sparkCount)
            val baseSparkU = rng.nextFloat()
            for (sIdx in 0 until sparkCount) {
                val u0 = (baseSparkU + sIdx.toFloat() / sparkCount + (rng.nextFloat() - 0.5f) * 0.05f) % 1.0f
                val kind = when {
                    hasPawBubble && !hasVortex -> {
                        if (sIdx % 3 == 0) 3 else if (sIdx % 4 == 1) 0 else 2 // ★五角萌星 + ○微气泡 + ✦小星闪
                    }
                    hasPawBubble && hasVortex -> {
                        when (sIdx % 4) {
                            0 -> 0 // ✦ 十字四芒星
                            1 -> 2 // ★ 五角萌星
                            2 -> 3 // ○ 幻彩微气泡
                            else -> 1 // • 露珠
                        }
                    }
                    else -> {
                        // 默认第2款（键廓旋流）：✦ 十字四芒星 + • 伴生微光露珠
                        if (sIdx % 2 == 0) 0 else 1
                    }
                }
                val szDp = when (kind) {
                    0 -> 2.6f + rng.nextFloat() * 1.4f // ✦ 十字四芒星半径
                    2 -> 2.8f + rng.nextFloat() * 1.3f // ★ 五角萌星半径
                    3 -> 2.0f + rng.nextFloat() * 1.5f // ○ 微气泡半径
                    else -> 1.15f + rng.nextFloat() * 0.65f // • 微光露珠半径
                }
                spList.add(
                    KeyContourSparkAndBubble(
                        kind = kind,
                        perimeterU = if (u0 < 0f) u0 + 1f else u0,
                        driftU = (if (sIdx % 2 == 0) 1f else -1f) * (0.04f + rng.nextFloat() * 0.06f),
                        startScale = 0.80f + rng.nextFloat() * 0.14f,
                        endScale = maxScaleReach * (0.94f + rng.nextFloat() * 0.14f),
                        sizePx = dpF(szDp),
                        rotationDeg = (rng.nextFloat() - 0.5f) * 36f,
                        spinDeg = (if (sIdx % 2 == 0) 1f else -1f) * (25f + rng.nextFloat() * 45f),
                        colorVariant = sIdx % 3,
                        twinklePhase = rng.nextFloat() * twoPi,
                        twinkleFreq = 0.020f + rng.nextFloat() * 0.016f,
                        delayRatio = 0.06f + (sIdx % 4) * 0.05f,
                        lifeRatio = 0.78f + rng.nextFloat() * 0.22f
                    )
                )
            }
            contourSparksAndBubbles = spList
        } else {
            contourSwirlRibbons = emptyList()
            contourSpindlePetals = emptyList()
            contourSparksAndBubbles = emptyList()
        }

        if (!shouldSpawnSurfaceParticles) {
            return SpotlightOrb(
                sourceView = sourceView,
                keyRect = rect,
                keyCornerRadiusPx = keyCornerRadiusPx.coerceAtLeast(dpF(6f)),
                surfaceKeyBgColor = resolvedSurfaceKeyBg,
                glowColor = glowColor,
                palette = palette,
                spawnTime = now,
                releaseTime = 0L,
                intensityNorm = normI,
                burstSpeedNorm = speedNorm,
                rippleSpeedNorm = rippleSpeedNorm,
                stardustSpeedNorm = sdSpeedNorm,
                keyBlushHaloEnabled = bhEnabled,
                keyBlushHaloStyle = bhStyle,
                keyBlushHaloDensityNorm = bhDensityNorm,
                keyBlushHaloSpeedNorm = bhSpeedNorm,
                keyBlushHaloRangeNorm = bhRangeNorm,
                blushTopColor = bhColors[0],
                blushBotColor = bhColors[1],
                blushHaloColor = bhColors[2],
                breadBearPopupEnabled = (renderLayerMode != LAYER_UNDER_GLOW) && isBreadBearPopupEnabled(context),
                bearStickerIndex = ((seed ushr 12).toInt() and 3),
                contourVortexStyle = cvStyle,
                contourVortexSpeedNorm = cvSpeedNorm,
                contourVortexRangeNorm = cvRangeNorm,
                contourSwirlRibbons = contourSwirlRibbons,
                contourSpindlePetals = contourSpindlePetals,
                contourSparksAndBubbles = contourSparksAndBubbles,
                liquidRipples = liquidRipples,
                fallingStardusts = fallingStardusts,
                flowRibbons = flowRibbons,
                etherealStarlets = etherealStarlets,
                stardustList = emptyList(),
                starPoints = emptyList(),
                nebulaSpots = emptyList(),
                starFlares = emptyList()
            )
        }

        // =========================================================================
        // B. 生成键盘上「表面璀璨星河（四角/六角星芒 + 星河微尘）」（独立保留）
        // =========================================================================
        val spreadScale = 0.78f + normI * 0.48f
        val spreadRx = (rect.width() * 0.54f + dpF(16f * spreadScale)).coerceAtLeast(dpF(26f))
        val spreadRy = (rect.height() * 0.54f + dpF(14f * spreadScale)).coerceAtLeast(dpF(22f))

        val galaxyAxisAngle = (rng.nextFloat() - 0.5f) * 1.9f
        val cosAxis = cos(galaxyAxisAngle)
        val sinAxis = sin(galaxyAxisAngle)

        val dustCount = (10 + (normI * normI * 24f + normI * 10f).toInt() + rng.nextInt(4)).coerceIn(8, 46)
        val stardustList = ArrayList<MicroStardustParticle>(dustCount)
        for (i in 0 until dustCount) {
            val alongBand = rng.nextFloat() < 0.68f
            val rx: Float
            val ry: Float
            if (alongBand) {
                val u = (rng.nextFloat() * 2f - 1f) * spreadRx * 0.96f
                val curveOffset = sin(u / spreadRx * 2.2f) * spreadRy * 0.16f
                val vSpread = (rng.nextFloat() + rng.nextFloat() - 1f) * spreadRy * 0.44f + curveOffset
                rx = u * cosAxis - vSpread * sinAxis
                ry = u * sinAxis + vSpread * cosAxis
            } else {
                val ang = rng.nextFloat() * twoPi
                val dist = 0.15f + rng.nextFloat() * 0.88f
                rx = cos(ang) * spreadRx * dist
                ry = sin(ang) * spreadRy * dist
            }
            val driftAng = atan2(ry, rx) + (rng.nextFloat() - 0.5f) * 0.5f
            val driftDist = dpF(1.2f + rng.nextFloat() * 2.8f)
            val radDp = 0.38f + rng.nextFloat() * 0.56f
            stardustList.add(
                MicroStardustParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(driftAng) * driftDist,
                    driftDy = sin(driftAng) * driftDist,
                    coreRadiusPx = dpF(radDp),
                    baseAlpha = (0.24f + rng.nextFloat() * 0.44f) * (0.68f + normI * 0.42f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.015f + rng.nextFloat() * 0.016f
                )
            )
        }

        val pointCount = (3 + (normI * 12f).toInt() + rng.nextInt(2)).coerceIn(3, 17)
        val starPoints = ArrayList<StarPointParticle>(pointCount)
        val ptBaseAng = rng.nextFloat() * twoPi
        for (i in 0 until pointCount) {
            val ang = ptBaseAng + (i.toFloat() / pointCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.65f
            val dist = 0.20f + rng.nextFloat() * 0.78f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val driftDist = dpF(1.5f + rng.nextFloat() * 3.0f)
            val coreDp = (0.72f + rng.nextFloat() * 0.65f) * (0.82f + normI * 0.28f)
            val haloDp = coreDp * (2.6f + rng.nextFloat() * 1.1f)
            starPoints.add(
                StarPointParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * driftDist,
                    driftDy = sin(ang) * driftDist,
                    haloRadiusPx = dpF(haloDp),
                    coreRadiusPx = dpF(coreDp),
                    baseAlpha = (0.52f + rng.nextFloat() * 0.42f) * (0.72f + normI * 0.38f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.012f + rng.nextFloat() * 0.012f
                )
            )
        }

        val nebulaCount = when {
            normI < 0.35f -> 1
            normI < 0.75f -> 2
            else -> 3
        }
        val nebulaSpots = ArrayList<SoftNebulaSpotParticle>(nebulaCount)
        for (i in 0 until nebulaCount) {
            val ang = galaxyAxisAngle + i * (Math.PI.toFloat()) + (rng.nextFloat() - 0.5f) * 0.9f
            val dist = 0.22f + rng.nextFloat() * 0.52f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val radDp = (4.2f + rng.nextFloat() * 3.0f) * (0.85f + normI * 0.25f)
            nebulaSpots.add(
                SoftNebulaSpotParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * dpF(2.0f),
                    driftDy = sin(ang) * dpF(2.0f),
                    radiusPx = dpF(radDp),
                    baseAlpha = (0.16f + rng.nextFloat() * 0.14f) * (0.75f + normI * 0.35f)
                )
            )
        }

        val heroCount = when {
            normI < 0.32f -> 1
            normI < 0.68f -> 2
            normI < 0.88f -> 3
            else -> 4
        }
        val miniCount = (1 + (normI * normI * 6.0f).toInt() + (if (normI > 0.5f) 1 else 0)).coerceIn(1, 7)
        val totalFlares = heroCount + miniCount
        val starFlares = ArrayList<CelestialStarFlareParticle>(totalFlares)
        val flareBaseAng = rng.nextFloat() * twoPi

        for (i in 0 until heroCount) {
            val ang = flareBaseAng + (i.toFloat() / heroCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.55f
            val dist = 0.30f + rng.nextFloat() * 0.54f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.2f + rng.nextFloat() * 2.2f)
            val rayScale = 0.72f + normI * 0.58f
            val primaryDp = (10.5f + rng.nextFloat() * 5.8f) * rayScale
            val primaryPx = dpF(primaryDp)
            val orthoPx = primaryPx * (0.64f + rng.nextFloat() * 0.26f)
            val diagPx = primaryPx * (0.28f + rng.nextFloat() * 0.14f)
            val halfW = dpF((0.48f + rng.nextFloat() * 0.22f) * (0.88f + normI * 0.18f))
            val isSix = (i == 1 && rng.nextFloat() < 0.55f) || (i >= 2 && rng.nextFloat() < 0.45f)
            val rotDeg = if (!isSix && rng.nextFloat() < 0.72f) {
                (if (rng.nextBoolean()) 0f else 90f) + (rng.nextFloat() - 0.5f) * 12f
            } else {
                (rng.nextFloat() - 0.5f) * 32f
            }
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = true,
                    baseAlpha = (0.88f + rng.nextFloat() * 0.12f) * (0.78f + normI * 0.32f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        val miniBaseAng = flareBaseAng + 0.48f
        for (i in 0 until miniCount) {
            val ang = miniBaseAng + (i.toFloat() / miniCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.72f
            val dist = 0.22f + rng.nextFloat() * 0.74f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.4f + rng.nextFloat() * 2.6f)
            val rayScale = 0.74f + normI * 0.46f
            val primaryDp = (5.0f + rng.nextFloat() * 3.6f) * rayScale
            val primaryPx = dpF(primaryDp)
            val orthoPx = primaryPx * (0.68f + rng.nextFloat() * 0.24f)
            val diagPx = if (rng.nextFloat() < 0.4f) primaryPx * 0.28f else 0f
            val halfW = dpF(0.36f + rng.nextFloat() * 0.16f)
            val isSix = rng.nextFloat() < 0.30f
            val rotDeg = (rng.nextFloat() - 0.5f) * 42f
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = false,
                    baseAlpha = (0.64f + rng.nextFloat() * 0.28f) * (0.72f + normI * 0.36f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        return SpotlightOrb(
            sourceView = sourceView,
            keyRect = rect,
            keyCornerRadiusPx = keyCornerRadiusPx.coerceAtLeast(dpF(6f)),
            surfaceKeyBgColor = resolvedSurfaceKeyBg,
            glowColor = glowColor,
            palette = palette,
            spawnTime = now,
            releaseTime = 0L,
            intensityNorm = normI,
            burstSpeedNorm = speedNorm,
            rippleSpeedNorm = rippleSpeedNorm,
            stardustSpeedNorm = sdSpeedNorm,
            keyBlushHaloEnabled = bhEnabled,
            keyBlushHaloStyle = bhStyle,
            keyBlushHaloDensityNorm = bhDensityNorm,
            keyBlushHaloSpeedNorm = bhSpeedNorm,
            keyBlushHaloRangeNorm = bhRangeNorm,
            blushTopColor = bhColors[0],
            blushBotColor = bhColors[1],
            blushHaloColor = bhColors[2],
            breadBearPopupEnabled = (renderLayerMode != LAYER_UNDER_GLOW) && isBreadBearPopupEnabled(context),
            bearStickerIndex = ((seed ushr 12).toInt() and 3),
            contourVortexStyle = cvStyle,
            contourVortexSpeedNorm = cvSpeedNorm,
            contourVortexRangeNorm = cvRangeNorm,
            contourSwirlRibbons = contourSwirlRibbons,
            contourSpindlePetals = contourSpindlePetals,
            contourSparksAndBubbles = contourSparksAndBubbles,
            liquidRipples = liquidRipples,
            fallingStardusts = fallingStardusts,
            flowRibbons = flowRibbons,
            etherealStarlets = etherealStarlets,
            stardustList = stardustList,
            starPoints = starPoints,
            nebulaSpots = nebulaSpots,
            starFlares = starFlares
        )
    }

    fun triggerKeyDown(
        keyView: View,
        cornerRadius: Float,
        glowColor: Int,
        surfaceBgColor: Int? = null
    ) {
        // 若当前为顶层星芒层，且用户已关闭「键下流光」与「键上星芒」，直接零开销返回，绝不空跑 120Hz 刷新循环！
        if (renderLayerMode == LAYER_OVER_SPARKLE && !isAnyOverLayerEffectEnabled(context)) {
            return
        }
        val vw = if (keyView.width > 0) keyView.width.toFloat() else dpF(36f)
        val vh = if (keyView.height > 0) keyView.height.toFloat() else dpF(36f)

        var relLeft = -left.toFloat()
        var relTop = -top.toFloat()
        var cur: View? = keyView
        val overlayParent = this.parent
        var matchedAncestor = false
        while (cur != null) {
            relLeft += cur.left - cur.scrollX
            relTop += cur.top - cur.scrollY
            val p = cur.parent
            if (p === overlayParent) {
                matchedAncestor = true
                break
            }
            cur = p as? View
        }
        val left: Float
        val top: Float
        if (matchedAncestor) {
            left = relLeft
            top = relTop
        } else {
            getLocationInWindow(selfLoc)
            keyView.getLocationInWindow(targetLoc)
            left = (targetLoc[0] - selfLoc[0]).toFloat()
            top = (targetLoc[1] - selfLoc[1]).toFloat()
        }
        val right = left + vw
        val bottom = top + vh

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(buildRandomOrb(keyView, RectF(left, top, right, bottom), glowColor, surfaceBgColor, cornerRadius))
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        try {
            emitBrushBursts(RectF(left, top, right, bottom), cornerRadius, glowColor)
        } catch (_: Throwable) {
        }
        invalidate()
    }

    /**
     * 笔刷特效发射：4 款「键上」效果各自一套笔刷配方，互不相同。
     * 每一款都用「疏密 / 幅度 / 速度」三个已有滑块实时驱动，不新增设置项。
     */
    /** 键帽底色是否偏浅（决定粒子要不要换成深一号的饱和色） */
    private fun isLightSurfaceColor(c: Int?): Boolean {
        if (c == null) return false
        val lum = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        return lum > 0.62f
    }

    private fun emitBrushBursts(rect: RectF, cornerRadius: Float, glowColor: Int) {
        if (renderLayerMode == LAYER_UNDER_GLOW) return
        val ctx = context
        // 0.68 是手感系数：粒子要看得见，又不能糊满整颗键
        val px = resources.displayMetrics.density * 0.68f
        // 浅色键帽上白色粒子会隐形 —— 交给笔刷引擎按皮肤明暗换色
        val light = isLightSurfaceColor(keyboardSurfaceBgColor)

        if (isLiquidRippleEnabled(ctx)) {
            val d = (getLiquidRippleDensity(ctx) - 10) / 90f
            val s = (getLiquidRippleSpeed(ctx) - 10) / 90f
            val r = (getLiquidRippleRange(ctx) - 10) / 90f
            brushField.emit(
                rect = rect, corner = cornerRadius, layers = BrushRecipes.liquidRipple(),
                tint = glowColor, tintMix = 0.30f,
                density = d, reach = r, spread = s, pxScale = px, surfaceLight = light
            )
        }
        if (isStardustFallEnabled(ctx)) {
            val d = (getStardustFallDensity(ctx) - 10) / 90f
            val s = (getStardustFallSpeed(ctx) - 10) / 90f
            val r = (getStardustFallRange(ctx) - 10) / 90f
            brushField.emit(
                rect = rect, corner = cornerRadius, layers = BrushRecipes.stardustFall(),
                tint = glowColor, tintMix = 0.26f,
                density = d, reach = r, spread = s, pxScale = px, surfaceLight = light
            )
        }
        if (isContourVortexEnabled(ctx)) {
            val d = (getContourVortexDensity(ctx) - 10) / 90f
            val s = (getContourVortexSpeed(ctx) - 10) / 90f
            val r = (getContourVortexRange(ctx) - 10) / 90f
            brushField.emit(
                rect = rect, corner = cornerRadius, layers = BrushRecipes.contourVortex(),
                tint = glowColor, tintMix = 0.34f,
                density = d, reach = r, spread = s, pxScale = px, surfaceLight = light
            )
        }
        if (isSparkleEnabled(ctx)) {
            val i = (getSparkleIntensity(ctx) - 10) / 90f
            brushField.emit(
                rect = rect, corner = cornerRadius, layers = BrushRecipes.sparkle(),
                tint = glowColor, tintMix = 0.22f,
                density = i, reach = 0.45f, spread = 0.55f, pxScale = px, surfaceLight = light
            )
        }
    }

    fun triggerPreviewBurst(glowColor: Int, surfaceBgColor: Int? = null) {
        val w = width.toFloat().coerceAtLeast(dpF(180f))
        val h = height.toFloat().coerceAtLeast(dpF(42f))
        val cx = w * (0.28f + (System.nanoTime() and 0xFF) / 580f)
        val cy = h * 0.5f
        val rect = RectF(cx - dpF(28f), cy - dpF(16f), cx + dpF(28f), cy + dpF(16f))
        val orb = buildRandomOrb(null, rect, glowColor, surfaceBgColor)
        orb.releaseTime = SystemClock.uptimeMillis()
        orbs.add(orb)
        try {
            // 设置页「预览」按钮：把笔刷粒子也一起演示出来
            emitBrushBursts(rect, dpF(10f), glowColor)
        } catch (_: Throwable) {
        }
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    fun clearAllOrbs() {
        brushField.clear()
        if (orbs.isNotEmpty()) {
            orbs.clear()
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val brushActive = brushField.isActive()
        if (orbs.isEmpty() && !brushActive) return

        val hasClip = clipCornerRadiusPx > 0.5f && width > 0 && height > 0
        val clipSave = if (hasClip) {
            val sc = canvas.save()
            clipBoundsPath.reset()
            tmpRectF.set(0f, 0f, width.toFloat(), height.toFloat())
            clipBoundsPath.addRoundRect(tmpRectF, clipCornerRadiusPx, clipCornerRadiusPx, Path.Direction.CW)
            canvas.clipPath(clipBoundsPath)
            sc
        } else -1

        val now = SystemClock.uptimeMillis()
        // ★ 笔刷粒子（水纹/星屑/键廓流光/星芒）画在原有光效之上，两层互不干扰
        try {
            brushField.draw(canvas, now)
        } catch (_: Throwable) {
        }
        val outerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 32f else 40f)
        val innerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 16f else 20f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            // 速度倍率：10% 为 0.50x（慢动作星语余韵），默认 60% 为 1.02x（柔美呼吸同步），100% 为 1.45x（轻快灵动）
            val speedScale = 0.50f + orb.burstSpeedNorm * 0.95f
            val holdMs = 150f / speedScale
            val fadeMs = 580f / speedScale
            val totalMs = holdMs + fadeMs

            val rippleSpeedScale = 0.52f + orb.rippleSpeedNorm * 0.96f
            val rippleTotalMs = if (orb.liquidRipples.isNotEmpty()) (820f / rippleSpeedScale) else 0f
            val stardustSpeedScale = 0.54f + orb.stardustSpeedNorm * 0.96f
            val stardustTotalMs = if (orb.fallingStardusts.isNotEmpty()) (660f / stardustSpeedScale) else 0f
            val cvSpeedScale = 0.52f + orb.contourVortexSpeedNorm * 0.98f
            val hasContourVortexParticles = orb.contourSwirlRibbons.isNotEmpty() || orb.contourSparksAndBubbles.isNotEmpty()
            val cvTotalMs = if (hasContourVortexParticles) (760f / cvSpeedScale) else 0f
            val bhSpeedScale = 0.52f + orb.keyBlushHaloSpeedNorm * 0.96f
            val bhHoldMs = 95f / bhSpeedScale
            val bhFadeMs = 540f / bhSpeedScale
            val bhReleaseTotalMs = if (orb.keyBlushHaloEnabled || orb.breadBearPopupEnabled) (bhHoldMs + bhFadeMs) else 0f
            val spawnElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()

            val progress: Float
            val driftProgress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
                driftProgress = (spawnElapsed / 540f).coerceIn(0f, 0.40f)
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs && elapsed >= bhReleaseTotalMs && spawnElapsed >= rippleTotalMs && spawnElapsed >= stardustTotalMs && spawnElapsed >= cvTotalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.05f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.95f * (1f - t) * (1f - t)
                }
                driftProgress = (0.16f + 0.84f * (elapsed / totalMs)).coerceIn(0f, 1f)
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val pal = orb.palette
            val rGlow = Color.red(orb.glowColor)
            val gGlow = Color.green(orb.glowColor)
            val bGlow = Color.blue(orb.glowColor)

            val masterPaintAlpha = (progress * 255f).toInt().coerceIn(0, 255)
            // 1. 底层选色背光光晕（复用预构建的单位 RadialGradient，0 对象分配！）
            if (renderLayerMode == LAYER_UNDER_GLOW || renderLayerMode == LAYER_FULL_COMBINED) {
                val rxOut = (orb.keyRect.width() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                val ryOut = (orb.keyRect.height() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                shaderMatrix.reset()
                shaderMatrix.setScale(rxOut / baseRadius, ryOut / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                orb.unitOuterGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = orb.unitOuterGrad
                orbPaint.alpha = masterPaintAlpha
                tmpRectF.set(cx - rxOut, cy - ryOut, cx + rxOut, cy + ryOut)
                canvas.drawOval(tmpRectF, orbPaint)

                val rxIn = (orb.keyRect.width() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                val ryIn = (orb.keyRect.height() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                shaderMatrix.reset()
                shaderMatrix.setScale(rxIn / baseRadius, ryIn / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                orb.unitInnerGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = orb.unitInnerGrad
                orbPaint.alpha = masterPaintAlpha
                tmpRectF.set(cx - rxIn, cy - ryIn, cx + rxIn, cy + ryIn)
                canvas.drawOval(tmpRectF, orbPaint)

                // 1B. 在单层合并模式 (LAYER_FULL_COMBINED) 下绘制「不规则弧形流光细丝 + 簇状星语」
                if (renderLayerMode == LAYER_FULL_COMBINED &&
                    (orb.flowRibbons.isNotEmpty() || orb.etherealStarlets.isNotEmpty())
                ) {
                    drawUnderKeyEtherealBloom(
                        canvas = canvas,
                        orb = orb,
                        now = now,
                        orbProgress = progress,
                        speedScale = speedScale,
                        alphaScale = 1.0f,
                        clipOutKeyCenter = true
                    )
                }
            } else if (renderLayerMode == LAYER_OVER_SPARKLE) {
                // 1C. 将当前按下的键帽圆角矩形精确镂空 (EVEN_ODD)，让弧形流光细丝与簇状小星芒
                //     从键帽底下边角自然漾出，既绝不遮挡当前键帽，又不会被邻键切掉尾韵星点，且不与底层重复叠加！
                if (orb.flowRibbons.isNotEmpty() || orb.etherealStarlets.isNotEmpty()) {
                    drawUnderKeyEtherealBloom(
                        canvas = canvas,
                        orb = orb,
                        now = now,
                        orbProgress = progress,
                        speedScale = speedScale,
                        alphaScale = 1.0f,
                        clipOutKeyCenter = true
                    )
                }

                if (orb.starFlares.isNotEmpty()) {
                    val rxVeil = (orb.keyRect.width() * 0.58f + dpF(18f)).coerceAtLeast(dpF(36f))
                    val ryVeil = (orb.keyRect.height() * 0.58f + dpF(16f)).coerceAtLeast(dpF(32f))
                    shaderMatrix.reset()
                    shaderMatrix.setScale(rxVeil / baseRadius, ryVeil / baseRadius)
                    shaderMatrix.postTranslate(cx, cy)
                    orb.unitVeilGrad.setLocalMatrix(shaderMatrix)
                    orbPaint.shader = orb.unitVeilGrad
                    orbPaint.alpha = masterPaintAlpha
                    tmpRectF.set(cx - rxVeil, cy - ryVeil, cx + rxVeil, cy + ryVeil)
                    canvas.drawOval(tmpRectF, orbPaint)
                }
            }
            orbPaint.alpha = 255

            // 2. 绘制键盘上「表面璀璨星河」四层粒子体系（可在「更多设置」中独立开关）
            if (renderLayerMode != LAYER_UNDER_GLOW &&
                (orb.stardustList.isNotEmpty() || orb.starPoints.isNotEmpty() || orb.starFlares.isNotEmpty())
            ) {
                val lifeElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()
                val rHalo = Color.red(pal.softHaloColor)
                val gHalo = Color.green(pal.softHaloColor)
                val bHalo = Color.blue(pal.softHaloColor)
                val rNearW = Color.red(pal.rayNearWhite)
                val gNearW = Color.green(pal.rayNearWhite)
                val bNearW = Color.blue(pal.rayNearWhite)
                val rShadow = Color.red(pal.lightContrastShadowColor)
                val gShadow = Color.green(pal.lightContrastShadowColor)
                val bShadow = Color.blue(pal.lightContrastShadowColor)

                for (neb in orb.nebulaSpots) {
                    val nx = cx + neb.relX + neb.driftDx * driftProgress
                    val ny = cy + neb.relY + neb.driftDy * driftProgress
                    val nr = neb.radiusPx
                    val nAlpha = (progress * neb.baseAlpha).coerceIn(0f, 1f)
                    val nebColR = if (pal.isLightSurface) rShadow else rHalo
                    val nebColG = if (pal.isLightSurface) gShadow else gHalo
                    val nebColB = if (pal.isLightSurface) bShadow else bHalo
                    val nebGrad = RadialGradient(
                        nx,
                        ny,
                        nr,
                        intArrayOf(
                            Color.argb((125f * nAlpha).toInt().coerceIn(0, 255), nebColR, nebColG, nebColB),
                            Color.argb((58f * nAlpha).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                            Color.argb(0, rHalo, gHalo, bHalo)
                        ),
                        floatArrayOf(0f, 0.52f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = nebGrad
                    canvas.drawCircle(nx, ny, nr, particleFillPaint)
                }

                particleFillPaint.shader = null
                for (dust in orb.stardustList) {
                    val dx = cx + dust.relX + dust.driftDx * driftProgress
                    val dy = cy + dust.relY + dust.driftDy * driftProgress
                    val twinkle = 0.62f + 0.38f * sin(lifeElapsed * dust.twinkleFreq + dust.twinklePhase)
                    val dAlpha = (progress * dust.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val cr = dust.coreRadiusPx

                    if (pal.isLightSurface) {
                        particleFillPaint.color = Color.argb(
                            (95f * dAlpha).toInt().coerceIn(0, 255),
                            rShadow,
                            gShadow,
                            bShadow
                        )
                        canvas.drawCircle(dx, dy, cr * 1.95f, particleFillPaint)
                    } else {
                        particleFillPaint.color = Color.argb(
                            (75f * dAlpha).toInt().coerceIn(0, 255),
                            rHalo,
                            gHalo,
                            bHalo
                        )
                        canvas.drawCircle(dx, dy, cr * 1.75f, particleFillPaint)
                    }

                    particleFillPaint.color = Color.argb(
                        (235f * dAlpha).toInt().coerceIn(0, 255),
                        rNearW,
                        gNearW,
                        bNearW
                    )
                    canvas.drawCircle(dx, dy, cr, particleFillPaint)
                }

                for (pt in orb.starPoints) {
                    val px = cx + pt.relX + pt.driftDx * driftProgress
                    val py = cy + pt.relY + pt.driftDy * driftProgress
                    val twinkle = 0.70f + 0.30f * sin(lifeElapsed * pt.twinkleFreq + pt.twinklePhase)
                    val pAlpha = (progress * pt.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val hr = pt.haloRadiusPx
                    val cr = pt.coreRadiusPx

                    val midHaloR = if (pal.isLightSurface) rShadow else rHalo
                    val midHaloG = if (pal.isLightSurface) gShadow else gHalo
                    val midHaloB = if (pal.isLightSurface) bShadow else bHalo

                    val ptGrad = RadialGradient(
                        px,
                        py,
                        hr,
                        intArrayOf(
                            Color.argb((245f * pAlpha).toInt().coerceIn(0, 255), 255, 255, 255),
                            Color.argb((165f * pAlpha).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                            Color.argb((78f * pAlpha).toInt().coerceIn(0, 255), midHaloR, midHaloG, midHaloB),
                            Color.argb(0, midHaloR, midHaloG, midHaloB)
                        ),
                        floatArrayOf(0f, 0.24f, 0.56f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = ptGrad
                    canvas.drawCircle(px, py, hr, particleFillPaint)

                    particleFillPaint.shader = null
                    particleFillPaint.color = Color.argb(
                        (255f * pAlpha).toInt().coerceIn(0, 255),
                        255,
                        255,
                        255
                    )
                    canvas.drawCircle(px, py, cr * 0.75f, particleFillPaint)
                }

                for (flare in orb.starFlares) {
                    val fx = cx + flare.relX + flare.driftDx * driftProgress
                    val fy = cy + flare.relY + flare.driftDy * driftProgress
                    val pulse = 0.88f + 0.12f * sin(lifeElapsed * 0.014f + flare.twinklePhase)
                    val fAlpha = (progress * flare.baseAlpha * pulse).coerceIn(0f, 1f)
                    val lenScale = 0.88f + 0.14f * progress
                    drawCelestialStarFlare(
                        canvas = canvas,
                        sx = fx,
                        sy = fy,
                        primaryRayPx = flare.primaryRayPx * lenScale,
                        orthogonalRayPx = flare.orthogonalRayPx * lenScale,
                        diagRayPx = flare.diagRayPx * lenScale,
                        baseHalfWidthPx = flare.baseHalfWidthPx,
                        rotationDeg = flare.rotationDeg,
                        isSixPointed = flare.isSixPointed,
                        isHeroFlare = flare.isHeroFlare,
                        alphaFactor = fAlpha,
                        pal = pal
                    )
                }
            }

            // 3. 绘制键盘上「💧 水纹落雨：浅层水波微漾」(LiquidRippleWave)
            if (renderLayerMode != LAYER_UNDER_GLOW && orb.liquidRipples.isNotEmpty()) {
                drawLiquidRippleWaves(
                    canvas = canvas,
                    orb = orb,
                    spawnElapsed = spawnElapsed,
                    rippleTotalMs = rippleTotalMs
                )
            }

            // 4. 绘制键盘上「✦ 暗夜微尘 / 幽夜流星：星屑沉落」(FallingStardustParticle)
            if (renderLayerMode != LAYER_UNDER_GLOW && orb.fallingStardusts.isNotEmpty()) {
                drawFallingStardustParticles(
                    canvas = canvas,
                    orb = orb,
                    spawnElapsed = spawnElapsed,
                    stardustTotalMs = stardustTotalMs
                )
            }

            // 5. 绘制浅色皮肤专属「🌀 键廓流光涡旋（视频1第2款）+ 🐾 键廓星泡萌爪（视频1第1款）」
            if (renderLayerMode != LAYER_UNDER_GLOW && hasContourVortexParticles) {
                drawKeyContourVortexAndStarBubble(
                    canvas = canvas,
                    orb = orb,
                    spawnElapsed = spawnElapsed,
                    cvTotalMs = cvTotalMs
                )
            }

            // 6. 绘制视频2同款「🌸 按键上面变色 + 下面同色光晕显示 + 键面微光小烟花（此刻心动）」
            if (renderLayerMode != LAYER_UNDER_GLOW && orb.keyBlushHaloEnabled) {
                drawKeyBlushAndMatchingHalo(
                    canvas = canvas,
                    orb = orb,
                    now = now,
                    spawnElapsed = spawnElapsed,
                    bhHoldMs = bhHoldMs,
                    bhFadeMs = bhFadeMs
                )
            }

            // 7. 绘制《面包脑袋》视频同款「🐻 按键弹出 Q 弹小熊脑袋贴纸 + 四角伴生金色萌星」
            if (renderLayerMode != LAYER_UNDER_GLOW && orb.breadBearPopupEnabled) {
                drawBreadBearPopupSticker(
                    canvas = canvas,
                    orb = orb,
                    now = now,
                    spawnElapsed = spawnElapsed,
                    bhHoldMs = bhHoldMs,
                    bhFadeMs = bhFadeMs
                )
            }
        }

        if (clipSave != -1) {
            canvas.restoreToCount(clipSave)
        }

        if (orbs.isNotEmpty() || brushField.isActive()) {
            postInvalidateOnAnimation()
        }
    }

    /**
     * 🌙 复刻参考视频2「唯美不规则弧形流光细丝 + 簇状星点余韵」：
     * 1. 零放射直线：彻底告别死板烟花感，采用 1~3 缕贴合键帽转角的弯弯弧形流光游丝；
     * 2. 疏密留白：仅在 2~3 个不对称角落绽放「实心小四芒星 ✦ + 空心细线小星 ✧ + 柔光小光圈 ° + 明暗碎星尘 ·」；
     * 3. 两段式余韵：前半段随底光轻盈漾开，后半段当底光渐淡时，小星点沿微弧线轻轻漂浮闪烁后再缓缓消融。
     */
    private fun drawUnderKeyEtherealBloom(
        canvas: Canvas,
        orb: SpotlightOrb,
        now: Long,
        orbProgress: Float,
        speedScale: Float,
        alphaScale: Float,
        clipOutKeyCenter: Boolean
    ) {
        val impactElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat() * speedScale
        // 第一阶段：轻盈绽开 (0 ~ 280ms)，采用柔滑 cubic ease-out
        val rawT = (impactElapsed / 280f).coerceIn(0f, 1f)
        val invT = 1f - rawT
        val bloomEase = 1f - invT * invT * invT

        // 第二阶段：尾韵微弧漂浮 (0 ~ 680ms)
        val afterglowDriftT = (impactElapsed / 640f).coerceIn(0f, 1f)

        // 即使长按按键不松手，流光与星点也在约 720ms 后温柔消融
        val holdDecay = if (impactElapsed <= 280f) {
            1.0f
        } else {
            ((740f - impactElapsed) / 460f).coerceIn(0f, 1f)
        }

        val holeSave = if (clipOutKeyCenter && width > 0 && height > 0) {
            val sc = canvas.save()
            keyHoleClipPath.reset()
            keyHoleClipPath.fillType = Path.FillType.EVEN_ODD
            keyHoleClipPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val insetPx = dpF(1.0f)
            tmpRectF.set(
                orb.keyRect.left + insetPx,
                orb.keyRect.top + insetPx,
                orb.keyRect.right - insetPx,
                orb.keyRect.bottom - insetPx
            )
            val kr = dpF(9.5f)
            keyHoleClipPath.addRoundRect(tmpRectF, kr, kr, Path.Direction.CW)
            canvas.clipPath(keyHoleClipPath)
            sc
        } else -1

        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val hw = (orb.keyRect.width() * 0.5f).coerceAtLeast(dpF(14f))
        val hh = (orb.keyRect.height() * 0.5f).coerceAtLeast(dpF(14f))
        val pal = orb.palette
        val rNearW = Color.red(pal.rayNearWhite)
        val gNearW = Color.green(pal.rayNearWhite)
        val bNearW = Color.blue(pal.rayNearWhite)
        val rLightHalo = Color.red(pal.meteorLightHaloColor)
        val gLightHalo = Color.green(pal.meteorLightHaloColor)
        val bLightHalo = Color.blue(pal.meteorLightHaloColor)

        particleFillPaint.shader = null

        // =====================================================================
        // 1. 绘制「不规则弧形流光细丝」(GossamerFlowRibbons)
        // =====================================================================
        val ribbonMasterAlpha = (orbProgress * holdDecay * alphaScale).coerceIn(0f, 1f)
        if (ribbonMasterAlpha > 0.02f) {
            for (ribbon in orb.flowRibbons) {
                val rAlpha = (ribbonMasterAlpha * ribbon.brightness).coerceIn(0f, 1f)
                if (rAlpha <= 0.02f) continue

                val tintColor = when (ribbon.colorVariant) {
                    1 -> pal.meteorAccent1
                    2 -> pal.meteorAccent2
                    else -> pal.meteorPrimaryTint
                }
                val rT = Color.red(tintColor)
                val gT = Color.green(tintColor)
                val bT = Color.blue(tintColor)

                val curStartAng = ribbon.startAngleRad + ribbon.angularDriftRad * afterglowDriftT
                val curSweepAng = ribbon.sweepAngleRad * (0.68f + 0.32f * bloomEase)

                // A. 外层柔焦光晕丝（浅色表面采用更柔和的高明度浅色晕染，绝不形成深色团块；深色表面完全保持原样）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx * (if (pal.isLightSurface) 1.68f else 1.75f),
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = 0.0f,
                    sEnd = 1.0f
                )
                val auraR = if (pal.isLightSurface) rLightHalo else rT
                val auraG = if (pal.isLightSurface) gLightHalo else gT
                val auraB = if (pal.isLightSurface) bLightHalo else bT
                val auraAlpha = (if (pal.isLightSurface) 96f else 115f) * rAlpha
                particleFillPaint.color = Color.argb(auraAlpha.toInt().coerceIn(0, 255), auraR, auraG, auraB)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // B. 中层丝滑彩色流光主体（1.0 倍宽：浅色表面呈现清透中等饱和度主题色，清晰可见且绝不发黑发棕）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx,
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = 0.06f,
                    sEnd = 0.94f
                )
                val midR = if (pal.isLightSurface) rT else (rT * 0.42f + rNearW * 0.58f).toInt()
                val midG = if (pal.isLightSurface) gT else (gT * 0.42f + gNearW * 0.58f).toInt()
                val midB = if (pal.isLightSurface) bT else (bBBlend(bT, bNearW))
                val bodyAlpha = (if (pal.isLightSurface) 208f else 210f) * rAlpha
                particleFillPaint.color = Color.argb(bodyAlpha.toInt().coerceIn(0, 255), midR, midG, midB)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // C. 内芯高亮银白游丝（浅色表面采用 0.44 倍纤细白芯，既保持清晰高光又绝不掩盖两侧彩色流光弧线）
                buildCurvedGossamerRibbonPath(
                    cx = cx,
                    cy = cy,
                    hw = hw,
                    hh = hh,
                    startAngle = curStartAng,
                    sweepAngle = curSweepAng,
                    baseOffsetPx = ribbon.baseOffsetPx,
                    swellOutPx = ribbon.swellOutPx * bloomEase,
                    maxHalfWidthPx = ribbon.maxHalfWidthPx * (if (pal.isLightSurface) 0.44f else 0.52f),
                    rippleWavePx = ribbon.rippleWavePx,
                    ripplePhase = ribbon.ripplePhase + afterglowDriftT * 1.8f,
                    sStart = if (pal.isLightSurface) 0.20f else 0.18f,
                    sEnd = if (pal.isLightSurface) 0.84f else 0.86f
                )
                val coreAlpha = (if (pal.isLightSurface) 244f else 250f) * rAlpha
                particleFillPaint.color = Color.argb(coreAlpha.toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // D. 主流光丝前端伴随一枚灵动小四芒星闪（复刻视频2第1款流光弧顶端的微星）
                if (ribbon.hasTipStarlet) {
                    val tipS = 0.82f
                    val tipAng = curStartAng + curSweepAng * tipS
                    val tipArch = sin(tipS * Math.PI.toFloat())
                    val tipEdge = computeKeyEdgeDist(hw, hh, tipAng)
                    val tipR = tipEdge + ribbon.baseOffsetPx + ribbon.swellOutPx * bloomEase * tipArch
                    val tipX = cx + cos(tipAng) * tipR
                    val tipY = cy + sin(tipAng) * tipR
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = tipX,
                        sy = tipY,
                        rayLenPx = dpF(2.8f) * (0.75f + 0.25f * bloomEase),
                        rotationDeg = (tipAng * 180f / Math.PI.toFloat()) + 15f,
                        alpha = rAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
            }
        }

        // =====================================================================
        // 2. 绘制「不对称簇状星群」（实心小四芒星 ✦ + 空心小星 ✧ + 柔光小光圈 ° + 明暗碎星尘 ·）
        // =====================================================================
        for (star in orb.etherealStarlets) {
            // 星点拥有更温柔的尾韵：主光晕变淡时，星点依然在空中保持闪烁再缓缓消散
            val lingerProgress = orbProgress.pow(star.lingerBoost)
            val twinkle = 0.64f + 0.36f * sin(impactElapsed * star.twinkleFreq + star.twinklePhase)
            val sAlpha = (lingerProgress * holdDecay * alphaScale * star.brightness * twinkle).coerceIn(0f, 1f)
            if (sAlpha <= 0.02f) continue

            // 运动轨迹：微弧度漾开 + 尾韵轻飘
            val curAng = star.baseAngleRad + star.arcCurveDriftRad * bloomEase
            val curRadialDist = star.edgeDistPx + star.startOffsetPx + star.bloomReachPx * bloomEase
            val sx = cx + cos(curAng) * curRadialDist + star.afterglowFloatDx * afterglowDriftT
            val sy = cy + sin(curAng) * curRadialDist + star.afterglowFloatDy * afterglowDriftT

            val tintColor = when (star.colorVariant) {
                1 -> pal.meteorAccent1
                2 -> pal.meteorAccent2
                else -> pal.meteorPrimaryTint
            }
            val rT = Color.red(tintColor)
            val gT = Color.green(tintColor)
            val bT = Color.blue(tintColor)

            when (star.shapeType) {
                SHAPE_SOLID_STAR4 -> {
                    val curRot = star.rotationDeg + star.spinDeg * afterglowDriftT
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        rayLenPx = star.sizePx * (0.82f + 0.18f * twinkle),
                        rotationDeg = curRot,
                        alpha = sAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
                SHAPE_HOLLOW_STAR4 -> {
                    val curRot = star.rotationDeg + star.spinDeg * afterglowDriftT
                    drawHollowFourPointStarlet(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        rayLenPx = star.sizePx * (0.85f + 0.15f * twinkle),
                        rotationDeg = curRot,
                        alpha = sAlpha,
                        rT = rT,
                        gT = gT,
                        bT = bT,
                        isLightSurface = pal.isLightSurface
                    )
                }
                SHAPE_SOFT_RING_PEARL -> {
                    val pr = star.sizePx
                    // 柔和内雾
                    particleFillPaint.color = Color.argb(
                        ((if (pal.isLightSurface) 95f else 62f) * sAlpha).toInt().coerceIn(0, 255),
                        rT,
                        gT,
                        bT
                    )
                    canvas.drawCircle(sx, sy, pr * 1.15f, particleFillPaint)
                    // 精致细线小光圈
                    particleStrokePaint.strokeWidth = dpF(0.68f)
                    particleStrokePaint.color = Color.argb(
                        ((if (pal.isLightSurface) 225f else 205f) * sAlpha).toInt().coerceIn(0, 255),
                        if (pal.isLightSurface) rT else (rT * 0.32f + 255 * 0.68f).toInt(),
                        if (pal.isLightSurface) gT else (gT * 0.32f + 255 * 0.68f).toInt(),
                        if (pal.isLightSurface) bT else (bT * 0.32f + 255 * 0.68f).toInt()
                    )
                    canvas.drawCircle(sx, sy, pr, particleStrokePaint)
                }
                else -> {
                    // 明暗错落的微星尘 (SHAPE_TWINKLE_DUST)
                    val cr = star.sizePx
                    if (pal.isLightSurface) {
                        particleFillPaint.color = Color.argb(
                            (130f * sAlpha).toInt().coerceIn(0, 255),
                            rLightHalo,
                            gLightHalo,
                            bLightHalo
                        )
                        canvas.drawCircle(sx, sy, cr * 2.1f, particleFillPaint)
                        particleFillPaint.color = Color.argb(
                            (228f * sAlpha).toInt().coerceIn(0, 255),
                            rT,
                            gT,
                            bT
                        )
                        canvas.drawCircle(sx, sy, cr * 1.25f, particleFillPaint)
                    } else {
                        particleFillPaint.color = Color.argb(
                            (105f * sAlpha).toInt().coerceIn(0, 255),
                            rT,
                            gT,
                            bT
                        )
                        canvas.drawCircle(sx, sy, cr * 1.95f, particleFillPaint)
                    }
                    particleFillPaint.color = Color.argb(
                        (252f * sAlpha).toInt().coerceIn(0, 255),
                        255,
                        255,
                        255
                    )
                    canvas.drawCircle(sx, sy, cr * (if (pal.isLightSurface) 0.65f else 0.85f), particleFillPaint)
                }
            }
        }

        if (holeSave != -1) {
            canvas.restoreToCount(holeSave)
        }
    }

    private fun bBBlend(bT: Int, bNearW: Int): Int {
        return (bT * 0.42f + bNearW * 0.58f).toInt().coerceIn(0, 255)
    }

    /**
     * 构建两头尖细如游丝、中间柔亮微拱的「不规则弧形流光细丝」几何路径
     */
    private fun buildCurvedGossamerRibbonPath(
        cx: Float,
        cy: Float,
        hw: Float,
        hh: Float,
        startAngle: Float,
        sweepAngle: Float,
        baseOffsetPx: Float,
        swellOutPx: Float,
        maxHalfWidthPx: Float,
        rippleWavePx: Float,
        ripplePhase: Float,
        sStart: Float,
        sEnd: Float
    ) {
        ribbonPath.reset()
        val steps = 8
        // 沿着弧线正向采样外侧边缘
        for (i in 0..steps) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val ux = cos(ang)
            val uy = sin(ang)
            val edgeDist = computeKeyEdgeDist(hw, hh, ang)
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.2f + ripplePhase) * rippleWavePx * arch
            val centerR = edgeDist + baseOffsetPx + swellOutPx * arch + wave
            // 丝线半宽在两端收束为 0，中间柔润饱满
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rOut = centerR + halfW
            val x = cx + ux * rOut
            val y = cy + uy * rOut
            if (i == 0) {
                ribbonPath.moveTo(x, y)
            } else {
                ribbonPath.lineTo(x, y)
            }
        }
        // 沿着弧线反向采样内侧边缘闭合
        for (i in steps downTo 0) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val ux = cos(ang)
            val uy = sin(ang)
            val edgeDist = computeKeyEdgeDist(hw, hh, ang)
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.2f + ripplePhase) * rippleWavePx * arch
            val centerR = edgeDist + baseOffsetPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rIn = centerR - halfW
            val x = cx + ux * rIn
            val y = cy + uy * rIn
            ribbonPath.lineTo(x, y)
        }
        ribbonPath.close()
    }

    /**
     * 绘制实心纤细小四芒星 ✦（带同色系柔晕 + 纯白璀璨星芯）
     */
    private fun drawSolidFourPointStarlet(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int,
        isLightSurface: Boolean
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        // 柔和星晕底衬
        particleFillPaint.color = Color.argb(
            ((if (isLightSurface) 140f else 95f) * alpha).toInt().coerceIn(0, 255),
            rT,
            gT,
            bT
        )
        canvas.drawCircle(0f, 0f, rayLenPx * 0.56f, particleFillPaint)

        val orthoLen = rayLenPx * 0.78f
        val waist = rayLenPx * 0.14f

        // 外层同色系星芒轮廓
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        particleFillPaint.color = Color.argb(
            ((if (isLightSurface) 238f else 210f) * alpha).toInt().coerceIn(0, 255),
            if (isLightSurface) rT else (rT * 0.38f + 255 * 0.62f).toInt(),
            if (isLightSurface) gT else (gT * 0.38f + 255 * 0.62f).toInt(),
            if (isLightSurface) bT else (bT * 0.38f + 255 * 0.62f).toInt()
        )
        canvas.drawPath(starPath, particleFillPaint)

        // 内层高亮纯白星核
        val innerScale = if (isLightSurface) 0.62f else 0.74f
        canvas.scale(innerScale, innerScale)
        particleFillPaint.color = Color.argb((255f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, particleFillPaint)

        canvas.restoreToCount(sc)
    }

    /**
     * 绘制空心细线小四芒星 ✧（复刻参考视频2标志性的精致镂空小星）
     */
    private fun drawHollowFourPointStarlet(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int,
        isLightSurface: Boolean
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val orthoLen = rayLenPx * 0.82f
        val waist = rayLenPx * 0.20f

        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        // 先画一层微弱同色柔雾描边
        particleStrokePaint.strokeWidth = dpF(1.25f)
        particleStrokePaint.color = Color.argb(
            ((if (isLightSurface) 175f else 115f) * alpha).toInt().coerceIn(0, 255),
            rT,
            gT,
            bT
        )
        canvas.drawPath(starPath, particleStrokePaint)

        // 再画纤细透亮的空心星线
        particleStrokePaint.strokeWidth = dpF(0.68f)
        particleStrokePaint.color = Color.argb(
            ((if (isLightSurface) 242f else 238f) * alpha).toInt().coerceIn(0, 255),
            if (isLightSurface) rT else (rT * 0.25f + 255 * 0.75f).toInt(),
            if (isLightSurface) gT else (gT * 0.25f + 255 * 0.75f).toInt(),
            if (isLightSurface) bT else (bT * 0.25f + 255 * 0.75f).toInt()
        )
        canvas.drawPath(starPath, particleStrokePaint)

        canvas.restoreToCount(sc)
    }

    private fun buildSlenderStarFlarePath(
        primaryLen: Float,
        orthoLen: Float,
        diagLen: Float,
        baseW: Float,
        isSixPointed: Boolean
    ) {
        starPath.reset()
        if (isSixPointed) {
            val angles = floatArrayOf(
                0f,
                (Math.PI / 3.0).toFloat(),
                (2.0 * Math.PI / 3.0).toFloat()
            )
            for (idx in angles.indices) {
                val a = angles[idx]
                val rayL = if (idx == 0) primaryLen else orthoLen * 0.88f
                val rw = if (idx == 0) baseW else baseW * 0.78f
                addSymmetricNeedlePair(a, rayL, rw)
            }
        } else {
            addSymmetricNeedlePair(0f, primaryLen, baseW)
            addSymmetricNeedlePair((Math.PI * 0.5).toFloat(), orthoLen, baseW * 0.88f)
            if (diagLen > 1.2f) {
                val dw = baseW * 0.52f
                addSymmetricNeedlePair((Math.PI * 0.25).toFloat(), diagLen, dw)
                addSymmetricNeedlePair((Math.PI * 0.75).toFloat(), diagLen, dw)
            }
        }
    }

    private fun addSymmetricNeedlePair(angleRad: Float, rayLen: Float, halfBaseW: Float) {
        val ux = cos(angleRad)
        val uy = sin(angleRad)
        val px = -uy
        val py = ux
        val cDist = rayLen * 0.11f
        val cW = halfBaseW * 0.075f

        starPath.moveTo(px * halfBaseW, py * halfBaseW)
        starPath.quadTo(ux * cDist + px * cW, uy * cDist + py * cW, ux * rayLen, uy * rayLen)
        starPath.quadTo(ux * cDist - px * cW, uy * cDist - py * cW, -px * halfBaseW, -py * halfBaseW)
        starPath.close()

        starPath.moveTo(-px * halfBaseW, -py * halfBaseW)
        starPath.quadTo(-ux * cDist - px * cW, -uy * cDist - py * cW, -ux * rayLen, -uy * rayLen)
        starPath.quadTo(-ux * cDist + px * cW, -uy * cDist + py * cW, px * halfBaseW, py * halfBaseW)
        starPath.close()
    }

    private fun drawCelestialStarFlare(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        primaryRayPx: Float,
        orthogonalRayPx: Float,
        diagRayPx: Float,
        baseHalfWidthPx: Float,
        rotationDeg: Float,
        isSixPointed: Boolean,
        isHeroFlare: Boolean,
        alphaFactor: Float,
        pal: StarlightColorAdapter.StarlightPalette
    ) {
        if (primaryRayPx <= 1f || alphaFactor <= 0.01f) return
        val save = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val rHalo = Color.red(pal.softHaloColor)
        val gHalo = Color.green(pal.softHaloColor)
        val bHalo = Color.blue(pal.softHaloColor)
        val rNearW = Color.red(pal.rayNearWhite)
        val gNearW = Color.green(pal.rayNearWhite)
        val bNearW = Color.blue(pal.rayNearWhite)
        val rShadow = Color.red(pal.lightContrastShadowColor)
        val gShadow = Color.green(pal.lightContrastShadowColor)
        val bShadow = Color.blue(pal.lightContrastShadowColor)

        val haloR = (primaryRayPx * (if (isHeroFlare) 0.44f else 0.40f)).coerceAtLeast(dpF(3.2f))
        val haloColR = if (pal.isLightSurface) rShadow else rHalo
        val haloColG = if (pal.isLightSurface) gShadow else gHalo
        val haloColB = if (pal.isLightSurface) bShadow else bHalo
        val haloCenterAlpha = (if (pal.isLightSurface) 118f else 92f) * alphaFactor
        val haloGrad = RadialGradient(
            0f,
            0f,
            haloR,
            intArrayOf(
                Color.argb(haloCenterAlpha.toInt().coerceIn(0, 255), haloColR, haloColG, haloColB),
                Color.argb((haloCenterAlpha * 0.42f).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.48f, 1.0f),
            Shader.TileMode.CLAMP
        )
        orbPaint.shader = haloGrad
        canvas.drawCircle(0f, 0f, haloR, orbPaint)

        if (pal.isLightSurface) {
            buildSlenderStarFlarePath(
                primaryLen = primaryRayPx * 1.02f,
                orthoLen = orthogonalRayPx * 1.02f,
                diagLen = diagRayPx,
                baseW = baseHalfWidthPx * 1.45f,
                isSixPointed = isSixPointed
            )
            val shadowRayGrad = RadialGradient(
                0f,
                0f,
                primaryRayPx * 1.02f,
                intArrayOf(
                    Color.argb((148f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((86f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((24f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb(0, rShadow, gShadow, bShadow)
                ),
                floatArrayOf(0f, 0.32f, 0.72f, 1.0f),
                Shader.TileMode.CLAMP
            )
            particleFillPaint.shader = shadowRayGrad
            canvas.drawPath(starPath, particleFillPaint)
        }

        buildSlenderStarFlarePath(
            primaryLen = primaryRayPx,
            orthoLen = orthogonalRayPx,
            diagLen = diagRayPx,
            baseW = baseHalfWidthPx,
            isSixPointed = isSixPointed
        )
        val rayGrad = RadialGradient(
            0f,
            0f,
            primaryRayPx,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((232f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((115f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((28f * alphaFactor).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.18f, 0.48f, 0.80f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = rayGrad
        canvas.drawPath(starPath, particleFillPaint)

        val coreR = (baseHalfWidthPx * (if (isHeroFlare) 2.3f else 1.9f)).coerceAtLeast(dpF(1.3f))
        val coreGrad = RadialGradient(
            0f,
            0f,
            coreR,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((210f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb(0, rNearW, gNearW, bNearW)
            ),
            floatArrayOf(0f, 0.45f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = coreGrad
        canvas.drawCircle(0f, 0f, coreR, particleFillPaint)

        canvas.restoreToCount(save)
    }

    /**
     * 💧 绘制键盘上「水纹落雨 · 浅层水波微漾」(Liquid Ripple)：
     * - 以按键中心为圆心，向外缓缓荡开 1~3 圈极细、极淡的半透明白色水波纹涟漪；
     * - 独创「内侧同色系微暗折光水影槽 + 纯白清透波峰 + 外侧细微折光」双边光学对比，
     *   即使在极浅的奶灰、浅芋泥紫、樱花粉键帽上，水波荡开的清透折射感依然清晰灵动！
     */
    private fun drawLiquidRippleWaves(
        canvas: Canvas,
        orb: SpotlightOrb,
        spawnElapsed: Float,
        rippleTotalMs: Float
    ) {
        if (rippleTotalMs <= 1f || spawnElapsed >= rippleTotalMs) return
        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val pal = orb.palette

        // 提取同色系折光水影色（浅色皮肤下使用深暮紫/莫兰迪深影色混合主题色，深色皮肤下使用柔光色）
        val rShadow = (Color.red(pal.lightContrastShadowColor) * 0.62f + Color.red(pal.meteorPrimaryTint) * 0.38f).toInt().coerceIn(0, 255)
        val gShadow = (Color.green(pal.lightContrastShadowColor) * 0.62f + Color.green(pal.meteorPrimaryTint) * 0.38f).toInt().coerceIn(0, 255)
        val bShadow = (Color.blue(pal.lightContrastShadowColor) * 0.62f + Color.blue(pal.meteorPrimaryTint) * 0.38f).toInt().coerceIn(0, 255)

        val rTint = Color.red(pal.meteorPrimaryTint)
        val gTint = Color.green(pal.meteorPrimaryTint)
        val bTint = Color.blue(pal.meteorPrimaryTint)

        val overallT = (spawnElapsed / rippleTotalMs).coerceIn(0f, 1f)
        particleFillPaint.shader = null
        particleStrokePaint.shader = null

        for (wave in orb.liquidRipples) {
            val localT = ((overallT - wave.delayRatio) / (1f - wave.delayRatio).coerceAtLeast(0.1f)).coerceIn(0f, 1f)
            if (localT <= 0.005f || localT >= 0.995f) continue

            // 水波阻尼扩散曲线：初段轻灵荡开，末段如湖水微澜缓缓停驻消散
            val inv = 1f - localT
            val easeOut = 1f - inv * inv * inv
            val curR = wave.startRadiusPx + (wave.maxRadiusPx - wave.startRadiusPx) * easeOut

            // 呼吸包络：切入柔顺，尾韵绵长
            val bell = sin(localT * Math.PI.toFloat()).pow(0.72f)
            val envAlpha = (bell * (1f - localT * 0.28f) * wave.contrastAlpha).coerceIn(0f, 1f)
            if (envAlpha <= 0.015f) continue

            val crestStroke = (wave.strokeWidthPx * (1.05f - 0.32f * localT)).coerceAtLeast(dpF(0.65f))

            // 1. 内侧水波折光暗槽（让极细白波纹在浅色/莫兰迪键帽上拥有真实水面凹凸折射对比）
            val troughR = (curR - crestStroke * 1.05f).coerceAtLeast(dpF(1.5f))
            particleStrokePaint.strokeWidth = crestStroke * (if (pal.isLightSurface) 1.65f else 1.35f)
            particleStrokePaint.color = if (pal.isLightSurface) {
                Color.argb((148f * envAlpha).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow)
            } else {
                Color.argb((110f * envAlpha).toInt().coerceIn(0, 255), rTint, gTint, bTint)
            }
            canvas.drawCircle(cx, cy, troughR, particleStrokePaint)

            // 2. 外侧极淡伴生水影边（增强浅色键帽上的清透立体感）
            if (pal.isLightSurface) {
                val outerShadowR = curR + crestStroke * 0.92f
                particleStrokePaint.strokeWidth = (crestStroke * 0.82f).coerceAtLeast(dpF(0.55f))
                particleStrokePaint.color = Color.argb((96f * envAlpha).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow)
                canvas.drawCircle(cx, cy, outerShadowR, particleStrokePaint)
            }

            // 3. 水波主峰：极细、清透的珍珠纯白水纹涟漪
            particleStrokePaint.strokeWidth = crestStroke
            val whiteAlpha = (if (pal.isLightSurface) 248f else 225f) * envAlpha
            particleStrokePaint.color = Color.argb(whiteAlpha.toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawCircle(cx, cy, curR, particleStrokePaint)

            // 4. 触点中心雨滴初落微光圈（仅在第一圈水纹前 36% 时间内浮现，宛如雨滴轻叩湖面）
            if (wave.delayRatio == 0f && localT < 0.36f) {
                val dropT = (localT / 0.36f).coerceIn(0f, 1f)
                val dropEnv = (1f - dropT) * (1f - dropT) * wave.contrastAlpha
                val dropR = dpF(2.0f + dropT * 5.2f)
                if (pal.isLightSurface) {
                    particleFillPaint.color = Color.argb((92f * dropEnv).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow)
                    canvas.drawCircle(cx, cy, dropR * 1.28f, particleFillPaint)
                }
                particleFillPaint.color = Color.argb((220f * dropEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawCircle(cx, cy, dropR * 0.72f, particleFillPaint)
            }

            // 5. 波峰伴生微水珠（2~3 颗贴着涟漪弧线轻漾的 1dp 露珠点缀）
            if (wave.hasMicroDrops) {
                for (dIdx in 0 until 3) {
                    val dAng = wave.dropBaseAngle + dIdx * 2.09f + localT * 0.25f
                    val dx = cx + cos(dAng) * curR
                    val dy = cy + sin(dAng) * curR
                    val dropRad = dpF(1.05f) * (1f - localT * 0.35f)
                    if (pal.isLightSurface) {
                        particleFillPaint.color = Color.argb((155f * envAlpha).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow)
                        canvas.drawCircle(dx, dy, dropRad * 1.45f, particleFillPaint)
                    }
                    particleFillPaint.color = Color.argb((245f * envAlpha).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(dx, dy, dropRad * 0.85f, particleFillPaint)
                }
            }
        }
    }

    /**
     * ✦ 绘制键盘上「暗夜微尘 / 幽夜流星 · 极细碎闪与星屑沉落」(Stardust Fall)：
     * - 点击按键时在按键周围迸出微小的四芒星尘（✦ / ✧，直径约 2~3dp），顺着重力微微下沉并消融；
     * - 浅色皮肤下智能采用「深暮紫/同色深墨微星 + 珍珠白星芯」高对比配色，深色皮肤下采用「清冷银白月光微星」，
     *   上方伴随一缕极淡的下落流星尾迹，无论浅色还是深色皮肤都精致灵动！
     */
    private fun drawFallingStardustParticles(
        canvas: Canvas,
        orb: SpotlightOrb,
        spawnElapsed: Float,
        stardustTotalMs: Float
    ) {
        if (stardustTotalMs <= 1f || spawnElapsed >= stardustTotalMs) return
        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val pal = orb.palette

        // 浅色皮肤专用的高对比同色系深暮紫/深墨色调（与按键深色字体相呼应，绝不发灰隐形，也绝不荧光）
        val rDarkInk = (Color.red(pal.lightContrastShadowColor) * 0.72f + Color.red(pal.meteorPrimaryTint) * 0.28f).toInt().coerceIn(0, 255)
        val gDarkInk = (Color.green(pal.lightContrastShadowColor) * 0.72f + Color.green(pal.meteorPrimaryTint) * 0.28f).toInt().coerceIn(0, 255)
        val bDarkInk = (Color.blue(pal.lightContrastShadowColor) * 0.72f + Color.blue(pal.meteorPrimaryTint) * 0.28f).toInt().coerceIn(0, 255)

        particleFillPaint.shader = null
        particleStrokePaint.shader = null

        for (sd in orb.fallingStardusts) {
            val pLifeMs = (stardustTotalMs * sd.lifeRatio).coerceAtLeast(180f)
            val t = (spawnElapsed / pLifeMs).coerceIn(0f, 1f)
            if (t <= 0.005f || t >= 0.995f) continue

            // 运动学轨迹：初段微向外/向上轻跃，随后在重力加速度下温柔下沉 (y = y0 + vy*t + 0.5*g*t^2)
            val easeX = 1f - (1f - t) * (1f - t)
            val curX = cx + sd.spawnXOffsetPx + sd.vxPx * easeX
            val curY = cy + sd.spawnYOffsetPx + sd.vyInitPx * t + sd.gravityPx * (t * t)

            val twinkle = 0.72f + 0.28f * sin(spawnElapsed * sd.twinkleFreq + sd.twinklePhase)
            val fadeEnv = if (t < 0.18f) (t / 0.18f) else (1f - ((t - 0.18f) / 0.82f).pow(1.45f))
            val alpha = (fadeEnv * twinkle).coerceIn(0f, 1f)
            if (alpha <= 0.02f) continue

            val tintCol = when (sd.colorVariant) {
                1 -> pal.meteorAccent1
                2 -> pal.meteorAccent2
                else -> pal.meteorPrimaryTint
            }
            val rT = if (pal.isLightSurface && sd.useDarkInkStyle) rDarkInk else Color.red(tintCol)
            val gT = if (pal.isLightSurface && sd.useDarkInkStyle) gDarkInk else Color.green(tintCol)
            val bT = if (pal.isLightSurface && sd.useDarkInkStyle) bDarkInk else Color.blue(tintCol)

            // 1. 绘制微尘沉落的纤细流星尾迹（向上逆推约 3~5dp 的极细渐隐流光丝）
            if (t > 0.12f) {
                val prevT = (t - 0.14f).coerceAtLeast(0f)
                val prevEaseX = 1f - (1f - prevT) * (1f - prevT)
                val tailX = cx + sd.spawnXOffsetPx + sd.vxPx * prevEaseX
                val tailY = cy + sd.spawnYOffsetPx + sd.vyInitPx * prevT + sd.gravityPx * (prevT * prevT)
                particleStrokePaint.strokeWidth = dpF(0.68f)
                particleStrokePaint.color = if (pal.isLightSurface) {
                    Color.argb((105f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
                } else {
                    Color.argb((115f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
                }
                canvas.drawLine(tailX, tailY, curX, curY, particleStrokePaint)
            }

            // 2. 绘制沉落中的微小四芒星尘 (✦ / ✧)
            val curRot = sd.rotationDeg + sd.spinDeg * t
            val curRay = sd.starRadiusPx * (0.85f + 0.15f * twinkle)
            if (sd.isHollowStar) {
                drawHollowFourPointStarlet(
                    canvas = canvas,
                    sx = curX,
                    sy = curY,
                    rayLenPx = curRay,
                    rotationDeg = curRot,
                    alpha = alpha,
                    rT = rT,
                    gT = gT,
                    bT = bT,
                    isLightSurface = pal.isLightSurface
                )
            } else {
                drawSolidFourPointStarlet(
                    canvas = canvas,
                    sx = curX,
                    sy = curY,
                    rayLenPx = curRay,
                    rotationDeg = curRot,
                    alpha = alpha,
                    rT = rT,
                    gT = gT,
                    bT = bT,
                    isLightSurface = pal.isLightSurface
                )
            }
        }
    }

    /**
     * 计算圆角矩形轮廓线在归一化弧长参数 u in [0, 1) 处的精确坐标 (px, py)、切向量 (tx, ty) 与外法线 (nx, ny)：
     * - 严格贴合键盘上任意按键（包括常规字母键、宽空格键、高功能键）的真实圆角矩形几何形状！
     * - 全程使用复用数组 out[0..5]，0 对象分配。
     */
    private fun evalRoundedRectPerimeter(
        cx: Float,
        cy: Float,
        hw: Float,
        hh: Float,
        cornerR: Float,
        rawU: Float,
        out: FloatArray
    ) {
        val r = cornerR.coerceIn(1f, min(hw, hh))
        val topLen = (2f * (hw - r)).coerceAtLeast(0f)
        val rightLen = (2f * (hh - r)).coerceAtLeast(0f)
        val arcLen = (0.5f * Math.PI.toFloat() * r).coerceAtLeast(0.5f)
        val totalPerim = (2f * topLen + 2f * rightLen + 4f * arcLen).coerceAtLeast(4f)

        var u = rawU % 1.0f
        if (u < 0f) u += 1.0f
        var s = u * totalPerim

        // 1. 顶边 (左 -> 右): x in [cx - hw + r, cx + hw - r], y = cy - hh
        if (s <= topLen) {
            out[0] = (cx - hw + r) + s
            out[1] = cy - hh
            out[2] = 1f; out[3] = 0f
            out[4] = 0f; out[5] = -1f
            return
        }
        s -= topLen

        // 2. 右上圆角: angle in [-PI/2, 0]
        if (s <= arcLen) {
            val ang = -0.5f * Math.PI.toFloat() + (s / arcLen) * (0.5f * Math.PI.toFloat())
            val ca = cos(ang); val sa = sin(ang)
            out[0] = (cx + hw - r) + r * ca
            out[1] = (cy - hh + r) + r * sa
            out[2] = -sa; out[3] = ca
            out[4] = ca; out[5] = sa
            return
        }
        s -= arcLen

        // 3. 右边 (上 -> 下): x = cx + hw, y in [cy - hh + r, cy + hh - r]
        if (s <= rightLen) {
            out[0] = cx + hw
            out[1] = (cy - hh + r) + s
            out[2] = 0f; out[3] = 1f
            out[4] = 1f; out[5] = 0f
            return
        }
        s -= rightLen

        // 4. 右下圆角: angle in [0, PI/2]
        if (s <= arcLen) {
            val ang = (s / arcLen) * (0.5f * Math.PI.toFloat())
            val ca = cos(ang); val sa = sin(ang)
            out[0] = (cx + hw - r) + r * ca
            out[1] = (cy + hh - r) + r * sa
            out[2] = -sa; out[3] = ca
            out[4] = ca; out[5] = sa
            return
        }
        s -= arcLen

        // 5. 底边 (右 -> 左): x in [cx + hw - r, cx - hw + r], y = cy + hh
        if (s <= topLen) {
            out[0] = (cx + hw - r) - s
            out[1] = cy + hh
            out[2] = -1f; out[3] = 0f
            out[4] = 0f; out[5] = 1f
            return
        }
        s -= topLen

        // 6. 左下圆角: angle in [PI/2, PI]
        if (s <= arcLen) {
            val ang = 0.5f * Math.PI.toFloat() + (s / arcLen) * (0.5f * Math.PI.toFloat())
            val ca = cos(ang); val sa = sin(ang)
            out[0] = (cx - hw + r) + r * ca
            out[1] = (cy + hh - r) + r * sa
            out[2] = -sa; out[3] = ca
            out[4] = ca; out[5] = sa
            return
        }
        s -= arcLen

        // 7. 左边 (下 -> 上): x = cx - hw, y in [cy + hh - r, cy - hh + r]
        if (s <= rightLen) {
            out[0] = cx - hw
            out[1] = (cy + hh - r) - s
            out[2] = 0f; out[3] = -1f
            out[4] = -1f; out[5] = 0f
            return
        }
        s -= rightLen

        // 8. 左上圆角: angle in [PI, 3*PI/2]
        val ang = Math.PI.toFloat() + (s / arcLen).coerceIn(0f, 1f) * (0.5f * Math.PI.toFloat())
        val ca = cos(ang); val sa = sin(ang)
        out[0] = (cx - hw + r) + r * ca
        out[1] = (cy - hh + r) + r * sa
        out[2] = -sa; out[3] = ca
        out[4] = ca; out[5] = sa
    }

    /**
     * 🌀/🐾 绘制浅色皮肤专属「键廓流光涡旋（视频1第2款）+ 键廓星泡萌爪（视频1第1款）」：
     * - 针对图2的四套常用浅色皮肤（莫奈晴空粉紫、紫雾星辰芋泥、焦糖拿铁燕麦、夜樱初绽豆沙粉）及所有自定义浅色皮肤深度校准取色：
     *   - 在浅色键帽（如 #F0DFEF、#F7EBDD、#FFF0F7、#B5D3F7）上：自动提取键帽同色系的温润莫兰迪中深色为主体色，
     *     内嵌珍珠纯白高光脊线与微暗折光边，既有水彩果冻般的清透感，又清晰醒目、0 荧光刺眼感！
     *   - 在深色跳色键（如 #4B3C5B、#9B6D4B、#8B4D5A、#425693）上：自动反转为同色系柔和粉彩亮光色 + 纯白高光芯！
     */
    private fun drawKeyContourVortexAndStarBubble(
        canvas: Canvas,
        orb: SpotlightOrb,
        spawnElapsed: Float,
        cvTotalMs: Float
    ) {
        if (cvTotalMs <= 1f || spawnElapsed >= cvTotalMs) return
        val overallT = (spawnElapsed / cvTotalMs).coerceIn(0f, 1f)
        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val baseHw = (orb.keyRect.width() * 0.5f).coerceAtLeast(dpF(14f))
        val baseHh = (orb.keyRect.height() * 0.5f).coerceAtLeast(dpF(14f))
        val baseCornerR = orb.keyCornerRadiusPx.coerceIn(dpF(5f), min(baseHw, baseHh))

        // 1. 根据当前按下的键帽颜色 (surfaceKeyBgColor) 与主题光晕色 (glowColor) 实时解算自适应三层配色
        val keyCol = orb.surfaceKeyBgColor
        val keyLum = (0.299f * Color.red(keyCol) + 0.587f * Color.green(keyCol) + 0.114f * Color.blue(keyCol)) / 255f
        val isLightKeyCap = keyLum >= 0.50f

        val keyHsv = FloatArray(3)
        val glowHsv = FloatArray(3)
        Color.colorToHSV(keyCol, keyHsv)
        Color.colorToHSV(orb.glowColor, glowHsv)

        // 若键帽本身接近奶白/纯白 (S < 0.09)，借用皮肤主题色相 glowHsv[0]；否则忠实采用当前键帽自身的色相（如莫奈蓝键发蓝光、粉键发粉光）
        val domHue = if (keyHsv[1] >= 0.09f) keyHsv[0] else glowHsv[0]
        val rawSat = max(keyHsv[1], glowHsv[1])

        val mainCol: Int
        val accentCol: Int
        val deepShadowCol: Int
        if (isLightKeyCap) {
            // 浅色键帽：采用温润饱满的莫兰迪中深色度 (S=0.36..0.54, V=0.58..0.74)，在极浅键帽上依然清晰灵动且绝不发荧光
            val mSat = (rawSat * 1.18f + 0.18f).coerceIn(0.36f, 0.55f)
            val mVal = (keyHsv[2] - 0.22f).coerceIn(0.56f, 0.74f)
            val shiftSign = if (domHue in 18f..65f) -14f else 16f
            val accHue = (domHue + shiftSign + 360f) % 360f
            mainCol = Color.HSVToColor(floatArrayOf(domHue, mSat, mVal))
            accentCol = Color.HSVToColor(floatArrayOf(accHue, (mSat * 0.92f).coerceIn(0.30f, 0.50f), (mVal + 0.08f).coerceIn(0.64f, 0.82f)))
            deepShadowCol = Color.HSVToColor(floatArrayOf(domHue, (mSat * 0.88f).coerceIn(0.28f, 0.48f), (mVal - 0.14f).coerceIn(0.42f, 0.58f)))
        } else {
            // 深色跳色键/功能键：自动切换为清透粉彩亮光色 (S=0.20..0.36, V=0.88..0.95)
            val mSat = (rawSat * 0.62f + 0.08f).coerceIn(0.20f, 0.36f)
            val mVal = 0.92f
            val accHue = (domHue + 16f) % 360f
            mainCol = Color.HSVToColor(floatArrayOf(domHue, mSat, mVal))
            accentCol = Color.HSVToColor(floatArrayOf(accHue, (mSat * 1.12f).coerceIn(0.22f, 0.40f), 0.86f))
            deepShadowCol = Color.HSVToColor(floatArrayOf(domHue, mSat, 0.68f))
        }

        val rMain = Color.red(mainCol); val gMain = Color.green(mainCol); val bMain = Color.blue(mainCol)
        val rAcc = Color.red(accentCol); val gAcc = Color.green(accentCol); val bAcc = Color.blue(accentCol)
        val rShad = Color.red(deepShadowCol); val gShad = Color.green(deepShadowCol); val bShad = Color.blue(deepShadowCol)

        val style = orb.contourVortexStyle
        val hasVortex = (style == STYLE_VORTEX_RING || style == STYLE_BOTH_COMBINED)
        val hasPawBubble = (style == STYLE_PAW_STAR_BUBBLE || style == STYLE_BOTH_COMBINED)

        particleFillPaint.shader = null
        particleStrokePaint.shader = null

        // =========================================================================
        // 效果 A（默认主力）：复刻视频1第1排第2款 · 贴合键帽圆角矩形形状的「键廓旋流弯月光环」
        // =========================================================================
        if (hasVortex) {
            // 1. 初段键心果冻光晕 + 空心化外扩圆角光环 (t = 0.00 .. 0.82)
            if (overallT < 0.82f) {
                val ringT = (overallT / 0.82f).coerceIn(0f, 1f)
                val inv = 1f - ringT
                val easeOut = 1f - inv * inv * inv
                val maxExpand = 1.03f + orb.contourVortexRangeNorm * 0.25f
                val curScale = 0.72f + (maxExpand - 0.72f) * easeOut
                val ringEnv = sin(ringT * Math.PI.toFloat()).pow(0.75f) * (1f - ringT * 0.25f)

                val rHw = baseHw * curScale
                val rHh = baseHh * curScale
                val rCorner = (baseCornerR * curScale).coerceAtMost(min(rHw, rHh))
                tmpRectF.set(cx - rHw, cy - rHh, cx + rHw, cy + rHh)

                // (a) 初段内聚果冻柔光环（前 48% 时间内从实心柔光逐渐空心化）
                if (overallT < 0.48f) {
                    val coreT = (overallT / 0.48f).coerceIn(0f, 1f)
                    val coreEnv = sin(coreT * Math.PI.toFloat())
                    val coreScale = 0.52f + 0.42f * (1f - (1f - coreT) * (1f - coreT))
                    val cHw = baseHw * coreScale
                    val cHh = baseHh * coreScale
                    val cCorner = (baseCornerR * coreScale).coerceAtMost(min(cHw, cHh))
                    val coreStroke = dpF(6.5f * (1f - coreT * 0.65f)).coerceAtLeast(dpF(1.4f))
                    particleStrokePaint.strokeWidth = coreStroke
                    particleStrokePaint.color = Color.argb((96f * coreEnv).toInt().coerceIn(0, 255), rAcc, gAcc, bAcc)
                    val innerRect = RectF(cx - cHw, cy - cHh, cx + cHw, cy + cHh)
                    canvas.drawRoundRect(innerRect, cCorner, cCorner, particleStrokePaint)
                }

                // (b) 外廓贴合键形的莫兰迪流光环 + 纯白细高光内芯
                val haloStroke = dpF(2.4f * (1f - ringT * 0.45f)).coerceAtLeast(dpF(0.9f))
                particleStrokePaint.strokeWidth = haloStroke * 1.45f
                particleStrokePaint.color = Color.argb((145f * ringEnv).toInt().coerceIn(0, 255), rMain, gMain, bMain)
                canvas.drawRoundRect(tmpRectF, rCorner, rCorner, particleStrokePaint)

                particleStrokePaint.strokeWidth = (haloStroke * 0.55f).coerceAtLeast(dpF(0.65f))
                particleStrokePaint.color = Color.argb((215f * ringEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawRoundRect(tmpRectF, rCorner, rCorner, particleStrokePaint)
            }

            // 2. 初段向外放射迸射的「梭形流光叶瓣」(Radial Spindle Petals, 复刻视频第2款前4帧的花瓣光针)
            for (petal in orb.contourSpindlePetals) {
                if (overallT >= petal.lifeRatio) continue
                val pt = (overallT / petal.lifeRatio).coerceIn(0f, 1f)
                val ease = 1f - (1f - pt) * (1f - pt)
                val env = sin(pt * Math.PI.toFloat()).pow(0.7f)
                if (env <= 0.02f) continue

                val curScale = petal.startScale + (petal.endScale - petal.startScale) * ease
                val ux = cos(petal.angleRad)
                val uy = sin(petal.angleRad)
                val edgeR = computeKeyEdgeDist(baseHw, baseHh, petal.angleRad) * curScale
                val curLen = petal.lengthPx * sin(pt * Math.PI.toFloat()).coerceAtLeast(0.25f)
                val hwP = petal.halfWidthPx * (1f - pt * 0.35f)
                val px = -uy
                val py = ux

                val tailX = cx + ux * (edgeR - curLen * 0.55f)
                val tailY = cy + uy * (edgeR - curLen * 0.55f)
                val midX = cx + ux * (edgeR + curLen * 0.08f)
                val midY = cy + uy * (edgeR + curLen * 0.08f)
                val tipX = cx + ux * (edgeR + curLen * 0.55f)
                val tipY = cy + uy * (edgeR + curLen * 0.55f)

                starPath.reset()
                starPath.moveTo(tailX, tailY)
                starPath.quadTo(midX + px * hwP, midY + py * hwP, tipX, tipY)
                starPath.quadTo(midX - px * hwP, midY - py * hwP, tailX, tailY)
                starPath.close()

                val pR = if (petal.useAccentTint) rAcc else rMain
                val pG = if (petal.useAccentTint) gAcc else gMain
                val pB = if (petal.useAccentTint) bAcc else bMain
                particleFillPaint.color = Color.argb((195f * env).toInt().coerceIn(0, 255), pR, pG, pB)
                canvas.drawPath(starPath, particleFillPaint)

                // 梭形花瓣内嵌纯白亮芯
                val coreHw = hwP * 0.48f
                starPath.reset()
                starPath.moveTo(tailX + ux * curLen * 0.18f, tailY + uy * curLen * 0.18f)
                starPath.quadTo(midX + px * coreHw, midY + py * coreHw, tipX - ux * curLen * 0.12f, tipY - uy * curLen * 0.12f)
                starPath.quadTo(midX - px * coreHw, midY - py * coreHw, tailX + ux * curLen * 0.18f, tailY + uy * curLen * 0.18f)
                starPath.close()
                particleFillPaint.color = Color.argb((235f * env).toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawPath(starPath, particleFillPaint)
            }

            // 3. 沿着圆角矩形键廓回旋滑行的「双层旋流弯月丝带」(KeyContourSwirlRibbons, 视频第2款灵魂核心！)
            val segCount = 12
            for (rib in orb.contourSwirlRibbons) {
                val localT = ((overallT - rib.delayRatio) / (rib.lifeRatio - rib.delayRatio).coerceAtLeast(0.15f)).coerceIn(0f, 1f)
                if (localT <= 0.005f || localT >= 0.995f) continue

                val inv = 1f - localT
                val ease = 1f - inv * inv * inv
                val env = sin(localT * Math.PI.toFloat()).pow(0.68f) * (1f - localT * 0.20f)
                if (env <= 0.02f) continue

                val curScale = rib.startScale + (rib.endScale - rib.startScale) * ease
                val curHw = baseHw * curScale
                val curHh = baseHh * curScale
                val curCornerR = (baseCornerR * curScale).coerceAtMost(min(curHw, curHh))

                val curStartU = rib.startPerimeterU + rib.travelSpeedU * ease
                // 旋流丝带随时间逐渐舒展并在末段收束变细
                val curArcLenU = rib.arcLengthU * (0.72f + 0.42f * sin(localT * Math.PI.toFloat()))
                val curMaxThick = rib.maxThicknessPx * (1.05f - 0.45f * localT)

                ribbonPath.reset()
                // 先沿丝带外侧边缘从尾 (i=0) 到头 (i=segCount) 采样
                for (i in 0..segCount) {
                    val frac = i.toFloat() / segCount.toFloat()
                    val u = curStartU + frac * curArcLenU
                    evalRoundedRectPerimeter(cx, cy, curHw, curHh, curCornerR, u, contourPtOut)
                    // 弯月剖面：尾部 0 -> 前部 68% 处最饱满 -> 头部尖端 0
                    val profile = sin(frac * Math.PI.toFloat()) * (0.55f + 0.65f * frac)
                    val halfW = curMaxThick * 0.5f * profile
                    val waveOff = rib.radialWavePx * sin((frac * 1.5f + localT) * Math.PI.toFloat()) * (1f - localT * 0.5f)
                    val ox = contourPtOut[0] + contourPtOut[4] * (waveOff + halfW)
                    val oy = contourPtOut[1] + contourPtOut[5] * (waveOff + halfW)
                    if (i == 0) ribbonPath.moveTo(ox, oy) else ribbonPath.lineTo(ox, oy)
                }
                // 再沿丝带内侧边缘从头 (i=segCount-1) 回到尾 (i=0)
                for (i in (segCount - 1) downTo 0) {
                    val frac = i.toFloat() / segCount.toFloat()
                    val u = curStartU + frac * curArcLenU
                    evalRoundedRectPerimeter(cx, cy, curHw, curHh, curCornerR, u, contourPtOut)
                    val profile = sin(frac * Math.PI.toFloat()) * (0.55f + 0.65f * frac)
                    val halfW = curMaxThick * 0.5f * profile
                    val waveOff = rib.radialWavePx * sin((frac * 1.5f + localT) * Math.PI.toFloat()) * (1f - localT * 0.5f)
                    val ix = contourPtOut[0] + contourPtOut[4] * (waveOff - halfW)
                    val iy = contourPtOut[1] + contourPtOut[5] * (waveOff - halfW)
                    ribbonPath.lineTo(ix, iy)
                }
                ribbonPath.close()

                // 3.1 浅色键帽下先衬一层极柔的深色折光底影，确保旋流丝带在 #FFF0F7 / #F7EBDD 上立体分明
                if (isLightKeyCap) {
                    particleStrokePaint.strokeWidth = dpF(0.95f)
                    particleStrokePaint.color = Color.argb((95f * env).toInt().coerceIn(0, 255), rShad, gShad, bShad)
                    canvas.drawPath(ribbonPath, particleStrokePaint)
                }

                // 3.2 旋流弯月丝带主体色（主色与伴生色交错）
                val bR = if (rib.useAccentTint) rAcc else rMain
                val bG = if (rib.useAccentTint) gAcc else gMain
                val bB = if (rib.useAccentTint) bAcc else bMain
                particleFillPaint.color = Color.argb((220f * env).toInt().coerceIn(0, 255), bR, bG, bB)
                canvas.drawPath(ribbonPath, particleFillPaint)

                // 3.3 丝带中心纯白高光脊线（赋予视频1第2款的水晶果冻光泽）
                ribbonPath.reset()
                for (i in 2..(segCount - 1)) {
                    val frac = i.toFloat() / segCount.toFloat()
                    val u = curStartU + frac * curArcLenU
                    evalRoundedRectPerimeter(cx, cy, curHw, curHh, curCornerR, u, contourPtOut)
                    val waveOff = rib.radialWavePx * sin((frac * 1.5f + localT) * Math.PI.toFloat()) * (1f - localT * 0.5f)
                    val sx = contourPtOut[0] + contourPtOut[4] * waveOff
                    val sy = contourPtOut[1] + contourPtOut[5] * waveOff
                    if (i == 2) ribbonPath.moveTo(sx, sy) else ribbonPath.lineTo(sx, sy)
                }
                particleStrokePaint.strokeWidth = (curMaxThick * 0.36f).coerceAtLeast(dpF(0.65f))
                particleStrokePaint.color = Color.argb((238f * env).toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawPath(ribbonPath, particleStrokePaint)
            }
        }

        // =========================================================================
        // 效果 B（可选切换/叠加）：复刻视频1第1排第1款 · 贴合键帽圆角矩形形状的「键廓星泡萌爪」
        // =========================================================================
        if (hasPawBubble) {
            val bubT = overallT
            val inv = 1f - bubT
            val easeOut = 1f - inv * inv * inv
            val maxExpand = 1.02f + orb.contourVortexRangeNorm * 0.22f
            val curScale = 0.76f + (maxExpand - 0.76f) * easeOut
            val bubEnv = sin(bubT * Math.PI.toFloat()).pow(0.72f) * (1f - bubT * 0.22f)

            val bHw = baseHw * curScale
            val bHh = baseHh * curScale
            val bCorner = (baseCornerR * curScale).coerceAtMost(min(bHw, bHh))
            tmpRectF.set(cx - bHw, cy - bHh, cx + bHw, cy + bHh)

            // 1. 圆角矩形幻彩双色气泡外框
            val rimStroke = dpF(2.1f * (1f - bubT * 0.38f)).coerceAtLeast(dpF(0.85f))
            particleStrokePaint.strokeWidth = rimStroke * 1.35f
            particleStrokePaint.color = Color.argb((155f * bubEnv).toInt().coerceIn(0, 255), rMain, gMain, bMain)
            canvas.drawRoundRect(tmpRectF, bCorner, bCorner, particleStrokePaint)

            val innerRect = RectF(cx - bHw + rimStroke * 0.7f, cy - bHh + rimStroke * 0.7f, cx + bHw - rimStroke * 0.7f, cy + bHh - rimStroke * 0.7f)
            particleStrokePaint.strokeWidth = (rimStroke * 0.65f).coerceAtLeast(dpF(0.65f))
            particleStrokePaint.color = Color.argb((230f * bubEnv).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRoundRect(innerRect, (bCorner - rimStroke * 0.5f).coerceAtLeast(dpF(4f)), (bCorner - rimStroke * 0.5f).coerceAtLeast(dpF(4f)), particleStrokePaint)

            // 2. 键心半透明果冻萌爪肉垫印记 (前 58% 时间内轻柔浮现并化作星泡消散)
            if (bubT < 0.58f) {
                val pawT = (bubT / 0.58f).coerceIn(0f, 1f)
                val pawEnv = sin(pawT * Math.PI.toFloat()).pow(0.75f)
                val pawScale = (0.72f + 0.34f * (1f - (1f - pawT) * (1f - pawT))) * (min(baseHw, baseHh) / dpF(20f)).coerceIn(0.65f, 1.25f)
                val padRx = dpF(5.6f) * pawScale
                val padRy = dpF(4.2f) * pawScale
                val padCy = cy + dpF(2.2f) * pawScale

                // 掌心大肉垫（外层主题色 + 内层纯白柔光芯）
                tmpRectF.set(cx - padRx, padCy - padRy, cx + padRx, padCy + padRy)
                particleFillPaint.color = Color.argb((150f * pawEnv).toInt().coerceIn(0, 255), rMain, gMain, bMain)
                canvas.drawOval(tmpRectF, particleFillPaint)
                tmpRectF.set(cx - padRx * 0.68f, padCy - padRy * 0.68f, cx + padRx * 0.68f, padCy + padRy * 0.68f)
                particleFillPaint.color = Color.argb((195f * pawEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawOval(tmpRectF, particleFillPaint)

                // 4 颗小趾豆
                val beanAngles = floatArrayOf(-2.22f, -1.76f, -1.38f, -0.92f)
                val beanDist = dpF(7.8f) * pawScale
                val beanR = dpF(2.1f) * pawScale
                for (bAng in beanAngles) {
                    val bx = cx + cos(bAng) * beanDist * 1.12f
                    val by = padCy + sin(bAng) * beanDist * 0.92f
                    particleFillPaint.color = Color.argb((155f * pawEnv).toInt().coerceIn(0, 255), rAcc, gAcc, bAcc)
                    canvas.drawCircle(bx, by, beanR, particleFillPaint)
                    particleFillPaint.color = Color.argb((210f * pawEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(bx, by, beanR * 0.58f, particleFillPaint)
                }
            }
        }

        // =========================================================================
        // 环绕圆角矩形键廓的伴生粒子（✦ 十字四芒星闪 / • 微光露珠 / ★ 五角萌星 / ○ 幻彩小气泡）
        // =========================================================================
        for (sp in orb.contourSparksAndBubbles) {
            val localT = ((overallT - sp.delayRatio) / (sp.lifeRatio - sp.delayRatio).coerceAtLeast(0.15f)).coerceIn(0f, 1f)
            if (localT <= 0.005f || localT >= 0.995f) continue

            val ease = 1f - (1f - localT) * (1f - localT)
            val twinkle = 0.72f + 0.28f * sin(spawnElapsed * sp.twinkleFreq + sp.twinklePhase)
            val env = sin(localT * Math.PI.toFloat()).pow(0.72f) * twinkle
            if (env <= 0.02f) continue

            val curScale = sp.startScale + (sp.endScale - sp.startScale) * ease
            val curHw = baseHw * curScale
            val curHh = baseHh * curScale
            val curCornerR = (baseCornerR * curScale).coerceAtMost(min(curHw, curHh))
            val curU = sp.perimeterU + sp.driftU * ease

            evalRoundedRectPerimeter(cx, cy, curHw, curHh, curCornerR, curU, contourPtOut)
            val sx = contourPtOut[0]
            val sy = contourPtOut[1]
            val curSize = sp.sizePx * (1.08f - 0.35f * localT)

            val cR = when (sp.colorVariant) {
                0 -> rMain
                1 -> rAcc
                else -> rShad
            }
            val cG = when (sp.colorVariant) {
                0 -> gMain
                1 -> gAcc
                else -> gShad
            }
            val cB = when (sp.colorVariant) {
                0 -> bMain
                1 -> bAcc
                else -> bShad
            }

            when (sp.kind) {
                0 -> {
                    // ✦ 十字四芒星闪（视频1第2款标志性星芒：外衬莫兰迪光晕 + 纯白纤细十字星芯）
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        rayLenPx = curSize * 1.35f,
                        rotationDeg = sp.rotationDeg + sp.spinDeg * localT,
                        alpha = env,
                        rT = cR,
                        gT = cG,
                        bT = cB,
                        isLightSurface = isLightKeyCap
                    )
                }
                2 -> {
                    // ★ 圆润五角萌星（视频1第1款标志性五角星）
                    drawPlumpFivePointStar(
                        canvas = canvas,
                        sx = sx,
                        sy = sy,
                        outerR = curSize * 1.25f,
                        rotationDeg = sp.rotationDeg + sp.spinDeg * localT,
                        alpha = env,
                        rT = cR,
                        gT = cG,
                        bT = cB,
                        rShad = rShad,
                        gShad = gShad,
                        bShad = bShad,
                        isLightKeyCap = isLightKeyCap
                    )
                }
                3 -> {
                    // ○ 幻彩微气泡（视频1第1款伴生小气泡 + 左上纯白高光点）
                    particleStrokePaint.strokeWidth = dpF(0.95f)
                    particleStrokePaint.color = Color.argb((185f * env).toInt().coerceIn(0, 255), cR, cG, cB)
                    canvas.drawCircle(sx, sy, curSize, particleStrokePaint)
                    particleFillPaint.color = Color.argb((235f * env).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx - curSize * 0.35f, sy - curSize * 0.35f, (curSize * 0.28f).coerceAtLeast(dpF(0.6f)), particleFillPaint)
                }
                else -> {
                    // • 伴生微光露珠（外圈同色系莫兰迪柔光 + 中心纯白亮珠）
                    particleFillPaint.color = Color.argb((175f * env).toInt().coerceIn(0, 255), cR, cG, cB)
                    canvas.drawCircle(sx, sy, curSize * 1.45f, particleFillPaint)
                    particleFillPaint.color = Color.argb((245f * env).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx, sy, curSize * 0.78f, particleFillPaint)
                }
            }
        }
    }

    private fun drawPlumpFivePointStar(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        outerR: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int,
        rShad: Int,
        gShad: Int,
        bShad: Int,
        isLightKeyCap: Boolean
    ) {
        val innerR = outerR * 0.48f
        val baseRad = Math.toRadians(rotationDeg.toDouble()).toFloat() - 0.5f * Math.PI.toFloat()
        val stepRad = (Math.PI / 5.0).toFloat()
        starPath.reset()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outerR else innerR
            val ang = baseRad + i * stepRad
            val px = sx + cos(ang) * r
            val py = sy + sin(ang) * r
            if (i == 0) starPath.moveTo(px, py) else starPath.lineTo(px, py)
        }
        starPath.close()

        if (isLightKeyCap) {
            particleStrokePaint.strokeWidth = dpF(0.85f)
            particleStrokePaint.color = Color.argb((110f * alpha).toInt().coerceIn(0, 255), rShad, gShad, bShad)
            canvas.drawPath(starPath, particleStrokePaint)
        }
        particleFillPaint.color = Color.argb((220f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
        canvas.drawPath(starPath, particleFillPaint)
        particleFillPaint.color = Color.argb((240f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawCircle(sx, sy, outerR * 0.34f, particleFillPaint)
    }

    /**
     * 🌸 绘制参考视频2同款「按键上面变色 + 下面有同色光晕显示 + 键面微光小烟花（此刻心动）」：
     * 1. 四周与键底同色柔雾大光晕：采用与键面变色完全同源的 blushHaloColor，通过 EVEN_ODD 精确镂空当前键帽中心，
     *    在键缝与四周 16~44dp 范围内晕开温润饱满的同色系大光晕（绝不遮挡当前按键文字，又让浅色皮肤下的背光光晕像视频一样明显！）；
     * 2. 预览层/键面柔焦腮红与微光内框：在状态栏预览条或键帽边沿叠加柔焦高光；
     * 3. 键面右上角精致 8 芒微烟花 (✺) + 四芒微星 (✦) + 幻彩小星泡 (○)：1:1 还原参考视频按下时键帽上的星火点缀！
     */
    private fun drawKeyBlushAndMatchingHalo(
        canvas: Canvas,
        orb: SpotlightOrb,
        now: Long,
        spawnElapsed: Float,
        bhHoldMs: Float,
        bhFadeMs: Float
    ) {
        val bhProgress: Float
        if (orb.releaseTime == 0L) {
            bhProgress = 1.0f
        } else {
            val elapsed = (now - orb.releaseTime).coerceAtLeast(0L).toFloat()
            val total = bhHoldMs + bhFadeMs
            if (elapsed >= total) return
            bhProgress = if (elapsed <= bhHoldMs) {
                1.0f - 0.06f * (elapsed / bhHoldMs.coerceAtLeast(1f))
            } else {
                val t = ((elapsed - bhHoldMs) / bhFadeMs.coerceAtLeast(1f)).coerceIn(0f, 1f)
                0.94f * (1f - t) * (1f - 0.35f * t)
            }
        }
        if (bhProgress <= 0.01f) return

        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY()
        val baseHw = (orb.keyRect.width() * 0.5f).coerceAtLeast(dpF(14f))
        val baseHh = (orb.keyRect.height() * 0.5f).coerceAtLeast(dpF(14f))
        val cornerR = orb.keyCornerRadiusPx.coerceIn(dpF(5f), min(baseHw, baseHh))

        val densityScale = (0.58f + orb.keyBlushHaloDensityNorm * 0.42f).coerceIn(0.45f, 1.0f)
        val env = (bhProgress * densityScale).coerceIn(0f, 1f)

        val rTop = Color.red(orb.blushTopColor)
        val gTop = Color.green(orb.blushTopColor)
        val bTop = Color.blue(orb.blushTopColor)
        val rBot = Color.red(orb.blushBotColor)
        val gBot = Color.green(orb.blushBotColor)
        val bBot = Color.blue(orb.blushBotColor)
        val rHalo = Color.red(orb.blushHaloColor)
        val gHalo = Color.green(orb.blushHaloColor)
        val bHalo = Color.blue(orb.blushHaloColor)

        // 1. 绘制按键下面与四周扩散的「同色系柔雾大光晕」（视频同款：围绕按键四周柔润晕开）
        val spreadPx = dpF(16f + orb.keyBlushHaloRangeNorm * 28f)
        val rxHalo = baseHw + spreadPx
        val ryHalo = baseHh + spreadPx

        val saveHalo = canvas.save()
        if (renderLayerMode == LAYER_OVER_SPARKLE) {
            // 精确镂空当前按下的键帽内部区域（向内微缩 1.5dp 以实现无缝边缘衔接），
            // 确保外层同色光晕只在按键四周缝隙与邻键外缘晕染，绝不遮盖当前按键上变白的清晰文字！
            keyHoleClipPath.reset()
            keyHoleClipPath.fillType = Path.FillType.EVEN_ODD
            keyHoleClipPath.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val inset = dpF(1.5f)
            tmpRectF.set(
                orb.keyRect.left + inset,
                orb.keyRect.top + inset,
                orb.keyRect.right - inset,
                orb.keyRect.bottom - inset
            )
            val kr = (cornerR - inset * 0.5f).coerceAtLeast(dpF(4f))
            keyHoleClipPath.addRoundRect(tmpRectF, kr, kr, Path.Direction.CW)
            canvas.clipPath(keyHoleClipPath)
        }

        val haloPeakAlpha = (210f * env).toInt().coerceIn(0, 240)
        val haloMidAlpha = (138f * env).toInt().coerceIn(0, 210)
        val haloSoftAlpha = (64f * env).toInt().coerceIn(0, 160)
        val outerHaloGrad = RadialGradient(
            0f, 0f, 100f,
            intArrayOf(
                Color.argb(haloPeakAlpha, rHalo, gHalo, bHalo),
                Color.argb(haloPeakAlpha, rHalo, gHalo, bHalo),
                Color.argb(haloMidAlpha, rHalo, gHalo, bHalo),
                Color.argb(haloSoftAlpha, rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.36f, 0.58f, 0.80f, 1.0f),
            Shader.TileMode.CLAMP
        )
        shaderMatrix.reset()
        shaderMatrix.setScale(rxHalo / 100f, ryHalo / 100f)
        shaderMatrix.postTranslate(cx, cy)
        outerHaloGrad.setLocalMatrix(shaderMatrix)
        particleFillPaint.shader = outerHaloGrad
        tmpRectF.set(cx - rxHalo, cy - ryHalo, cx + rxHalo, cy + ryHalo)
        canvas.drawOval(tmpRectF, particleFillPaint)
        particleFillPaint.shader = null
        canvas.restoreToCount(saveHalo)

        // 2. 若为状态栏预览模式 (LAYER_FULL_COMBINED) 或开启了「按键上面变色」，绘制键面腮红柔光边缘与小烟花
        if (orb.keyBlushHaloStyle != STYLE_HALO_ONLY) {
            if (renderLayerMode == LAYER_FULL_COMBINED) {
                // 在状态栏快捷菜单预览卡片中直接渲染变色虚拟键帽
                val previewGrad = LinearGradient(
                    cx, orb.keyRect.top, cx, orb.keyRect.bottom,
                    Color.argb((235f * env).toInt().coerceIn(0, 255), rTop, gTop, bTop),
                    Color.argb((220f * env).toInt().coerceIn(0, 255), rBot, gBot, bBot),
                    Shader.TileMode.CLAMP
                )
                particleFillPaint.shader = previewGrad
                canvas.drawRoundRect(orb.keyRect, cornerR, cornerR, particleFillPaint)
                particleFillPaint.shader = null
            }

            // 键帽边缘 1.15dp 柔白水晶内高光框（复刻视频中变色按键四周的精致柔亮包边）
            val rimInset = dpF(0.6f)
            tmpRectF.set(
                orb.keyRect.left + rimInset,
                orb.keyRect.top + rimInset,
                orb.keyRect.right - rimInset,
                orb.keyRect.bottom - rimInset
            )
            particleStrokePaint.shader = null
            particleStrokePaint.strokeWidth = dpF(1.15f)
            particleStrokePaint.color = Color.argb((175f * env).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawRoundRect(tmpRectF, cornerR, cornerR, particleStrokePaint)
        }

        // 3. 视频1:1同款「键面微光 8 芒小烟花 (✺) + 四芒微星 (✦) + 幻彩小气泡 (○)」
        if (orb.keyBlushHaloStyle == STYLE_BLUSH_HALO_SPARKLE) {
            val sparkLifeMs = 460f / (0.52f + orb.keyBlushHaloSpeedNorm * 0.96f)
            if (spawnElapsed < sparkLifeMs) {
                val st = (spawnElapsed / sparkLifeMs).coerceIn(0f, 1f)
                val ease = 1f - (1f - st) * (1f - st)
                val sparkEnv = sin(st * Math.PI.toFloat()).pow(0.65f) * env
                if (sparkEnv > 0.02f) {
                    // 小烟花中心位于键帽中偏右上位置（完全复刻参考视频 6.8s PQRS 与 10.8s TUV 的烟花位置）
                    val fx = cx + baseHw * 0.18f
                    val fy = cy - baseHh * 0.16f - dpF(2.5f) * ease
                    val innerR = dpF(1.2f + 1.8f * ease)
                    val outerR = dpF(3.8f + 3.6f * ease)

                    // 8 道暖香槟金 + 纯白水滴状小烟花射线
                    for (rayIdx in 0 until 8) {
                        val ang = rayIdx * (Math.PI.toFloat() * 0.25f) + st * 0.22f
                        val ca = cos(ang)
                        val sa = sin(ang)
                        val x1 = fx + ca * innerR
                        val y1 = fy + sa * innerR
                        val x2 = fx + ca * outerR
                        val y2 = fy + sa * outerR

                        particleStrokePaint.strokeWidth = dpF(1.45f * (1f - st * 0.35f))
                        particleStrokePaint.color = Color.argb((210f * sparkEnv).toInt().coerceIn(0, 255), 255, 236, 175)
                        canvas.drawLine(x1, y1, x2, y2, particleStrokePaint)

                        particleStrokePaint.strokeWidth = dpF(0.85f * (1f - st * 0.35f))
                        particleStrokePaint.color = Color.argb((248f * sparkEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                        canvas.drawLine(x1, y1, x2, y2, particleStrokePaint)
                    }

                    // 烟花中心暖金亮珠
                    particleFillPaint.color = Color.argb((235f * sparkEnv).toInt().coerceIn(0, 255), 255, 245, 200)
                    canvas.drawCircle(fx, fy, dpF(1.1f), particleFillPaint)

                    // 左侧伴生精致小四芒星 ✦
                    val starX = fx - dpF(6.8f + 1.8f * ease)
                    val starY = fy + dpF(1.2f - 1.5f * ease)
                    drawSolidFourPointStarlet(
                        canvas = canvas,
                        sx = starX,
                        sy = starY,
                        rayLenPx = dpF(3.4f * (1f - st * 0.25f)),
                        rotationDeg = 12f + st * 25f,
                        alpha = sparkEnv,
                        rT = 255,
                        gT = 235,
                        bT = 175,
                        isLightSurface = false
                    )

                    // 右上与左下两颗透明小星泡 ○
                    particleStrokePaint.strokeWidth = dpF(0.85f)
                    particleStrokePaint.color = Color.argb((215f * sparkEnv).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(fx + dpF(4.2f + 2.0f * ease), fy - dpF(3.6f + 1.8f * ease), dpF(1.65f), particleStrokePaint)
                    canvas.drawCircle(fx - dpF(3.5f + 1.5f * ease), fy - dpF(4.2f + 1.5f * ease), dpF(1.15f), particleStrokePaint)
                }
            }
        }
    }

    private val bearBmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bearSrcRect = Rect()
    private val bearDstRectF = RectF()

    /**
     * 🐻 1:1 复刻《面包脑袋》演示视频「按键点击弹出 Q 弹小熊脑袋贴纸 + 四角金色星芒」：
     * - 按下瞬间小熊贴纸从键心以微弹簧曲线 (0.50x -> 1.08x -> 1.00x) 啵地弹出，伴随轻柔晃脑与四角小黄星闪烁；
     * - 松手后轻盈上浮消散，丝滑不挡字。
     */
    private fun drawBreadBearPopupSticker(
        canvas: Canvas,
        orb: SpotlightOrb,
        now: Long,
        spawnElapsed: Float,
        bhHoldMs: Float,
        bhFadeMs: Float
    ) {
        val bearBmp = MonetTextureManager.getBreadPopupBearBitmap(context, orb.bearStickerIndex) ?: return
        if (bearBmp.width <= 0 || bearBmp.height <= 0) return

        val alphaEnv: Float
        val releaseLiftRatio: Float
        if (orb.releaseTime == 0L) {
            alphaEnv = (spawnElapsed / 75f).coerceIn(0.25f, 1.0f)
            releaseLiftRatio = 0f
        } else {
            val elapsed = (now - orb.releaseTime).coerceAtLeast(0L).toFloat()
            val total = (bhHoldMs + bhFadeMs * 0.82f).coerceAtLeast(180f)
            if (elapsed >= total) return
            val t = (elapsed / total).coerceIn(0f, 1f)
            alphaEnv = (1f - t * t).coerceIn(0f, 1f)
            releaseLiftRatio = t
        }
        if (alphaEnv <= 0.02f) return

        // Q 弹微弹簧缩放曲线：0~140ms 从 0.52 弹至 1.08 再回落到 1.00
        val popT = (spawnElapsed / 145f).coerceIn(0f, 1f)
        val springScale = if (popT < 0.72f) {
            val u = popT / 0.72f
            0.52f + 0.56f * (1f - (1f - u) * (1f - u))
        } else {
            val u = (popT - 0.72f) / 0.28f
            1.08f - 0.08f * u
        } * (1f - 0.16f * releaseLiftRatio)

        val cx = orb.keyRect.centerX()
        val cy = orb.keyRect.centerY() - dpF(2.2f) - dpF(5.5f) * releaseLiftRatio
        val baseSide = min(orb.keyRect.width(), orb.keyRect.height()).coerceIn(dpF(28f), dpF(54f)) * 0.88f
        val drawSize = baseSide * springScale
        val halfS = drawSize * 0.5f

        val tiltDeg = sin(spawnElapsed * 0.014f + orb.bearStickerIndex * 1.3f) * 4.2f

        val sc = canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(tiltDeg)

        bearBmpPaint.alpha = (252f * alphaEnv).toInt().coerceIn(0, 255)
        bearSrcRect.set(0, 0, bearBmp.width, bearBmp.height)
        bearDstRectF.set(-halfS, -halfS, halfS, halfS)
        canvas.drawBitmap(bearBmp, bearSrcRect, bearDstRectF, bearBmpPaint)
        canvas.restoreToCount(sc)

        // 伴生四角金色五角萌星 (⭐) 与四芒闪星 (✦)
        val starAlpha = (alphaEnv * (1f - 0.25f * releaseLiftRatio)).coerceIn(0f, 1f)
        if (starAlpha > 0.05f) {
            val hw = orb.keyRect.width() * 0.44f
            val hh = orb.keyRect.height() * 0.40f
            val drift = dpF(3.5f) * (spawnElapsed / 380f).coerceIn(0f, 1f)
            // 左下与右上圆润小黄星 ⭐
            drawPlumpFivePointStar(
                canvas = canvas,
                sx = cx - hw - drift * 0.6f,
                sy = cy + hh * 0.65f - drift * 0.4f,
                outerR = dpF(4.6f) * springScale,
                rotationDeg = -15f + spawnElapsed * 0.06f,
                alpha = starAlpha,
                rT = 250, gT = 212, bT = 92,
                rShad = 196, gShad = 142, bShad = 48,
                isLightKeyCap = true
            )
            drawPlumpFivePointStar(
                canvas = canvas,
                sx = cx + hw + drift * 0.5f,
                sy = cy - hh * 0.72f - drift * 0.5f,
                outerR = dpF(3.8f) * springScale,
                rotationDeg = 18f - spawnElapsed * 0.05f,
                alpha = starAlpha * 0.92f,
                rT = 252, gT = 220, bT = 108,
                rShad = 196, gShad = 142, bShad = 48,
                isLightKeyCap = true
            )
            // 左上与右下四芒金星 ✦
            drawSolidFourPointStarlet(
                canvas = canvas,
                sx = cx - hw * 0.85f,
                sy = cy - hh * 0.78f - drift * 0.5f,
                rayLenPx = dpF(3.8f) * springScale,
                rotationDeg = 8f,
                alpha = starAlpha,
                rT = 255, gT = 224, bT = 115,
                isLightSurface = false
            )
            drawSolidFourPointStarlet(
                canvas = canvas,
                sx = cx + hw * 0.90f,
                sy = cy + hh * 0.70f,
                rayLenPx = dpF(3.2f) * springScale,
                rotationDeg = -12f,
                alpha = starAlpha * 0.88f,
                rT = 255, gT = 224, bT = 115,
                isLightSurface = false
            )
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 统一按键与顶栏背景视图（支持三大渲染模式）：
 * 1. 莫奈花园模式 (bitmap != null)：渲染 1:1 油画睡莲键帽贴图；
 * 2. 纯色框架 + 已上传自定义背景图模式 (useFrostedCustomBg = true)：
 *    自动定位当前按键在键盘中的坐标，实时读取并模糊对应位置的底图 (CustomBgManager.getBlurredBitmap)，
 *    再叠加半透明毛玻璃键帽底色与细腻磨砂白边；
 * 3. 纯色框架默认模式：渲染干净的纯色键帽，按下时自动呈现柔和同色系反馈。
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    val glowColor: Int = Color.parseColor("#528262"),
    val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT,
    private val useFrostedCustomBg: Boolean = false
) : View(context) {

    private var pressStartMs: Long = 0L
    private var pressReleaseMs: Long = 0L
    private val blushColorBuf = IntArray(3)
    private val blushOverlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val blushRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private var cachedSiblingTextViews: List<Pair<TextView, Int>>? = null
    private var lastAppliedWhiteMix: Float = 0f

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                val now = SystemClock.uptimeMillis()
                if (value) {
                    pressStartMs = now
                    pressReleaseMs = 0L
                    KeySoundManager.playClick(context)
                } else {
                    pressReleaseMs = now
                }
                if (enableGlow) {
                    val bgSample = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else null
                    forEachBacklightOverlay { overlay ->
                        if (value) {
                            overlay.triggerKeyDown(this, cornerRadiusPx, glowColor, bgSample)
                        } else {
                            overlay.triggerKeyUp(this)
                        }
                    }
                }
                invalidate()
            }
        }

    private var cachedOverlays: List<KeyboardBacklightOverlayView>? = null

    private inline fun forEachBacklightOverlay(action: (KeyboardBacklightOverlayView) -> Unit) {
        val existing = cachedOverlays
        if (existing != null) {
            for (ov in existing) action(ov)
            return
        }
        var p = parent
        val found = ArrayList<KeyboardBacklightOverlayView>(2)
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    found.add(child)
                }
            }
            if (found.isNotEmpty()) {
                cachedOverlays = found
                for (ov in found) action(ov)
                return
            }
            p = p.parent
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        restoreSiblingTextColorsIfNeeded()
        cachedSiblingTextViews = null
        cachedOverlays = null
        frostedCoordsValid = false
    }

    private fun ensureSiblingTextViews(): List<Pair<TextView, Int>> {
        cachedSiblingTextViews?.let { return it }
        val p = parent as? ViewGroup ?: return emptyList()
        val list = ArrayList<Pair<TextView, Int>>(3)
        for (i in 0 until p.childCount) {
            val ch = p.getChildAt(i)
            if (ch is TextView) {
                list.add(ch to ch.currentTextColor)
            }
        }
        cachedSiblingTextViews = list
        return list
    }

    private fun applySiblingTextBlushMix(whiteMix: Float) {
        val clamped = whiteMix.coerceIn(0f, 1f)
        if (abs(clamped - lastAppliedWhiteMix) < 0.015f && clamped > 0f && clamped < 1f) return
        lastAppliedWhiteMix = clamped
        val list = ensureSiblingTextViews()
        for ((tv, origCol) in list) {
            if (clamped <= 0.01f) {
                tv.setTextColor(origCol)
            } else {
                val r = (Color.red(origCol) * (1f - clamped) + 255f * clamped).toInt().coerceIn(0, 255)
                val g = (Color.green(origCol) * (1f - clamped) + 255f * clamped).toInt().coerceIn(0, 255)
                val b = (Color.blue(origCol) * (1f - clamped) + 255f * clamped).toInt().coerceIn(0, 255)
                tv.setTextColor(Color.argb(Color.alpha(origCol), r, g, b))
            }
        }
    }

    private fun restoreSiblingTextColorsIfNeeded() {
        if (lastAppliedWhiteMix > 0f) {
            lastAppliedWhiteMix = 0f
            cachedSiblingTextViews?.forEach { (tv, origCol) ->
                tv.setTextColor(origCol)
            }
        }
    }

    private fun computeCurrentBlushProgress(): Float {
        if (!enableGlow) return 0f
        if (!KeyboardBacklightOverlayView.isKeyBlushHaloEnabled(context)) return 0f
        if (KeyboardBacklightOverlayView.getKeyBlushHaloStyle(context) == KeyboardBacklightOverlayView.STYLE_HALO_ONLY) return 0f

        if (isKeyPressedState) return 1.0f
        if (pressReleaseMs <= 0L) return 0f

        val speedNorm = ((KeyboardBacklightOverlayView.getKeyBlushHaloSpeed(context) - 10f) / 90f).coerceIn(0f, 1f)
        val speedScale = 0.52f + speedNorm * 0.96f
        val holdMs = 95f / speedScale
        val fadeMs = 540f / speedScale
        val elapsed = (SystemClock.uptimeMillis() - pressReleaseMs).coerceAtLeast(0L).toFloat()
        if (elapsed >= holdMs + fadeMs) {
            pressReleaseMs = 0L
            return 0f
        }
        return if (elapsed <= holdMs) {
            1.0f - 0.06f * (elapsed / holdMs.coerceAtLeast(1f))
        } else {
            val t = ((elapsed - holdMs) / fadeMs.coerceAtLeast(1f)).coerceIn(0f, 1f)
            0.94f * (1f - t) * (1f - 0.35f * t)
        }
    }

    private fun drawBlushSurfaceOverlayIfNeeded(canvas: Canvas, w: Float, h: Float, r: Float, blushProgress: Float) {
        if (blushProgress <= 0.005f) {
            restoreSiblingTextColorsIfNeeded()
            return
        }
        val baseCol = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else Color.WHITE
        KeyboardBacklightOverlayView.resolveKeyBlushAndHaloColors(
            keyBgColor = baseCol,
            kbBgColor = baseCol,
            glowColor = glowColor,
            outColors = blushColorBuf
        )
        val densityNorm = ((KeyboardBacklightOverlayView.getKeyBlushHaloDensity(context) - 10f) / 90f).coerceIn(0f, 1f)
        val strength = (0.58f + densityNorm * 0.40f).coerceIn(0.45f, 0.98f)
        val curBlend = (blushProgress * strength).coerceIn(0f, 0.98f)

        val topCol = blushColorBuf[0]
        val botCol = blushColorBuf[1]
        val isPaintedKey = (bitmap != null)
        val topAlpha = (curBlend * (if (isPaintedKey) 78f else 246f)).toInt().coerceIn(0, 252)
        val botAlpha = (curBlend * (if (isPaintedKey) 60f else 232f)).toInt().coerceIn(0, 245)

        blushOverlayPaint.shader = LinearGradient(
            w * 0.5f, 0f, w * 0.5f, h,
            Color.argb(topAlpha, Color.red(topCol), Color.green(topCol), Color.blue(topCol)),
            Color.argb(botAlpha, Color.red(botCol), Color.green(botCol), Color.blue(botCol)),
            Shader.TileMode.CLAMP
        )
        keyRectF.set(0f, 0f, w, h)
        canvas.drawRoundRect(keyRectF, r, r, blushOverlayPaint)
        blushOverlayPaint.shader = null

        // 键帽四周柔白高光内衬边
        val strokeW = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.15f, resources.displayMetrics)
        val halfS = strokeW * 0.5f
        blushRimPaint.strokeWidth = strokeW
        blushRimPaint.color = Color.argb((175f * curBlend).toInt().coerceIn(0, 255), 255, 255, 255)
        keyRectF.set(halfS, halfS, w - halfS, h - halfS)
        canvas.drawRoundRect(keyRectF, (r - halfS).coerceAtLeast(2f), (r - halfS).coerceAtLeast(2f), blushRimPaint)

        // 纯色皮肤变色时同步让当前按键上的文字转为清透纯白；真贴图皮肤保留深咖原字色以便看清键帽插画与字母
        if (!isPaintedKey) {
            applySiblingTextBlushMix((curBlend * 1.08f).coerceIn(0f, 0.96f))
        }

        if (!isKeyPressedState) {
            postInvalidateOnAnimation()
        }
    }

    private fun findRootKbContainer(): View? {
        var cur: View? = this
        var last: View? = null
        while (cur != null) {
            last = cur
            val np = cur.parent
            cur = if (np is View) np else null
        }
        return last
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val frostBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.0f, resources.displayMetrics)
        color = Color.argb(135, 255, 255, 255)
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()
    private val blurMatrix = Matrix()
    private val selfLoc = IntArray(2)
    private val rootLoc = IntArray(2)
    private var frostedCoordsValid = false
    private var cachedRelX = 0f
    private var cachedRelY = 0f
    private var cachedRootW = 0f
    private var cachedRootH = 0f

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        if (changed) frostedCoordsValid = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        val blurredBg = if (useFrostedCustomBg) CustomBgManager.getBlurredBitmap(context) else null

        val blushProgress = computeCurrentBlushProgress()

        // 极速通道（模式 3：纯色键帽）：直接使用 GPU 硬件加速的 drawRoundRect，彻底免除高开销的 canvas.clipPath 蒙版裁剪！
        if (bitmap == null && blurredBg == null) {
            if (fallbackBgTop != Color.TRANSPARENT) {
                val drawCol = if (isKeyPressedState && blushProgress <= 0f) blendLivelyPressColor(fallbackBgTop, glowColor) else fallbackBgTop
                fallbackFillPaint.color = Color.argb(
                    255,
                    Color.red(drawCol),
                    Color.green(drawCol),
                    Color.blue(drawCol)
                )
                canvas.drawRoundRect(keyRectF, r, r, fallbackFillPaint)
                drawBlushSurfaceOverlayIfNeeded(canvas, w, h, r, blushProgress)
            }
            return
        }

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            // 模式 1：莫奈花园专属油画键帽贴图
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (blurredBg != null) {
            // 模式 2：纯色框架下已上传自定义背景图 -> 缓存相对坐标读取并模糊对应坐标处的底图 + 半透明毛玻璃键帽层
            if (!frostedCoordsValid || cachedRootW <= 1f || cachedRootH <= 1f) {
                val rootV = findRootKbContainer()
                cachedRootW = (rootV?.width ?: width).toFloat().coerceAtLeast(1f)
                cachedRootH = (rootV?.height ?: height).toFloat().coerceAtLeast(1f)
                getLocationInWindow(selfLoc)
                rootV?.getLocationInWindow(rootLoc)
                cachedRelX = (selfLoc[0] - rootLoc[0]).toFloat()
                cachedRelY = (selfLoc[1] - rootLoc[1]).toFloat()
                frostedCoordsValid = true
            }

            val scale = max(cachedRootW / blurredBg.width.toFloat(), cachedRootH / blurredBg.height.toFloat())
            val dx = (cachedRootW - blurredBg.width * scale) * 0.5f - cachedRelX
            val dy = (cachedRootH - blurredBg.height * scale) * 0.5f - cachedRelY
            blurMatrix.reset()
            blurMatrix.setScale(scale, scale)
            blurMatrix.postTranslate(dx, dy)
            canvas.drawBitmap(blurredBg, blurMatrix, bmpPaint)

            // 叠加半透明毛玻璃键帽色（按下时向灵动光晕色轻柔过渡 22%，绝不压暗变灰！）
            val baseCol = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else Color.WHITE
            val tintCol = if (isKeyPressedState) blendLivelyPressColor(baseCol, glowColor) else baseCol
            val frostAlpha = if (isKeyPressedState) 138 else 110
            fallbackFillPaint.color = Color.argb(
                frostAlpha,
                Color.red(tintCol),
                Color.green(tintCol),
                Color.blue(tintCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)

        if (blurredBg != null && bitmap == null) {
            val half = frostBorderPaint.strokeWidth * 0.5f
            keyRectF.set(half, half, w - half, h - half)
            canvas.drawRoundRect(keyRectF, r, r, frostBorderPaint)
        }
        drawBlushSurfaceOverlayIfNeeded(canvas, w, h, r, blushProgress)
    }

    private fun blendLivelyPressColor(baseColor: Int, livelyGlowColor: Int): Int {
        val r = (Color.red(baseColor) * 0.72f + Color.red(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val g = (Color.green(baseColor) * 0.72f + Color.green(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val b = (Color.blue(baseColor) * 0.72f + Color.blue(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }
}

/**
 * 现代圆角极简风「顶部状态栏 4 图标视图」（复刻参考图 1000128623.jpg & 1000128608.jpg）：
 * - 与圆角按键风格高度统一，采用圆角方糖（Squircle）微填充底衬 + 圆润胶囊线条：
 *   0 (设置)：现代圆角四宫格控制中心图标（3 枚圆角方格 + 右上角点睛圆点）
 *   1 (表情)：圆角方糖微填充萌系笑脸图标（圆润胶囊眼 + 柔和微笑弧）
 *   2 (常用)：圆角书签卡片图标（圆角外框 + 双胶囊横线 + 右上角小折角）
 *   3 (收起)：圆角胶囊下折图标（柔和圆角底衬 + 宽角圆头下折箭头 + 底部短横）
 * - 在莫奈花园模式下支持渲染水彩睡莲图标。
 */
/**
 * 顶部状态栏 5 图标独立自定义上传与大小/染色管理器：
 * - 支持为 5 个顶栏槽位独立上传自定义 PNG/WebP/JPG 图标：
 *   0 (TYPE_SETTINGS)：第1个 - 设置（内置默认：去猫脸保留耳廓与小胡须的圆润猫猫头）
 *   1 (TYPE_EMOJI)：第2个 - 表情（内置默认：大小双爱心）
 *   4 (TYPE_CLIPBOARD)：第3个 - 剪贴板（内置默认：环绕小星球）
 *   2 (TYPE_FAVORITE)：第4个 - 收藏/常用语（内置默认：圆润胖五角星）
 *   3 (TYPE_COLLAPSE)：第5个 - 收起键盘（内置默认：三尖圆珠小皇冠）
 * - 智能背景处理：若用户上传的是透明底 PNG，直接保留透明通道并自动裁切多余透明边距；
 *   若用户上传的是白底/纯浅色底图片，自动识别四角背景色并智能抠除转为透明底！
 * - 支持「线条随皮肤自动变色」与「保留彩色原图本色」两种渲染模式自由切换。
 * - 支持 14dp ~ 34dp 无级调节顶栏图标显示大小（默认 22dp，精致不突兀）。
 */
object CustomTopIconManager {
    const val DEFAULT_ICON_SIZE_DP = 22
    const val MIN_ICON_SIZE_DP = 14
    const val MAX_ICON_SIZE_DP = 34

    private val customBmpCache = HashMap<Int, Pair<Long, Bitmap>>()

    fun getSlotFile(context: Context, iconType: Int): File {
        return File(context.filesDir, "custom_top_icon_$iconType.png")
    }

    fun getSlotTimestamp(context: Context, iconType: Int): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_top_icon_ts_$iconType", 0L)
    }

    fun getSlotPresetIconId(context: Context, iconType: Int): Int {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getInt("top_slot_preset_icon_$iconType", iconType)
    }

    fun setSlotPresetIconId(context: Context, iconType: Int, presetId: Int) {
        try {
            getSlotFile(context, iconType).delete()
        } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putInt("top_slot_preset_icon_$iconType", presetId)
            .putLong("custom_top_icon_ts_$iconType", 0L)
            .putLong("custom_top_icon_global_ts", now)
            .apply()
        synchronized(customBmpCache) {
            customBmpCache.remove(iconType)
        }
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val tintFlag = if (isFollowSkinColor(context)) 1L else 0L
        val sizeDp = getIconSizeDp(context).toLong()
        val presetHash = (getSlotPresetIconId(context, 0).toLong() shl 5) xor
            (getSlotPresetIconId(context, 1).toLong() shl 8) xor
            (getSlotPresetIconId(context, 2).toLong() shl 11) xor
            (getSlotPresetIconId(context, 3).toLong() shl 14) xor
            (getSlotPresetIconId(context, 4).toLong() shl 17)
        return getSlotTimestamp(context, 0) xor
            (getSlotTimestamp(context, 1) shl 1) xor
            (getSlotTimestamp(context, 2) shl 2) xor
            (getSlotTimestamp(context, 3) shl 3) xor
            (getSlotTimestamp(context, 4) shl 4) xor
            presetHash xor
            (tintFlag shl 20) xor
            (sizeDp shl 24) xor
            prefs.getLong("custom_top_icon_global_ts", 0L)
    }

    fun hasCustomIcon(context: Context, iconType: Int): Boolean {
        return getSlotTimestamp(context, iconType) > 0L && getSlotFile(context, iconType).exists()
    }

    fun isFollowSkinColor(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("custom_top_icon_follow_skin", true)
    }

    fun setFollowSkinColor(context: Context, follow: Boolean) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("custom_top_icon_follow_skin", follow)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun getIconSizeDp(context: Context): Int {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getInt("top_bar_icon_size_dp", DEFAULT_ICON_SIZE_DP).coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
    }

    fun setIconSizeDp(context: Context, sizeDp: Int) {
        val clamped = sizeDp.coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("top_bar_icon_size_dp", clamped)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun clearCustomIcon(context: Context, iconType: Int) {
        try {
            getSlotFile(context, iconType).delete()
        } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .remove("top_slot_preset_icon_$iconType")
            .putLong("custom_top_icon_ts_$iconType", 0L)
            .putLong("custom_top_icon_global_ts", now)
            .apply()
        synchronized(customBmpCache) {
            customBmpCache.remove(iconType)
        }
    }

    fun clearAllCustomIcons(context: Context) {
        for (t in listOf(0, 1, 2, 3, 4)) {
            try {
                getSlotFile(context, t).delete()
            } catch (_: Exception) {}
        }
        val now = System.currentTimeMillis()
        val editor = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE).edit()
        for (t in listOf(0, 1, 2, 3, 4)) {
            editor.remove("top_slot_preset_icon_$t")
            editor.putLong("custom_top_icon_ts_$t", 0L)
        }
        editor.putLong("custom_top_icon_global_ts", now).apply()
        synchronized(customBmpCache) {
            customBmpCache.clear()
        }
    }

    fun getCustomBitmap(context: Context, iconType: Int): Bitmap? {
        val ts = getSlotTimestamp(context, iconType)
        if (ts <= 0L) return null
        synchronized(customBmpCache) {
            val cached = customBmpCache[iconType]
            if (cached != null && cached.first == ts && !cached.second.isRecycled) {
                return cached.second
            }
            val f = getSlotFile(context, iconType)
            if (!f.exists()) return null
            try {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp != null) {
                    customBmpCache[iconType] = ts to bmp
                    return bmp
                }
            } catch (_: Exception) {}
            return null
        }
    }

    /**
     * 导入并智能处理用户上传的图标：
     * 1. 若原图自带透明通道（PNG/WebP），完整保留透明通道与抗锯齿边缘；
     * 2. 若原图是不透明白底/浅色底图片，自动采样四角背景色并智能去底转为透明通道；
     * 3. 自动裁切四周多余空白并保留均匀呼吸边距，存入应用私有目录。
     */
    fun saveCustomIconFromBitmap(context: Context, iconType: Int, rawBitmap: Bitmap): Boolean {
        try {
            val maxDim = 256
            val rw = rawBitmap.width
            val rh = rawBitmap.height
            if (rw <= 0 || rh <= 0) return false

            val scaled = if (rw > maxDim || rh > maxDim) {
                val ratio = minOf(maxDim.toFloat() / rw.toFloat(), maxDim.toFloat() / rh.toFloat())
                Bitmap.createScaledBitmap(
                    rawBitmap,
                    (rw * ratio).toInt().coerceAtLeast(1),
                    (rh * ratio).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                rawBitmap.copy(Bitmap.Config.ARGB_8888, true)
            }

            val w = scaled.width
            val h = scaled.height
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)

            // 检测是否已有透明背景
            var transparentCount = 0
            for (p in pixels) {
                val a = (p ushr 24) and 0xFF
                if (a < 210) transparentCount++
            }
            val hasNativeAlpha = transparentCount > (w * h) / 25

            if (!hasNativeAlpha) {
                // 自动采样四角背景色，智能抠除纯色底
                val corners = intArrayOf(
                    pixels[0],
                    pixels[w - 1],
                    pixels[(h - 1) * w],
                    pixels[(h - 1) * w + (w - 1)]
                )
                var bgR = 0f
                var bgG = 0f
                var bgB = 0f
                for (c in corners) {
                    bgR += ((c shr 16) and 0xFF)
                    bgG += ((c shr 8) and 0xFF)
                    bgB += (c and 0xFF)
                }
                bgR /= 4f
                bgG /= 4f
                bgB /= 4f

                var maxDist = 1f
                for (p in pixels) {
                    val dr = ((p shr 16) and 0xFF) - bgR
                    val dg = ((p shr 8) and 0xFF) - bgG
                    val db = (p and 0xFF) - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    if (d > maxDist) maxDist = d
                }

                val lowThresh = (maxDist * 0.16f).coerceAtLeast(18f)
                val highThresh = (maxDist * 0.52f).coerceAtLeast(lowThresh + 16f)

                for (i in pixels.indices) {
                    val p = pixels[i]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val dr = r - bgR
                    val dg = g - bgG
                    val db = b - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    val t = ((d - lowThresh) / (highThresh - lowThresh)).coerceIn(0f, 1f)
                    val smoothA = (t * t * (3f - 2f * t) * 255f).toInt().coerceIn(0, 255)
                    pixels[i] = (smoothA shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            // 自动寻找有效像素边界并适度留白裁切
            var minX = w
            var minY = h
            var maxX = 0
            var maxY = 0
            for (y in 0 until h) {
                val rowOff = y * w
                for (x in 0 until w) {
                    val a = (pixels[rowOff + x] ushr 24) and 0xFF
                    if (a > 24) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }

            val processed = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            processed.setPixels(pixels, 0, w, 0, 0, w, h)

            val finalBmp = if (minX <= maxX && minY <= maxY) {
                val padX = ((maxX - minX + 1) * 0.05f).toInt().coerceAtLeast(2)
                val padY = ((maxY - minY + 1) * 0.05f).toInt().coerceAtLeast(2)
                val cx0 = (minX - padX).coerceAtLeast(0)
                val cy0 = (minY - padY).coerceAtLeast(0)
                val cx1 = (maxX + padX).coerceAtMost(w - 1)
                val cy1 = (maxY + padY).coerceAtMost(h - 1)
                Bitmap.createBitmap(processed, cx0, cy0, (cx1 - cx0 + 1).coerceAtLeast(1), (cy1 - cy0 + 1).coerceAtLeast(1))
            } else {
                processed
            }

            val outFile = getSlotFile(context, iconType)
            FileOutputStream(outFile).use { fos ->
                finalBmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            val now = System.currentTimeMillis()
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putLong("custom_top_icon_ts_$iconType", now)
                .putLong("custom_top_icon_global_ts", now)
                .apply()
            synchronized(customBmpCache) {
                customBmpCache[iconType] = now to finalBmp
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }
}

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = false,
    private val paintedSkinFolder: String? = null
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0       // 🐱 小胡须圆润猫猫头
        const val TYPE_EMOJI = 1          // 💕 大小双爱心（图5同款）
        const val TYPE_PHRASE = 2         // ⭐ 圆润胖五角小星星（图5同款）
        const val TYPE_FAVORITE = 2       // ⭐ 圆润胖五角小星星（图5同款）
        const val TYPE_COLLAPSE = 3       // 👑 三尖圆珠小皇冠（图5同款）
        const val TYPE_CLIPBOARD = 4      // 🪐 环绕小星球（图5同款）
        const val ICON_BOW = 5            // 🎀 甜心蝴蝶结（图5同款全新重绘）
        const val ICON_FLOWER = 6         // 🌸 六瓣小樱花（图5同款全新重绘）
        const val ICON_SPARKLES = 7       // ✨ 双子闪星芒（图5同款）
        const val ICON_CLOVER = 8         // 🍀 四叶幸运草（图5同款）
        const val ICON_LUCKY_CLOVER = 9   // ☘️ 带茎幸运草（图5同款）
        const val ICON_METEOR = 10        // 🌠 弧线许愿星（图5同款）
        const val ICON_SNOWFLAKE = 11     // ❄️ 晶莹小雪花（图5同款）
        const val ICON_BOOK = 12          // 📖 翻开小书本（图5同款）
        const val ICON_STAR_MOON = 13     // 🌙 弯月伴萌星
        const val ICON_MAGIC_WAND = 14    // 🪄 魔法小星杖

        val ALL_PRESET_ICONS: List<Pair<Int, String>> = listOf(
            ICON_BOW to "🎀蝴蝶结",
            ICON_FLOWER to "🌸小樱花",
            ICON_SPARKLES to "✨双星芒",
            ICON_CLOVER to "🍀四叶草",
            ICON_LUCKY_CLOVER to "☘️幸运草",
            ICON_METEOR to "🌠许愿星",
            ICON_SNOWFLAKE to "❄️小雪花",
            ICON_BOOK to "📖小书本",
            ICON_STAR_MOON to "🌙星月",
            ICON_MAGIC_WAND to "🪄星杖",
            TYPE_SETTINGS to "🐱猫猫头",
            TYPE_EMOJI to "💕双爱心",
            TYPE_CLIPBOARD to "🪐小星球",
            TYPE_FAVORITE to "⭐胖星星",
            TYPE_COLLAPSE to "👑小皇冠"
        )

        fun getPresetIconName(presetId: Int): String {
            return ALL_PRESET_ICONS.firstOrNull { it.first == presetId }?.second ?: "✨可爱图标"
        }

        private val cuteBitmapCache = HashMap<Int, Bitmap>()

        fun getCuteHollowBitmap(context: Context, type: Int): Bitmap? {
            if (type == ICON_STAR_MOON || type == ICON_MAGIC_WAND) return null
            synchronized(cuteBitmapCache) {
                cuteBitmapCache[type]?.let { if (!it.isRecycled) return it }
                val assetName = when (type) {
                    TYPE_SETTINGS -> "cute_icons/icon_cat.png"
                    TYPE_EMOJI -> "cute_icons/icon_paw.png"
                    TYPE_CLIPBOARD -> "cute_icons/icon_heart.png"
                    TYPE_PHRASE -> "cute_icons/icon_star.png"
                    TYPE_COLLAPSE -> "cute_icons/icon_sakura.png"
                    ICON_BOW -> "cute_icons/icon_bow.png"
                    ICON_FLOWER -> "cute_icons/icon_flower.png"
                    ICON_SPARKLES -> "cute_icons/icon_sparkles.png"
                    ICON_CLOVER -> "cute_icons/icon_clover.png"
                    ICON_LUCKY_CLOVER -> "cute_icons/icon_lucky_clover.png"
                    ICON_METEOR -> "cute_icons/icon_meteor.png"
                    ICON_SNOWFLAKE -> "cute_icons/icon_snowflake.png"
                    ICON_BOOK -> "cute_icons/icon_book.png"
                    else -> "cute_icons/icon_star.png"
                }
                try {
                    context.assets.open(assetName).use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) {
                            cuteBitmapCache[type] = bmp
                            return bmp
                        }
                    }
                } catch (_: Exception) {}
                return null
            }
        }
    }

    private val tintedBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(iconColor, PorterDuff.Mode.SRC_IN)
    }
    private val rawColorBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(3.0f))
        color = iconColor
    }

    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        tintedBitmapPaint.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
        strokePaint.color = newColor
        fineStrokePaint.color = newColor
        starStrokePaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f

        // 0. 莫奈花园油画睡莲特殊皮肤专属状态栏：优先绘制原版水彩睡莲/花苞/荷叶图标（1:1 复刻图5，绝不变成猫猫头！）
        if (useBotanicalStyle) {
            val lotusIdx = when (iconType) {
                TYPE_SETTINGS -> 0
                TYPE_EMOJI -> 1
                TYPE_CLIPBOARD, TYPE_PHRASE -> 2
                TYPE_COLLAPSE -> 3
                else -> 0
            }
            val folder = paintedSkinFolder ?: "monet"
            val lotusBmp = MonetTextureManager.getTopIconBitmap(context, lotusIdx, folder)
            if (lotusBmp != null && lotusBmp.width > 0 && lotusBmp.height > 0) {
                val aspect = lotusBmp.width.toFloat() / lotusBmp.height.toFloat()
                var drawH = h * 0.94f
                var drawW = drawH * aspect
                if (drawW > w * 0.96f) {
                    drawW = w * 0.96f
                    drawH = drawW / aspect
                }
                srcRect.set(0, 0, lotusBmp.width, lotusBmp.height)
                dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
                canvas.drawBitmap(lotusBmp, srcRect, dstRectF, rawColorBitmapPaint)
                return
            }
        }

        // 1. 优先检查用户是否为该槽位上传了自定义状态栏图标
        val customBmp = CustomTopIconManager.getCustomBitmap(context, iconType)
        if (customBmp != null && customBmp.width > 0 && customBmp.height > 0) {
            val aspect = customBmp.width.toFloat() / customBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, customBmp.width, customBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            val paintToUse = if (CustomTopIconManager.isFollowSkinColor(context)) tintedBitmapPaint else rawColorBitmapPaint
            canvas.drawBitmap(customBmp, srcRect, dstRectF, paintToUse)
            return
        }

        // 2. 检查当前顶栏槽位选中的内置可爱图标（支持在 15 款图 5 同款可爱图标间任意换装！）
        val presetId = CustomTopIconManager.getSlotPresetIconId(context, iconType)
        if (presetId == ICON_STAR_MOON || presetId == ICON_MAGIC_WAND) {
            val r = minOf(w, h) * 0.38f
            if (presetId == ICON_MAGIC_WAND) {
                WildcardCuteIconView.drawVectorStarWand(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path)
            } else {
                WildcardCuteIconView.drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
            }
            return
        }

        val cuteBmp = getCuteHollowBitmap(context, presetId)
        if (cuteBmp != null && cuteBmp.width > 0 && cuteBmp.height > 0) {
            val aspect = cuteBmp.width.toFloat() / cuteBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, cuteBmp.width, cuteBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            canvas.drawBitmap(cuteBmp, srcRect, dstRectF, tintedBitmapPaint)
            return
        }

        val r = minOf(w, h) * 0.42f
        drawCuteHollowIcon(canvas, cx, cy, r)
    }

    private fun drawCuteHollowIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val cyCat = cy + r * 0.05f
                path.reset()
                path.moveTo(cx - r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx, cyCat - r * 0.46f, cx + r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx + r * 0.62f, cyCat - r * 0.86f, cx + r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx + r * 0.94f, cyCat - r * 0.52f, cx + r * 0.92f, cyCat - r * 0.12f)
                path.cubicTo(cx + r * 1.12f, cyCat + r * 0.44f, cx + r * 0.64f, cyCat + r * 0.82f, cx, cyCat + r * 0.82f)
                path.cubicTo(cx - r * 0.64f, cyCat + r * 0.82f, cx - r * 1.12f, cyCat + r * 0.44f, cx - r * 0.92f, cyCat - r * 0.12f)
                path.quadTo(cx - r * 0.94f, cyCat - r * 0.52f, cx - r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx - r * 0.62f, cyCat - r * 0.86f, cx - r * 0.36f, cyCat - r * 0.42f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - r * 0.74f, cyCat + r * 0.15f, cx - r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx - r * 0.70f, cyCat + r * 0.32f, cx - r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.74f, cyCat + r * 0.15f, cx + r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.70f, cyCat + r * 0.32f, cx + r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
            }
            else -> {
                val outerR = r * 0.96f
                val innerR = r * 0.54f
                path.reset()
                for (i in 0 until 10) {
                    val ang = Math.toRadians((-90.0 + i * 36.0))
                    val rad = if (i % 2 == 0) outerR else innerR
                    val px = cx + (rad * cos(ang)).toFloat()
                    val py = cy + (rad * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, starStrokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class BackspaceIconView(
    context: Context,
    private val iconColor: Int,
    private val alignTopLeft: Boolean = false
) : View(context) {

    private val tagPath = Path()
    private val cornerEffect = CornerPathEffect(dpF(3.8f))

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(36, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor))
        pathEffect = cornerEffect
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
        pathEffect = cornerEffect
    }

    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        color = iconColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = if (alignTopLeft) w * 0.28f else w * 0.5f
        val cy = if (alignTopLeft) h * 0.28f else h * 0.5f
        val sc = if (alignTopLeft) 0.82f else 1.0f
        val halfW = dpF(10.5f) * sc
        val halfH = dpF(7.2f) * sc
        val noseX = cx - halfW
        val bodyLeft = cx - halfW * 0.38f
        val rightX = cx + halfW

        tagPath.reset()
        tagPath.moveTo(noseX, cy)
        tagPath.lineTo(bodyLeft, cy - halfH)
        tagPath.lineTo(rightX, cy - halfH)
        tagPath.lineTo(rightX, cy + halfH)
        tagPath.lineTo(bodyLeft, cy + halfH)
        tagPath.close()

        // 100% 纯镂空退格键图标（去除半透明灰色内填充）
        canvas.drawPath(tagPath, strokePaint)

        // 内部居中偏右一点的圆头 × 号
        val xCenter = (bodyLeft + rightX) * 0.5f + dpF(0.6f)
        val xSpan = dpF(2.7f)
        canvas.drawLine(xCenter - xSpan, cy - xSpan, xCenter + xSpan, cy + xSpan, crossPaint)
        canvas.drawLine(xCenter + xSpan, cy - xSpan, xCenter - xSpan, cy + xSpan, crossPaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}


/**
 * 空格键专属「迷你精致镂空小话筒」图标视图 (SpaceHollowMicIconView)：
 * - 专为「空格键长按呼出语音输入」设计，尺寸极袖珍（约 11.5dp × 13dp），100% 纤细圆头镂空线条 (1.32dp)；
 * - 颜色自动跟随当前皮肤空格键文字色 (iconColor) 并带 78% 温润半透明度，与莫奈花园、樱花粉、暗夜黑金及所有自定义 CSS 皮肤浑然一体！
 */
class SpaceHollowMicIconView(
    context: Context,
    private var iconColor: Int
) : View(context) {

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.32f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = applySoftAlpha(iconColor)
    }

    private val capsuleRect = RectF()
    private val cradleRect = RectF()

    private fun applySoftAlpha(c: Int): Int {
        val baseA = Color.alpha(c)
        val targetA = ((baseA * 0.78f).toInt()).coerceIn(90, 225)
        return Color.argb(targetA, Color.red(c), Color.green(c), Color.blue(c))
    }

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = applySoftAlpha(newColor)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val unit = min(w, h) * 0.42f

        // 1. 顶部镂空圆润胶囊收音头
        val capHalfW = unit * 0.42f
        val capTop = cy - unit * 0.94f
        val capBottom = cy + unit * 0.14f
        capsuleRect.set(cx - capHalfW, capTop, cx + capHalfW, capBottom)
        canvas.drawRoundRect(capsuleRect, capHalfW, capHalfW, strokePaint)

        // 2. 中部 U 型半圆托架
        val cradleRadius = unit * 0.74f
        val arcCenterY = cy - unit * 0.18f
        cradleRect.set(
            cx - cradleRadius,
            arcCenterY - cradleRadius,
            cx + cradleRadius,
            arcCenterY + cradleRadius
        )
        canvas.drawArc(cradleRect, 12f, 156f, false, strokePaint)

        // 3. 底部纤细竖杆与迷你横底座
        val stemTop = arcCenterY + cradleRadius
        val stemBottom = cy + unit * 0.92f
        canvas.drawLine(cx, stemTop, cx, stemBottom, strokePaint)
        val baseHalfW = unit * 0.44f
        canvas.drawLine(cx - baseHalfW, stemBottom, cx + baseHalfW, stemBottom, strokePaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 通配键专属「萌系镂空可爱图标」视图 (WildcardCuteIconView)：
 * - 图标大小与顶部状态栏图标大小 (CustomTopIconManager.getIconSizeDp) 1:1 完全同步绑定，绝不偏大突兀！
 * - 内置 15 款图 5 同款可爱镂空图标（含全新重绘的图 5 甜心蝴蝶结、六瓣小樱花、双子星芒、四叶草、幸运草、许愿流星、小雪花、小书本等）。
 */
class WildcardCuteIconView(
    context: Context,
    private var iconColor: Int,
    @Suppress("UNUSED_PARAMETER") private var iconScale: Float = 1.0f
) : View(context) {

    companion object {
        const val STYLE_STAR_MOON = 0       // 🌙 星月伴闪
        const val STYLE_MAGIC_WAND = 1      // 🪄 魔法星杖
        const val STYLE_CUTE_BOW = 2        // 🎀 甜心蝴蝶结（图5同款全新重绘）
        const val STYLE_SAKURA = 3          // 🌸 六瓣小樱花（图5同款全新重绘）
        const val STYLE_TEXT_LABEL = 4      // 🔤 经典文字「通配」
        const val STYLE_SPARKLES = 5        // ✨ 双子闪星芒（图5同款）
        const val STYLE_CLOVER = 6          // 🍀 四叶草（图5同款）
        const val STYLE_LUCKY_CLOVER = 7    // ☘️ 带茎幸运草（图5同款）
        const val STYLE_METEOR = 8          // 🌠 弧线许愿星（图5同款）
        const val STYLE_SNOWFLAKE = 9       // ❄️ 晶莹小雪花（图5同款）
        const val STYLE_BOOK = 10           // 📖 翻开小书本（图5同款）
        const val STYLE_CAT = 11            // 🐱 小胡须猫猫头
        const val STYLE_HEART = 12          // 💕 大小双爱心
        const val STYLE_PLANET = 13         // 🪐 环绕小星球
        const val STYLE_STAR = 14           // ⭐ 圆润胖星星
        const val STYLE_CROWN = 15          // 👑 三尖小皇冠

        val ALL_WILDCARD_STYLES: List<Pair<Int, String>> = listOf(
            STYLE_CUTE_BOW to "🎀蝴蝶结",
            STYLE_SAKURA to "🌸小樱花",
            STYLE_SPARKLES to "✨双星芒",
            STYLE_CLOVER to "🍀四叶草",
            STYLE_LUCKY_CLOVER to "☘️幸运草",
            STYLE_METEOR to "🌠许愿星",
            STYLE_SNOWFLAKE to "❄️小雪花",
            STYLE_BOOK to "📖小书本",
            STYLE_STAR_MOON to "🌙星月",
            STYLE_MAGIC_WAND to "🪄星杖",
            STYLE_CAT to "🐱猫猫头",
            STYLE_HEART to "💕双爱心",
            STYLE_PLANET to "🪐小星球",
            STYLE_STAR to "⭐胖星星",
            STYLE_CROWN to "👑小皇冠",
            STYLE_TEXT_LABEL to "🔤文字"
        )

        fun getStyleDisplayName(style: Int): String {
            return ALL_WILDCARD_STYLES.firstOrNull { it.first == style }?.second ?: "🎀蝴蝶结"
        }

        fun getWildcardIconStyle(context: Context): Int {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt("wildcard_cute_icon_style", STYLE_CUTE_BOW).coerceIn(0, 15)
        }

        fun setWildcardIconStyle(context: Context, style: Int) {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putInt("wildcard_cute_icon_style", style.coerceIn(0, 15))
                .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
                .apply()
        }

        fun mapWildcardStyleToPresetId(style: Int): Int = when (style) {
            STYLE_CUTE_BOW -> MinimalistIconView.ICON_BOW
            STYLE_SAKURA -> MinimalistIconView.ICON_FLOWER
            STYLE_SPARKLES -> MinimalistIconView.ICON_SPARKLES
            STYLE_CLOVER -> MinimalistIconView.ICON_CLOVER
            STYLE_LUCKY_CLOVER -> MinimalistIconView.ICON_LUCKY_CLOVER
            STYLE_METEOR -> MinimalistIconView.ICON_METEOR
            STYLE_SNOWFLAKE -> MinimalistIconView.ICON_SNOWFLAKE
            STYLE_BOOK -> MinimalistIconView.ICON_BOOK
            STYLE_CAT -> MinimalistIconView.TYPE_SETTINGS
            STYLE_HEART -> MinimalistIconView.TYPE_EMOJI
            STYLE_PLANET -> MinimalistIconView.TYPE_CLIPBOARD
            STYLE_STAR -> MinimalistIconView.TYPE_FAVORITE
            STYLE_CROWN -> MinimalistIconView.TYPE_COLLAPSE
            STYLE_STAR_MOON -> MinimalistIconView.ICON_STAR_MOON
            STYLE_MAGIC_WAND -> MinimalistIconView.ICON_MAGIC_WAND
            else -> MinimalistIconView.ICON_BOW
        }

        fun drawVectorStarMoon(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            r: Float,
            strokePaint: Paint,
            fineStrokePaint: Paint,
            starStrokePaint: Paint,
            path: Path,
            arcRect: RectF
        ) {
            val moonCx = cx - r * 0.14f
            val moonCy = cy + r * 0.04f
            val outerR = r * 0.86f
            path.reset()
            arcRect.set(moonCx - outerR, moonCy - outerR, moonCx + outerR, moonCy + outerR)
            path.addArc(arcRect, 42f, 266f)
            canvas.drawPath(path, strokePaint)

            val startAng = Math.toRadians(42.0)
            val endAng = Math.toRadians(308.0)
            val sx = moonCx + (outerR * cos(startAng)).toFloat()
            val sy = moonCy + (outerR * sin(startAng)).toFloat()
            val ex = moonCx + (outerR * cos(endAng)).toFloat()
            val ey = moonCy + (outerR * sin(endAng)).toFloat()

            path.reset()
            path.moveTo(ex, ey)
            path.cubicTo(
                moonCx - outerR * 0.42f, moonCy - outerR * 0.36f,
                moonCx - outerR * 0.38f, moonCy + outerR * 0.44f,
                sx, sy
            )
            canvas.drawPath(path, strokePaint)

            val starCx = cx + r * 0.42f
            val starCy = cy - r * 0.22f
            val sOut = r * 0.45f
            val sIn = r * 0.24f
            path.reset()
            for (i in 0 until 10) {
                val ang = Math.toRadians(-90.0 + i * 36.0 + 12.0)
                val rad = if (i % 2 == 0) sOut else sIn
                val px = starCx + (rad * cos(ang)).toFloat()
                val py = starCy + (rad * sin(ang)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            canvas.drawPath(path, starStrokePaint)

            val spX = cx - r * 0.60f
            val spY = cy - r * 0.62f
            val arm = r * 0.18f
            canvas.drawLine(spX - arm, spY, spX + arm, spY, fineStrokePaint)
            canvas.drawLine(spX, spY - arm, spX, spY + arm, fineStrokePaint)
        }

        fun drawVectorStarWand(
            canvas: Canvas,
            cx: Float,
            cy: Float,
            r: Float,
            strokePaint: Paint,
            fineStrokePaint: Paint,
            starStrokePaint: Paint,
            path: Path
        ) {
            val starCx = cx - r * 0.20f
            val starCy = cy - r * 0.20f
            val sOut = r * 0.64f
            val sIn = r * 0.36f
            path.reset()
            for (i in 0 until 10) {
                val ang = Math.toRadians(-135.0 + i * 36.0)
                val rad = if (i % 2 == 0) sOut else sIn
                val px = starCx + (rad * cos(ang)).toFloat()
                val py = starCy + (rad * sin(ang)).toFloat()
                if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            canvas.drawPath(path, starStrokePaint)

            val hStartX = starCx + sIn * 0.72f
            val hStartY = starCy + sIn * 0.72f
            val hEndX = cx + r * 0.82f
            val hEndY = cy + r * 0.82f
            canvas.drawLine(hStartX, hStartY, hEndX, hEndY, strokePaint)

            val bowX = (hStartX + hEndX) * 0.48f
            val bowY = (hStartY + hEndY) * 0.48f
            path.reset()
            path.moveTo(bowX, bowY)
            path.quadTo(bowX + r * 0.36f, bowY - r * 0.34f, bowX + r * 0.42f, bowY - r * 0.06f)
            path.quadTo(bowX + r * 0.26f, bowY + r * 0.12f, bowX, bowY)
            path.moveTo(bowX, bowY)
            path.quadTo(bowX - r * 0.34f, bowY + r * 0.36f, bowX - r * 0.06f, bowY + r * 0.42f)
            path.quadTo(bowX + r * 0.12f, bowY + r * 0.26f, bowX, bowY)
            canvas.drawPath(path, fineStrokePaint)

            val spX = cx + r * 0.54f
            val spY = cy - r * 0.56f
            val arm = r * 0.18f
            canvas.drawLine(spX - arm, spY, spX + arm, spY, fineStrokePaint)
            canvas.drawLine(spX, spY - arm, spX, spY + arm, fineStrokePaint)
        }
    }

    private val tintedBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(iconColor, PorterDuff.Mode.SRC_IN)
    }
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.62f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.42f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.58f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(2.2f))
        color = iconColor
    }

    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f

        // 严格与顶部状态栏图标大小 (CustomTopIconManager.getIconSizeDp) 1:1 绑定同步！
        val topIconDp = CustomTopIconManager.getIconSizeDp(context).toFloat()
        val boxH = min(h * 0.78f, dpF(topIconDp))
        val boxW = min(w * 0.88f, boxH * 1.38f)

        val style = getWildcardIconStyle(context)
        if (style == STYLE_STAR_MOON) {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
            return
        } else if (style == STYLE_MAGIC_WAND) {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarWand(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path)
            return
        }

        val presetId = mapWildcardStyleToPresetId(style)
        val cuteBmp = MinimalistIconView.getCuteHollowBitmap(context, presetId)
        if (cuteBmp != null && cuteBmp.width > 0 && cuteBmp.height > 0) {
            val aspect = cuteBmp.width.toFloat() / cuteBmp.height.toFloat()
            var drawH = boxH * 0.90f
            var drawW = drawH * aspect
            if (drawW > boxW * 0.94f) {
                drawW = boxW * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, cuteBmp.width, cuteBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            canvas.drawBitmap(cuteBmp, srcRect, dstRectF, tintedBitmapPaint)
        } else {
            val r = min(boxW, boxH) * 0.38f
            drawVectorStarMoon(canvas, cx, cy, r, strokePaint, fineStrokePaint, starStrokePaint, path, dstRectF)
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 盛夏光年 · 拼音同款星轨圈圈 + 夏以昼同款流光星芒光晕旋转视图 (StarlightVoiceWaveView)：
 * - 1:1 还原参考图中的中央圆盘极简白话筒 + 三层旋转同心星轨圆弧与轨道白珍珠；
 * - 深度融合「夏以昼」同款多层旋转流光星云大光晕 + 3 缕弯弯弧形流光游丝 (GossamerFlowRibbons) +
 *   环绕旋转闪烁的实心四芒星 (✦)、空心四芒星 (✧)、十字星耀与柔光微星尘；
 * - 轻点或按住说话时，圈圈与夏以昼流光星芒光晕 60FPS 丝滑同步旋转，并随说话音量实时呼吸绽放！
 */
class StarlightVoiceWaveView(
    context: Context,
    private var glowColor: Int,
    private var surfaceBgColor: Int,
    private var keyboardSurfaceBgColor: Int
) : View(context) {

    var isListeningState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (!value) targetRmsNorm = 0.12f
                tapSparkleBoost = 1.0f
                lastFrameMs = SystemClock.uptimeMillis()
                postInvalidateOnAnimation()
            }
        }

    private var currentRmsNorm = 0.15f
    private var targetRmsNorm = 0.15f
    private var rotAngleRad = 0f
    private var tapSparkleBoost = 0.35f
    private var lastFrameMs = 0L

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val ribbonPath = Path()
    private val starPath = Path()
    private val ovalRect = RectF()

    private var palette = StarlightColorAdapter.resolvePalette(
        rawGlowColor = glowColor,
        surfaceBgColor = surfaceBgColor,
        keyboardBgColor = keyboardSurfaceBgColor
    )

    // 预置 14 颗环绕星轨旋转的「夏以昼同款簇状星点」（实心四芒星 ✦ + 空心四芒星 ✧ + 柔光小光圈 ° + 闪烁星尘 ·）
    private data class OrbitStarParticle(
        val shapeType: Int,     // 0=实心四芒星✦, 1=空心四芒星✧, 2=柔光小光圈°, 3=闪烁微星尘·, 4=修长十字星耀✷
        val baseAngleRad: Float,
        val radiusFactor: Float,
        val speedFactor: Float,
        val sizeDp: Float,
        val colorVariant: Int,
        val twinklePhase: Float,
        val twinkleSpeed: Float
    )

    private val orbitStars = listOf(
        // 簇 1（左上星群）
        OrbitStarParticle(4, 0.35f, 1.38f, 1.08f, 5.2f, 0, 0.2f, 0.008f),
        OrbitStarParticle(0, 0.58f, 1.18f, 1.15f, 3.8f, 1, 1.1f, 0.011f),
        OrbitStarParticle(1, 0.82f, 1.48f, 0.92f, 3.4f, 0, 2.4f, 0.009f),
        OrbitStarParticle(2, 0.44f, 1.54f, 1.02f, 1.8f, 2, 0.7f, 0.010f),
        OrbitStarParticle(3, 0.70f, 1.30f, 1.18f, 1.2f, 0, 3.1f, 0.014f),
        // 簇 2（右下星群）
        OrbitStarParticle(4, 2.52f, 1.42f, 1.05f, 4.8f, 1, 1.8f, 0.009f),
        OrbitStarParticle(0, 2.78f, 1.12f, 1.22f, 3.6f, 0, 0.5f, 0.012f),
        OrbitStarParticle(1, 3.05f, 1.50f, 0.88f, 3.2f, 2, 2.9f, 0.010f),
        OrbitStarParticle(2, 2.36f, 1.28f, 1.12f, 1.7f, 1, 4.0f, 0.011f),
        OrbitStarParticle(3, 2.92f, 1.36f, 0.96f, 1.1f, 0, 1.5f, 0.015f),
        // 簇 3（右上/左下灵动伴星）
        OrbitStarParticle(0, 4.55f, 1.26f, 1.10f, 3.5f, 2, 2.1f, 0.010f),
        OrbitStarParticle(1, 4.88f, 1.46f, 0.94f, 3.0f, 0, 3.7f, 0.012f),
        OrbitStarParticle(2, 5.20f, 1.16f, 1.20f, 1.6f, 1, 0.9f, 0.013f),
        OrbitStarParticle(3, 5.55f, 1.52f, 0.86f, 1.2f, 2, 4.8f, 0.016f)
    )

    fun setListening(listening: Boolean) {
        isListeningState = listening
    }

    fun triggerTapSparkle() {
        tapSparkleBoost = 1.0f
        postInvalidateOnAnimation()
    }

    fun updatePalette(newGlow: Int, newSurfaceBg: Int, newKbBg: Int) {
        glowColor = newGlow
        surfaceBgColor = newSurfaceBg
        keyboardSurfaceBgColor = newKbBg
        palette = StarlightColorAdapter.resolvePalette(
            rawGlowColor = glowColor,
            surfaceBgColor = surfaceBgColor,
            keyboardBgColor = keyboardSurfaceBgColor
        )
        invalidate()
    }

    fun updateRmsDb(rmsdB: Float) {
        targetRmsNorm = ((rmsdB + 2f) / 11f).coerceIn(0.12f, 1.0f)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val baseR = min(w, h) * 0.255f
        val now = SystemClock.uptimeMillis()

        val dtSec = if (lastFrameMs == 0L) 0.016f else ((now - lastFrameMs).coerceIn(1L, 64L) / 1000f)
        lastFrameMs = now

        currentRmsNorm += (targetRmsNorm - currentRmsNorm) * 0.25f
        if (!isListeningState && tapSparkleBoost > 0.02f) {
            tapSparkleBoost = (tapSparkleBoost - dtSec * 0.55f).coerceAtLeast(0f)
        }

        // 旋转角速度：说话聆听时轻盈欢快旋转并随声音分贝加速；待机时温柔慢速星轨流转
        val activeEnergy = if (isListeningState) (0.75f + currentRmsNorm * 0.65f) else (0.28f + tapSparkleBoost * 0.52f)
        val angularSpeed = if (isListeningState) {
            1.55f + currentRmsNorm * 1.45f
        } else {
            0.48f + tapSparkleBoost * 0.95f
        }
        rotAngleRad = (rotAngleRad + dtSec * angularSpeed) % (Math.PI.toFloat() * 200f)

        val pulse = if (isListeningState) {
            1.0f + currentRmsNorm * 0.38f + 0.07f * sin(now * 0.010f)
        } else {
            1.0f + 0.04f * sin(now * 0.0045f) + tapSparkleBoost * 0.12f
        }

        val tintCol = palette.meteorPrimaryTint
        val acc1 = palette.meteorAccent1
        val acc2 = palette.meteorAccent2
        val haloCol = palette.softHaloColor
        val rT = Color.red(tintCol)
        val gT = Color.green(tintCol)
        val bT = Color.blue(tintCol)
        val rA1 = Color.red(acc1)
        val gA1 = Color.green(acc1)
        val bA1 = Color.blue(acc1)
        val rA2 = Color.red(acc2)
        val gA2 = Color.green(acc2)
        val bA2 = Color.blue(acc2)

        // =========================================================================
        // 1. 夏以昼同款「多层旋转星云大光晕」（中心呼吸柔光 + 3 团随圈圈同步旋转的流光星云团）
        // =========================================================================
        val outerR = baseR * pulse * 1.72f
        val mainAuraGrad = RadialGradient(
            cx, cy, outerR.coerceAtLeast(12f),
            intArrayOf(
                Color.argb(if (isListeningState) 185 else 115, rT, gT, bT),
                Color.argb(if (isListeningState) 110 else 62, rA1, gA1, bA1),
                Color.argb(if (isListeningState) 45 else 22, rA2, gA2, bA2),
                Color.argb(0, rT, gT, bT)
            ),
            floatArrayOf(0f, 0.45f, 0.76f, 1f),
            Shader.TileMode.CLAMP
        )
        fillPaint.shader = mainAuraGrad
        canvas.drawCircle(cx, cy, outerR, fillPaint)

        // 3 朵随星轨旋转的偏心夏以昼柔光星云团，让光晕本身呈现灵动的流转呼吸感
        for (k in 0 until 3) {
            val cloudAng = rotAngleRad * (1.05f + k * 0.12f) + k * 2.094f
            val orbitDist = baseR * (0.52f + 0.18f * sin(now * 0.005f + k * 1.7f)) * pulse
            val ncx = cx + cos(cloudAng) * orbitDist
            val ncy = cy + sin(cloudAng) * orbitDist
            val cloudR = baseR * (0.95f + 0.22f * activeEnergy)
            val cCol = when (k) {
                0 -> tintCol
                1 -> acc1
                else -> haloCol
            }
            val cr = Color.red(cCol)
            val cg = Color.green(cCol)
            val cb = Color.blue(cCol)
            val cloudAlpha = ((if (isListeningState) 92f else 48f) * (0.82f + 0.18f * sin(now * 0.008f + k))).toInt().coerceIn(0, 160)
            fillPaint.shader = RadialGradient(
                ncx, ncy, cloudR.coerceAtLeast(8f),
                intArrayOf(
                    Color.argb(cloudAlpha, cr, cg, cb),
                    Color.argb((cloudAlpha * 0.45f).toInt(), cr, cg, cb),
                    Color.argb(0, cr, cg, cb)
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(ncx, ncy, cloudR, fillPaint)
        }
        fillPaint.shader = null

        // =========================================================================
        // 2. 拼音同款「三层旋转同心圆弧 + 轨道星珠」（1:1 复刻截图圈圈并在说话时丝滑旋转）
        // =========================================================================
        for (i in 0 until 3) {
            val dir = if (i == 1) -0.82f else (1.0f + i * 0.22f)
            val phase = rotAngleRad * dir + i * 2.1f
            val ringR = baseR * (0.88f + i * 0.24f) * (if (isListeningState) (0.96f + currentRmsNorm * 0.24f) else 1.0f)
            val col = when (i) {
                0 -> tintCol
                1 -> acc1
                else -> acc2
            }
            val rc = Color.red(col)
            val gc = Color.green(col)
            val bc = Color.blue(col)

            // 外层微光衬底弧
            ringPaint.strokeWidth = dpF(if (i == 0) 4.5f else 3.2f)
            ringPaint.color = Color.argb(if (isListeningState) (65 - i * 12) else (36 - i * 8), rc, gc, bc)
            ovalRect.set(cx - ringR, cy - ringR, cx + ringR, cy + ringR)
            val startDeg = Math.toDegrees(phase.toDouble()).toFloat() % 360f
            canvas.drawArc(ovalRect, startDeg, 115f + i * 20f, false, ringPaint)
            canvas.drawArc(ovalRect, startDeg + 180f, 95f + i * 15f, false, ringPaint)

            // 核心精致圆弧线
            ringPaint.strokeWidth = dpF(if (i == 0) 2.2f else 1.45f)
            ringPaint.color = Color.argb(
                if (isListeningState) (210 - i * 35) else (135 - i * 24),
                rc, gc, bc
            )
            canvas.drawArc(ovalRect, startDeg, 115f + i * 20f, false, ringPaint)
            canvas.drawArc(ovalRect, startDeg + 180f, 95f + i * 15f, false, ringPaint)

            // 环轨上的发光白珍珠圆点
            val starAng = phase + 0.6f
            val sx = cx + cos(starAng) * ringR
            val sy = cy + sin(starAng) * ringR
            fillPaint.color = Color.argb(if (isListeningState) 110 else 60, rc, gc, bc)
            canvas.drawCircle(sx, sy, dpF(4.6f), fillPaint)
            fillPaint.color = Color.argb(if (isListeningState) 245 else 175, 255, 255, 255)
            canvas.drawCircle(sx, sy, dpF(2.25f), fillPaint)
        }

        // =========================================================================
        // 3. 夏以昼同款「旋转弯弯弧形流光游丝 + 顶端领航四芒星 ✦」(Gossamer Meteor Ribbons)
        // =========================================================================
        val ribbonAlphaBase = if (isListeningState) (0.78f + 0.22f * currentRmsNorm).coerceIn(0f, 1f) else (0.42f + 0.45f * tapSparkleBoost).coerceIn(0f, 1f)
        for (rIdx in 0 until 3) {
            val rDir = if (rIdx == 1) -1.12f else (1.28f - rIdx * 0.15f)
            val startAng = rotAngleRad * rDir + rIdx * 2.09f + 0.85f
            val sweepAng = (if (rIdx == 0) 1.25f else 0.96f) * (if (rIdx == 1) -1f else 1f)
            val baseOrbitR = baseR * (0.98f + rIdx * 0.23f) * (if (isListeningState) (0.96f + currentRmsNorm * 0.26f) else 1.0f)
            val swellPx = dpF(5.5f + rIdx * 2.2f) * (0.75f + 0.45f * activeEnergy)
            val maxHalfW = dpF(if (rIdx == 0) 1.35f else 1.05f)
            val wavePx = dpF(1.8f) * (if (rIdx % 2 == 0) 1f else -1f)
            val wavePhase = now * 0.007f + rIdx * 1.9f

            val cCol = when (rIdx) {
                0 -> tintCol
                1 -> acc1
                else -> acc2
            }
            val rc = Color.red(cCol)
            val gc = Color.green(cCol)
            val bc = Color.blue(cCol)

            // A. 外层柔焦星晕游丝
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW * 1.85f, wavePx, wavePhase, 0f, 1f)
            fillPaint.color = Color.argb((105f * ribbonAlphaBase).toInt().coerceIn(0, 255), rc, gc, bc)
            canvas.drawPath(ribbonPath, fillPaint)

            // B. 中层丝滑彩色流光主体
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW, wavePx, wavePhase, 0.06f, 0.94f)
            val midR = (rc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            val midG = (gc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            val midB = (bc * 0.48f + 255 * 0.52f).toInt().coerceIn(0, 255)
            fillPaint.color = Color.argb((210f * ribbonAlphaBase).toInt().coerceIn(0, 255), midR, midG, midB)
            canvas.drawPath(ribbonPath, fillPaint)

            // C. 内芯璀璨纯白游丝
            buildCircularGossamerRibbonPath(cx, cy, baseOrbitR, startAng, sweepAng, swellPx, maxHalfW * 0.48f, wavePx, wavePhase, 0.18f, 0.86f)
            fillPaint.color = Color.argb((248f * ribbonAlphaBase).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawPath(ribbonPath, fillPaint)

            // D. 流光游丝前端领航的闪烁四芒星 ✦
            val tipS = 0.86f
            val tipAng = startAng + sweepAng * tipS
            val tipArch = sin(tipS * Math.PI.toFloat())
            val tipR = baseOrbitR + swellPx * tipArch + sin(tipS * 5.2f + wavePhase) * wavePx * tipArch
            val tipX = cx + cos(tipAng) * tipR
            val tipY = cy + sin(tipAng) * tipR
            drawVoiceSolidFourPointStar(
                canvas = canvas,
                sx = tipX,
                sy = tipY,
                rayLenPx = dpF(if (rIdx == 0) 3.8f else 3.1f) * (0.85f + 0.25f * activeEnergy),
                rotationDeg = Math.toDegrees(tipAng.toDouble()).toFloat() + 18f,
                alpha = ribbonAlphaBase,
                rT = rc,
                gT = gc,
                bT = bc
            )
        }

        // =========================================================================
        // 4. 夏以昼同款「环绕闪烁簇状星群」（实心四芒星 ✦ + 空心四芒星 ✧ + 十字星耀 ✷ + 柔光圈 ° + 星尘 ·）
        // =========================================================================
        for (star in orbitStars) {
            val curAng = star.baseAngleRad + rotAngleRad * star.speedFactor
            val breatheOut = 1.0f + (if (isListeningState) currentRmsNorm * 0.24f else 0.0f) + 0.05f * sin(now * 0.005f + star.twinklePhase)
            val rad = baseR * star.radiusFactor * breatheOut
            val sx = cx + cos(curAng) * rad
            val sy = cy + sin(curAng) * rad

            val twinkle = 0.58f + 0.42f * sin(now * star.twinkleSpeed + star.twinklePhase)
            val sAlpha = ((if (isListeningState) 0.96f else 0.62f) * twinkle).coerceIn(0.05f, 1.0f)

            val cCol = when (star.colorVariant) {
                1 -> acc1
                2 -> acc2
                else -> tintCol
            }
            val rc = Color.red(cCol)
            val gc = Color.green(cCol)
            val bc = Color.blue(cCol)
            val sizePx = dpF(star.sizeDp) * (0.86f + 0.22f * twinkle)
            val rotDeg = Math.toDegrees((curAng * 0.6f).toDouble()).toFloat()

            when (star.shapeType) {
                0 -> drawVoiceSolidFourPointStar(canvas, sx, sy, sizePx, rotDeg, sAlpha, rc, gc, bc)
                1 -> drawVoiceHollowFourPointStar(canvas, sx, sy, sizePx, rotDeg, sAlpha, rc, gc, bc)
                4 -> drawVoiceCelestialCrossFlare(canvas, sx, sy, sizePx, rotDeg * 0.4f, sAlpha, rc, gc, bc)
                2 -> {
                    // 柔光小光圈 °
                    fillPaint.color = Color.argb((72f * sAlpha).toInt().coerceIn(0, 255), rc, gc, bc)
                    canvas.drawCircle(sx, sy, sizePx * 1.25f, fillPaint)
                    ringPaint.strokeWidth = dpF(0.85f)
                    ringPaint.color = Color.argb((220f * sAlpha).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx, sy, sizePx, ringPaint)
                }
                else -> {
                    // 璀璨微星尘 ·
                    fillPaint.color = Color.argb((115f * sAlpha).toInt().coerceIn(0, 255), rc, gc, bc)
                    canvas.drawCircle(sx, sy, sizePx * 2.1f, fillPaint)
                    fillPaint.color = Color.argb((250f * sAlpha).toInt().coerceIn(0, 255), 255, 255, 255)
                    canvas.drawCircle(sx, sy, sizePx * 0.9f, fillPaint)
                }
            }
        }

        // =========================================================================
        // 5. 中心星光麦克风圆盘与极简白话筒图标（1:1 复刻截图）
        // =========================================================================
        val coreR = baseR * 0.68f
        fillPaint.color = Color.argb(if (palette.isLightSurface) 225 else 200, rT, gT, bT)
        canvas.drawCircle(cx, cy, coreR, fillPaint)

        // 圆盘边缘柔白微高光圈
        ringPaint.strokeWidth = dpF(1.1f)
        ringPaint.color = Color.argb(if (isListeningState) 145 else 85, 255, 255, 255)
        canvas.drawCircle(cx, cy, coreR, ringPaint)

        // 中央纯白极简麦克风图标
        ringPaint.color = Color.WHITE
        ringPaint.strokeWidth = dpF(2.0f)
        val micW = dpF(5.5f)
        val micH = dpF(9.5f)
        ovalRect.set(cx - micW, cy - micH - dpF(2f), cx + micW, cy + micH - dpF(4f))
        canvas.drawRoundRect(ovalRect, micW, micW, ringPaint)
        ovalRect.set(cx - dpF(9.5f), cy - dpF(8f), cx + dpF(9.5f), cy + dpF(8.5f))
        canvas.drawArc(ovalRect, 15f, 150f, false, ringPaint)
        canvas.drawLine(cx, cy + dpF(8.5f), cx, cy + dpF(13f), ringPaint)
        canvas.drawLine(cx - dpF(5f), cy + dpF(13f), cx + dpF(5f), cy + dpF(13f), ringPaint)

        if (isAttachedToWindow && visibility == VISIBLE) {
            postInvalidateOnAnimation()
        }
    }

    private fun buildCircularGossamerRibbonPath(
        cx: Float,
        cy: Float,
        baseRadiusPx: Float,
        startAngle: Float,
        sweepAngle: Float,
        swellOutPx: Float,
        maxHalfWidthPx: Float,
        rippleWavePx: Float,
        ripplePhase: Float,
        sStart: Float,
        sEnd: Float
    ) {
        ribbonPath.reset()
        val steps = 12
        for (i in 0..steps) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.0f + ripplePhase) * rippleWavePx * arch
            val centerR = baseRadiusPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rOut = centerR + halfW
            val x = cx + cos(ang) * rOut
            val y = cy + sin(ang) * rOut
            if (i == 0) ribbonPath.moveTo(x, y) else ribbonPath.lineTo(x, y)
        }
        for (i in steps downTo 0) {
            val u = i.toFloat() / steps
            val s = sStart + (sEnd - sStart) * u
            val ang = startAngle + sweepAngle * s
            val arch = sin(s * Math.PI.toFloat())
            val wave = sin(s * 5.0f + ripplePhase) * rippleWavePx * arch
            val centerR = baseRadiusPx + swellOutPx * arch + wave
            val localEnv = sin(u * Math.PI.toFloat())
            val halfW = maxHalfWidthPx * localEnv * arch
            val rIn = centerR - halfW
            val x = cx + cos(ang) * rIn
            val y = cy + sin(ang) * rIn
            ribbonPath.lineTo(x, y)
        }
        ribbonPath.close()
    }

    private fun drawVoiceSolidFourPointStar(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 0.6f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        fillPaint.color = Color.argb((110f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
        canvas.drawCircle(0f, 0f, rayLenPx * 0.62f, fillPaint)

        val orthoLen = rayLenPx * 0.78f
        val waist = rayLenPx * 0.15f
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        fillPaint.color = Color.argb(
            (225f * alpha).toInt().coerceIn(0, 255),
            (rT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255),
            (gT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255),
            (bT * 0.35f + 255 * 0.65f).toInt().coerceIn(0, 255)
        )
        canvas.drawPath(starPath, fillPaint)

        val coreLen = rayLenPx * 0.56f
        val coreOrtho = orthoLen * 0.56f
        val coreWaist = waist * 0.52f
        starPath.reset()
        starPath.moveTo(0f, -coreLen)
        starPath.quadTo(coreWaist, -coreWaist, coreOrtho, 0f)
        starPath.quadTo(coreWaist, coreWaist, 0f, coreLen)
        starPath.quadTo(-coreWaist, coreWaist, -coreOrtho, 0f)
        starPath.quadTo(-coreWaist, -coreWaist, 0f, -coreLen)
        starPath.close()
        fillPaint.color = Color.argb((252f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, fillPaint)

        canvas.restoreToCount(sc)
    }

    private fun drawVoiceHollowFourPointStar(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 0.8f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val orthoLen = rayLenPx * 0.82f
        val waist = rayLenPx * 0.22f
        starPath.reset()
        starPath.moveTo(0f, -rayLenPx)
        starPath.quadTo(waist, -waist, orthoLen, 0f)
        starPath.quadTo(waist, waist, 0f, rayLenPx)
        starPath.quadTo(-waist, waist, -orthoLen, 0f)
        starPath.quadTo(-waist, -waist, 0f, -rayLenPx)
        starPath.close()

        ringPaint.strokeWidth = dpF(0.95f)
        ringPaint.color = Color.argb(
            (225f * alpha).toInt().coerceIn(0, 255),
            (rT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255),
            (gT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255),
            (bT * 0.28f + 255 * 0.72f).toInt().coerceIn(0, 255)
        )
        canvas.drawPath(starPath, ringPaint)
        canvas.restoreToCount(sc)
    }

    private fun drawVoiceCelestialCrossFlare(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        rayLenPx: Float,
        rotationDeg: Float,
        alpha: Float,
        rT: Int,
        gT: Int,
        bT: Int
    ) {
        if (rayLenPx <= 1.0f || alpha <= 0.02f) return
        val sc = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        // 柔和星芒中心光晕
        fillPaint.color = Color.argb((125f * alpha).toInt().coerceIn(0, 255), rT, gT, bT)
        canvas.drawCircle(0f, 0f, rayLenPx * 0.68f, fillPaint)

        val longR = rayLenPx * 1.15f
        val shortR = rayLenPx * 0.72f
        val diagR = rayLenPx * 0.42f
        val waist = rayLenPx * 0.11f

        // 对角细芒
        ringPaint.strokeWidth = dpF(0.75f)
        ringPaint.color = Color.argb((170f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawLine(-diagR, -diagR, diagR, diagR, ringPaint)
        canvas.drawLine(-diagR, diagR, diagR, -diagR, ringPaint)

        // 主十字星耀
        starPath.reset()
        starPath.moveTo(0f, -longR)
        starPath.quadTo(waist, -waist, shortR, 0f)
        starPath.quadTo(waist, waist, 0f, longR)
        starPath.quadTo(-waist, waist, -shortR, 0f)
        starPath.quadTo(-waist, -waist, 0f, -longR)
        starPath.close()
        fillPaint.color = Color.argb((248f * alpha).toInt().coerceIn(0, 255), 255, 255, 255)
        canvas.drawPath(starPath, fillPaint)

        canvas.restoreToCount(sc)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
