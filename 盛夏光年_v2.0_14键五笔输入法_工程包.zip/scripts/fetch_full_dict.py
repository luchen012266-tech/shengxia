#!/usr/bin/env python3
# -*- coding: utf-8 -*-
'''
Compiles a comprehensive 86 Wubi + Segmented Pinyin dictionary for ShengXiaGuangNian IME v2.0.
Combines:
- rime/rime-wubi (wubi86.dict.yaml)
- iDvel/rime-ice (cn_dicts/8105.dict.yaml & cn_dicts/base.dict.yaml)
- rime/rime-luna-pinyin (luna_pinyin.dict.yaml)
Auto-generates missing 86 Wubi codes for Pinyin phrases and missing segmented Pinyin for Wubi phrases.
'''
import os
import urllib.request

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
RIME_ICE_8105_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/8105.dict.yaml"
RIME_ICE_BASE_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/base.dict.yaml"
LUNA_PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def clean_py_syllable(s):
    s = s.strip().lower()
    return "".join(ch for ch in s if 'a' <= ch <= 'z')

def parse_rime_yaml(lines):
    in_body = False
    for line in lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip()
            weight = 500
            if len(parts) >= 3:
                w_str = parts[2].strip().rstrip("%")
                try:
                    weight = int(float(w_str))
                except ValueError:
                    weight = 500
            yield word, code, weight

def main():
    wubi_lines = download_lines(WUBI_URL)
    ice_8105_lines = download_lines(RIME_ICE_8105_URL)
    ice_base_lines = download_lines(RIME_ICE_BASE_URL)
    luna_lines = download_lines(LUNA_PINYIN_URL)

    if not wubi_lines:
        print("Offline mode: keeping starter dictionary.")
        return

    single_char_wubi = {}
    single_char_py = {}
    word_py_map = {}

    # 1. Parse single-char & phrase Pinyin from rime-ice 8105, luna_pinyin, and rime-ice base
    for word, raw_py, weight in parse_rime_yaml(ice_8105_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if len(word) == 1 and syllables:
            if word not in single_char_py:
                single_char_py[word] = syllables[0]

    for word, raw_py, weight in parse_rime_yaml(luna_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables:
            continue
        seg_py = "'".join(syllables)
        if len(word) == 1 and word not in single_char_py:
            single_char_py[word] = syllables[0]
        if word not in word_py_map:
            word_py_map[word] = (seg_py, weight)

    for word, raw_py, weight in parse_rime_yaml(ice_base_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables or len(word) > 8:
            continue
        seg_py = "'".join(syllables)
        if word not in word_py_map or weight > word_py_map[word][1]:
            word_py_map[word] = (seg_py, weight)

    # 2. Parse Wubi 86 entries & build single_char_wubi
    wubi_entries = []
    seen_wubi_words = set()
    for word, raw_code, weight in parse_rime_yaml(wubi_lines):
        code = raw_code.strip().lower()
        if not word or not code or not code.isalpha():
            continue
        wubi_entries.append((word, code, weight))
        seen_wubi_words.add(word)
        if len(word) == 1:
            if word not in single_char_wubi or len(code) > len(single_char_wubi[word]):
                single_char_wubi[word] = code

    def gen_wubi86(word):
        if len(word) == 1:
            return single_char_wubi.get(word, "")[:4]
        codes = [single_char_wubi.get(ch, "") for ch in word]
        if any(not c for c in codes):
            return ""
        if len(word) == 2:
            return codes[0][:2] + codes[1][:2]
        elif len(word) == 3:
            return codes[0][:1] + codes[1][:1] + codes[2][:2]
        else:
            return codes[0][:1] + codes[1][:1] + codes[2][:1] + codes[-1][:1]

    def gen_seg_pinyin(word):
        if word in word_py_map:
            return word_py_map[word][0]
        syls = [single_char_py.get(ch, "") for ch in word]
        if all(syls):
            return "'".join(syls)
        return ""

    # 3. Ensure popular modern words like 薅羊毛, 高羊茅, 盛夏光年 are always present
    extra_modern = [
        ("薅羊毛", "hao'yang'mao", 9500),
        ("高羊茅", "gao'yang'mao", 6000),
        ("盛夏光年", "sheng'xia'guang'nian", 9900),
        ("尴尬", "gan'ga", 9000),
        ("角色扮演", "jue'se'ban'yan", 8500),
        ("世界观", "shi'jie'guan", 8500)
    ]
    for w, py, wt in extra_modern:
        word_py_map[w] = (py, wt)

    # 4. Write merged dictionary to app/src/main/assets/wubi86_dict.tsv
    # Format: word \t wubi_code \t segmented_pinyin \t weight
    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    total_written = 0
    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, weight in wubi_entries:
            seg_py = gen_seg_pinyin(word)
            f.write(f"{word}\t{wcode}\t{seg_py}\t{weight}\n")
            total_written += 1

        # Add Pinyin phrases from rime-ice base / luna that weren't in wubi86
        for word, (seg_py, weight) in word_py_map.items():
            if word not in seen_wubi_words and 1 <= len(word) <= 6:
                wcode = gen_wubi86(word)
                if wcode or seg_py:
                    f.write(f"{word}\t{wcode}\t{seg_py}\t{max(weight, 600)}\n")
                    seen_wubi_words.add(word)
                    total_written += 1

        # Add remaining single chars from 8105
        for ch, py in single_char_py.items():
            if ch not in seen_wubi_words:
                wcode = single_char_wubi.get(ch, "")
                f.write(f"{ch}\t{wcode}\t{py}\t400\n")
                total_written += 1

    # 5. Write single_char_wubi.tsv
    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    with open(single_path, "w", encoding="utf-8") as f:
        all_chars = set(single_char_wubi.keys()) | set(single_char_py.keys())
        for ch in all_chars:
            wcode = single_char_wubi.get(ch, "")
            py = single_char_py.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    print(f"Successfully compiled {total_written} Wubi+Pinyin entries and {len(all_chars)} single chars!")

if __name__ == "__main__":
    main()
