package com.shengxiaguangnian.ime

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Candidate(
    val word: String,
    val wubiHint: String?,     // 拼音匹配出字时显示 86 五笔码，如 "autf"
    val displayCode: String,   // 左上角浮窗显示的编码，如 "hao'yang'mao" 或 "autf"
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0  // 若为长句局部匹配，消耗的键数（0表示消耗全部）
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String, // 如 "hao'yang'mao"
    val t14Wubi: String,
    val t14Pinyin: String,       // 完整拼音的14键编码
    val t14PyAbbr: String,       // 拼音首字母简拼的14键编码（如 hym -> 83d）
    val weight: Int
)

object T14WubiEngine {
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    // 标准普通话拼音音节表（用于在 14 键下自动切分出类似 "hao'yang'mao" 的浮窗提示）
    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "liao", "miao", "niao", "piao", "qiao", "xiao", "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "DUN".lowercase(), "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )

    // T14 音节编码 -> 最常见拼音音节名
    private val t14SyllableMap = LinkedHashMap<String, String>()
    // T14 单字拼音编码 -> 最高频单字列表（用于超长自定义句子自动组词兜底）
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private var initialized = false
    private val entries = ArrayList<DictEntry>(110000)
    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)
    private val userEntries = ArrayList<DictEntry>()

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    @Synchronized
    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        if (initialized) return
        entries.clear()
        singleCharWubi.clear()
        singleCharPinyin.clear()
        t14SyllableMap.clear()
        t14SingleCharByPy.clear()

        for (syl in VALID_SYLLABLES) {
            val code = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code)) {
                t14SyllableMap[code] = syl
            }
        }

        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2) {
                        val word = parts[0].trim()
                        val wcode = parts[1].trim().lowercase()
                        val rawPy = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        val weight = if (parts.size >= 4) parts[3].trim().toIntOrNull() ?: 500 else 500
                        if (word.isNotEmpty()) {
                            if (word.length == 1) {
                                if (wcode.isNotEmpty() && !singleCharWubi.containsKey(word[0])) {
                                    singleCharWubi[word[0]] = wcode
                                }
                                if (rawPy.isNotEmpty() && !singleCharPinyin.containsKey(word[0])) {
                                    singleCharPinyin[word[0]] = rawPy.replace("'", "")
                                }
                            }
                            val segPy = if (rawPy.isNotEmpty()) {
                                if (rawPy.contains('\'') || word.length == 1) rawPy else generateSegmentedPinyinForWord(word).ifEmpty { rawPy }
                            } else {
                                generateSegmentedPinyinForWord(word)
                            }
                            val cleanPy = segPy.replace("'", "")
                            val finalWubi = wcode.ifEmpty { generateWubi86CodeForWord(word) }
                            val t14Py = if (cleanPy.isNotEmpty()) letterToT14Code(cleanPy) else ""
                            val de = DictEntry(
                                word = word,
                                wubiCode = finalWubi,
                                segmentedPinyin = segPy,
                                t14Wubi = if (finalWubi.isNotEmpty()) letterToT14Code(finalWubi) else "",
                                t14Pinyin = t14Py,
                                t14PyAbbr = extractPyAbbrT14(segPy),
                                weight = weight
                            )
                            entries.add(de)
                            if (word.length == 1 && t14Py.isNotEmpty()) {
                                val list = t14SingleCharByPy.getOrPut(t14Py) { ArrayList() }
                                if (list.size < 6) list.add(de)
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        reloadUserDict(dbHelper)
        initialized = true
    }

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        userEntries.clear()
        dbHelper.readableDatabase.rawQuery(
            "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                val w = c.getString(0)
                val wc = c.getString(1)
                val py = c.getString(2).ifEmpty { generateSegmentedPinyinForWord(w) }
                userEntries.add(
                    DictEntry(
                        word = w,
                        wubiCode = wc,
                        segmentedPinyin = py,
                        t14Wubi = c.getString(3),
                        t14Pinyin = c.getString(4),
                        t14PyAbbr = extractPyAbbrT14(py),
                        weight = c.getInt(5)
                    )
                )
            }
        }
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    fun generatePinyinForWord(word: String): String {
        return generateSegmentedPinyinForWord(word)
    }

    /**
     * 将任意长度的 14 键编码切分为带单引号的拼音音节串（如 "hao'yang'mao"）
     */
    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code -> t14SyllableMap[code] ?: code }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    /**
     * 支持任意长度的 14 键五笔 + 拼音混输查询：
     * - 1~4 码：五笔精确匹配优先，同时提供完整拼音匹配、拼音前缀匹配与简拼匹配
     * - 5 码及以上：自动切换为纯拼音长词/整句检索（如打 "haoyangmao" 共 10 键，精准匹配 "薅羊毛(autf)"、"高羊茅(yuac)"）
     * - 若输入超长多音节且词库无现成整词，自动按音节拼接单字生成整句候选，并提供首音节候选字，绝不断流！
     */
    fun queryCandidates(t14Input: String, rawFallback: String, limit: Int = 80): List<Candidate> {
        if (t14Input.isEmpty()) return emptyList()
        val exactWubi = ArrayList<Candidate>()
        val prefixWubi = ArrayList<Candidate>()
        val exactPinyin = ArrayList<Candidate>()
        val abbrPinyin = ArrayList<Candidate>()
        val prefixPinyin = ArrayList<Candidate>()
        val seen = HashSet<String>()

        val isLongPinyinMode = t14Input.length > 4

        fun scanList(list: List<DictEntry>, bonusWeight: Int) {
            for (e in list) {
                // 1. 1~4 码时的五笔匹配
                if (!isLongPinyinMode && e.t14Wubi.isNotEmpty()) {
                    if (e.t14Wubi == t14Input) {
                        if (seen.add(e.word)) {
                            exactWubi.add(
                                Candidate(
                                    word = e.word,
                                    wubiHint = null,
                                    displayCode = e.wubiCode,
                                    weight = e.weight + bonusWeight + 200000,
                                    isWubiMatch = true
                                )
                            )
                        }
                        continue
                    } else if (e.t14Wubi.startsWith(t14Input)) {
                        if (seen.add(e.word)) {
                            prefixWubi.add(
                                Candidate(
                                    word = e.word,
                                    wubiHint = null,
                                    displayCode = e.wubiCode.take(t14Input.length),
                                    weight = e.weight + bonusWeight,
                                    isWubiMatch = true
                                )
                            )
                        }
                    }
                }

                // 2. 全长度拼音精确与前缀匹配（不限 4 码！支持 haoyangmao 等长拼音）
                if (e.t14Pinyin.isNotEmpty()) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    if (e.t14Pinyin == t14Input) {
                        if (seen.add(e.word)) {
                            exactPinyin.add(
                                Candidate(
                                    word = e.word,
                                    wubiHint = wHint,
                                    displayCode = e.segmentedPinyin.ifEmpty { rawFallback },
                                    weight = e.weight + bonusWeight + 150000 + e.word.length * 5000,
                                    isWubiMatch = false
                                )
                            )
                        }
                        continue
                    } else if (e.t14Pinyin.startsWith(t14Input) && e.t14Pinyin.length <= t14Input.length + 6) {
                        if (seen.add(e.word)) {
                            prefixPinyin.add(
                                Candidate(
                                    word = e.word,
                                    wubiHint = wHint,
                                    displayCode = segmentT14ToPinyinDisplay(t14Input, rawFallback),
                                    weight = e.weight + bonusWeight,
                                    isWubiMatch = false
                                )
                            )
                        }
                    }
                }

                // 3. 多字词简拼匹配（如打 hym 匹配 薅羊毛）
                if (t14Input.length >= 2 && e.t14PyAbbr == t14Input) {
                    if (seen.add(e.word)) {
                        val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                        abbrPinyin.add(
                            Candidate(
                                word = e.word,
                                wubiHint = wHint,
                                displayCode = e.segmentedPinyin.ifEmpty { rawFallback },
                                weight = e.weight + bonusWeight + 40000,
                                isWubiMatch = false
                            )
                        )
                    }
                }
            }
        }

        scanList(userEntries, 60000)
        scanList(entries, 0)

        exactWubi.sortByDescending { it.weight }
        exactPinyin.sortByDescending { it.weight }
        abbrPinyin.sortByDescending { it.weight }
        prefixWubi.sortByDescending { it.weight }
        prefixPinyin.sortByDescending { it.weight }

        val result = ArrayList<Candidate>(limit)

        if (!isLongPinyinMode) {
            for (c in exactWubi) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin.take(10)) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixWubi.take(25)) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
        } else {
            // >4 码长拼音模式：精确全拼词组第一优先，接着前缀拼音词组、简拼词组、自动音节组词兜底
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin.take(30)) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin.take(15)) {
                result.add(c)
                if (result.size >= limit) return result
            }
        }

        // 4. 如果输入了很长的拼音（如自造长句），自动按音节组字 + 提供首音节单字候选，保证永远有候选字！
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            val segDisplay = sylCodes.joinToString("'") { code -> t14SyllableMap[code] ?: code }
            // 自动合成多音节词条
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord)) {
                    val wHint = generateWubi86CodeForWord(synthWord)
                    result.add(
                        0.coerceAtMost(result.size),
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            // 同时附上第一个音节对应的常见单字（选中后只消耗第一个音节的长度）
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl]?.sortedByDescending { it.weight } ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = fc.wubiCode,
                            displayCode = segDisplay,
                            weight = fc.weight,
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        return result
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()
        val words = ArrayList<String>()
        try {
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var pos = 0x2628
            while (pos + 4 < bytes.size) {
                val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                pos += 4 + pyIdxBytesLen
                if (samePyCount <= 0 || samePyCount > 100 || pos >= bytes.size) break
                for (i in 0 until samePyCount) {
                    if (pos + 2 >= bytes.size) break
                    val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2
                    if (wordByteLen <= 0 || wordByteLen > 64 || pos + wordByteLen > bytes.size) break
                    val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                    pos += wordByteLen
                    if (pos + 2 > bytes.size) break
                    val extLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2 + extLen
                    if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 2..12) {
                        words.add(word)
                    }
                }
            }
        } catch (_: Exception) {}
        return words.distinct()
    }
}
