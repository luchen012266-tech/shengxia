package com.shengxiaguangnian.ime

data class SymbolEntry(
    val text: String,
    val isEnglish: Boolean = false
)

object EmojiKaomojiData {

    // 1:1 复刻图 2 的左侧分类符号库（带右上角 "英" 字标识）
    val SYMBOL_CATEGORIES = linkedMapOf(
        "最近" to listOf(
            SymbolEntry("～"), SymbolEntry("【】"), SymbolEntry("；"), SymbolEntry("“”"), SymbolEntry("："),
            SymbolEntry("（）"), SymbolEntry("+", true), SymbolEntry(":", true), SymbolEntry("{}", true), SymbolEntry("/", true),
            SymbolEntry("%"), SymbolEntry("`", true), SymbolEntry("×"), SymbolEntry("[]", true), SymbolEntry("&", true),
            SymbolEntry("-", true), SymbolEntry(")", true), SymbolEntry("(", true), SymbolEntry("❤️"), SymbolEntry("◎"),
            SymbolEntry("，"), SymbolEntry("。"), SymbolEntry("？"), SymbolEntry("！"), SymbolEntry("、"),
            SymbolEntry("…"), SymbolEntry("—"), SymbolEntry("《》"), SymbolEntry("「」"), SymbolEntry("『』")
        ),
        "中文" to listOf(
            SymbolEntry("，"), SymbolEntry("。"), SymbolEntry("？"), SymbolEntry("！"), SymbolEntry("、"),
            SymbolEntry("："), SymbolEntry("；"), SymbolEntry("“”"), SymbolEntry("‘’"), SymbolEntry("（）"),
            SymbolEntry("【】"), SymbolEntry("《》"), SymbolEntry("「」"), SymbolEntry("『』"), SymbolEntry("〔〕"),
            SymbolEntry("…"), SymbolEntry("——"), SymbolEntry("～"), SymbolEntry("·"), SymbolEntry("｜"),
            SymbolEntry("“"), SymbolEntry("”"), SymbolEntry("‘"), SymbolEntry("’"), SymbolEntry("（"),
            SymbolEntry("）"), SymbolEntry("【"), SymbolEntry("】"), SymbolEntry("《"), SymbolEntry("》"),
            SymbolEntry("「"), SymbolEntry("」"), SymbolEntry("『"), SymbolEntry("』"), SymbolEntry("﹏"),
            SymbolEntry("￥"), SymbolEntry("‰"), SymbolEntry("§"), SymbolEntry("※"), SymbolEntry("〇")
        ),
        "英文" to listOf(
            SymbolEntry(",", true), SymbolEntry(".", true), SymbolEntry("?", true), SymbolEntry("!", true), SymbolEntry(":", true),
            SymbolEntry(";", true), SymbolEntry("\"", true), SymbolEntry("'", true), SymbolEntry("()", true), SymbolEntry("[]", true),
            SymbolEntry("{}", true), SymbolEntry("<>", true), SymbolEntry("+", true), SymbolEntry("-", true), SymbolEntry("*", true),
            SymbolEntry("/", true), SymbolEntry("=", true), SymbolEntry("_", true), SymbolEntry("\\", true), SymbolEntry("|", true),
            SymbolEntry("@", true), SymbolEntry("#", true), SymbolEntry("$", true), SymbolEntry("%", true), SymbolEntry("^", true),
            SymbolEntry("&", true), SymbolEntry("~", true), SymbolEntry("`", true), SymbolEntry("(", true), SymbolEntry(")", true),
            SymbolEntry("[", true), SymbolEntry("]", true), SymbolEntry("{", true), SymbolEntry("}", true), SymbolEntry("<", true),
            SymbolEntry(">", true)
        ),
        "表情" to listOf(
            SymbolEntry("❤️"), SymbolEntry("✨"), SymbolEntry("🔥"), SymbolEntry("⭐"), SymbolEntry("🎉"),
            SymbolEntry("🌹"), SymbolEntry("☀️"), SymbolEntry("🌙"), SymbolEntry("💧"), SymbolEntry("⚡"),
            SymbolEntry("(T^T)"), SymbolEntry("(￣.￣)"), SymbolEntry("→_→"), SymbolEntry("\\^O^/"), SymbolEntry("つ♡⊂"),
            SymbolEntry("☺"), SymbolEntry("☻"), SymbolEntry("♡"), SymbolEntry("♥"), SymbolEntry("♤"),
            SymbolEntry("♠"), SymbolEntry("♢"), SymbolEntry("♦"), SymbolEntry("♧"), SymbolEntry("♣"),
            SymbolEntry("♪"), SymbolEntry("♫"), SymbolEntry("♬"), SymbolEntry("♭"), SymbolEntry("♮")
        ),
        "网络" to listOf(
            SymbolEntry("### "), SymbolEntry("**"), SymbolEntry("```"), SymbolEntry("> "), SymbolEntry("- [ ] "),
            SymbolEntry("http://", true), SymbolEntry("https://", true), SymbolEntry("www.", true), SymbolEntry(".com", true), SymbolEntry(".cn", true),
            SymbolEntry("◎"), SymbolEntry("●"), SymbolEntry("○"), SymbolEntry("◆"), SymbolEntry("◇"),
            SymbolEntry("■"), SymbolEntry("□"), SymbolEntry("▲"), SymbolEntry("△"), SymbolEntry("▼"),
            SymbolEntry("▽"), SymbolEntry("★"), SymbolEntry("☆"), SymbolEntry("→"), SymbolEntry("←"),
            SymbolEntry("↑"), SymbolEntry("↓"), SymbolEntry("↔"), SymbolEntry("√"), SymbolEntry("×")
        ),
        "数学" to listOf(
            SymbolEntry("＋"), SymbolEntry("－"), SymbolEntry("×"), SymbolEntry("÷"), SymbolEntry("＝"),
            SymbolEntry("≠"), SymbolEntry("≈"), SymbolEntry("≡"), SymbolEntry("≤"), SymbolEntry("≥"),
            SymbolEntry("＜"), SymbolEntry("＞"), SymbolEntry("±"), SymbolEntry("√"), SymbolEntry("∞"),
            SymbolEntry("∵"), SymbolEntry("∴"), SymbolEntry("⊥"), SymbolEntry("∥"), SymbolEntry("∠"),
            SymbolEntry("°"), SymbolEntry("′"), SymbolEntry("″"), SymbolEntry("％"), SymbolEntry("‰"),
            SymbolEntry("∪"), SymbolEntry("∩"), SymbolEntry("∈"), SymbolEntry("∉"), SymbolEntry("⊆")
        ),
        "序号" to listOf(
            SymbolEntry("①"), SymbolEntry("②"), SymbolEntry("③"), SymbolEntry("④"), SymbolEntry("⑤"),
            SymbolEntry("⑥"), SymbolEntry("⑦"), SymbolEntry("⑧"), SymbolEntry("⑨"), SymbolEntry("⑩"),
            SymbolEntry("一、"), SymbolEntry("二、"), SymbolEntry("三、"), SymbolEntry("四、"), SymbolEntry("五、"),
            SymbolEntry("1."), SymbolEntry("2."), SymbolEntry("3."), SymbolEntry("4."), SymbolEntry("5."),
            SymbolEntry("Ⅰ"), SymbolEntry("Ⅱ"), SymbolEntry("Ⅲ"), SymbolEntry("Ⅳ"), SymbolEntry("Ⅴ"),
            SymbolEntry("Ⅵ"), SymbolEntry("Ⅶ"), SymbolEntry("Ⅷ"), SymbolEntry("Ⅸ"), SymbolEntry("Ⅹ")
        )
    )

    val EMOJI_CATEGORIES = linkedMapOf(
        "笑脸" to listOf(
            "🤣", "🤔", "😘", "😂", "🥺", "🥳", "😭", "😝",
            "👌", "😠", "😋", "🤨", "✌️", "❤️", "😅", "😆",
            "🌹", "😢", "😉", "🥰", "🍠", "☺️", "😄", "😊",
            "🌞", "😤", "🙁", "🙃", "🍓", "🍒", "😌", "⭐",
            "😍", "🤩", "😎", "🥳", "😏", "😒", "😞", "😔",
            "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩",
            "🥱", "😴", "🤤", "😪", "😵", "🤐", "🥴", "🤢"
        ),
        "动物" to listOf(
            "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼",
            "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🐔",
            "🐧", "🐦", "🐤", "🦆", "🦅", "🦉", "🦇", "🐺",
            "🦄", "🐝", "🦋", "🐌", "🐞", "🐢", "🐍", "🐙"
        ),
        "象形" to listOf(
            "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍",
            "💔", "❣️", "💕", "💞", "💓", "💗", "💖", "💘",
            "✨", "🌟", "💫", "💥", "💢", "💦", "💧", "💤",
            "🔥", "🌈", "☀️", "🌙", "⭐", "☁️", "❄️", "⚡"
        ),
        "食物" to listOf(
            "🍓", "🍒", "🍎", "🍉", "🍑", "🍊", "🍋", "🍌",
            "🍍", "🥭", "🍇", "🍈", "🍐", "🥝", "🍅", "🥑",
            "🍠", "🥐", "🍞", "🥖", "🧀", "🥚", "🍳", "🥞",
            "🍔", "🍟", "🍕", "🌭", "🥪", "🌮", "🍜", "🍣",
            "🍦", "🍰", "🎂", "🧁", "🍫", "🍬", "🧋", "☕"
        ),
        "活动" to listOf(
            "🎉", "🎊", "🎈", "🎁", "🎀", "🏆", "🏅", "🥇",
            "⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🎮", "🎲",
            "🎵", "🎶", "🎤", "🎧", "🎸", "🎹", "🎨", "🎬"
        ),
        "旅行" to listOf(
            "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑",
            "🚲", "🛵", "🏍️", "🚄", "✈️", "🚀", "🛸", "⛵",
            "🏠", "🏡", "🏢", "🏰", "🎡", "🎢", "🏖️", "🏔️"
        )
    )

    val KAOMOJI_CATEGORIES = linkedMapOf(
        "经典" to listOf(
            "(T^T)", "<(｀^´)>", "(￣.￣)", "→_→",
            "^v^♡^v^", "(♡>𖥦<)/♥", "つ♡⊂", "૮ ・ﻌ・ ა",
            "\\^O^/", "(^˶•ω•˶^)୨", "ෆ( ˶'ᵕ'˶)ෆ", "(* ´ ︶ ` *)",
            "(,,>᎑<,,)", "(｡•̀ᴗ-)✧", "(๑•̀ㅂ•́)و✧", "✧(≖ ◡ ≖✿)",
            "(¬_¬)", "(°ー°〃)", "(￣▽￣)", "╮(╯▽╰)╭"
        ),
        "卖萌" to listOf(
            "૮ ・ﻌ・ ა", "(^˶•ω•˶^)୨", "ෆ( ˶'ᵕ'˶)ෆ", "(,,>᎑<,,)",
            "(๑>؂<๑）", "(｡･ω･｡)ﾉ♡", "(◍•ᴗ•◍)", "ฅ՞•ﻌ•՞ฅ",
            "(づ｡◕‿‿◕｡)づ", "ヾ(◍°∇°◍)ﾉﾞ", "(๑• . •๑)", "૮₍ ˶•⤙•˶ ₎ა"
        ),
        "爱心" to listOf(
            "^v^♡^v^", "(♡>𖥦<)/♥", "つ♡⊂", "(｡･ω･｡)ﾉ♡",
            "(´▽`ʃ♡ƪ)", "(✿◡‿◡)", "(♥ω♥*)", "♡(˃͈ દ ˂͈ ༶ )",
            "(ɔˆ ³(ˆ⌣ˆc)", "(*♡∀♡)", "(๑′ᴗ‵๑)Ｉ Lᵒᵛᵉᵧₒᵤ❤"
        ),
        "伤心" to listOf(
            "(T^T)", "(；′⌒`)", "(｡•́︿•̀｡)", "(>_<)",
            "(╥﹏╥)", "(´;ω;`)", "o(╥﹏╥)o", "( ´•̥̥̥ω•̥̥̥` )",
            "/(ㄒoㄒ)/~~", "(｡ŏ_ŏ)", "(´-ω-`)"
        )
    )
}
