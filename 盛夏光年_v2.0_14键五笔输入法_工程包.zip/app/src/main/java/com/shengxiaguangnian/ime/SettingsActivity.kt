package com.shengxiaguangnian.ime

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.InputStreamReader

class SettingsActivity : AppCompatActivity() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private val REQ_IMPORT_DICT = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dbHelper = ImeDatabaseHelper(this)
        val prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        T14WubiEngine.ensureInitialized(this, dbHelper)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F5F6FA"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(32))
        }

        val titleTv = TextView(this).apply {
            text = "盛夏光年 v2.0 · 专属 14 键五笔"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#1A1C1E"))
        }
        root.addView(titleTv)

        val subTv = TextView(this).apply {
            text = "纯本地零联网 · 14键五笔+全长拼音混输 · 英文26键 · 面板高度自由调节"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(subTv)

        // 1. 快速启用与切换输入法
        val stepCard = makeCard("第一步：启用与切换到「盛夏光年」")
        val enableBtn = Button(this).apply {
            text = "1. 在系统设置中勾选「盛夏光年」"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }
        val switchBtn = Button(this).apply {
            text = "2. 切换当前输入法为「盛夏光年」"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        stepCard.addView(enableBtn)
        stepCard.addView(switchBtn)
        root.addView(stepCard)

        // 2. 键盘高度调节（也可直接在键盘顶栏点「⚙️ 设置」实时边看边调）
        val heightCard = makeCard("面板高度调节（手机/平板自适应，也可在键盘顶栏点「⚙️ 设置」实时调节）")
        val curHeight = prefs.getInt("keyboard_height_dp", 285)
        val heightTv = TextView(this).apply {
            text = "当前键盘高度：$curHeight dp"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        }
        val seekBar = SeekBar(this).apply {
            max = 300 // 200dp ~ 500dp
            progress = (curHeight - 200).coerceIn(0, 300)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val h = 200 + p
                    heightTv.text = "当前键盘高度：$h dp"
                    prefs.edit().putInt("keyboard_height_dp", h).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        heightCard.addView(heightTv)
        heightCard.addView(seekBar)
        root.addView(heightCard)

        // 3. 新增无限字数常用语 & 管理分类标签
        val phraseCard = makeCard("常用语管理（无字数限制 · 支持万字角色扮演设定集）")
        val catLabel = TextView(this).apply {
            text = "当前分类标签（点击下方可新建或删除分类）："
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        phraseCard.addView(catLabel)

        val categorySpinner = Spinner(this)
        fun refreshSpinner() {
            val cats = dbHelper.getCategories().filter { it != "最近" }
            categorySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cats)
            val defaultCat = intent.getStringExtra("default_category")
            if (defaultCat != null) {
                val idx = cats.indexOf(defaultCat)
                if (idx >= 0) categorySpinner.setSelection(idx)
            }
        }
        refreshSpinner()
        phraseCard.addView(categorySpinner)

        val newCatInput = EditText(this).apply {
            hint = "输入新分类名（如：咒语 / 设定 / 常用）"
        }
        val catBtnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val addCatBtn = Button(this).apply {
            text = "＋新增分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val name = newCatInput.text.toString().trim()
                if (name.isNotEmpty()) {
                    dbHelper.addCategory(name)
                    newCatInput.setText("")
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已添加分类：$name", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val delCatBtn = Button(this).apply {
            text = "删除选中分类"
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                val sel = categorySpinner.selectedItem?.toString() ?: return@setOnClickListener
                if (sel == "收藏" || sel == "最近") {
                    Toast.makeText(this@SettingsActivity, "基础分类不可删除", Toast.LENGTH_SHORT).show()
                } else {
                    dbHelper.deleteCategory(sel)
                    refreshSpinner()
                    Toast.makeText(this@SettingsActivity, "已删除分类：$sel", Toast.LENGTH_SHORT).show()
                }
            }
        }
        catBtnRow.addView(addCatBtn)
        catBtnRow.addView(delCatBtn)
        phraseCard.addView(newCatInput)
        phraseCard.addView(catBtnRow)

        val phraseInput = EditText(this).apply {
            hint = "在此粘贴或输入长篇常用语（无字数上限，支持 10000+ 字）..."
            minLines = 4
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
        }
        val starCheck = CheckBox(this).apply {
            text = "同时加入「收藏」星标置顶"
            isChecked = true
        }
        val savePhraseBtn = Button(this).apply {
            text = "保存常用语到选中分类"
            setOnClickListener {
                val cat = categorySpinner.selectedItem?.toString() ?: "演"
                val content = phraseInput.text.toString()
                if (content.isNotBlank()) {
                    dbHelper.addOrUpdatePhrase(null, cat, content, starCheck.isChecked)
                    phraseInput.setText("")
                    Toast.makeText(this@SettingsActivity, "已保存至「$cat」（共 ${content.length} 字）", Toast.LENGTH_SHORT).show()
                }
            }
        }
        phraseCard.addView(phraseInput)
        phraseCard.addView(starCheck)
        phraseCard.addView(savePhraseBtn)
        root.addView(phraseCard)

        // 4. 自定义添加五笔新词 & 一键导入流行歌曲/动画/名人词库 (.scel / .txt)
        val dictCard = makeCard("词库扩展（自动生成 86 五笔码 · 支持搜狗 .scel 细胞词库与 .txt）")
        val wordInput = EditText(this).apply {
            hint = "输入你想添加的新词（如：薅羊毛 / 芙莉莲 / 周杰伦）"
        }
        val codeInput = EditText(this).apply {
            hint = "86五笔编码（留空即可！系统会自动按 2+2 / 1+1+2 / 1+1+1+末1 规则生成）"
        }
        val addWordBtn = Button(this).apply {
            text = "＋添加到我的五笔词库"
            setOnClickListener {
                val w = wordInput.text.toString().trim()
                if (w.isEmpty()) return@setOnClickListener
                var wcode = codeInput.text.toString().trim().lowercase()
                if (wcode.isEmpty()) {
                    wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                }
                val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                if (wcode.isEmpty() && py.isEmpty()) {
                    Toast.makeText(this@SettingsActivity, "请填写该词的五笔编码", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                dbHelper.insertUserWord(w, wcode, py, 8000)
                T14WubiEngine.reloadUserDict(dbHelper)
                wordInput.setText("")
                codeInput.setText("")
                Toast.makeText(this@SettingsActivity, "已添加词组「$w」(五笔码: $wcode)", Toast.LENGTH_SHORT).show()
            }
        }

        val importScelBtn = Button(this).apply {
            text = "📂 选择手机中的 .scel (搜狗细胞词库) 或 .txt 词表批量导入"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(Intent.createChooser(intent, "选择 .scel 或 .txt 词库文件"), REQ_IMPORT_DICT)
            }
        }

        dictCard.addView(wordInput)
        dictCard.addView(codeInput)
        dictCard.addView(addWordBtn)
        dictCard.addView(importScelBtn)
        root.addView(dictCard)

        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_IMPORT_DICT && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            Thread {
                var importedCount = 0
                try {
                    val path = uri.toString().lowercase()
                    contentResolver.openInputStream(uri)?.use { ins ->
                        if (path.endsWith(".scel")) {
                            val words = T14WubiEngine.parseSogouScel(ins)
                            val db = dbHelper.writableDatabase
                            db.beginTransaction()
                            try {
                                for (w in words) {
                                    val wcode = T14WubiEngine.generateWubi86CodeForWord(w)
                                    val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                                    if (wcode.isNotEmpty() || py.isNotEmpty()) {
                                        dbHelper.insertUserWord(w, wcode, py, 5000)
                                        importedCount++
                                    }
                                }
                                db.setTransactionSuccessful()
                            } finally {
                                db.endTransaction()
                            }
                        } else {
                            val reader = BufferedReader(InputStreamReader(ins, Charsets.UTF_8))
                            val db = dbHelper.writableDatabase
                            db.beginTransaction()
                            try {
                                reader.forEachLine { line ->
                                    val clean = line.trim()
                                    if (clean.isEmpty() || clean.startsWith("#")) return@forEachLine
                                    val parts = clean.split(Regex("[\\s,]+"))
                                    val w = parts[0]
                                    val wcode = if (parts.size >= 2 && parts[1].all { it.isLetter() }) {
                                        parts[1].lowercase()
                                    } else {
                                        T14WubiEngine.generateWubi86CodeForWord(w)
                                    }
                                    val py = T14WubiEngine.generateSegmentedPinyinForWord(w)
                                    if (w.isNotEmpty() && (wcode.isNotEmpty() || py.isNotEmpty())) {
                                        dbHelper.insertUserWord(w, wcode, py, 5000)
                                        importedCount++
                                    }
                                }
                                db.setTransactionSuccessful()
                            } finally {
                                db.endTransaction()
                            }
                        }
                    }
                    T14WubiEngine.reloadUserDict(dbHelper)
                } catch (_: Exception) {}
                runOnUiThread {
                    Toast.makeText(this, "成功导入 $importedCount 条词组并自动生成 86 五笔编码！", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
    }

    private fun makeCard(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(16)
            layoutParams = lp

            val tv = TextView(this@SettingsActivity).apply {
                text = title
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#222428"))
                setPadding(0, 0, 0, dp(10))
            }
            addView(tv)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
