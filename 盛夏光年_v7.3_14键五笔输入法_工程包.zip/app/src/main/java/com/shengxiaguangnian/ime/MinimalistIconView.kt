package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "kb_frosted_bg", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getFrostedKbBgBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["kb_frosted_bg"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 1:1 复刻图 2 (1000127949.png) 的「奶油雾面毛玻璃键盘背景视图」：
 * - 渲染柔焦散景毛玻璃底层 (kb_frosted_bg.webp) + 半透明牛奶雾面玻璃罩层；
 * - 顶部带 22dp 圆角与 1.5dp 晶莹白高光玻璃描边，彻底告别单调的纯蓝背景。
 */
class FrostedGlassKbBgDrawable(
    context: Context,
    private val bitmap: Bitmap?,
    private val topCornerRadiusPx: Float
) : android.graphics.drawable.Drawable() {

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        // 仅 24% 轻柔散景柔雾纹理，既赋予键盘区磨砂雾面质感，又绝不遮挡下方透出的商品图/聊天背景
        alpha = 62
    }
    private val frostPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.5f, context.resources.displayMetrics)
        color = Color.argb(220, 255, 255, 255)
    }
    private val srcRect = Rect()
    private val dstRectF = RectF()
    private val clipPath = Path()
    private val radii = FloatArray(8)

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        dstRectF.set(b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat())
        radii[0] = topCornerRadiusPx
        radii[1] = topCornerRadiusPx
        radii[2] = topCornerRadiusPx
        radii[3] = topCornerRadiusPx
        radii[4] = 0f
        radii[5] = 0f
        radii[6] = 0f
        radii[7] = 0f

        clipPath.reset()
        clipPath.addRoundRect(dstRectF, radii, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, dstRectF, bmpPaint)
        }

        // 半透明冰雾磨砂玻璃罩层（仅作用于下半屏键盘区域，上方聊天记录/搜索框保持 100% 清晰！）
        frostPaint.shader = android.graphics.LinearGradient(
            0f,
            b.top.toFloat(),
            0f,
            b.bottom.toFloat(),
            intArrayOf(
                Color.argb(128, 250, 252, 255),
                Color.argb(105, 244, 248, 255),
                Color.argb(115, 246, 249, 255)
            ),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(dstRectF, frostPaint)
        canvas.restoreToCount(save)

        // 顶部与两侧 1.5dp 冰白高光玻璃描边
        val halfStroke = rimPaint.strokeWidth * 0.5f
        dstRectF.set(
            b.left + halfStroke,
            b.top + halfStroke,
            b.right - halfStroke,
            b.bottom + topCornerRadiusPx
        )
        canvas.drawRoundRect(dstRectF, topCornerRadiusPx, topCornerRadiusPx, rimPaint)
    }

    override fun setAlpha(alpha: Int) {
        frostPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        frostPaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

/**
 * 位于键盘最底层的「中心深、四周浅、双层半透明朦胧背光层」（采纳 DeepSeek 3 点改进）：
 * 1. 彻底去除内圈白光跳变与键帽外圈浅色边，全光晕采用同一清透亮粉彩色相，仅透明度从中心向四周单调递减，
 *    真正实现「中间深、越往周围扩散就越浅，毫无结界圈」；
 * 2. 双层发光叠加：「内层柔亮聚光核心（扩散 19dp）」+「外层朦胧大范围柔雾（扩散 42dp）」，过渡丝滑无硬边；
 * 3. 全程半透明水彩质感（不死实），光晕色比键帽更亮更透。
 */
class KeyboardBacklightOverlayView(context: Context) : View(context) {

    private class SpotlightOrb(
        val sourceView: View,
        val keyRect: RectF,
        val glowColor: Int,
        var releaseTime: Long = 0L
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val shaderMatrix = android.graphics.Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    fun triggerKeyDown(keyView: View, @Suppress("UNUSED_PARAMETER") cornerRadius: Float, glowColor: Int) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + keyView.width
        val bottom = top + keyView.height

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(
            SpotlightOrb(
                sourceView = keyView,
                keyRect = RectF(left, top, right, bottom),
                glowColor = glowColor,
                releaseTime = 0L
            )
        )
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val holdMs = 150f
        val fadeMs = 650f
        val totalMs = holdMs + fadeMs
        val outerSpread = dpF(42f)
        val innerSpread = dpF(19f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.06f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.94f * (1f - t) * (1f - t)
                }
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val rGlow = Color.red(orb.glowColor)
            val gGlow = Color.green(orb.glowColor)
            val bGlow = Color.blue(orb.glowColor)

            // 第一层：外层朦胧扩散柔雾（spread = 42dp，全程保持同一亮色 RGB，仅 Alpha 从中心向外单调递减，绝无浅色结界圈！）
            val rxOut = (orb.keyRect.width() * 0.5f + outerSpread).coerceAtLeast(dpF(56f))
            val ryOut = (orb.keyRect.height() * 0.5f + outerSpread).coerceAtLeast(dpF(56f))
            val outerGrad = RadialGradient(
                0f,
                0f,
                baseRadius,
                intArrayOf(
                    Color.argb((175 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((155 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((110 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((58 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((20 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                ),
                floatArrayOf(0f, 0.32f, 0.52f, 0.70f, 0.86f, 1.0f),
                Shader.TileMode.CLAMP
            )
            shaderMatrix.reset()
            shaderMatrix.setScale(rxOut / baseRadius, ryOut / baseRadius)
            shaderMatrix.postTranslate(cx, cy)
            outerGrad.setLocalMatrix(shaderMatrix)
            orbPaint.shader = outerGrad
            tmpRectF.set(cx - rxOut, cy - ryOut, cx + rxOut, cy + ryOut)
            canvas.drawOval(tmpRectF, orbPaint)

            // 第二层：内层柔亮聚光核心（spread = 19dp，叠加在中心区域，让靠近按键处更浓郁饱满，越往外越轻透）
            val rxIn = (orb.keyRect.width() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
            val ryIn = (orb.keyRect.height() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
            val innerGrad = RadialGradient(
                0f,
                0f,
                baseRadius,
                intArrayOf(
                    Color.argb((200 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((175 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((108 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb((38 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                    Color.argb(0, rGlow, gGlow, bGlow)
                ),
                floatArrayOf(0f, 0.40f, 0.62f, 0.84f, 1.0f),
                Shader.TileMode.CLAMP
            )
            shaderMatrix.reset()
            shaderMatrix.setScale(rxIn / baseRadius, ryIn / baseRadius)
            shaderMatrix.postTranslate(cx, cy)
            innerGrad.setLocalMatrix(shaderMatrix)
            orbPaint.shader = innerGrad
            tmpRectF.set(cx - rxIn, cy - ryIn, cx + rxIn, cy + ryIn)
            canvas.drawOval(tmpRectF, orbPaint)
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#76A2F2"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (enableGlow) {
                    val overlay = findBacklightOverlay()
                    if (value) {
                        overlay?.triggerKeyDown(this, cornerRadiusPx, glowColor)
                    } else {
                        overlay?.triggerKeyUp(this)
                    }
                }
                invalidate()
            }
        }

    private fun findBacklightOverlay(): KeyboardBacklightOverlayView? {
        var p = parent
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    return child
                }
            }
            p = p.parent
        }
        return null
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            // 莫奈油画键帽纹理内部 100% 不透明，直接绘制可确保键帽完全遮挡底部的背光层，绝不被背光染色
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (fallbackBgTop != Color.TRANSPARENT) {
            // 非莫奈皮肤下使用实心不透明键帽底色，同样确保键帽不被底部背光染色
            fallbackFillPaint.color = Color.argb(
                255,
                Color.red(fallbackBgTop),
                Color.green(fallbackBgTop),
                Color.blue(fallbackBgTop)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)
    }
}

/**
 * 顶部状态栏 4 图标视图：
 * - 当 useBotanicalStyle = true 时，直接渲染高清水彩晕染的「小莲花、双生睡莲花苞、缺口浮叶、双叶托莲水波」4 枚纯植物图标（彻底告别搞笑圆脸！）
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = true
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (useBotanicalStyle) {
            val bmp = MonetTextureManager.getTopIconBitmap(context, iconType)
            if (bmp != null) {
                val pad = 0f
                dstRectF.set(pad, pad, w - pad, h - pad)
                srcRect.set(0, 0, bmp.width, bmp.height)
                canvas.drawBitmap(bmp, srcRect, dstRectF, bmpPaint)
                return
            }
        }

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.36f
        drawClassicMinimalistIcon(canvas, cx, cy, r)
    }

    private fun drawClassicMinimalistIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
