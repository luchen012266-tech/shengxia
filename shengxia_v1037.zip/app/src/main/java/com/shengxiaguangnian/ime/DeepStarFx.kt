package com.shengxiaguangnian.ime

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * 深空星盘（DeepStarFx）
 *
 * 1:1 复刻参考视频「深空特效.mp4」第 35~46 帧那个点击特效：
 *   一次点击 →
 *     ① 一颗圆润的五角星，淡紫填充 + 白色描边 + 多层外发光
 *     ② 星心是一个「星盘」：白环 + 十字刻度 + 八角星
 *     ③ 左上一弯月牙
 *     ④ 四周星尘（四角闪星 + 小圆点）随机闪烁
 *     ⑤ 两条淡紫丝带绕着星角飘
 *   全程约 420ms：弹出（带一点回弹）→ 停留 → 消散。
 *
 * 存在的意义：这套"徽章式"美术是用代码画出来的矢量图，
 * 不依赖图片资源，所以能跟着键盘底色自适应，也能被 .keyfx 里的
 * "emblem": "deep_star" 直接调用。
 */
object DeepStarFx {
    const val EMBLEM = "deep_star"
    const val DURATION_MS = 460

    private const val PI_F = 3.1415927f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val tmpPath = Path()
    private val tmpA = Path()
    private val tmpB = Path()
    private val rectF = RectF()

    /** 四周星尘：x, y（单位是外接半径的倍数）, 大小, 闪烁相位 */
    private val SPARKLES = floatArrayOf(
        0.96f, -0.74f, 0.135f, 0.00f,
        1.14f, -0.02f, 0.080f, 0.33f,
        0.92f, 0.74f, 0.085f, 0.71f,
        0.52f, 1.06f, 0.050f, 0.18f,
        -0.52f, 1.08f, 0.060f, 0.56f,
        -1.06f, 0.44f, 0.070f, 0.86f,
        -1.04f, -0.36f, 0.048f, 0.40f,
        0.30f, -1.04f, 0.058f, 0.12f,
        -0.34f, -1.02f, 0.044f, 0.63f,
        1.02f, 0.40f, 0.036f, 0.27f,
        -0.86f, 0.84f, 0.034f, 0.79f
    )

    /** 小圆点：x, y, 半径, 相位 */
    private val DOTS = floatArrayOf(
        0.62f, -0.52f, 0.014f, 0.10f,
        -0.30f, -0.70f, 0.011f, 0.45f,
        0.30f, 0.62f, 0.016f, 0.70f,
        -0.72f, 0.16f, 0.012f, 0.25f,
        0.10f, -0.36f, 0.009f, 0.88f,
        0.78f, 0.14f, 0.010f, 0.52f
    )

    /**
     * @param rect  这颗键的可绘制区域（已经含了 pad）
     * @param t     0..1 的进度
     * @param light 键盘是不是浅色底（浅底要把白色换成深紫，否则看不见）
     */
    fun draw(canvas: Canvas, rect: RectF, t: Float, light: Boolean) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX()
        val cy = rect.centerY()
        val R = min(rect.width(), rect.height()) * 0.5f * 0.58f
        if (R <= 1f) return

        // ---- 时间曲线：0.14 之前弹出，0.55 之后消散 ----
        val inT = (t / 0.14f).coerceIn(0f, 1f)
        val outT = ((t - 0.55f) / 0.45f).coerceIn(0f, 1f)
        val pop = 0.52f + 0.55f * easeOutBack(inT) - 0.07f * outT
        val alpha = (inT * (1f - outT * outT)).coerceIn(0f, 1f)
        if (alpha <= 0.01f) return

        val core = if (light) 0xFF2B2142.toInt() else Color.WHITE
        val halo = if (light) 0xFF7A61C4.toInt() else 0xFFC9B4FF.toInt()
        val haze = if (light) 0xFF8E74DE.toInt() else 0xFFB49BFF.toInt()

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(-7f + 11f * t)
        canvas.scale(pop, pop)

        // 五角星轮廓（圆润，k=0.32）
        starPath(tmpA, 0f, 0f, R, R * 0.45f, 5, -88f, 0.32f)

        // ---- 大范围光晕（径向渐变，替代 MaskFilter —— 硬件加速下 MaskFilter 无效）----
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            0f, 0f, R * 1.45f,
            intArrayOf(
                withA(halo, (alpha * 0.30f * 255f).toInt()),
                withA(halo, (alpha * 0.09f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, 0f, R * 1.45f, p)
        p.shader = null

        // ---- 星体内部的紫色雾（裁剪在星形里，中心亮边缘暗）----
        canvas.save()
        canvas.clipPath(tmpA)
        p.shader = RadialGradient(
            -R * 0.12f, R * 0.18f, R * 1.05f,
            intArrayOf(
                withA(haze, (alpha * 0.52f * 255f).toInt()),
                withA(haze, (alpha * 0.22f * 255f).toInt()),
                withA(haze, (alpha * 0.06f * 255f).toInt())
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(-R * 1.2f, -R * 1.2f, R * 1.2f, R * 1.2f, p)
        p.shader = null
        canvas.restore()

        // ---- 描边：三层由宽到窄，做出"边缘发光" ----
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = R * 0.32f
        p.color = withA(core, (alpha * 0.06f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.strokeWidth = R * 0.13f
        p.color = withA(core, (alpha * 0.15f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.strokeWidth = R * 0.016f
        p.color = withA(core, (alpha * 0.85f * 255f).toInt())
        canvas.drawPath(tmpA, p)

        // ---- 淡紫丝带（两条，贴着星角绕） ----
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 2) {
            val wob = 0.03f * sin((t * 6f + i) * PI_F)
            tmpPath.reset()
            if (i == 0) {
                tmpPath.moveTo(-R * 0.62f, R * 0.86f)
                tmpPath.cubicTo(
                    -R * (1.10f + wob), R * 0.30f,
                    -R * 1.02f, -R * 0.55f,
                    -R * 0.42f, -R * 1.02f
                )
            } else {
                tmpPath.moveTo(R * 0.55f, -R * 0.95f)
                tmpPath.cubicTo(
                    R * (1.12f + wob), -R * 0.30f,
                    R * 1.05f, R * 0.45f,
                    R * 0.50f, R * 1.00f
                )
            }
            p.strokeWidth = R * 0.06f
            p.color = withA(haze, (alpha * 0.10f * 255f).toInt())
            canvas.drawPath(tmpPath, p)
            p.strokeWidth = R * 0.020f
            p.color = withA(core, (alpha * 0.06f * 255f).toInt())
            canvas.drawPath(tmpPath, p)
        }

        // ---- 星心星盘 ----
        val rr = R * 0.44f
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.09f
        p.color = withA(core, (alpha * 0.07f * 255f).toInt())
        canvas.drawCircle(0f, 0f, rr, p)

        p.strokeWidth = R * 0.010f
        p.color = withA(core, (alpha * 0.85f * 255f).toInt())
        canvas.drawCircle(0f, 0f, rr, p)
        // 十字刻度
        canvas.drawLine(-rr * 1.18f, 0f, rr * 1.18f, 0f, p)
        canvas.drawLine(0f, -rr * 1.14f, 0f, -rr * 0.66f, p)
        canvas.drawLine(0f, rr * 0.66f, 0f, rr * 1.14f, p)
        // 内圈
        p.strokeWidth = R * 0.006f
        p.color = withA(core, (alpha * 0.35f * 255f).toInt())
        canvas.drawCircle(0f, 0f, rr * 0.74f, p)

        // 中心八角星（缓慢自转）
        canvas.save()
        canvas.rotate(t * 14f)
        starPath(tmpB, 0f, 0f, rr * 0.80f, rr * 0.16f, 8, -90f, 0.05f)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        for (k in 0 until 3) {
            p.strokeWidth = rr * (0.26f - k * 0.07f)
            p.color = withA(core, (alpha * (0.05f + k * 0.05f) * 255f).toInt())
            canvas.drawPath(tmpB, p)
        }
        p.style = Paint.Style.FILL
        p.color = withA(core, (alpha * 0.95f * 255f).toInt())
        canvas.drawPath(tmpB, p)
        canvas.restore()

        // ---- 月牙（左上） ----
        canvas.save()
        canvas.translate(-R * 0.80f, -R * 0.66f)
        canvas.rotate(-28f)
        tmpA.reset()
        tmpA.addCircle(0f, 0f, R * 0.150f, Path.Direction.CW)
        tmpB.reset()
        tmpB.addCircle(R * 0.070f, 0f, R * 0.135f, Path.Direction.CW)
        tmpA.op(tmpB, Path.Op.DIFFERENCE)
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.07f
        p.color = withA(core, (alpha * 0.10f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.style = Paint.Style.FILL
        p.color = withA(core, (alpha * 0.88f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        canvas.restore()

        // ---- 星尘 ----
        p.style = Paint.Style.FILL
        var i = 0
        while (i + 3 < SPARKLES.size) {
            val x = SPARKLES[i] * R
            val y = SPARKLES[i + 1] * R
            val sz = SPARKLES[i + 2] * R
            val ph = SPARKLES[i + 3]
            val tw = 0.45f + 0.55f * ((sin((t * 6.5f + ph) * 2f * PI_F) + 1f) * 0.5f)
            drawSparkle(canvas, x, y, sz * (0.55f + 0.65f * tw), alpha, tw, core, halo)
            i += 4
        }
        i = 0
        while (i + 3 < DOTS.size) {
            val x = DOTS[i] * R
            val y = DOTS[i + 1] * R
            val sz = DOTS[i + 2] * R
            val ph = DOTS[i + 3]
            val tw = 0.35f + 0.65f * ((sin((t * 5f + ph) * 2f * PI_F) + 1f) * 0.5f)
            p.style = Paint.Style.FILL
            p.color = withA(core, (alpha * tw * 0.85f * 255f).toInt())
            canvas.drawCircle(x, y, sz, p)
            i += 4
        }

        canvas.restore()
    }

    /** 一颗四角闪星（凹边），带一点点光晕 */
    private fun drawSparkle(
        canvas: Canvas, cx: Float, cy: Float, r: Float,
        alpha: Float, tw: Float, core: Int, halo: Int
    ) {
        if (r <= 0.4f) return
        sparklePath(tmpA, cx, cy, r, 0.22f)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.85f
        p.color = withA(halo, (alpha * tw * 0.18f * 255f).toInt())
        canvas.drawPath(tmpA, p)
        p.style = Paint.Style.FILL
        p.color = withA(core, (alpha * tw * 255f).toInt())
        canvas.drawPath(tmpA, p)
    }

    /** 圆角星：k=0.5 很圆润，k 越小越尖 */
    private fun starPath(
        out: Path, cx: Float, cy: Float, outer: Float, inner: Float,
        points: Int, rotDeg: Float, k: Float
    ) {
        out.reset()
        val n = points * 2
        val xs = FloatArray(n)
        val ys = FloatArray(n)
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians((rotDeg + i * 180.0 / points))
            xs[i] = cx + (r * cos(a)).toFloat()
            ys[i] = cy + (r * sin(a)).toFloat()
        }
        var first = true
        for (i in 0 until n) {
            val pv = (i - 1 + n) % n
            val nv = (i + 1) % n
            val px = xs[i] + (xs[pv] - xs[i]) * k
            val py = ys[i] + (ys[pv] - ys[i]) * k
            val qx = xs[i] + (xs[nv] - xs[i]) * k
            val qy = ys[i] + (ys[nv] - ys[i]) * k
            if (first) {
                out.moveTo(px, py)
                first = false
            } else {
                out.lineTo(px, py)
            }
            out.quadTo(xs[i], ys[i], qx, qy)
        }
        out.close()
    }

    private fun sparklePath(out: Path, cx: Float, cy: Float, r: Float, k: Float) {
        out.reset()
        out.moveTo(cx, cy - r)
        out.quadTo(cx + r * k, cy - r * k, cx + r, cy)
        out.quadTo(cx + r * k, cy + r * k, cx, cy + r)
        out.quadTo(cx - r * k, cy + r * k, cx - r, cy)
        out.quadTo(cx - r * k, cy - r * k, cx, cy - r)
        out.close()
    }

    private fun withA(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun easeOutBack(x: Float): Float {
        val c1 = 1.70158f
        val d = x - 1f
        return 1f + (c1 + 1f) * d * d * d + c1 * d * d
    }
}
