package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import java.io.File
import java.io.FileOutputStream
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt



/**
 * 三大字体模块独立导入与缓存管理器：
 * 1. SLOT_ENG ("font_eng.ttf")：按键英文字母与数字字体
 * 2. SLOT_CAND ("font_cand.ttf")：中文候选词与状态栏字体
 * 3. SLOT_ENTER ("font_enter.ttf")：右下角自定义文字（如“盛夏光年”）专属字体
 */
object CustomFontManager {
    const val SLOT_ENG = "eng"
    const val SLOT_CAND = "cand"
    const val SLOT_ENTER = "enter"

    private var cachedEngTs: Long = -1L
    private var cachedCandTs: Long = -1L
    private var cachedEnterTs: Long = -1L

    private var engTypeface: Typeface? = null
    private var candTypeface: Typeface? = null
    private var enterTypeface: Typeface? = null

    fun getFontFile(context: Context, slot: String): File {
        return File(context.filesDir, "custom_font_$slot.ttf")
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_eng", 0L) xor
            (prefs.getLong("font_ts_cand", 0L) shl 1) xor
            (prefs.getLong("font_ts_enter", 0L) shl 2)
    }

    fun hasCustomFont(context: Context, slot: String): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("font_ts_$slot", 0L) > 0L && getFontFile(context, slot).exists()
    }

    fun getCustomFontName(context: Context, slot: String): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("font_name_$slot", "未导入（使用系统默认）") ?: "未导入（使用系统默认）"
    }

    fun clearCustomFont(context: Context, slot: String) {
        try {
            getFontFile(context, slot).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("font_ts_$slot", 0L)
            .remove("font_name_$slot")
            .apply()
        synchronized(this) {
            when (slot) {
                SLOT_ENG -> { cachedEngTs = 0L; engTypeface = null }
                SLOT_CAND -> { cachedCandTs = 0L; candTypeface = null }
                SLOT_ENTER -> { cachedEnterTs = 0L; enterTypeface = null }
            }
        }
    }

    fun getEngKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_eng", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedEngTs && engTypeface != null) return engTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENG)
            if (f.exists()) {
                try {
                    engTypeface = Typeface.createFromFile(f)
                    cachedEngTs = ts
                    return engTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getCandidateTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_cand", 0L)
        if (ts <= 0L) return Typeface.DEFAULT
        if (ts == cachedCandTs && candTypeface != null) return candTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_CAND)
            if (f.exists()) {
                try {
                    candTypeface = Typeface.createFromFile(f)
                    cachedCandTs = ts
                    return candTypeface!!
                } catch (_: Exception) {}
            }
            return Typeface.DEFAULT
        }
    }

    fun getEnterKeyTypeface(context: Context): Typeface {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("font_ts_enter", 0L)
        if (ts <= 0L) return getCandidateTypeface(context)
        if (ts == cachedEnterTs && enterTypeface != null) return enterTypeface!!
        synchronized(this) {
            val f = getFontFile(context, SLOT_ENTER)
            if (f.exists()) {
                try {
                    enterTypeface = Typeface.createFromFile(f)
                    cachedEnterTs = ts
                    return enterTypeface!!
                } catch (_: Exception) {}
            }
            return getCandidateTypeface(context)
        }
    }
}


/**
 * 基于 OKLCH 感知均匀色彩空间的按键背光自动取色器：
 * - 完全独立于现有的 KeyboardBacklightOverlayView 光晕动画与双层渐变绘制；
 * - 直接根据单键最终生效的背景色（含按排配色、单键独立配色、随机跳色）计算背光色；
 * - 不设死板的统一饱和度下限，采用「比例温和增益 + 软上限压缩（Soft-Knee）」，保留浅色系的呼吸层次感；
 * - 针对人眼最敏感的绿/黄绿波段（Hue 100°~165°）施加平滑色度阻尼，根治荧光绿，同时绝不压低明度 L 导致浅粉/焦糖变灰；
 * - 自动区分浅色皮肤与深色皮肤（如暗夜黑金）：当检测到深色按键或深黑底板时，自动开启「暗底逆向提亮 + 暖珀流金」模式。
 */
object OklchBacklightExtractor {

    fun extractGlowColor(
        finalKeyBgColor: Int,
        kbBgColor: Int = Color.WHITE,
        themeTintColor: Int = Color.WHITE,
        explicitCssGlowColor: Int? = null
    ): Int {
        explicitCssGlowColor?.let { return it }

        val r = Color.red(finalKeyBgColor) / 255.0
        val g = Color.green(finalKeyBgColor) / 255.0
        val b = Color.blue(finalKeyBgColor) / 255.0

        val tr = Color.red(themeTintColor) / 255.0
        val tg = Color.green(themeTintColor) / 255.0
        val tb = Color.blue(themeTintColor) / 255.0

        val (l, c, hDeg) = srgbToOklch(r, g, b)
        val (_, themeC, themeHDeg) = srgbToOklch(tr, tg, tb)

        // 1. 深色按键 (L < 0.45，如黑粉皮肤的第3排深紫灰键、黑色功能键，或黑金皮肤的深黑功能键)：
        //    彻底移除写死的金色！若深色键自身色度较低 (c < 0.032)，自动借用当前皮肤的主色调色相 themeHDeg
        //    （黑粉皮肤自动发柔和樱花粉光晕，黑金皮肤自动发香槟金光晕，绝不串色！）
        if (l < 0.45) {
            val effectiveHue = when {
                c < 0.026 && themeC >= 0.014 -> themeHDeg
                c < 0.038 && themeC >= 0.018 -> blendHueDegrees(hDeg, themeHDeg, 0.55)
                else -> hDeg
            }
            val liftedL = (l + 0.42).coerceIn(0.76, 0.83)
            val baseC = max(c, themeC * 0.85)
            val liftedC = (baseC * 1.45 + 0.032).coerceIn(0.072, 0.110)
            return oklchToSrgbColor(liftedL, liftedC, effectiveHue)
        }

        // 2. 极低色度纯白/纯灰键 (C < 0.012)：若当前皮肤有明确主题色相则轻柔借用主题色相，否则给出清透冰蓝微光
        if (c < 0.012) {
            if (themeC >= 0.015) {
                val borrowedC = (themeC * 1.35 + 0.025).coerceIn(0.055, 0.088)
                return oklchToSrgbColor(0.84, borrowedC, themeHDeg)
            }
            return Color.parseColor("#B6CDF2")
        }

        // 3. 计算绿/黄绿敏感色相区的柔性色度上限（Hue 在 105°~165° 之间时人眼对绿光最敏感，软上限收敛防荧光）
        val greenSensitivity = when {
            hDeg in 105.0..165.0 -> {
                val distFromPeak = kotlin.math.abs(hDeg - 135.0) / 30.0
                1.0 - 0.28 * (1.0 - distFromPeak.coerceIn(0.0, 1.0))
            }
            else -> 1.0
        }

        val maxChromaCap = 0.128 * greenSensitivity

        // 4. 比例柔性色度增益（彻底移除 isDarkTheme 写死金色逻辑！让黑粉皮肤第1排浅粉键 #F0D8E5 忠实绽放樱花粉光晕，
        //    黑金皮肤暖杏仁白键 #FAF3E6 忠实绽放暖金光晕）
        val boostedC = if (l >= 0.80) {
            val rawC = c * 1.95 + 0.036
            softKneeCompress(rawC, maxChromaCap * 0.88, maxChromaCap)
        } else {
            val rawC = c * 1.22 + 0.020
            softKneeCompress(rawC, maxChromaCap * 0.85, maxChromaCap)
        }

        // 5. 感知明度 L 校正：绝不把浅色压暗成水泥灰！
        val targetL = when {
            l >= 0.85 -> (l * 0.93).coerceIn(0.82, 0.89)
            l >= 0.65 -> (l * 1.04).coerceIn(0.76, 0.86)
            else -> (l + 0.14).coerceIn(0.70, 0.80)
        }

        return oklchToSrgbColor(targetL, boostedC, hDeg)
    }

    private fun blendHueDegrees(h1: Double, h2: Double, ratioH2: Double): Double {
        val r1 = Math.toRadians(h1)
        val r2 = Math.toRadians(h2)
        val x = (1.0 - ratioH2) * cos(r1) + ratioH2 * cos(r2)
        val y = (1.0 - ratioH2) * sin(r1) + ratioH2 * sin(r2)
        var deg = Math.toDegrees(atan2(y, x))
        if (deg < 0.0) deg += 360.0
        return deg
    }

    private fun softKneeCompress(x: Double, knee: Double, maxVal: Double): Double {
        if (x <= knee) return x
        val excess = x - knee
        val span = (maxVal - knee).coerceAtLeast(0.005)
        return knee + span * (excess / (excess + span))
    }

    private fun srgbToLinear(v: Double): Double {
        return if (v <= 0.04045) v / 12.92 else ((v + 0.055) / 1.055).pow(2.4)
    }

    private fun linearToSrgb(v: Double): Double {
        val clamped = v.coerceIn(0.0, 1.0)
        return if (clamped <= 0.0031308) 12.92 * clamped else 1.055 * clamped.pow(1.0 / 2.4) - 0.055
    }

    private fun srgbToOklch(r: Double, g: Double, b: Double): Triple<Double, Double, Double> {
        val lr = srgbToLinear(r)
        val lg = srgbToLinear(g)
        val lb = srgbToLinear(b)

        val l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb)
        val m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb)
        val s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb)

        val okL = 0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s
        val okA = 1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s
        val okB = 0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s

        val c = hypot(okA, okB)
        var h = Math.toDegrees(atan2(okB, okA))
        if (h < 0.0) h += 360.0
        return Triple(okL, c, h)
    }

    private fun oklchToSrgbColor(l: Double, c: Double, hDeg: Double): Int {
        val hRad = Math.toRadians(hDeg)
        val okA = c * cos(hRad)
        val okB = c * sin(hRad)

        val l_ = l + 0.3963377774 * okA + 0.2158037573 * okB
        val m_ = l - 0.1055613458 * okA - 0.0638541728 * okB
        val s_ = l - 0.0894841775 * okA - 1.2914855480 * okB

        val lCube = l_ * l_ * l_
        val mCube = m_ * m_ * m_
        val sCube = s_ * s_ * s_

        val lr = +4.0767416621 * lCube - 3.3077115913 * mCube + 0.2309699292 * sCube
        val lg = -1.2684380046 * lCube + 2.6097574011 * mCube - 0.3413193965 * sCube
        val lb = -0.0041960863 * lCube - 0.7034186147 * mCube + 1.7076147010 * sCube

        val sr = (linearToSrgb(lr) * 255.0).toInt().coerceIn(0, 255)
        val sg = (linearToSrgb(lg) * 255.0).toInt().coerceIn(0, 255)
        val sb = (linearToSrgb(lb) * 255.0).toInt().coerceIn(0, 255)
        return Color.rgb(sr, sg, sb)
    }
}


/**
 * 零延迟按键敲击音效管理器（内置用户提供的清脆敲击音 key_click.wav，支持设置页 Switch 自由开关）
 */
object KeySoundManager {
    private const val CUSTOM_SOUND_FILE = "custom_key_sound.dat"
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    private var loaded = false
    private var loadedSoundTs: Long = -1L

    fun getCustomSoundFile(context: Context): File = File(context.filesDir, CUSTOM_SOUND_FILE)

    fun hasCustomSound(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_sound_ts", 0L) > 0L && getCustomSoundFile(context).exists()
    }

    fun getCustomSoundName(context: Context): String {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getString("custom_sound_name", "自定义音效") ?: "自定义音效"
    }

    fun clearCustomSound(context: Context) {
        try {
            getCustomSoundFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_sound_ts", 0L)
            .remove("custom_sound_name")
            .apply()
        reloadSound(context)
    }

    fun reloadSound(context: Context) {
        synchronized(this) {
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            soundPool = null
            clickSoundId = 0
            loaded = false
            loadedSoundTs = -1L
            ensureInitialized(context)
        }
    }

    fun ensureInitialized(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val curTs = prefs.getLong("custom_sound_ts", 0L)
        if (soundPool != null && curTs == loadedSoundTs) return
        synchronized(this) {
            if (soundPool != null && curTs == loadedSoundTs) return
            try {
                soundPool?.release()
            } catch (_: Exception) {}
            loaded = false
            clickSoundId = 0
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
                val sp = SoundPool.Builder()
                    .setMaxStreams(6)
                    .setAudioAttributes(attrs)
                    .build()
                sp.setOnLoadCompleteListener { pool, sampleId, status ->
                    if (status == 0 && sampleId == clickSoundId) {
                        loaded = true
                        if (pendingPreviewPlay) {
                            pendingPreviewPlay = false
                            pool.play(clickSoundId, 0.90f, 0.90f, 1, 0, 1.0f)
                        }
                    }
                }
                val customFile = getCustomSoundFile(context)
                clickSoundId = if (curTs > 0L && customFile.exists()) {
                    sp.load(customFile.absolutePath, 1)
                } else {
                    context.assets.openFd("key_click.wav").use { afd ->
                        sp.load(afd, 1)
                    }
                }
                soundPool = sp
                loadedSoundTs = curTs
            } catch (_: Exception) {}
        }
    }

    @Volatile
    private var pendingPreviewPlay = false

    fun playClick(context: Context, forcePreview: Boolean = false) {
        try {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            if (!forcePreview && !prefs.getBoolean("key_sound_enabled", true)) return
            ensureInitialized(context)
            val sp = soundPool ?: return
            if (loaded && clickSoundId != 0) {
                sp.play(clickSoundId, 0.88f, 0.88f, 1, 0, 1.0f)
            } else if (forcePreview) {
                pendingPreviewPlay = true
            }
        } catch (_: Exception) {}
    }
}

/**
 * 纯色框架下的「自定义键盘背景图 + 实时高斯模糊底图采样」管理器：
 * - 当用户从相册上传背景图后，自动按 background-size: cover 铺满键盘底板；
 * - 同时预计算高平滑度高斯模糊底图 (blurredBitmap)，供所有半透明毛玻璃按键与顶栏实时读取并模糊对应坐标处的底图！
 */
object CustomBgManager {
    private const val FILE_NAME = "custom_kb_bg.png"
    private var cachedTimestamp: Long = -1L
    private var rawBitmap: Bitmap? = null
    private var blurredBitmap: Bitmap? = null

    fun getBgFile(context: Context): File = File(context.filesDir, FILE_NAME)

    fun hasCustomBg(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        return ts > 0L && getBgFile(context).exists()
    }

    fun clearCustomBg(context: Context) {
        try {
            getBgFile(context).delete()
        } catch (_: Exception) {}
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_bg_ts", 0L)
            .apply()
        synchronized(this) {
            cachedTimestamp = 0L
            rawBitmap = null
            blurredBitmap = null
        }
    }

    private fun ensureLoaded(context: Context) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val ts = prefs.getLong("custom_bg_ts", 0L)
        if (ts <= 0L) {
            rawBitmap = null
            blurredBitmap = null
            cachedTimestamp = 0L
            return
        }
        if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
        synchronized(this) {
            if (ts == cachedTimestamp && rawBitmap != null && blurredBitmap != null) return
            val file = getBgFile(context)
            if (!file.exists()) {
                rawBitmap = null
                blurredBitmap = null
                cachedTimestamp = 0L
                return
            }
            try {
                val bmp = BitmapFactory.decodeFile(file.absolutePath)
                if (bmp != null) {
                    rawBitmap = bmp
                    blurredBitmap = createGaussianBlurredBitmap(bmp)
                    cachedTimestamp = ts
                }
            } catch (_: Exception) {}
        }
    }

    fun getRawBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return rawBitmap
    }

    fun getBlurredBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return blurredBitmap
    }

    /**
     * 通过 1/4 下采样 + 3 遍可分离均值滤波（中心极限定理等效高半径高斯模糊）生成柔焦毛玻璃底图
     */
    private fun createGaussianBlurredBitmap(src: Bitmap): Bitmap {
        val sw = (src.width / 4).coerceAtLeast(64)
        val sh = (src.height / 4).coerceAtLeast(48)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pixels = IntArray(sw * sh)
        small.getPixels(pixels, 0, sw, 0, 0, sw, sh)
        val tmp = IntArray(sw * sh)
        val radius = 6

        repeat(3) {
            // Horizontal pass
            for (y in 0 until sh) {
                val rowOff = y * sw
                for (x in 0 until sw) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val x0 = max(0, x - radius)
                    val x1 = min(sw - 1, x + radius)
                    for (ix in x0..x1) {
                        val c = pixels[rowOff + ix]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    tmp[rowOff + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
            // Vertical pass
            for (x in 0 until sw) {
                for (y in 0 until sh) {
                    var rSum = 0
                    var gSum = 0
                    var bSum = 0
                    var count = 0
                    val y0 = max(0, y - radius)
                    val y1 = min(sh - 1, y + radius)
                    for (iy in y0..y1) {
                        val c = tmp[iy * sw + x]
                        rSum += (c shr 16) and 0xFF
                        gSum += (c shr 8) and 0xFF
                        bSum += c and 0xFF
                        count++
                    }
                    pixels[y * sw + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                }
            }
        }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, sw, 0, 0, sw, sh)
        return out
    }
}

/**
 * 自定义背景图的 background-size: cover + 可调节（0~100）背景毛玻璃程度渲染 Drawable：
 * - blurLevel = 0 时：100% 清晰显示用户上传的原图；
 * - blurLevel = 1..100 时：按比例平滑混合高清原图与柔焦高斯模糊底图，并叠加清透毛玻璃雾面光泽！
 */
class CustomCoverBgDrawable(
    private val rawBitmap: Bitmap,
    private val blurredBitmap: Bitmap?,
    var blurLevel: Int = 25
) : Drawable() {
    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val blurPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val frostVeilPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val matrix = Matrix()

    override fun draw(canvas: Canvas) {
        val b = bounds
        val bw = b.width().toFloat()
        val bh = b.height().toFloat()
        if (bw <= 0f || bh <= 0f || rawBitmap.width <= 0 || rawBitmap.height <= 0) return

        val lv = blurLevel.coerceIn(0, 100)
        val save = canvas.save()
        canvas.clipRect(b)

        // 1. 绘制原图（当 blurLevel < 100 时作为清晰基底）
        if (lv < 100 || blurredBitmap == null) {
            val scale = max(bw / rawBitmap.width.toFloat(), bh / rawBitmap.height.toFloat())
            val dx = b.left + (bw - rawBitmap.width * scale) * 0.5f
            val dy = b.top + (bh - rawBitmap.height * scale) * 0.5f
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(dx, dy)
            canvas.drawBitmap(rawBitmap, matrix, rawPaint)
        }

        // 2. 按 0~100 程度叠加背景毛玻璃模糊层与轻柔雾面光泽
        if (lv > 0 && blurredBitmap != null && blurredBitmap.width > 0 && blurredBitmap.height > 0) {
            val bScale = max(bw / blurredBitmap.width.toFloat(), bh / blurredBitmap.height.toFloat())
            val bDx = b.left + (bw - blurredBitmap.width * bScale) * 0.5f
            val bDy = b.top + (bh - blurredBitmap.height * bScale) * 0.5f
            matrix.reset()
            matrix.setScale(bScale, bScale)
            matrix.postTranslate(bDx, bDy)
            blurPaint.alpha = (lv * 2.55f).toInt().coerceIn(0, 255)
            canvas.drawBitmap(blurredBitmap, matrix, blurPaint)

            // 随毛玻璃程度增加一点点清透雾白柔光感（最高约 22% 雾面感，不遮挡画面色彩）
            val veilAlpha = (lv * 0.56f).toInt().coerceIn(0, 56)
            if (veilAlpha > 0) {
                frostVeilPaint.color = Color.argb(veilAlpha, 255, 255, 255)
                canvas.drawRect(b, frostVeilPaint)
            }
        }
        canvas.restoreToCount(save)
    }

    private val paint = rawPaint

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 位于键盘最底层的「中心浓郁加深、四周柔和减淡」双层半透明背光层：
 * - 彻底摒弃刺眼的荧光亮色；
 * - 内层核心（innerGrad）自动比外层柔雾（outerGrad）再加深 22%，让按键中心位置呈现出浓郁温润的深睡莲绿/同色系深色核心，
 *   越往周围扩散越浅、越半透明，与莫奈花园及所有纯色皮肤完美融合。
 */
/**
 * 独立星河色彩适配器（与粒子几何形状、星芒绘制逻辑完全解耦）：
 * - 星芒核心恒定采用纯净高亮白 (#FFFFFF) 与近白星光色；
 * - 外围柔光继承当前皮肤主色相，但自动降低饱和度，彻底杜绝刺眼荧光色与深色背景下的「黄色烟雾感」；
 * - 同时自动适配深色背景与浅色背景，不将任何固定颜色写死到皮肤中。
 */
object StarlightColorAdapter {

    class StarlightPalette(
        val coreWhite: Int,
        val rayNearWhite: Int,
        val softHaloColor: Int,
        val ambientGlowColor: Int,
        val lightContrastShadowColor: Int,
        val isLightSurface: Boolean,
        val ambientAlphaScale: Float
    )

    fun resolvePalette(rawGlowColor: Int, surfaceBgColor: Int? = null): StarlightPalette {
        val hsv = FloatArray(3)
        Color.colorToHSV(rawGlowColor, hsv)
        val rawH = hsv[0]
        val rawS = hsv[1]
        val rawV = hsv[2]

        val surfaceLum = if (surfaceBgColor != null && Color.alpha(surfaceBgColor) > 40) {
            0.2126f * (Color.red(surfaceBgColor) / 255f) +
                0.7152f * (Color.green(surfaceBgColor) / 255f) +
                0.0722f * (Color.blue(surfaceBgColor) / 255f)
        } else {
            0.2126f * (Color.red(rawGlowColor) / 255f) +
                0.7152f * (Color.green(rawGlowColor) / 255f) +
                0.0722f * (Color.blue(rawGlowColor) / 255f)
        }
        val isLightSurface = surfaceLum >= 0.56f

        // 1. 针对偏黄/暖金波段 (Hue 26°~76°)，大幅降低外围光晕饱和度并向清冷月光香槟白偏移，彻底消除深色底上的“黄色烟雾”
        val isYellowWarmBand = rawH in 26f..76f
        val isGreenBand = rawH in 90f..168f

        // 2. 星芒近白过渡色（90% 纯白 + 10% 低饱和皮肤色相）
        val nearWhiteHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.0f else (rawS * 0.22f).coerceIn(0.04f, if (isYellowWarmBand) 0.10f else 0.15f),
            0.99f
        )
        val rayNearWhite = Color.HSVToColor(nearWhiteHsv)

        // 3. 星芒外围柔光色（继承皮肤色相但显著降低饱和度，清爽通透）
        val haloSatCap = when {
            rawS < 0.05f -> 0.08f
            isYellowWarmBand -> if (isLightSurface) 0.24f else 0.16f
            isGreenBand -> 0.25f
            else -> if (isLightSurface) 0.34f else 0.26f
        }
        val haloHsv = floatArrayOf(
            rawH,
            (rawS * 0.58f).coerceIn(0.08f, haloSatCap),
            if (isLightSurface) rawV.coerceIn(0.78f, 0.90f) else rawV.coerceIn(0.86f, 0.96f)
        )
        val softHaloColor = Color.HSVToColor(haloHsv)

        // 4. 底层环境背光晕颜色（深色皮肤下降低黄色浓度与不透明度，保持深邃夜空感）
        val ambientSatCap = when {
            rawS < 0.05f -> 0.10f
            isYellowWarmBand -> if (isLightSurface) 0.28f else 0.18f
            isGreenBand -> 0.28f
            else -> if (isLightSurface) 0.38f else 0.30f
        }
        val ambientHsv = floatArrayOf(
            rawH,
            (rawS * 0.65f).coerceIn(0.08f, ambientSatCap),
            if (isLightSurface) rawV.coerceIn(0.80f, 0.92f) else rawV.coerceIn(0.78f, 0.90f)
        )
        val ambientGlowColor = Color.HSVToColor(ambientHsv)

        // 5. 浅色背景专属柔和星影衬底色（低饱和温润灰粉/灰紫/灰青，无硬边，衬托纯白星核）
        val contrastHsv = floatArrayOf(
            rawH,
            if (rawS < 0.05f) 0.12f else (rawS * 0.68f + 0.08f).coerceIn(0.20f, if (isYellowWarmBand) 0.30f else 0.38f),
            if (isLightSurface) 0.70f else 0.82f
        )
        val lightContrastShadowColor = Color.HSVToColor(contrastHsv)

        val ambientAlphaScale = if (isLightSurface) 0.86f else if (isYellowWarmBand) 0.56f else 0.68f

        return StarlightPalette(
            coreWhite = Color.rgb(255, 255, 255),
            rayNearWhite = rayNearWhite,
            softHaloColor = softHaloColor,
            ambientGlowColor = ambientGlowColor,
            lightContrastShadowColor = lightContrastShadowColor,
            isLightSurface = isLightSurface,
            ambientAlphaScale = ambientAlphaScale
        )
    }
}

class KeyboardBacklightOverlayView(
    context: Context,
    val renderLayerMode: Int = LAYER_UNDER_GLOW,
    val clipCornerRadiusPx: Float = 0f
) : View(context) {

    companion object {
        const val LAYER_UNDER_GLOW = 0
        const val LAYER_OVER_SPARKLE = 1
        const val LAYER_FULL_COMBINED = 2

        const val PREF_SPARKLE_ENABLED = "backlight_sparkle_enabled"
        const val PREF_SPARKLE_INTENSITY = "backlight_sparkle_intensity"
        const val DEFAULT_SPARKLE_INTENSITY = 82

        private var orbSeedCounter: Long = 1L

        fun isSparkleEnabled(context: Context): Boolean {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getBoolean(PREF_SPARKLE_ENABLED, true)
        }

        fun setSparkleEnabled(context: Context, enabled: Boolean) {
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_SPARKLE_ENABLED, enabled)
                .apply()
        }

        fun getSparkleIntensity(context: Context): Int {
            val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            return prefs.getInt(PREF_SPARKLE_INTENSITY, DEFAULT_SPARKLE_INTENSITY).coerceIn(10, 100)
        }

        fun setSparkleIntensity(context: Context, intensity: Int) {
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putInt(PREF_SPARKLE_INTENSITY, intensity.coerceIn(10, 100))
                .apply()
        }

        fun getIntensityTierName(intensity: Int): String {
            return when {
                intensity < 42 -> "轻柔星尘"
                intensity < 75 -> "柔美星光"
                else -> "璀璨星河"
            }
        }
    }

    // 第 1 层级：微小星尘（数量最多、体积微小、顺沿星河轨迹散落，绝无描边圆环）
    private class MicroStardustParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 第 2 层级：普通星点（带柔和径向渐变光晕 + 亮白星核，边缘自然消融为 0，绝无硬边气泡感）
    private class StarPointParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val haloRadiusPx: Float,
        val coreRadiusPx: Float,
        val baseAlpha: Float,
        val twinklePhase: Float,
        val twinkleFreq: Float
    )

    // 第 3 层级：少量柔焦星云光斑（每键仅 1~3 枚，纯高斯径向羽化云雾，零描边、零反光点，彻底告别泡泡感）
    private class SoftNebulaSpotParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val radiusPx: Float,
        val baseAlpha: Float
    )

    // 第 4 层级：细长锐利的四角/六角星芒（中心高亮纯白，尖端随径向渐变自然淡出消隐）
    private class CelestialStarFlareParticle(
        val relX: Float,
        val relY: Float,
        val driftDx: Float,
        val driftDy: Float,
        val primaryRayPx: Float,
        val orthogonalRayPx: Float,
        val diagRayPx: Float,
        val baseHalfWidthPx: Float,
        val rotationDeg: Float,
        val isSixPointed: Boolean,
        val isHeroFlare: Boolean,
        val baseAlpha: Float,
        val twinklePhase: Float
    )

    private class SpotlightOrb(
        val sourceView: View?,
        val keyRect: RectF,
        val glowColor: Int,
        val palette: StarlightColorAdapter.StarlightPalette,
        val spawnTime: Long,
        var releaseTime: Long = 0L,
        val intensityNorm: Float,
        val stardustList: List<MicroStardustParticle>,
        val starPoints: List<StarPointParticle>,
        val nebulaSpots: List<SoftNebulaSpotParticle>,
        val starFlares: List<CelestialStarFlareParticle>
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val particleFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val starPath = Path()
    private val clipBoundsPath = Path()
    private val shaderMatrix = Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    private fun buildRandomOrb(
        sourceView: View?,
        rect: RectF,
        glowColor: Int,
        surfaceBgColor: Int? = null
    ): SpotlightOrb {
        val shouldSpawnParticles = (renderLayerMode != LAYER_UNDER_GLOW) && isSparkleEnabled(context)
        val rawIntensity = getSparkleIntensity(context)
        val normI = ((rawIntensity - 10f) / 90f).coerceIn(0f, 1f) // 0.0 (10%) .. 1.0 (100%)
        val palette = StarlightColorAdapter.resolvePalette(glowColor, surfaceBgColor)
        val now = SystemClock.uptimeMillis()

        if (!shouldSpawnParticles) {
            return SpotlightOrb(
                sourceView = sourceView,
                keyRect = rect,
                glowColor = glowColor,
                palette = palette,
                spawnTime = now,
                releaseTime = 0L,
                intensityNorm = normI,
                stardustList = emptyList(),
                starPoints = emptyList(),
                nebulaSpots = emptyList(),
                starFlares = emptyList()
            )
        }

        val seed = System.nanoTime() xor
            ((sourceView?.hashCode()?.toLong() ?: 0x5A17L) shl 17) xor
            (orbSeedCounter++ * -7046029254386353131L)
        val rng = java.util.Random(seed)
        val twoPi = (Math.PI * 2.0).toFloat()

        // 星河扩散半径随强度显著拉开差距（轻柔紧凑、柔美舒展、璀璨星河宽广深邃）
        val spreadScale = 0.78f + normI * 0.48f
        val spreadRx = (rect.width() * 0.54f + dpF(16f * spreadScale)).coerceAtLeast(dpF(26f))
        val spreadRy = (rect.height() * 0.54f + dpF(14f * spreadScale)).coerceAtLeast(dpF(22f))

        // 随机生成一条横跨当前按键光晕的「星河主轴倾角」（让每次点击的星尘呈银河带状自然流淌，而非死板圆圈）
        val galaxyAxisAngle = (rng.nextFloat() - 0.5f) * 1.9f // 约 -54° ~ +54°
        val cosAxis = cos(galaxyAxisAngle)
        val sinAxis = sin(galaxyAxisAngle)

        // 1. 生成第 1 层级：微小星尘 (MicroStardust) —— 数量最多、体积微小、低调铺底
        //    轻柔(25%): ~12 颗 | 柔美(55%): ~22 颗 | 璀璨(95%): ~40 颗
        val dustCount = (10 + (normI * normI * 24f + normI * 10f).toInt() + rng.nextInt(4)).coerceIn(8, 46)
        val stardustList = ArrayList<MicroStardustParticle>(dustCount)
        for (i in 0 until dustCount) {
            val alongBand = rng.nextFloat() < 0.68f
            val rx: Float
            val ry: Float
            if (alongBand) {
                // 沿星河主轴分布，带自然S型弯曲与垂直方向高斯发散
                val u = (rng.nextFloat() * 2f - 1f) * spreadRx * 0.96f
                val curveOffset = sin(u / spreadRx * 2.2f) * spreadRy * 0.16f
                val vSpread = (rng.nextFloat() + rng.nextFloat() - 1f) * spreadRy * 0.44f + curveOffset
                rx = u * cosAxis - vSpread * sinAxis
                ry = u * sinAxis + vSpread * cosAxis
            } else {
                val ang = rng.nextFloat() * twoPi
                val dist = 0.15f + rng.nextFloat() * 0.88f
                rx = cos(ang) * spreadRx * dist
                ry = sin(ang) * spreadRy * dist
            }
            val driftAng = atan2(ry, rx) + (rng.nextFloat() - 0.5f) * 0.5f
            val driftDist = dpF(1.2f + rng.nextFloat() * 2.8f)
            val radDp = 0.38f + rng.nextFloat() * 0.56f // 0.38dp ~ 0.94dp 极细微星尘
            stardustList.add(
                MicroStardustParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(driftAng) * driftDist,
                    driftDy = sin(driftAng) * driftDist,
                    coreRadiusPx = dpF(radDp),
                    baseAlpha = (0.24f + rng.nextFloat() * 0.44f) * (0.68f + normI * 0.42f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.015f + rng.nextFloat() * 0.016f
                )
            )
        }

        // 2. 生成第 2 层级：普通星点 (StarPoints) —— 中等亮度、带柔和径向光晕的星辰点
        //    轻柔(25%): ~4 颗 | 柔美(55%): ~8 颗 | 璀璨(95%): ~15 颗
        val pointCount = (3 + (normI * 12f).toInt() + rng.nextInt(2)).coerceIn(3, 17)
        val starPoints = ArrayList<StarPointParticle>(pointCount)
        val ptBaseAng = rng.nextFloat() * twoPi
        for (i in 0 until pointCount) {
            val ang = ptBaseAng + (i.toFloat() / pointCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.65f
            val dist = 0.20f + rng.nextFloat() * 0.78f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val driftDist = dpF(1.5f + rng.nextFloat() * 3.0f)
            val coreDp = (0.72f + rng.nextFloat() * 0.65f) * (0.82f + normI * 0.28f)
            val haloDp = coreDp * (2.6f + rng.nextFloat() * 1.1f)
            starPoints.add(
                StarPointParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * driftDist,
                    driftDy = sin(ang) * driftDist,
                    haloRadiusPx = dpF(haloDp),
                    coreRadiusPx = dpF(coreDp),
                    baseAlpha = (0.52f + rng.nextFloat() * 0.42f) * (0.72f + normI * 0.38f),
                    twinklePhase = rng.nextFloat() * twoPi,
                    twinkleFreq = 0.012f + rng.nextFloat() * 0.012f
                )
            )
        }

        // 3. 生成第 3 层级：少量柔焦星云光斑 (SoftNebulaSpots) —— 严格限制 1~3 枚，纯径向雾化，无任何描边或反光点
        val nebulaCount = when {
            normI < 0.35f -> 1
            normI < 0.75f -> 2
            else -> 3
        }
        val nebulaSpots = ArrayList<SoftNebulaSpotParticle>(nebulaCount)
        for (i in 0 until nebulaCount) {
            val ang = galaxyAxisAngle + i * (Math.PI.toFloat()) + (rng.nextFloat() - 0.5f) * 0.9f
            val dist = 0.22f + rng.nextFloat() * 0.52f
            val rx = cos(ang) * spreadRx * dist
            val ry = sin(ang) * spreadRy * dist
            val radDp = (4.2f + rng.nextFloat() * 3.0f) * (0.85f + normI * 0.25f)
            nebulaSpots.add(
                SoftNebulaSpotParticle(
                    relX = rx,
                    relY = ry,
                    driftDx = cos(ang) * dpF(2.0f),
                    driftDy = sin(ang) * dpF(2.0f),
                    radiusPx = dpF(radDp),
                    baseAlpha = (0.16f + rng.nextFloat() * 0.14f) * (0.75f + normI * 0.35f)
                )
            )
        }

        // 4. 生成第 4 层级：细长锐利的四角/六角视觉焦点星芒 (CelestialStarFlares)
        //    - 主焦点大星芒 (Hero Flares)：轻柔 1 枚 | 柔美 2 枚 | 璀璨 3~4 枚
        //    - 伴生小星芒 (Mini Starlets)：轻柔 1 枚 | 柔美 2~3 枚 | 璀璨 5~7 枚
        val heroCount = when {
            normI < 0.32f -> 1
            normI < 0.68f -> 2
            normI < 0.88f -> 3
            else -> 4
        }
        val miniCount = (1 + (normI * normI * 6.0f).toInt() + (if (normI > 0.5f) 1 else 0)).coerceIn(1, 7)
        val totalFlares = heroCount + miniCount
        val starFlares = ArrayList<CelestialStarFlareParticle>(totalFlares)
        val flareBaseAng = rng.nextFloat() * twoPi

        // 4A. 主焦点大星芒（细长锐利、长短交错、尖端渐隐）
        for (i in 0 until heroCount) {
            val ang = flareBaseAng + (i.toFloat() / heroCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.55f
            val dist = 0.30f + rng.nextFloat() * 0.54f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.2f + rng.nextFloat() * 2.2f)
            val rayScale = 0.72f + normI * 0.58f // 璀璨档位星芒显著修长锐利
            val primaryDp = (10.5f + rng.nextFloat() * 5.8f) * rayScale
            val primaryPx = dpF(primaryDp)
            // 横纵光线采用自然不对称比例（避免死板等长粗十字）
            val orthoPx = primaryPx * (0.64f + rng.nextFloat() * 0.26f)
            val diagPx = primaryPx * (0.28f + rng.nextFloat() * 0.14f)
            // 极纤细光线根部半宽（仅 0.48dp ~ 0.72dp，彻底告别粗大十字！）
            val halfW = dpF((0.48f + rng.nextFloat() * 0.22f) * (0.88f + normI * 0.18f))
            val isSix = (i == 1 && rng.nextFloat() < 0.55f) || (i >= 2 && rng.nextFloat() < 0.45f)
            val rotDeg = if (!isSix && rng.nextFloat() < 0.72f) {
                // 保持接近水平/垂直的星光衍射主轴（微倾 ±6°），或切换主轴方向
                (if (rng.nextBoolean()) 0f else 90f) + (rng.nextFloat() - 0.5f) * 12f
            } else {
                (rng.nextFloat() - 0.5f) * 32f
            }
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = true,
                    baseAlpha = (0.88f + rng.nextFloat() * 0.12f) * (0.78f + normI * 0.32f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        // 4B. 伴生细小星芒（点缀在星河轨迹中的小四角/六角星闪）
        val miniBaseAng = flareBaseAng + 0.48f
        for (i in 0 until miniCount) {
            val ang = miniBaseAng + (i.toFloat() / miniCount) * twoPi + (rng.nextFloat() - 0.5f) * 0.72f
            val dist = 0.22f + rng.nextFloat() * 0.74f
            val sx = cos(ang) * spreadRx * dist
            val sy = sin(ang) * spreadRy * dist
            val drift = dpF(1.4f + rng.nextFloat() * 2.6f)
            val rayScale = 0.74f + normI * 0.46f
            val primaryDp = (5.0f + rng.nextFloat() * 3.6f) * rayScale
            val primaryPx = dpF(primaryDp)
            val orthoPx = primaryPx * (0.68f + rng.nextFloat() * 0.24f)
            val diagPx = if (rng.nextFloat() < 0.4f) primaryPx * 0.28f else 0f
            val halfW = dpF(0.36f + rng.nextFloat() * 0.16f)
            val isSix = rng.nextFloat() < 0.30f
            val rotDeg = (rng.nextFloat() - 0.5f) * 42f
            starFlares.add(
                CelestialStarFlareParticle(
                    relX = sx,
                    relY = sy,
                    driftDx = cos(ang) * drift,
                    driftDy = sin(ang) * drift,
                    primaryRayPx = primaryPx,
                    orthogonalRayPx = orthoPx,
                    diagRayPx = diagPx,
                    baseHalfWidthPx = halfW,
                    rotationDeg = rotDeg,
                    isSixPointed = isSix,
                    isHeroFlare = false,
                    baseAlpha = (0.64f + rng.nextFloat() * 0.28f) * (0.72f + normI * 0.36f),
                    twinklePhase = rng.nextFloat() * twoPi
                )
            )
        }

        return SpotlightOrb(
            sourceView = sourceView,
            keyRect = rect,
            glowColor = glowColor,
            palette = palette,
            spawnTime = now,
            releaseTime = 0L,
            intensityNorm = normI,
            stardustList = stardustList,
            starPoints = starPoints,
            nebulaSpots = nebulaSpots,
            starFlares = starFlares
        )
    }

    fun triggerKeyDown(
        keyView: View,
        @Suppress("UNUSED_PARAMETER") cornerRadius: Float,
        glowColor: Int,
        surfaceBgColor: Int? = null
    ) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val vw = if (keyView.width > 0) keyView.width.toFloat() else dpF(36f)
        val vh = if (keyView.height > 0) keyView.height.toFloat() else dpF(36f)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + vw
        val bottom = top + vh

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(buildRandomOrb(keyView, RectF(left, top, right, bottom), glowColor, surfaceBgColor))
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerPreviewBurst(glowColor: Int, surfaceBgColor: Int? = null) {
        val w = width.toFloat().coerceAtLeast(dpF(180f))
        val h = height.toFloat().coerceAtLeast(dpF(42f))
        val cx = w * (0.28f + (System.nanoTime() and 0xFF) / 580f)
        val cy = h * 0.5f
        val rect = RectF(cx - dpF(28f), cy - dpF(16f), cx + dpF(28f), cy + dpF(16f))
        val orb = buildRandomOrb(null, rect, glowColor, surfaceBgColor)
        orb.releaseTime = SystemClock.uptimeMillis()
        orbs.add(orb)
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    fun clearAllOrbs() {
        if (orbs.isNotEmpty()) {
            orbs.clear()
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val hasClip = clipCornerRadiusPx > 0.5f && width > 0 && height > 0
        val clipSave = if (hasClip) {
            val sc = canvas.save()
            clipBoundsPath.reset()
            tmpRectF.set(0f, 0f, width.toFloat(), height.toFloat())
            clipBoundsPath.addRoundRect(tmpRectF, clipCornerRadiusPx, clipCornerRadiusPx, Path.Direction.CW)
            canvas.clipPath(clipBoundsPath)
            sc
        } else -1

        val now = SystemClock.uptimeMillis()
        val holdMs = 160f
        val fadeMs = 680f
        val totalMs = holdMs + fadeMs
        val outerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 32f else 40f)
        val innerSpread = dpF(if (renderLayerMode == LAYER_FULL_COMBINED) 16f else 20f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            val driftProgress: Float
            if (orb.releaseTime == 0L) {
                val heldElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()
                progress = 1.0f
                driftProgress = (heldElapsed / 540f).coerceIn(0f, 0.40f)
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.05f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.95f * (1f - t) * (1f - t)
                }
                driftProgress = (0.16f + 0.84f * (elapsed / totalMs)).coerceIn(0f, 1f)
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val pal = orb.palette
            val rGlow = Color.red(orb.glowColor)
            val gGlow = Color.green(orb.glowColor)
            val bGlow = Color.blue(orb.glowColor)

            // 1. 100% 恢复原版浓郁灵动的 OKLCH 选色背光方案（浅色皮肤与深色皮肤下光晕均清晰饱满，绝不减淡隐身！）
            if (renderLayerMode == LAYER_UNDER_GLOW || renderLayerMode == LAYER_FULL_COMBINED) {
                val rxOut = (orb.keyRect.width() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                val ryOut = (orb.keyRect.height() * 0.5f + outerSpread).coerceAtLeast(dpF(54f))
                val outerGrad = RadialGradient(
                    0f,
                    0f,
                    baseRadius,
                    intArrayOf(
                        Color.argb((185 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((160 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((110 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((56 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((18 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb(0, rGlow, gGlow, bGlow)
                    ),
                    floatArrayOf(0f, 0.34f, 0.54f, 0.72f, 0.86f, 1.0f),
                    Shader.TileMode.CLAMP
                )
                shaderMatrix.reset()
                shaderMatrix.setScale(rxOut / baseRadius, ryOut / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                outerGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = outerGrad
                tmpRectF.set(cx - rxOut, cy - ryOut, cx + rxOut, cy + ryOut)
                canvas.drawOval(tmpRectF, orbPaint)

                val rxIn = (orb.keyRect.width() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                val ryIn = (orb.keyRect.height() * 0.5f + innerSpread).coerceAtLeast(dpF(36f))
                val innerGrad = RadialGradient(
                    0f,
                    0f,
                    baseRadius,
                    intArrayOf(
                        Color.argb((215 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((185 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((118 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb((40 * progress).toInt().coerceIn(0, 255), rGlow, gGlow, bGlow),
                        Color.argb(0, rGlow, gGlow, bGlow)
                    ),
                    floatArrayOf(0f, 0.42f, 0.65f, 0.85f, 1.0f),
                    Shader.TileMode.CLAMP
                )
                shaderMatrix.reset()
                shaderMatrix.setScale(rxIn / baseRadius, ryIn / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                innerGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = innerGrad
                tmpRectF.set(cx - rxIn, cy - ryIn, cx + rxIn, cy + ryIn)
                canvas.drawOval(tmpRectF, orbPaint)
            } else if (renderLayerMode == LAYER_OVER_SPARKLE && orb.starFlares.isNotEmpty()) {
                // 在实心纯色按键上方同步叠加原版选色柔光晕，让浅色键帽上的光晕与星芒都饱满清晰
                val rxVeil = (orb.keyRect.width() * 0.58f + dpF(18f)).coerceAtLeast(dpF(36f))
                val ryVeil = (orb.keyRect.height() * 0.58f + dpF(16f)).coerceAtLeast(dpF(32f))
                val veilAlpha = (56f * progress).toInt().coerceIn(0, 95)
                val veilGrad = RadialGradient(
                    0f,
                    0f,
                    baseRadius,
                    intArrayOf(
                        Color.argb(veilAlpha, rGlow, gGlow, bGlow),
                        Color.argb((veilAlpha * 0.68f).toInt(), rGlow, gGlow, bGlow),
                        Color.argb((veilAlpha * 0.25f).toInt(), rGlow, gGlow, bGlow),
                        Color.argb(0, rGlow, gGlow, bGlow)
                    ),
                    floatArrayOf(0f, 0.48f, 0.78f, 1.0f),
                    Shader.TileMode.CLAMP
                )
                shaderMatrix.reset()
                shaderMatrix.setScale(rxVeil / baseRadius, ryVeil / baseRadius)
                shaderMatrix.postTranslate(cx, cy)
                veilGrad.setLocalMatrix(shaderMatrix)
                orbPaint.shader = veilGrad
                tmpRectF.set(cx - rxVeil, cy - ryVeil, cx + rxVeil, cy + ryVeil)
                canvas.drawOval(tmpRectF, orbPaint)
            }

            // 2. 绘制璀璨星河四层粒子体系（1.柔焦星云光斑 -> 2.微小星尘 -> 3.普通星点 -> 4.细长锐利四角/六角星芒）
            if (renderLayerMode != LAYER_UNDER_GLOW &&
                (orb.stardustList.isNotEmpty() || orb.starPoints.isNotEmpty() || orb.starFlares.isNotEmpty())
            ) {
                val lifeElapsed = (now - orb.spawnTime).coerceAtLeast(0L).toFloat()
                val rHalo = Color.red(pal.softHaloColor)
                val gHalo = Color.green(pal.softHaloColor)
                val bHalo = Color.blue(pal.softHaloColor)
                val rNearW = Color.red(pal.rayNearWhite)
                val gNearW = Color.green(pal.rayNearWhite)
                val bNearW = Color.blue(pal.rayNearWhite)
                val rShadow = Color.red(pal.lightContrastShadowColor)
                val gShadow = Color.green(pal.lightContrastShadowColor)
                val bShadow = Color.blue(pal.lightContrastShadowColor)

                // 层级 A：少量柔焦星云光斑 (SoftNebulaSpots，纯高斯径向渐隐，无任何圆环描边)
                for (neb in orb.nebulaSpots) {
                    val nx = cx + neb.relX + neb.driftDx * driftProgress
                    val ny = cy + neb.relY + neb.driftDy * driftProgress
                    val nr = neb.radiusPx
                    val nAlpha = (progress * neb.baseAlpha).coerceIn(0f, 1f)
                    val nebColR = if (pal.isLightSurface) rShadow else rHalo
                    val nebColG = if (pal.isLightSurface) gShadow else gHalo
                    val nebColB = if (pal.isLightSurface) bShadow else bHalo
                    val nebGrad = RadialGradient(
                        nx,
                        ny,
                        nr,
                        intArrayOf(
                            Color.argb((125f * nAlpha).toInt().coerceIn(0, 255), nebColR, nebColG, nebColB),
                            Color.argb((58f * nAlpha).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                            Color.argb(0, rHalo, gHalo, bHalo)
                        ),
                        floatArrayOf(0f, 0.52f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = nebGrad
                    canvas.drawCircle(nx, ny, nr, particleFillPaint)
                }

                // 层级 B：微小星尘 (MicroStardust，顺沿星河轨迹散落的细小微光尘埃)
                particleFillPaint.shader = null
                for (dust in orb.stardustList) {
                    val dx = cx + dust.relX + dust.driftDx * driftProgress
                    val dy = cy + dust.relY + dust.driftDy * driftProgress
                    val twinkle = 0.62f + 0.38f * sin(lifeElapsed * dust.twinkleFreq + dust.twinklePhase)
                    val dAlpha = (progress * dust.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val cr = dust.coreRadiusPx

                    if (pal.isLightSurface) {
                        // 浅色皮肤下先铺一层极柔和的微光晕底，避免白点隐形
                        particleFillPaint.color = Color.argb(
                            (95f * dAlpha).toInt().coerceIn(0, 255),
                            rShadow,
                            gShadow,
                            bShadow
                        )
                        canvas.drawCircle(dx, dy, cr * 1.95f, particleFillPaint)
                    } else {
                        particleFillPaint.color = Color.argb(
                            (75f * dAlpha).toInt().coerceIn(0, 255),
                            rHalo,
                            gHalo,
                            bHalo
                        )
                        canvas.drawCircle(dx, dy, cr * 1.75f, particleFillPaint)
                    }

                    // 星尘亮白微核
                    particleFillPaint.color = Color.argb(
                        (235f * dAlpha).toInt().coerceIn(0, 255),
                        rNearW,
                        gNearW,
                        bNearW
                    )
                    canvas.drawCircle(dx, dy, cr, particleFillPaint)
                }

                // 层级 C：普通星点 (StarPoints，带柔和径向渐变光晕 + 纯白亮核，边缘完全消隐为 0)
                for (pt in orb.starPoints) {
                    val px = cx + pt.relX + pt.driftDx * driftProgress
                    val py = cy + pt.relY + pt.driftDy * driftProgress
                    val twinkle = 0.70f + 0.30f * sin(lifeElapsed * pt.twinkleFreq + pt.twinklePhase)
                    val pAlpha = (progress * pt.baseAlpha * twinkle).coerceIn(0f, 1f)
                    val hr = pt.haloRadiusPx
                    val cr = pt.coreRadiusPx

                    val midHaloR = if (pal.isLightSurface) rShadow else rHalo
                    val midHaloG = if (pal.isLightSurface) gShadow else gHalo
                    val midHaloB = if (pal.isLightSurface) bShadow else bHalo

                    val ptGrad = RadialGradient(
                        px,
                        py,
                        hr,
                        intArrayOf(
                            Color.argb((245f * pAlpha).toInt().coerceIn(0, 255), 255, 255, 255),
                            Color.argb((165f * pAlpha).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                            Color.argb((78f * pAlpha).toInt().coerceIn(0, 255), midHaloR, midHaloG, midHaloB),
                            Color.argb(0, midHaloR, midHaloG, midHaloB)
                        ),
                        floatArrayOf(0f, 0.24f, 0.56f, 1.0f),
                        Shader.TileMode.CLAMP
                    )
                    particleFillPaint.shader = ptGrad
                    canvas.drawCircle(px, py, hr, particleFillPaint)

                    particleFillPaint.shader = null
                    particleFillPaint.color = Color.argb(
                        (255f * pAlpha).toInt().coerceIn(0, 255),
                        255,
                        255,
                        255
                    )
                    canvas.drawCircle(px, py, cr * 0.75f, particleFillPaint)
                }

                // 层级 D：细长锐利的四角与六角星芒 (CelestialStarFlares，中心纯白高亮、尖端径向渐隐)
                for (flare in orb.starFlares) {
                    val fx = cx + flare.relX + flare.driftDx * driftProgress
                    val fy = cy + flare.relY + flare.driftDy * driftProgress
                    val pulse = 0.88f + 0.12f * sin(lifeElapsed * 0.014f + flare.twinklePhase)
                    val fAlpha = (progress * flare.baseAlpha * pulse).coerceIn(0f, 1f)
                    val lenScale = 0.88f + 0.14f * progress
                    drawCelestialStarFlare(
                        canvas = canvas,
                        sx = fx,
                        sy = fy,
                        primaryRayPx = flare.primaryRayPx * lenScale,
                        orthogonalRayPx = flare.orthogonalRayPx * lenScale,
                        diagRayPx = flare.diagRayPx * lenScale,
                        baseHalfWidthPx = flare.baseHalfWidthPx,
                        rotationDeg = flare.rotationDeg,
                        isSixPointed = flare.isSixPointed,
                        isHeroFlare = flare.isHeroFlare,
                        alphaFactor = fAlpha,
                        pal = pal
                    )
                }
            }
        }

        if (clipSave != -1) {
            canvas.restoreToCount(clipSave)
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    /**
     * 构建纤细、锐利的四角或六角星芒几何路径（与颜色完全解耦）：
     * - 采用深度内凹曲线 (cDist = 0.11 * L, cW = 0.07 * baseW)，使星芒仅在中心聚光核处饱满，
     *   向外极速收束为发丝级锐利针尖，彻底告别笨重的粗十字！
     */
    private fun buildSlenderStarFlarePath(
        primaryLen: Float,
        orthoLen: Float,
        diagLen: Float,
        baseW: Float,
        isSixPointed: Boolean
    ) {
        starPath.reset()
        if (isSixPointed) {
            // 六角星芒：1 对主长芒 (0°/180°) + 2 对 60°/120° 辅长芒
            val angles = floatArrayOf(
                0f,
                (Math.PI / 3.0).toFloat(),
                (2.0 * Math.PI / 3.0).toFloat()
            )
            for (idx in angles.indices) {
                val a = angles[idx]
                val rayL = if (idx == 0) primaryLen else orthoLen * 0.88f
                val rw = if (idx == 0) baseW else baseW * 0.78f
                addSymmetricNeedlePair(a, rayL, rw)
            }
        } else {
            // 四角星芒：长短微差别的横纵细长主光线 + 可选极细微对角星芒
            addSymmetricNeedlePair(0f, primaryLen, baseW)
            addSymmetricNeedlePair((Math.PI * 0.5).toFloat(), orthoLen, baseW * 0.88f)
            if (diagLen > 1.2f) {
                val dw = baseW * 0.52f
                addSymmetricNeedlePair((Math.PI * 0.25).toFloat(), diagLen, dw)
                addSymmetricNeedlePair((Math.PI * 0.75).toFloat(), diagLen, dw)
            }
        }
    }

    private fun addSymmetricNeedlePair(angleRad: Float, rayLen: Float, halfBaseW: Float) {
        val ux = cos(angleRad)
        val uy = sin(angleRad)
        val px = -uy
        val py = ux
        val cDist = rayLen * 0.11f
        val cW = halfBaseW * 0.075f

        // 正向针芒 (+ux, +uy)
        starPath.moveTo(px * halfBaseW, py * halfBaseW)
        starPath.quadTo(ux * cDist + px * cW, uy * cDist + py * cW, ux * rayLen, uy * rayLen)
        starPath.quadTo(ux * cDist - px * cW, uy * cDist - py * cW, -px * halfBaseW, -py * halfBaseW)
        starPath.close()

        // 反向针芒 (-ux, -uy)
        starPath.moveTo(-px * halfBaseW, -py * halfBaseW)
        starPath.quadTo(-ux * cDist - px * cW, -uy * cDist - py * cW, -ux * rayLen, -uy * rayLen)
        starPath.quadTo(-ux * cDist + px * cW, -uy * cDist + py * cW, px * halfBaseW, py * halfBaseW)
        starPath.close()
    }

    private fun drawCelestialStarFlare(
        canvas: Canvas,
        sx: Float,
        sy: Float,
        primaryRayPx: Float,
        orthogonalRayPx: Float,
        diagRayPx: Float,
        baseHalfWidthPx: Float,
        rotationDeg: Float,
        isSixPointed: Boolean,
        isHeroFlare: Boolean,
        alphaFactor: Float,
        pal: StarlightColorAdapter.StarlightPalette
    ) {
        if (primaryRayPx <= 1f || alphaFactor <= 0.01f) return
        val save = canvas.save()
        canvas.translate(sx, sy)
        canvas.rotate(rotationDeg)

        val rHalo = Color.red(pal.softHaloColor)
        val gHalo = Color.green(pal.softHaloColor)
        val bHalo = Color.blue(pal.softHaloColor)
        val rNearW = Color.red(pal.rayNearWhite)
        val gNearW = Color.green(pal.rayNearWhite)
        val bNearW = Color.blue(pal.rayNearWhite)
        val rShadow = Color.red(pal.lightContrastShadowColor)
        val gShadow = Color.green(pal.lightContrastShadowColor)
        val bShadow = Color.blue(pal.lightContrastShadowColor)

        // 1. 柔和外围星晕（中心亮、向外自然消散为 0，继承低饱和度皮肤色相）
        val haloR = (primaryRayPx * (if (isHeroFlare) 0.44f else 0.40f)).coerceAtLeast(dpF(3.2f))
        val haloColR = if (pal.isLightSurface) rShadow else rHalo
        val haloColG = if (pal.isLightSurface) gShadow else gHalo
        val haloColB = if (pal.isLightSurface) bShadow else bHalo
        val haloCenterAlpha = (if (pal.isLightSurface) 118f else 92f) * alphaFactor
        val haloGrad = RadialGradient(
            0f,
            0f,
            haloR,
            intArrayOf(
                Color.argb(haloCenterAlpha.toInt().coerceIn(0, 255), haloColR, haloColG, haloColB),
                Color.argb((haloCenterAlpha * 0.42f).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.48f, 1.0f),
            Shader.TileMode.CLAMP
        )
        orbPaint.shader = haloGrad
        canvas.drawCircle(0f, 0f, haloR, orbPaint)

        // 2. 浅色皮肤专属：极轻柔的渐隐底层星影（同样采用 RadialGradient 尖端消隐为 0，绝无生硬外框）
        if (pal.isLightSurface) {
            buildSlenderStarFlarePath(
                primaryLen = primaryRayPx * 1.02f,
                orthoLen = orthogonalRayPx * 1.02f,
                diagLen = diagRayPx,
                baseW = baseHalfWidthPx * 1.45f,
                isSixPointed = isSixPointed
            )
            val shadowRayGrad = RadialGradient(
                0f,
                0f,
                primaryRayPx * 1.02f,
                intArrayOf(
                    Color.argb((148f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((86f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb((24f * alphaFactor).toInt().coerceIn(0, 255), rShadow, gShadow, bShadow),
                    Color.argb(0, rShadow, gShadow, bShadow)
                ),
                floatArrayOf(0f, 0.32f, 0.72f, 1.0f),
                Shader.TileMode.CLAMP
            )
            particleFillPaint.shader = shadowRayGrad
            canvas.drawPath(starPath, particleFillPaint)
        }

        // 3. 核心星芒光线：中心纯白高亮 (#FFFFFF)，沿光线向尖端平滑渐隐至完全透明 (alpha = 0)！
        buildSlenderStarFlarePath(
            primaryLen = primaryRayPx,
            orthoLen = orthogonalRayPx,
            diagLen = diagRayPx,
            baseW = baseHalfWidthPx,
            isSixPointed = isSixPointed
        )
        val rayGrad = RadialGradient(
            0f,
            0f,
            primaryRayPx,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((232f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((115f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb((28f * alphaFactor).toInt().coerceIn(0, 255), rHalo, gHalo, bHalo),
                Color.argb(0, rHalo, gHalo, bHalo)
            ),
            floatArrayOf(0f, 0.18f, 0.48f, 0.80f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = rayGrad
        canvas.drawPath(starPath, particleFillPaint)

        // 4. 星芒中心璀璨纯白亮核（径向过渡，中心凝亮）
        val coreR = (baseHalfWidthPx * (if (isHeroFlare) 2.3f else 1.9f)).coerceAtLeast(dpF(1.3f))
        val coreGrad = RadialGradient(
            0f,
            0f,
            coreR,
            intArrayOf(
                Color.argb((255f * alphaFactor).toInt().coerceIn(0, 255), 255, 255, 255),
                Color.argb((210f * alphaFactor).toInt().coerceIn(0, 255), rNearW, gNearW, bNearW),
                Color.argb(0, rNearW, gNearW, bNearW)
            ),
            floatArrayOf(0f, 0.45f, 1.0f),
            Shader.TileMode.CLAMP
        )
        particleFillPaint.shader = coreGrad
        canvas.drawCircle(0f, 0f, coreR, particleFillPaint)

        canvas.restoreToCount(save)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 统一按键与顶栏背景视图（支持三大渲染模式）：
 * 1. 莫奈花园模式 (bitmap != null)：渲染 1:1 油画睡莲键帽贴图；
 * 2. 纯色框架 + 已上传自定义背景图模式 (useFrostedCustomBg = true)：
 *    自动定位当前按键在键盘中的坐标，实时读取并模糊对应位置的底图 (CustomBgManager.getBlurredBitmap)，
 *    再叠加半透明毛玻璃键帽底色与细腻磨砂白边；
 * 3. 纯色框架默认模式：渲染干净的纯色键帽，按下时自动呈现柔和同色系反馈。
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#528262"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT,
    private val useFrostedCustomBg: Boolean = false
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    KeySoundManager.playClick(context)
                }
                if (enableGlow) {
                    val bgSample = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else null
                    forEachBacklightOverlay { overlay ->
                        if (value) {
                            overlay.triggerKeyDown(this, cornerRadiusPx, glowColor, bgSample)
                        } else {
                            overlay.triggerKeyUp(this)
                        }
                    }
                }
                invalidate()
            }
        }

    private inline fun forEachBacklightOverlay(action: (KeyboardBacklightOverlayView) -> Unit) {
        var p = parent
        var foundInGroup = false
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    action(child)
                    foundInGroup = true
                }
            }
            if (foundInGroup) return
            p = p.parent
        }
    }

    private fun findRootKbContainer(): View? {
        var cur: View? = this
        var last: View? = null
        while (cur != null) {
            last = cur
            val np = cur.parent
            cur = if (np is View) np else null
        }
        return last
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val frostBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1.0f, resources.displayMetrics)
        color = Color.argb(135, 255, 255, 255)
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()
    private val blurMatrix = Matrix()
    private val selfLoc = IntArray(2)
    private val rootLoc = IntArray(2)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        val blurredBg = if (useFrostedCustomBg) CustomBgManager.getBlurredBitmap(context) else null

        if (bitmap != null) {
            // 模式 1：莫奈花园专属油画键帽贴图
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (blurredBg != null) {
            // 模式 2：纯色框架下已上传自定义背景图 -> 实时读取并模糊对应坐标处的底图 + 半透明毛玻璃键帽层
            val rootV = findRootKbContainer()
            val rw = (rootV?.width ?: width).toFloat().coerceAtLeast(1f)
            val rh = (rootV?.height ?: height).toFloat().coerceAtLeast(1f)
            getLocationInWindow(selfLoc)
            rootV?.getLocationInWindow(rootLoc)
            val relX = (selfLoc[0] - rootLoc[0]).toFloat()
            val relY = (selfLoc[1] - rootLoc[1]).toFloat()

            val scale = max(rw / blurredBg.width.toFloat(), rh / blurredBg.height.toFloat())
            val dx = (rw - blurredBg.width * scale) * 0.5f - relX
            val dy = (rh - blurredBg.height * scale) * 0.5f - relY
            blurMatrix.reset()
            blurMatrix.setScale(scale, scale)
            blurMatrix.postTranslate(dx, dy)
            canvas.drawBitmap(blurredBg, blurMatrix, bmpPaint)

            // 叠加半透明毛玻璃键帽色（按下时向灵动光晕色轻柔过渡 22%，绝不压暗变灰！）
            val baseCol = if (fallbackBgTop != Color.TRANSPARENT) fallbackBgTop else Color.WHITE
            val tintCol = if (isKeyPressedState) blendLivelyPressColor(baseCol, glowColor) else baseCol
            val frostAlpha = if (isKeyPressedState) 138 else 110
            fallbackFillPaint.color = Color.argb(
                frostAlpha,
                Color.red(tintCol),
                Color.green(tintCol),
                Color.blue(tintCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        } else if (fallbackBgTop != Color.TRANSPARENT) {
            // 模式 3：纯色框架默认模式（未上传背景图）-> 实心纯色键帽，按下时向同色系灵动粉彩轻柔过渡，绝不变灰！
            val drawCol = if (isKeyPressedState) blendLivelyPressColor(fallbackBgTop, glowColor) else fallbackBgTop
            fallbackFillPaint.color = Color.argb(
                255,
                Color.red(drawCol),
                Color.green(drawCol),
                Color.blue(drawCol)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)

        if (blurredBg != null && bitmap == null) {
            val half = frostBorderPaint.strokeWidth * 0.5f
            keyRectF.set(half, half, w - half, h - half)
            canvas.drawRoundRect(keyRectF, r, r, frostBorderPaint)
        }
    }

    private fun blendLivelyPressColor(baseColor: Int, livelyGlowColor: Int): Int {
        val r = (Color.red(baseColor) * 0.72f + Color.red(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val g = (Color.green(baseColor) * 0.72f + Color.green(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        val b = (Color.blue(baseColor) * 0.72f + Color.blue(livelyGlowColor) * 0.28f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }
}

/**
 * 现代圆角极简风「顶部状态栏 4 图标视图」（复刻参考图 1000128623.jpg & 1000128608.jpg）：
 * - 与圆角按键风格高度统一，采用圆角方糖（Squircle）微填充底衬 + 圆润胶囊线条：
 *   0 (设置)：现代圆角四宫格控制中心图标（3 枚圆角方格 + 右上角点睛圆点）
 *   1 (表情)：圆角方糖微填充萌系笑脸图标（圆润胶囊眼 + 柔和微笑弧）
 *   2 (常用)：圆角书签卡片图标（圆角外框 + 双胶囊横线 + 右上角小折角）
 *   3 (收起)：圆角胶囊下折图标（柔和圆角底衬 + 宽角圆头下折箭头 + 底部短横）
 * - 在莫奈花园模式下支持渲染水彩睡莲图标。
 */
/**
 * 顶部状态栏 5 图标独立自定义上传与大小/染色管理器：
 * - 支持为 5 个顶栏槽位独立上传自定义 PNG/WebP/JPG 图标：
 *   0 (TYPE_SETTINGS)：第1个 - 设置（内置默认：去猫脸保留耳廓与小胡须的圆润猫猫头）
 *   1 (TYPE_EMOJI)：第2个 - 表情（内置默认：大小双爱心）
 *   4 (TYPE_CLIPBOARD)：第3个 - 剪贴板（内置默认：环绕小星球）
 *   2 (TYPE_FAVORITE)：第4个 - 收藏/常用语（内置默认：圆润胖五角星）
 *   3 (TYPE_COLLAPSE)：第5个 - 收起键盘（内置默认：三尖圆珠小皇冠）
 * - 智能背景处理：若用户上传的是透明底 PNG，直接保留透明通道并自动裁切多余透明边距；
 *   若用户上传的是白底/纯浅色底图片，自动识别四角背景色并智能抠除转为透明底！
 * - 支持「线条随皮肤自动变色」与「保留彩色原图本色」两种渲染模式自由切换。
 * - 支持 14dp ~ 34dp 无级调节顶栏图标显示大小（默认 22dp，精致不突兀）。
 */
object CustomTopIconManager {
    const val DEFAULT_ICON_SIZE_DP = 22
    const val MIN_ICON_SIZE_DP = 14
    const val MAX_ICON_SIZE_DP = 34

    private val customBmpCache = HashMap<Int, Pair<Long, Bitmap>>()

    fun getSlotFile(context: Context, iconType: Int): File {
        return File(context.filesDir, "custom_top_icon_$iconType.png")
    }

    fun getSlotTimestamp(context: Context, iconType: Int): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getLong("custom_top_icon_ts_$iconType", 0L)
    }

    fun getCombinedTimestamp(context: Context): Long {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        val tintFlag = if (isFollowSkinColor(context)) 1L else 0L
        val sizeDp = getIconSizeDp(context).toLong()
        return getSlotTimestamp(context, 0) xor
            (getSlotTimestamp(context, 1) shl 1) xor
            (getSlotTimestamp(context, 2) shl 2) xor
            (getSlotTimestamp(context, 3) shl 3) xor
            (getSlotTimestamp(context, 4) shl 4) xor
            (tintFlag shl 20) xor
            (sizeDp shl 24) xor
            prefs.getLong("custom_top_icon_global_ts", 0L)
    }

    fun hasCustomIcon(context: Context, iconType: Int): Boolean {
        return getSlotTimestamp(context, iconType) > 0L && getSlotFile(context, iconType).exists()
    }

    fun isFollowSkinColor(context: Context): Boolean {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean("custom_top_icon_follow_skin", true)
    }

    fun setFollowSkinColor(context: Context, follow: Boolean) {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("custom_top_icon_follow_skin", follow)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun getIconSizeDp(context: Context): Int {
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        return prefs.getInt("top_bar_icon_size_dp", DEFAULT_ICON_SIZE_DP).coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
    }

    fun setIconSizeDp(context: Context, sizeDp: Int) {
        val clamped = sizeDp.coerceIn(MIN_ICON_SIZE_DP, MAX_ICON_SIZE_DP)
        val prefs = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("top_bar_icon_size_dp", clamped)
            .putLong("custom_top_icon_global_ts", System.currentTimeMillis())
            .apply()
    }

    fun clearCustomIcon(context: Context, iconType: Int) {
        try {
            getSlotFile(context, iconType).delete()
        } catch (_: Exception) {}
        val now = System.currentTimeMillis()
        context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
            .edit()
            .putLong("custom_top_icon_ts_$iconType", 0L)
            .putLong("custom_top_icon_global_ts", now)
            .apply()
        synchronized(customBmpCache) {
            customBmpCache.remove(iconType)
        }
    }

    fun clearAllCustomIcons(context: Context) {
        for (t in listOf(0, 1, 2, 3, 4)) {
            try {
                getSlotFile(context, t).delete()
            } catch (_: Exception) {}
        }
        val now = System.currentTimeMillis()
        val editor = context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE).edit()
        for (t in listOf(0, 1, 2, 3, 4)) {
            editor.putLong("custom_top_icon_ts_$t", 0L)
        }
        editor.putLong("custom_top_icon_global_ts", now).apply()
        synchronized(customBmpCache) {
            customBmpCache.clear()
        }
    }

    fun getCustomBitmap(context: Context, iconType: Int): Bitmap? {
        val ts = getSlotTimestamp(context, iconType)
        if (ts <= 0L) return null
        synchronized(customBmpCache) {
            val cached = customBmpCache[iconType]
            if (cached != null && cached.first == ts && !cached.second.isRecycled) {
                return cached.second
            }
            val f = getSlotFile(context, iconType)
            if (!f.exists()) return null
            try {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp != null) {
                    customBmpCache[iconType] = ts to bmp
                    return bmp
                }
            } catch (_: Exception) {}
            return null
        }
    }

    /**
     * 导入并智能处理用户上传的图标：
     * 1. 若原图自带透明通道（PNG/WebP），完整保留透明通道与抗锯齿边缘；
     * 2. 若原图是不透明白底/浅色底图片，自动采样四角背景色并智能去底转为透明通道；
     * 3. 自动裁切四周多余空白并保留均匀呼吸边距，存入应用私有目录。
     */
    fun saveCustomIconFromBitmap(context: Context, iconType: Int, rawBitmap: Bitmap): Boolean {
        try {
            val maxDim = 256
            val rw = rawBitmap.width
            val rh = rawBitmap.height
            if (rw <= 0 || rh <= 0) return false

            val scaled = if (rw > maxDim || rh > maxDim) {
                val ratio = minOf(maxDim.toFloat() / rw.toFloat(), maxDim.toFloat() / rh.toFloat())
                Bitmap.createScaledBitmap(
                    rawBitmap,
                    (rw * ratio).toInt().coerceAtLeast(1),
                    (rh * ratio).toInt().coerceAtLeast(1),
                    true
                )
            } else {
                rawBitmap.copy(Bitmap.Config.ARGB_8888, true)
            }

            val w = scaled.width
            val h = scaled.height
            val pixels = IntArray(w * h)
            scaled.getPixels(pixels, 0, w, 0, 0, w, h)

            // 检测是否已有透明背景
            var transparentCount = 0
            for (p in pixels) {
                val a = (p ushr 24) and 0xFF
                if (a < 210) transparentCount++
            }
            val hasNativeAlpha = transparentCount > (w * h) / 25

            if (!hasNativeAlpha) {
                // 自动采样四角背景色，智能抠除纯色底
                val corners = intArrayOf(
                    pixels[0],
                    pixels[w - 1],
                    pixels[(h - 1) * w],
                    pixels[(h - 1) * w + (w - 1)]
                )
                var bgR = 0f
                var bgG = 0f
                var bgB = 0f
                for (c in corners) {
                    bgR += ((c shr 16) and 0xFF)
                    bgG += ((c shr 8) and 0xFF)
                    bgB += (c and 0xFF)
                }
                bgR /= 4f
                bgG /= 4f
                bgB /= 4f

                var maxDist = 1f
                for (p in pixels) {
                    val dr = ((p shr 16) and 0xFF) - bgR
                    val dg = ((p shr 8) and 0xFF) - bgG
                    val db = (p and 0xFF) - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    if (d > maxDist) maxDist = d
                }

                val lowThresh = (maxDist * 0.16f).coerceAtLeast(18f)
                val highThresh = (maxDist * 0.52f).coerceAtLeast(lowThresh + 16f)

                for (i in pixels.indices) {
                    val p = pixels[i]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val dr = r - bgR
                    val dg = g - bgG
                    val db = b - bgB
                    val d = sqrt(dr * dr + dg * dg + db * db)
                    val t = ((d - lowThresh) / (highThresh - lowThresh)).coerceIn(0f, 1f)
                    val smoothA = (t * t * (3f - 2f * t) * 255f).toInt().coerceIn(0, 255)
                    pixels[i] = (smoothA shl 24) or (r shl 16) or (g shl 8) or b
                }
            }

            // 自动寻找有效像素边界并适度留白裁切
            var minX = w
            var minY = h
            var maxX = 0
            var maxY = 0
            for (y in 0 until h) {
                val rowOff = y * w
                for (x in 0 until w) {
                    val a = (pixels[rowOff + x] ushr 24) and 0xFF
                    if (a > 24) {
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }

            val processed = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            processed.setPixels(pixels, 0, w, 0, 0, w, h)

            val finalBmp = if (minX <= maxX && minY <= maxY) {
                val padX = ((maxX - minX + 1) * 0.05f).toInt().coerceAtLeast(2)
                val padY = ((maxY - minY + 1) * 0.05f).toInt().coerceAtLeast(2)
                val cx0 = (minX - padX).coerceAtLeast(0)
                val cy0 = (minY - padY).coerceAtLeast(0)
                val cx1 = (maxX + padX).coerceAtMost(w - 1)
                val cy1 = (maxY + padY).coerceAtMost(h - 1)
                Bitmap.createBitmap(processed, cx0, cy0, (cx1 - cx0 + 1).coerceAtLeast(1), (cy1 - cy0 + 1).coerceAtLeast(1))
            } else {
                processed
            }

            val outFile = getSlotFile(context, iconType)
            FileOutputStream(outFile).use { fos ->
                finalBmp.compress(Bitmap.CompressFormat.PNG, 100, fos)
            }
            val now = System.currentTimeMillis()
            context.getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
                .edit()
                .putLong("custom_top_icon_ts_$iconType", now)
                .putLong("custom_top_icon_global_ts", now)
                .apply()
            synchronized(customBmpCache) {
                customBmpCache[iconType] = now to finalBmp
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }
}

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = false
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0   // 小胡须圆润猫猫头（无五官猫脸，保留内耳与小胡须）
        const val TYPE_EMOJI = 1      // 大小双爱心（表情/颜文字）
        const val TYPE_PHRASE = 2     // 圆润胖五角小星星（收藏/常用语）
        const val TYPE_FAVORITE = 2   // 圆润胖五角小星星（收藏/常用语）
        const val TYPE_COLLAPSE = 3   // 三尖圆珠小皇冠（收起键盘）
        const val TYPE_CLIPBOARD = 4  // 环绕小星球（剪贴板）

        private val cuteBitmapCache = HashMap<Int, Bitmap>()

        fun getCuteHollowBitmap(context: Context, type: Int): Bitmap? {
            synchronized(cuteBitmapCache) {
                cuteBitmapCache[type]?.let { if (!it.isRecycled) return it }
                val assetName = when (type) {
                    TYPE_SETTINGS -> "cute_icons/icon_cat.png"
                    TYPE_EMOJI -> "cute_icons/icon_paw.png"
                    TYPE_CLIPBOARD -> "cute_icons/icon_heart.png"
                    TYPE_PHRASE -> "cute_icons/icon_star.png"
                    TYPE_COLLAPSE -> "cute_icons/icon_sakura.png"
                    else -> "cute_icons/icon_star.png"
                }
                try {
                    context.assets.open(assetName).use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) {
                            cuteBitmapCache[type] = bmp
                            return bmp
                        }
                    }
                } catch (_: Exception) {}
                return null
            }
        }
    }

    private val tintedBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = PorterDuffColorFilter(iconColor, PorterDuff.Mode.SRC_IN)
    }
    private val rawColorBitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fineStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val starStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(dpF(3.0f))
        color = iconColor
    }

    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        tintedBitmapPaint.colorFilter = PorterDuffColorFilter(newColor, PorterDuff.Mode.SRC_IN)
        strokePaint.color = newColor
        fineStrokePaint.color = newColor
        starStrokePaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f

        // 0. 莫奈花园油画睡莲特殊皮肤专属状态栏：优先绘制原版水彩睡莲/花苞/荷叶图标（1:1 复刻图5，绝不变成猫猫头！）
        if (useBotanicalStyle) {
            val lotusIdx = when (iconType) {
                TYPE_SETTINGS -> 0
                TYPE_EMOJI -> 1
                TYPE_CLIPBOARD, TYPE_PHRASE -> 2
                TYPE_COLLAPSE -> 3
                else -> 0
            }
            val lotusBmp = MonetTextureManager.getTopIconBitmap(context, lotusIdx)
            if (lotusBmp != null && lotusBmp.width > 0 && lotusBmp.height > 0) {
                val aspect = lotusBmp.width.toFloat() / lotusBmp.height.toFloat()
                var drawH = h * 0.94f
                var drawW = drawH * aspect
                if (drawW > w * 0.96f) {
                    drawW = w * 0.96f
                    drawH = drawW / aspect
                }
                srcRect.set(0, 0, lotusBmp.width, lotusBmp.height)
                dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
                canvas.drawBitmap(lotusBmp, srcRect, dstRectF, rawColorBitmapPaint)
                return
            }
        }

        // 1. 优先检查用户是否为该槽位上传了自定义状态栏图标
        val customBmp = CustomTopIconManager.getCustomBitmap(context, iconType)
        if (customBmp != null && customBmp.width > 0 && customBmp.height > 0) {
            val aspect = customBmp.width.toFloat() / customBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, customBmp.width, customBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            val paintToUse = if (CustomTopIconManager.isFollowSkinColor(context)) tintedBitmapPaint else rawColorBitmapPaint
            canvas.drawBitmap(customBmp, srcRect, dstRectF, paintToUse)
            return
        }

        // 2. 内置默认图标：1:1 复刻最新参考图（小胡须无五官猫猫头、大小双爱心、环绕小星球、圆润胖星星、三尖圆珠小皇冠）
        val cuteBmp = getCuteHollowBitmap(context, iconType)
        if (cuteBmp != null && cuteBmp.width > 0 && cuteBmp.height > 0) {
            val aspect = cuteBmp.width.toFloat() / cuteBmp.height.toFloat()
            var drawH = h * 0.90f
            var drawW = drawH * aspect
            if (drawW > w * 0.94f) {
                drawW = w * 0.94f
                drawH = drawW / aspect
            }
            srcRect.set(0, 0, cuteBmp.width, cuteBmp.height)
            dstRectF.set(cx - drawW * 0.5f, cy - drawH * 0.5f, cx + drawW * 0.5f, cy + drawH * 0.5f)
            canvas.drawBitmap(cuteBmp, srcRect, dstRectF, tintedBitmapPaint)
            return
        }

        val r = minOf(w, h) * 0.42f
        drawCuteHollowIcon(canvas, cx, cy, r)
    }

    private fun drawCuteHollowIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val cyCat = cy + r * 0.05f
                path.reset()
                path.moveTo(cx - r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx, cyCat - r * 0.46f, cx + r * 0.36f, cyCat - r * 0.42f)
                path.quadTo(cx + r * 0.62f, cyCat - r * 0.86f, cx + r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx + r * 0.94f, cyCat - r * 0.52f, cx + r * 0.92f, cyCat - r * 0.12f)
                path.cubicTo(cx + r * 1.12f, cyCat + r * 0.44f, cx + r * 0.64f, cyCat + r * 0.82f, cx, cyCat + r * 0.82f)
                path.cubicTo(cx - r * 0.64f, cyCat + r * 0.82f, cx - r * 1.12f, cyCat + r * 0.44f, cx - r * 0.92f, cyCat - r * 0.12f)
                path.quadTo(cx - r * 0.94f, cyCat - r * 0.52f, cx - r * 0.80f, cyCat - r * 0.86f)
                path.quadTo(cx - r * 0.62f, cyCat - r * 0.86f, cx - r * 0.36f, cyCat - r * 0.42f)
                path.close()
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - r * 0.74f, cyCat + r * 0.15f, cx - r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx - r * 0.70f, cyCat + r * 0.32f, cx - r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.74f, cyCat + r * 0.15f, cx + r * 1.22f, cyCat + r * 0.17f, fineStrokePaint)
                canvas.drawLine(cx + r * 0.70f, cyCat + r * 0.32f, cx + r * 1.14f, cyCat + r * 0.45f, fineStrokePaint)
            }
            else -> {
                val outerR = r * 0.96f
                val innerR = r * 0.54f
                path.reset()
                for (i in 0 until 10) {
                    val ang = Math.toRadians((-90.0 + i * 36.0))
                    val rad = if (i % 2 == 0) outerR else innerR
                    val px = cx + (rad * cos(ang)).toFloat()
                    val py = cy + (rad * sin(ang)).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                canvas.drawPath(path, starStrokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class BackspaceIconView(
    context: Context,
    private val iconColor: Int
) : View(context) {

    private val tagPath = Path()
    private val cornerEffect = CornerPathEffect(dpF(3.8f))

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(36, Color.red(iconColor), Color.green(iconColor), Color.blue(iconColor))
        pathEffect = cornerEffect
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
        pathEffect = cornerEffect
    }

    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.85f)
        strokeCap = Paint.Cap.ROUND
        color = iconColor
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w * 0.5f
        val cy = h * 0.5f
        val halfW = dpF(10.5f)
        val halfH = dpF(7.2f)
        val noseX = cx - halfW
        val bodyLeft = cx - halfW * 0.38f
        val rightX = cx + halfW

        tagPath.reset()
        tagPath.moveTo(noseX, cy)
        tagPath.lineTo(bodyLeft, cy - halfH)
        tagPath.lineTo(rightX, cy - halfH)
        tagPath.lineTo(rightX, cy + halfH)
        tagPath.lineTo(bodyLeft, cy + halfH)
        tagPath.close()

        // 100% 纯镂空退格键图标（去除半透明灰色内填充）
        canvas.drawPath(tagPath, strokePaint)

        // 内部居中偏右一点的圆头 × 号
        val xCenter = (bodyLeft + rightX) * 0.5f + dpF(0.6f)
        val xSpan = dpF(2.7f)
        canvas.drawLine(xCenter - xSpan, cy - xSpan, xCenter + xSpan, cy + xSpan, crossPaint)
        canvas.drawLine(xCenter + xSpan, cy - xSpan, xCenter - xSpan, cy + xSpan, crossPaint)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
