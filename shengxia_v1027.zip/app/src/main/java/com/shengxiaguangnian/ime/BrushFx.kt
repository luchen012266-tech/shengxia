package com.shengxiaguangnian.ime


import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

private const val TWO_PI = 6.2831855f
private const val HALF_PI = 1.5707964f
private const val PI_F = 3.1415927f
private const val DEG_TO_RAD = 0.017453292f

/**
 * 通用笔刷特效引擎（Brush FX）
 *
 * 一个特效 = 若干「笔刷层」(BrushLayer) 叠加。每种笔刷只描述"长什么样"，
 * 参数只描述"多少、多大、多快、活多久、往哪飞"。换一组参数就是另一个特效，
 * 不需要写新代码 —— 这是整套键盘特效体系的解构基础。
 *
 * 8 种笔刷：
 *   GLOW   柔光雾（垫底）
 *   SPIKE  放射尖刺 / 细丝
 *   RING   圆环扩散（水波）
 *   STAR   四芒星 / 多角星
 *   BUBBLE 半透明泡泡
 *   ARC    弧形飘带 / 弯月丝带
 *   DOT    亮点星尘（可受重力）
 *   GLYPH  字符星点（✦ ✧ ° ·）
 */
enum class BrushKind { GLOW, SPIKE, RING, STAR, BUBBLE, ARC, DOT, GLYPH }

/** 淡出方式 */
object Fade {
    const val OUT = 0     // 亮起后渐隐
    const val HOLD = 1    // 保持到末尾再淡出
    const val FLICKER = 2 // 一路闪烁衰减
}

/**
 * 一层笔刷参数。所有区间参数都是 [最小, 最大]，每个粒子在其中随机取值。
 * 长度单位统一是 px（调用方会按屏幕密度换算）。
 */
data class BrushLayer(
    val brush: BrushKind,
    val count: Int,
    val sizeMin: Float,
    val sizeMax: Float,
    val lengthMin: Float = 0f,
    val lengthMax: Float = 0f,
    val speedMin: Float = 0f,
    val speedMax: Float = 0f,
    val lifeMin: Int = 400,
    val lifeMax: Int = 800,
    val angleFrom: Float = 0f,
    val angleTo: Float = 360f,
    val curve: Float = 0f,
    val colorStart: Int = 0xFFFFFFFF.toInt(),
    val colorEnd: Int = 0xFFAAAAAA.toInt(),
    val alpha: Float = 0.9f,
    val glow: Float = 0.6f,
    val gravity: Float = 0f,
    val spin: Float = 0f,
    val glyphs: List<String> = emptyList(),
    val fade: Int = Fade.OUT,
    val orbit: Boolean = false,
    val delayMs: Int = 0
)

/** 一个正在飞行的粒子 */
private class BrushParticle(
    val kind: BrushKind,
    val rootX: Float,
    val rootY: Float,
    val vx: Float,
    val vy: Float,
    val size: Float,
    val length: Float,
    val lifeMs: Int,
    val bornAt: Long,
    val delayMs: Int,
    val curve: Float,
    val colorStart: Int,
    val colorEnd: Int,
    val alpha: Float,
    val glow: Float,
    val gravity: Float,
    val spin: Float,
    val rot0: Float,
    val glyph: String,
    val fadeMode: Int,
    val orbit: Boolean,
    val orbitRx: Float,
    val orbitRy: Float,
    val orbitPhase: Float,
    val orbitDir: Float,
    val orbitTurns: Float,
    val cx: Float,
    val cy: Float
)

class BrushBurstField {

    companion object {
        private const val MAX_PARTICLES = 260
    }

    private val particles = ArrayList<BrushParticle>(MAX_PARTICLES + 16)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val dst = RectF()
    private val rng = Random(System.nanoTime())
    private val filterCache = HashMap<Int, PorterDuffColorFilter>(16)
    private var softDot: Bitmap? = null

    init {
        paint.style = Paint.Style.FILL
        paint.strokeCap = Paint.Cap.ROUND
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.isAntiAlias = true
    }

    fun isActive(): Boolean = particles.isNotEmpty()

    fun clear() {
        particles.clear()
    }

    /** 换肤 / 切特效时把颜色过滤器缓存作废 */
    fun invalidateColorCache() {
        filterCache.clear()
    }

    // ---------------- 发射 ----------------

    /**
     * 在按键矩形上发射一组笔刷层。
     * @param rect       按键在覆盖层里的位置
     * @param corner     键帽圆角
     * @param layers     笔刷配方
     * @param tint       皮肤取色（会和配方颜色混一点，保证深/浅皮肤上都看得见）
     * @param tintMix    混色比例 0~1
     * @param density    疏密 0~1（0.5 = 原配方数量）
     * @param reach      幅度 0~1（影响速度与长度倍数）
     * @param spread     扩散速度 0~1（影响速度倍数）
     */
    fun emit(
        rect: RectF,
        corner: Float,
        layers: List<BrushLayer>,
        tint: Int,
        tintMix: Float = 0.35f,
        density: Float = 0.6f,
        reach: Float = 0.5f,
        spread: Float = 0.6f,
        pxScale: Float = 1f
    ) {
        if (layers.isEmpty() || rect.width() <= 0f || rect.height() <= 0f) return
        val now = SystemClock.uptimeMillis()
        val countScale = 0.55f + density * 1.15f
        val speedScale = 0.55f + spread * 1.05f
        val sizeScale = 0.82f + reach * 0.55f
        val orbitRx = rect.width() * 0.5f + corner * 0.55f
        val orbitRy = rect.height() * 0.5f + corner * 0.55f
        val cx = rect.centerX()
        val cy = rect.centerY()

        for (layer in layers) {
            val n = (layer.count * countScale).toInt().coerceIn(1, 48)
            val basePhase = rng.nextFloat() * TWO_PI
            for (i in 0 until n) {
                val angDeg = layer.angleFrom + rng.nextFloat() * (layer.angleTo - layer.angleFrom)
                val ang = angDeg * DEG_TO_RAD
                // 从键帽边缘附近起飞，避免所有粒子挤在中心一个点
                val edgePad = layer.sizeMax * 0.6f
                val startR = if (layer.orbit) 0f else rng.nextFloat() * edgePad
                val sx = cx + cos(ang) * startR
                val sy = cy + sin(ang) * startR
                val spd = (layer.speedMin + rng.nextFloat() * (layer.speedMax - layer.speedMin)) * speedScale
                val size = (layer.sizeMin + rng.nextFloat() * (layer.sizeMax - layer.sizeMin)) * sizeScale * pxScale
                val len = (layer.lengthMin + rng.nextFloat() * (layer.lengthMax - layer.lengthMin)) *
                    (0.82f + reach * 0.5f) * pxScale
                val life = (layer.lifeMin + rng.nextInt((layer.lifeMax - layer.lifeMin).coerceAtLeast(1)))
                    .coerceIn(120, 2600)
                val glyph = if (layer.glyphs.isEmpty()) "✦" else layer.glyphs[rng.nextInt(layer.glyphs.size)]

                particles.add(
                    BrushParticle(
                        kind = layer.brush,
                        rootX = sx,
                        rootY = sy,
                        vx = cos(ang) * spd,
                        vy = -sin(ang) * spd,
                        size = size.coerceIn(0.8f, 90f),
                        length = len.coerceIn(0f, 260f),
                        lifeMs = life,
                        bornAt = now,
                        delayMs = layer.delayMs,
                        curve = layer.curve,
                        colorStart = mixColor(layer.colorStart, tint, tintMix * 0.5f),
                        colorEnd = mixColor(layer.colorEnd, tint, tintMix),
                        alpha = layer.alpha,
                        glow = layer.glow,
                        gravity = layer.gravity * (0.6f + reach * 0.8f),
                        spin = layer.spin,
                        rot0 = rng.nextFloat() * 360f,
                        glyph = glyph,
                        fadeMode = layer.fade,
                        orbit = layer.orbit,
                        orbitRx = orbitRx,
                        orbitRy = orbitRy,
                        orbitPhase = basePhase + (i.toFloat() / n) * TWO_PI + (rng.nextFloat() - 0.5f) * 0.5f,
                        orbitDir = if (rng.nextBoolean()) 1f else -1f,
                        orbitTurns = (0.55f + rng.nextFloat() * 0.75f) * (0.7f + spread * 0.8f),
                        cx = cx,
                        cy = cy
                    )
                )
            }
        }
        while (particles.size > MAX_PARTICLES) {
            particles.removeAt(0)
        }
    }

    // ---------------- 绘制 ----------------

    fun draw(canvas: Canvas, now: Long) {
        if (particles.isEmpty()) return
        val iter = particles.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            val age = now - p.bornAt - p.delayMs
            if (age < 0L) continue
            val t = age.toFloat() / p.lifeMs.toFloat()
            if (t >= 1f) {
                iter.remove()
                continue
            }
            drawOne(canvas, p, t, age.toFloat())
        }
        paint.shader = null
        paint.colorFilter = null
        paint.alpha = 255
        paint.strokeWidth = 1f
    }

    private fun drawOne(canvas: Canvas, p: BrushParticle, t: Float, ageMs: Float) {
        val env = envelope(t, p.fadeMode)
        if (env <= 0.01f) return
        val aMul = (env * p.alpha).coerceIn(0f, 1f)
        when (p.kind) {
            BrushKind.GLOW -> drawGlow(canvas, p, t, aMul)
            BrushKind.SPIKE -> drawSpike(canvas, p, t, aMul)
            BrushKind.RING -> drawRing(canvas, p, t, aMul)
            BrushKind.STAR -> drawStar(canvas, p, t, aMul)
            BrushKind.BUBBLE -> drawBubble(canvas, p, t, aMul, ageMs)
            BrushKind.ARC -> drawArcRibbon(canvas, p, t, aMul, ageMs)
            BrushKind.DOT -> drawDot(canvas, p, t, aMul, ageMs)
            BrushKind.GLYPH -> drawGlyph(canvas, p, t, aMul, ageMs)
        }
    }

    // --- 位置解算 ---
    private fun posX(p: BrushParticle, ageMs: Float): Float {
        if (p.orbit) return p.cx + cos(p.orbitPhase + p.orbitDir * p.orbitTurns * TWO_PI * (ageMs / p.lifeMs)) * p.orbitRx
        val s = ageMs / 1000f
        return p.rootX + p.vx * s + p.curve * p.vx * 0.22f * s * s
    }

    private fun posY(p: BrushParticle, ageMs: Float): Float {
        if (p.orbit) return p.cy + sin(p.orbitPhase + p.orbitDir * p.orbitTurns * TWO_PI * (ageMs / p.lifeMs)) * p.orbitRy
        val s = ageMs / 1000f
        return p.rootY + p.vy * s + 0.5f * p.gravity * s * s
    }

    private fun angleOf(p: BrushParticle, ageMs: Float): Float {
        if (p.orbit) {
            val a = p.orbitPhase + p.orbitDir * p.orbitTurns * TWO_PI * (ageMs / p.lifeMs)
            val tx = -p.orbitRx * sin(a) * p.orbitDir
            val ty = p.orbitRy * cos(a) * p.orbitDir
            return kotlin.math.atan2(ty, tx)
        }
        return kotlin.math.atan2(p.vy + p.gravity * (ageMs / 1000f), p.vx)
    }

    private fun colorAt(p: BrushParticle, t: Float): Int {
        val e = t.coerceIn(0f, 1f)
        val a = Color.alpha(p.colorStart)
        val b = Color.alpha(p.colorEnd)
        val r = (Color.red(p.colorStart) + (Color.red(p.colorEnd) - Color.red(p.colorStart)) * e).toInt()
        val g = (Color.green(p.colorStart) + (Color.green(p.colorEnd) - Color.green(p.colorStart)) * e).toInt()
        val bl = (Color.blue(p.colorStart) + (Color.blue(p.colorEnd) - Color.blue(p.colorStart)) * e).toInt()
        val al = (a + (b - a) * e).toInt()
        return Color.argb(al.coerceIn(0, 255), r.coerceIn(0, 255), g.coerceIn(0, 255), bl.coerceIn(0, 255))
    }

    private fun envelope(t: Float, mode: Int): Float {
        val attack = (t / 0.10f).coerceIn(0f, 1f)
        return when (mode) {
            Fade.HOLD -> {
                val tail = ((1f - t) / 0.30f).coerceIn(0f, 1f)
                attack * tail
            }
            Fade.FLICKER -> {
                val flick = 0.35f + 0.65f * abs(sin(t * PI_F * 3.2f))
                attack * (1f - t).pow(0.9f) * flick
            }
            else -> attack * (1f - t).pow(1.25f)
        }
    }

    // --- 各笔刷 ---

    private fun drawGlow(canvas: Canvas, p: BrushParticle, t: Float, a: Float) {
        // 用预渲染的柔光圆点放大代替实时 RadialGradient，省掉每帧的渐变分配
        val ageMs = t * p.lifeMs
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val r = (p.size * (1f + t * 1.7f)).coerceAtLeast(1f)
        val c = colorAt(p, t)
        drawSoftDot(canvas, x, y, r, withAlpha(c, (Color.alpha(c) * a * 0.95f * p.glow).toInt()))
    }

    private fun drawSpike(canvas: Canvas, p: BrushParticle, t: Float, a: Float) {
        val ageMs = t * p.lifeMs
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val grow = 1f - (1f - t).pow(2.2f)
        val len = p.length * grow
        if (len < 1.5f) return
        val ang = angleOf(p, ageMs) + p.curve * 0.55f * t
        val tipX = x + cos(ang) * len
        val tipY = y + sin(ang) * len
        val nx = cos(ang + HALF_PI)
        val ny = sin(ang + HALF_PI)
        val w0 = p.size * (1f - t * 0.7f)
        if (w0 <= 0.05f) return
        val midX = (x + tipX) * 0.5f + nx * p.curve * len * 0.30f
        val midY = (y + tipY) * 0.5f + ny * p.curve * len * 0.30f
        path.reset()
        path.moveTo(x + nx * w0, y + ny * w0)
        path.quadTo(midX + nx * w0 * 0.5f, midY + ny * w0 * 0.5f, tipX, tipY)
        path.quadTo(midX - nx * w0 * 0.5f, midY - ny * w0 * 0.5f, x - nx * w0, y - ny * w0)
        path.close()
        val c = colorAt(p, t)
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.colorFilter = null
        paint.alpha = 255
        paint.color = withAlpha(c, (Color.alpha(c) * a).toInt())
        canvas.drawPath(path, paint)
        // 头部一点柔光，让丝线有"流光"感
        if (p.glow > 0.05f) {
            drawSoftDot(canvas, tipX, tipY, p.size * 1.6f, withAlpha(c, (Color.alpha(c) * a * 0.55f * p.glow).toInt()))
        }
    }

    private fun drawRing(canvas: Canvas, p: BrushParticle, t: Float, a: Float) {
        val ageMs = t * p.lifeMs
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val eased = 1f - (1f - t).pow(2.6f)
        val spd = kotlin.math.hypot(p.vx, p.vy)
        val r = (p.size + spd * eased * 0.55f).coerceAtLeast(1f)
        val c = colorAt(p, t)
        paint.shader = null
        paint.colorFilter = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (p.size * 0.16f * (1f - t) + 0.6f).coerceAtLeast(0.6f)
        paint.color = withAlpha(c, (Color.alpha(c) * a).toInt())
        canvas.drawCircle(x, y, r, paint)
        if (p.glow > 0.05f) {
            paint.strokeWidth = paint.strokeWidth * 2.4f
            paint.color = withAlpha(c, (Color.alpha(c) * a * 0.22f * p.glow).toInt())
            canvas.drawCircle(x, y, r, paint)
        }
    }

    private fun drawStar(canvas: Canvas, p: BrushParticle, t: Float, a: Float) {
        val ageMs = t * p.lifeMs
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val pop = if (t < 0.25f) (t / 0.25f) else 1f
        val outer = p.size * pop * (1f - t * 0.35f)
        if (outer < 0.6f) return
        val inner = outer * 0.20f
        val rot = (p.rot0 + p.spin * ageMs / 1000f) * DEG_TO_RAD
        path.reset()
        for (i in 0 until 8) {
            val r = if (i % 2 == 0) outer else inner
            val aa = rot + i * (PI_F / 4f)
            val px = x + cos(aa) * r
            val py = y + sin(aa) * r
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        val c = colorAt(p, t)
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.colorFilter = null
        paint.color = withAlpha(c, (Color.alpha(c) * a).toInt())
        canvas.drawPath(path, paint)
        if (p.glow > 0.05f) {
            drawSoftDot(canvas, x, y, outer * 2.2f, withAlpha(c, (Color.alpha(c) * a * 0.5f * p.glow).toInt()))
        }
    }

    private fun drawBubble(canvas: Canvas, p: BrushParticle, t: Float, a: Float, ageMs: Float) {
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val r = p.size * (0.55f + 0.6f * t)
        val c = colorAt(p, t)
        paint.shader = null
        paint.colorFilter = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (r * 0.22f).coerceAtLeast(0.7f)
        paint.color = withAlpha(c, (Color.alpha(c) * a * 0.9f).toInt())
        canvas.drawCircle(x, y, r, paint)
        paint.style = Paint.Style.FILL
        paint.color = withAlpha(c, (Color.alpha(c) * a * 0.16f).toInt())
        canvas.drawCircle(x, y, r, paint)
        drawSoftDot(canvas, x - r * 0.34f, y - r * 0.34f, r * 0.55f, withAlpha(c, (Color.alpha(c) * a * 0.7f).toInt()))
    }

    private fun drawArcRibbon(canvas: Canvas, p: BrushParticle, t: Float, a: Float, ageMs: Float) {
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val grow = 1f - (1f - t).pow(1.9f)
        val len = p.length * grow
        if (len < 2f) return
        val ang = angleOf(p, ageMs)
        val sweep = (0.9f + p.curve * 0.9f) * grow
        val steps = 9
        val c = colorAt(p, t)
        paint.shader = null
        paint.colorFilter = null
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        var prevX = x
        var prevY = y
        for (i in 1..steps) {
            val f = i.toFloat() / steps
            val aa = ang + sweep * f
            val rr = len * f
            val px = x + cos(aa) * rr
            val py = y + sin(aa) * rr
            val fadeSeg = (1f - f * 0.75f)
            paint.strokeWidth = (p.size * (1f - f * 0.65f)).coerceAtLeast(0.6f)
            paint.color = withAlpha(c, (Color.alpha(c) * a * fadeSeg).toInt())
            canvas.drawLine(prevX, prevY, px, py, paint)
            prevX = px
            prevY = py
        }
        if (p.glow > 0.05f) {
            drawSoftDot(canvas, prevX, prevY, p.size * 2.4f, withAlpha(c, (Color.alpha(c) * a * 0.7f * p.glow).toInt()))
        }
    }

    private fun drawDot(canvas: Canvas, p: BrushParticle, t: Float, a: Float, ageMs: Float) {
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val r = p.size * (1f - t * 0.35f)
        if (r < 0.3f) return
        val c = colorAt(p, t)
        drawSoftDot(canvas, x, y, r * 1.9f, withAlpha(c, (Color.alpha(c) * a).toInt()))
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.colorFilter = null
        paint.color = withAlpha(c, (Color.alpha(c) * a).toInt())
        canvas.drawCircle(x, y, (r * 0.42f).coerceAtLeast(0.4f), paint)
    }

    private fun drawGlyph(canvas: Canvas, p: BrushParticle, t: Float, a: Float, ageMs: Float) {
        val x = posX(p, ageMs)
        val y = posY(p, ageMs)
        val size = p.size * (0.7f + 0.5f * (if (t < 0.25f) t / 0.25f else 1f))
        val c = colorAt(p, t)
        textPaint.textSize = size.coerceAtLeast(4f)
        textPaint.color = withAlpha(c, (Color.alpha(c) * a).toInt())
        textPaint.typeface = android.graphics.Typeface.DEFAULT
        canvas.save()
        canvas.rotate(p.rot0 * 0.12f + p.spin * ageMs / 1000f * 0.35f, x, y)
        canvas.drawText(p.glyph, x, y + size * 0.36f, textPaint)
        canvas.restore()
        if (p.glow > 0.05f) {
            drawSoftDot(canvas, x, y, size * 1.1f, withAlpha(c, (Color.alpha(c) * a * 0.35f * p.glow).toInt()))
        }
    }

    // --- 工具 ---

    private fun drawSoftDot(canvas: Canvas, x: Float, y: Float, r: Float, color: Int) {
        if (r <= 0.2f) return
        val bmp = dotBitmap()
        dst.set(x - r, y - r, x + r, y + r)
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.alpha = Color.alpha(color).coerceIn(0, 255)
        paint.colorFilter = filterFor(color)
        canvas.drawBitmap(bmp, null, dst, paint)
        paint.alpha = 255
        paint.colorFilter = null
    }

    private fun filterFor(color: Int): PorterDuffColorFilter {
        val key = color or 0xFF000000.toInt()
        filterCache[key]?.let { return it }
        val f = PorterDuffColorFilter(key, PorterDuff.Mode.SRC_IN)
        if (filterCache.size > 48) filterCache.clear()
        filterCache[key] = f
        return f
    }

    private fun dotBitmap(): Bitmap {
        softDot?.let { return it }
        val size = 64
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(
            32f, 32f, 32f,
            intArrayOf(
                0xFFFFFFFF.toInt(),
                0xCCFFFFFF.toInt(),
                0x66FFFFFF,
                0x22FFFFFF,
                0x00FFFFFF
            ),
            floatArrayOf(0f, 0.22f, 0.5f, 0.78f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(32f, 32f, 32f, p)
        softDot = bmp
        return bmp
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        Color.argb(alpha.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))

    private fun mixColor(a: Int, b: Int, t: Float): Int {
        val f = t.coerceIn(0f, 1f)
        return Color.argb(
            (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * f).toInt().coerceIn(0, 255),
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt().coerceIn(0, 255),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt().coerceIn(0, 255),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt().coerceIn(0, 255)
        )
    }
}


/**
 * 笔刷配方表：4 款「平淡」特效各自换上一套完全不同的笔刷组合。
 * 每一套都能独立调 疏密 / 幅度 / 速度。
 */
object BrushRecipes {

    /** 水纹落雨：一圈圈很浅的水波 + 溅起的水珠 + 雾状水光 */
    fun liquidRipple(): List<BrushLayer> = listOf(
        BrushLayer(
            brush = BrushKind.GLOW,
            count = 1,
            sizeMin = 26f,
            sizeMax = 34f,
            speedMin = 0f, speedMax = 0f,
            lifeMin = 520, lifeMax = 680,
            colorStart = 0x99DFF7FF.toInt(),
            colorEnd = 0x113E8FD6,
            alpha = 0.55f, glow = 0.5f, fade = Fade.OUT
        ),
        BrushLayer(
            brush = BrushKind.RING,
            count = 2,
            sizeMin = 10f, sizeMax = 16f,
            speedMin = 90f, speedMax = 130f,
            lifeMin = 620, lifeMax = 820,
            angleFrom = 0f, angleTo = 360f,
            colorStart = 0xEEDFF7FF.toInt(),
            colorEnd = 0x2260B4F0,
            alpha = 0.85f, glow = 0.45f, fade = Fade.OUT, delayMs = 40
        ),
        BrushLayer(
            brush = BrushKind.BUBBLE,
            count = 4,
            sizeMin = 2.6f, sizeMax = 5.0f,
            speedMin = 24f, speedMax = 58f,
            lifeMin = 520, lifeMax = 780,
            angleFrom = 20f, angleTo = 340f,
            colorStart = 0xFFEAF9FF.toInt(),
            colorEnd = 0x3389D3F7,
            alpha = 0.9f, glow = 0.35f, gravity = -42f, fade = Fade.OUT
        ),
        BrushLayer(
            brush = BrushKind.DOT,
            count = 5,
            sizeMin = 1.6f, sizeMax = 3.2f,
            speedMin = 40f, speedMax = 95f,
            lifeMin = 360, lifeMax = 560,
            angleFrom = 40f, angleTo = 140f,
            colorStart = 0xFFFFFFFF.toInt(),
            colorEnd = 0x445BA8E8,
            alpha = 0.8f, glow = 0.3f, gravity = 180f, fade = Fade.FLICKER
        )
    )

    /** 暗夜微尘：极细星屑缓缓落下 + 偶尔一道流星 */
    fun stardustFall(): List<BrushLayer> = listOf(
        BrushLayer(
            brush = BrushKind.ARC,
            count = 1,
            sizeMin = 1.1f, sizeMax = 1.8f,
            lengthMin = 34f, lengthMax = 58f,
            speedMin = 120f, speedMax = 190f,
            lifeMin = 620, lifeMax = 860,
            angleFrom = 232f, angleTo = 260f,
            curve = 0.55f,
            colorStart = 0xFFFFF3C8.toInt(),
            colorEnd = 0x225B7BD6,
            alpha = 0.75f, glow = 0.7f, fade = Fade.OUT, delayMs = 60
        ),
        BrushLayer(
            brush = BrushKind.DOT,
            count = 9,
            sizeMin = 1.3f, sizeMax = 2.9f,
            speedMin = 20f, speedMax = 48f,
            lifeMin = 900, lifeMax = 1500,
            angleFrom = 250f, angleTo = 290f,
            colorStart = 0xFFFFFFFF.toInt(),
            colorEnd = 0x6699B4FF,
            alpha = 0.85f, glow = 0.45f, gravity = 36f, fade = Fade.FLICKER
        ),
        BrushLayer(
            brush = BrushKind.STAR,
            count = 2,
            sizeMin = 2.4f, sizeMax = 4.4f,
            speedMin = 16f, speedMax = 42f,
            lifeMin = 620, lifeMax = 900,
            angleFrom = 200f, angleTo = 340f,
            colorStart = 0xFFFFFFFF.toInt(),
            colorEnd = 0x55969BFF,
            alpha = 0.9f, glow = 0.6f, spin = 26f, fade = Fade.FLICKER, delayMs = 120
        ),
        BrushLayer(
            brush = BrushKind.GLOW,
            count = 1,
            sizeMin = 22f, sizeMax = 30f,
            speedMin = 0f, speedMax = 0f,
            lifeMin = 640, lifeMax = 800,
            colorStart = 0x555F7BD6,
            colorEnd = 0x0E2A3A80,
            alpha = 0.42f, glow = 0.4f
        )
    )

    /** 键廓流光：贴着键帽轮廓绕圈跑的弯月丝带 + 星芒 + 小泡 */
    fun contourVortex(): List<BrushLayer> = listOf(
        BrushLayer(
            brush = BrushKind.ARC,
            count = 2,
            sizeMin = 2.0f, sizeMax = 3.2f,
            lengthMin = 20f, lengthMax = 34f,
            speedMin = 0f, speedMax = 0f,
            lifeMin = 720, lifeMax = 980,
            curve = 1.0f,
            colorStart = 0xFFFFF6DA.toInt(),
            colorEnd = 0x557F8BFF,
            alpha = 0.9f, glow = 0.6f, fade = Fade.OUT,
            orbit = true
        ),
        BrushLayer(
            brush = BrushKind.SPIKE,
            count = 3,
            sizeMin = 1.4f, sizeMax = 2.4f,
            lengthMin = 12f, lengthMax = 24f,
            speedMin = 40f, speedMax = 80f,
            lifeMin = 420, lifeMax = 620,
            angleFrom = 0f, angleTo = 360f,
            curve = 0.5f,
            colorStart = 0xFFFFE9B0.toInt(),
            colorEnd = 0x339B8CFF,
            alpha = 0.8f, glow = 0.5f, fade = Fade.OUT, delayMs = 70
        ),
        BrushLayer(
            brush = BrushKind.STAR,
            count = 3,
            sizeMin = 3.2f, sizeMax = 6.0f,
            speedMin = 18f, speedMax = 46f,
            lifeMin = 460, lifeMax = 700,
            angleFrom = 0f, angleTo = 360f,
            colorStart = 0xFFFFFFFF.toInt(),
            colorEnd = 0x66A99BFF,
            alpha = 0.95f, glow = 0.65f, spin = 34f, fade = Fade.OUT, delayMs = 40
        ),
        BrushLayer(
            brush = BrushKind.BUBBLE,
            count = 4,
            sizeMin = 1.8f, sizeMax = 3.6f,
            speedMin = 22f, speedMax = 52f,
            lifeMin = 480, lifeMax = 720,
            angleFrom = 0f, angleTo = 360f,
            colorStart = 0xCCFFF6E0.toInt(),
            colorEnd = 0x2A9E8BFF,
            alpha = 0.8f, glow = 0.4f, gravity = -26f, fade = Fade.OUT
        )
    )

    /** 键上星芒：细碎糖粉星芒，短促闪烁 */
    fun sparkle(): List<BrushLayer> = listOf(
        BrushLayer(
            brush = BrushKind.STAR,
            count = 4,
            sizeMin = 3.4f, sizeMax = 7.6f,
            speedMin = 14f, speedMax = 42f,
            lifeMin = 280, lifeMax = 460,
            angleFrom = 30f, angleTo = 150f,
            colorStart = 0xFFFFFFFF.toInt(),
            colorEnd = 0x77FFD9A0,
            alpha = 1f, glow = 0.75f, spin = 55f, fade = Fade.FLICKER
        ),
        BrushLayer(
            brush = BrushKind.GLYPH,
            count = 3,
            sizeMin = 9f, sizeMax = 14f,
            speedMin = 10f, speedMax = 34f,
            lifeMin = 320, lifeMax = 520,
            angleFrom = 30f, angleTo = 150f,
            colorStart = 0xFFFFFDF2.toInt(),
            colorEnd = 0x88FFC98A.toInt(),
            alpha = 0.95f, glow = 0.5f, spin = 18f, fade = Fade.FLICKER,
            glyphs = listOf("✦", "✧", "·", "°"), delayMs = 30
        ),
        BrushLayer(
            brush = BrushKind.GLOW,
            count = 1,
            sizeMin = 14f, sizeMax = 20f,
            speedMin = 0f, speedMax = 0f,
            lifeMin = 300, lifeMax = 420,
            colorStart = 0x66FFE9C0,
            colorEnd = 0x0AFFC98A,
            alpha = 0.5f, glow = 0.5f
        )
    )
}
