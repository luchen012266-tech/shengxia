package com.shengxiaguangnian.ime

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.util.TypedValue
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 莫奈油画键帽 + 「平时完全正常、仅按下去时浮现柔雾背光与微光星点（复刻参考图2 & 图3）」视图：
 * - 当未按下（pressGlowProgress == 0f）时：完全是干净正常的原版键盘，没有任何外框或霓虹圈！
 * - 当手指按下（及松手后 360ms 余晖消散期间）：
 *   1. 在当前按下的这一个按键四周与背后，柔和晕开 6 层羽化呼吸背光光晕（像图2/图3那样从键底透出柔光）
 *   2. 在按键四角泛起细碎的微光星点（复刻图3按键周边的梦幻小星光）
 *   3. 键帽内部泛起一层温柔的暖白流光
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.WHITE,
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    private var pressGlowProgress: Float = 0f
    private var fadeAnimator: ValueAnimator? = null

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    fadeAnimator?.cancel()
                    pressGlowProgress = 1.0f
                    invalidate()
                } else {
                    fadeAnimator?.cancel()
                    fadeAnimator = ValueAnimator.ofFloat(pressGlowProgress, 0f).apply {
                        duration = 360L
                        interpolator = DecelerateInterpolator()
                        addUpdateListener { anim ->
                            pressGlowProgress = anim.animatedValue as Float
                            invalidate()
                        }
                        start()
                    }
                }
            }
        }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pressBloomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val featherHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val sparklePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val glowRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // 平时 100% 铺满正常键帽尺寸，没有任何多余边框！
        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx
        val p = if (enableGlow) pressGlowProgress.coerceIn(0f, 1f) else 0f

        val rCol = Color.red(glowColor)
        val gCol = Color.green(glowColor)
        val bCol = Color.blue(glowColor)

        // 1. 仅当手指按下（p > 0.01f）时，在该按键背后与四周绘制图2/图3同款的「柔雾羽化背光 + 梦幻小星点」！
        if (p > 0.01f) {
            // (a) 背后大范围柔光呼吸光团（复刻图2按键底下的柔光晕染）
            val ambientRadius = maxOf(w, h) * 0.78f
            pressBloomPaint.shader = RadialGradient(
                w / 2f,
                h / 2f,
                ambientRadius,
                intArrayOf(
                    Color.argb((170 * p).toInt(), rCol, gCol, bCol),
                    Color.argb((95 * p).toInt(), rCol, gCol, bCol),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            val expand = dpF(8f)
            glowRectF.set(-expand, -expand, w + expand, h + expand)
            canvas.drawOval(glowRectF, pressBloomPaint)

            // (b) 6 层由外向内细腻过渡的羽化柔光光晕（复刻图3按键周边的柔和发散光圈，绝不生硬！）
            val steps = listOf(
                Triple(dpF(5.5f), dpF(3.5f), 26),
                Triple(dpF(4.2f), dpF(3.0f), 46),
                Triple(dpF(3.0f), dpF(2.5f), 72),
                Triple(dpF(1.9f), dpF(2.0f), 105),
                Triple(dpF(0.9f), dpF(1.6f), 145),
                Triple(dpF(0.0f), dpF(1.2f), 210)
            )
            for ((outDist, strokeW, baseAlpha) in steps) {
                featherHaloPaint.strokeWidth = strokeW
                // 越靠内越偏向柔和珠光白，越靠外越呈现梦幻氛围色
                val mixRatio = if (outDist < dpF(1.2f)) 0.65f else 0.25f
                val mr = (rCol * (1f - mixRatio) + 255 * mixRatio).toInt().coerceIn(0, 255)
                val mg = (gCol * (1f - mixRatio) + 255 * mixRatio).toInt().coerceIn(0, 255)
                val mb = (bCol * (1f - mixRatio) + 255 * mixRatio).toInt().coerceIn(0, 255)
                featherHaloPaint.color = Color.argb((baseAlpha * p).toInt().coerceIn(0, 255), mr, mg, mb)
                glowRectF.set(-outDist, -outDist, w + outDist, h + outDist)
                canvas.drawRoundRect(glowRectF, r + outDist, r + outDist, featherHaloPaint)
            }

            // (c) 按键四周点缀细碎的微光小星点（复刻图3按键发光边缘的小星芒！）
            sparklePaint.color = Color.argb((230 * p).toInt().coerceIn(0, 255), 255, 255, 255)
            val sRad = dpF(1.4f) * (0.6f + 0.4f * p)
            canvas.drawCircle(-dpF(2.2f), h * 0.22f, sRad, sparklePaint)
            canvas.drawCircle(w + dpF(2.4f), h * 0.28f, sRad * 0.85f, sparklePaint)
            canvas.drawCircle(-dpF(1.8f), h * 0.78f, sRad * 0.8f, sparklePaint)
            canvas.drawCircle(w + dpF(2.0f), h * 0.74f, sRad * 1.05f, sparklePaint)
            canvas.drawCircle(w * 0.25f, -dpF(2.2f), sRad * 0.9f, sparklePaint)
            canvas.drawCircle(w * 0.76f, h + dpF(2.2f), sRad * 0.9f, sparklePaint)
        }

        // 2. 绘制正常键帽主体
        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (fallbackBgTop != Color.TRANSPARENT) {
            fallbackFillPaint.color = fallbackBgTop
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        if (bitmap != null) {
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        }

        // 3. 按下时键帽内部泛起一层柔光提亮（像背光灯从键帽底下透上来）
        if (p > 0.01f) {
            val innerAlpha = (85f * p).toInt().coerceIn(0, 255)
            pressBloomPaint.shader = RadialGradient(
                w / 2f,
                h / 2f,
                maxOf(w, h) * 0.68f,
                intArrayOf(
                    Color.argb(innerAlpha, 255, 255, 255),
                    Color.argb((innerAlpha * 0.55f).toInt(), rCol, gCol, bCol),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.6f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(keyRectF, pressBloomPaint)
        }
        canvas.restoreToCount(saveCount)
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

/**
 * 顶部状态栏 4 图标视图：
 * - 当 useBotanicalStyle = true（莫奈睡莲主题自动开启）时，绘制与睡莲皮肤配套的「莫奈花园水彩轻绘风格」4 图标：
 *   1. 设置 (TYPE_SETTINGS): 六瓣盛开睡莲花盘（柔粉花瓣 + 暖金花心 + 莫奈蓝灰细描边）
 *   2. 表情 (TYPE_EMOJI): 弯月笑眼微醺花苞团子（温柔弯弯笑眼 + 玫瑰粉腮红 + 头顶嫩绿小叶片）
 *   3. 常用 (TYPE_PHRASE): 荷叶书签诗集手账本（圆角诗集卡片 + 右上角嫩绿荷叶小书签 + 粉白花瓣点缀）
 *   4. 收起 (TYPE_COLLAPSE): 睡莲花瓣伴池水双涟漪收起标（柔美弧形花瓣下折 + 双层水波纹 + 粉花苞）
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = true
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.55f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    // 莫奈花园配套柔和色彩画笔
    private val petalPinkFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(185, 236, 182, 198) // 莫奈睡莲柔粉
    }
    private val leafGreenFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(195, 146, 182, 138) // 莫奈嫩荷叶绿
    }
    private val pondBlueFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(110, 175, 198, 238) // 莫奈池水淡蓝
    }
    private val goldHeartFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(235, 244, 208, 122) // 睡莲暖金花心
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.38f

        if (useBotanicalStyle) {
            drawMonetBotanicalIcon(canvas, cx, cy, r)
        } else {
            drawClassicMinimalistIcon(canvas, cx, cy, r)
        }
    }

    private fun drawMonetBotanicalIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                // 🌸 1. 设置：六瓣莫奈睡莲花盘（告别生硬机械齿轮，化作一朵精致俯视睡莲花）
                for (i in 0 until 6) {
                    canvas.save()
                    canvas.translate(cx, cy)
                    canvas.rotate(i * 60f)
                    path.reset()
                    path.moveTo(0f, 0f)
                    path.quadTo(-r * 0.42f, -r * 0.52f, 0f, -r * 0.98f)
                    path.quadTo(r * 0.42f, -r * 0.52f, 0f, 0f)
                    path.close()
                    canvas.drawPath(path, if (i % 2 == 0) petalPinkFill else pondBlueFill)
                    canvas.drawPath(path, strokePaint)
                    canvas.restore()
                }
                // 暖金花蕊中心
                canvas.drawCircle(cx, cy, r * 0.30f, goldHeartFill)
                canvas.drawCircle(cx, cy, r * 0.30f, strokePaint)
            }
            TYPE_EMOJI -> {
                // 😊 2. 表情：头顶小嫩叶的弯月笑眼微醺团子（温柔治愈，带睡莲粉腮红）
                val faceR = r * 0.88f
                val faceCy = cy + r * 0.08f
                canvas.drawCircle(cx, faceCy, faceR, pondBlueFill)
                canvas.drawCircle(cx, faceCy, faceR, strokePaint)

                // 头顶一片嫩绿小荷叶芽
                path.reset()
                path.moveTo(cx, faceCy - faceR)
                path.quadTo(cx + r * 0.45f, faceCy - faceR - r * 0.38f, cx + r * 0.52f, faceCy - faceR + r * 0.05f)
                path.quadTo(cx + r * 0.20f, faceCy - faceR + r * 0.12f, cx, faceCy - faceR)
                path.close()
                canvas.drawPath(path, leafGreenFill)
                canvas.drawPath(path, strokePaint)

                // 两朵睡莲粉小腮红
                canvas.drawCircle(cx - faceR * 0.52f, faceCy + faceR * 0.14f, dpF(2.1f), petalPinkFill)
                canvas.drawCircle(cx + faceR * 0.52f, faceCy + faceR * 0.14f, dpF(2.1f), petalPinkFill)

                // 温柔弯月笑眼 ︵ ︵
                val eyeW = faceR * 0.24f
                val eyeY = faceCy - faceR * 0.10f
                rectF.set(cx - faceR * 0.52f, eyeY - eyeW * 0.7f, cx - faceR * 0.12f, eyeY + eyeW * 0.8f)
                canvas.drawArc(rectF, 200f, 140f, false, strokePaint)
                rectF.set(cx + faceR * 0.12f, eyeY - eyeW * 0.7f, cx + faceR * 0.52f, eyeY + eyeW * 0.8f)
                canvas.drawArc(rectF, 200f, 140f, false, strokePaint)

                // 浅浅微笑弧线
                val smileR = faceR * 0.32f
                rectF.set(cx - smileR, faceCy - smileR * 0.3f, cx + smileR, faceCy + smileR * 0.95f)
                canvas.drawArc(rectF, 28f, 124f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                // 🍃 3. 常用：带嫩绿荷叶书签与粉花瓣的手账诗集卡
                val w = r * 1.55f
                val h = r * 1.78f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(4f), dpF(4f), pondBlueFill)
                canvas.drawRoundRect(rectF, dpF(4f), dpF(4f), strokePaint)

                // 右上角斜倚一片莫奈绿小叶子书签
                path.reset()
                val lx = cx + w * 0.28f
                val ly = cy - h * 0.42f
                path.moveTo(lx - r * 0.15f, ly + r * 0.15f)
                path.quadTo(lx + r * 0.35f, ly - r * 0.35f, lx + r * 0.42f, ly + r * 0.18f)
                path.quadTo(lx + r * 0.05f, ly + r * 0.35f, lx - r * 0.15f, ly + r * 0.15f)
                path.close()
                canvas.drawPath(path, leafGreenFill)
                canvas.drawPath(path, strokePaint)

                // 内部两行诗句细线 + 左下角一粒粉花瓣点缀
                val lineHalfW = w * 0.25f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.08f, cx + lineHalfW, cy - h * 0.08f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.18f, cx + lineHalfW * 0.55f, cy + h * 0.18f, strokePaint)
                canvas.drawCircle(cx + lineHalfW * 0.85f, cy + h * 0.18f, dpF(1.7f), petalPinkFill)
            }
            TYPE_COLLAPSE -> {
                // 🪷 4. 收起：睡莲花苞伴池水微澜收起图标（上方一朵小粉莲苞 + 柔美弧形下折 + 底部双水波纹）
                // 顶部小粉莲花苞
                path.reset()
                path.moveTo(cx, cy - r * 0.15f)
                path.quadTo(cx - r * 0.32f, cy - r * 0.58f, cx, cy - r * 0.82f)
                path.quadTo(cx + r * 0.32f, cy - r * 0.58f, cx, cy - r * 0.15f)
                path.close()
                canvas.drawPath(path, petalPinkFill)
                canvas.drawPath(path, strokePaint)

                // 向下柔美折角
                val w = r * 0.68f
                path.reset()
                path.moveTo(cx - w, cy - r * 0.12f)
                path.lineTo(cx, cy + r * 0.42f)
                path.lineTo(cx + w, cy - r * 0.12f)
                canvas.drawPath(path, strokePaint)

                // 底部池水涟漪微弧线
                rectF.set(cx - w * 0.82f, cy + r * 0.58f, cx + w * 0.82f, cy + r * 0.88f)
                canvas.drawArc(rectF, 15f, 150f, false, strokePaint)
            }
        }
    }

    private fun drawClassicMinimalistIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
