#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pre-compiles 86 Wubi + Segmented Pinyin + T14 Codes + Smart Idiom/Word Associations + English Dictionary at build time.
Key upgrades in v99.4:
1. Everyday 2-Character Word Priority (日常高频2字词绝对优先):
   - Eliminates the old bug where 0-weight entries in wubi86.dict.yaml dragged down modern rime-ice weights (0.65*4200 + 0.35*py_wt).
   - Gives modern everyday 2-char words (such as 或许, 括号, 其实, 刚才, 觉得, 因为) top priority over 1990s newspaper/industrial compounds.
2. Industrial / Bureaucratic / News Jargon Demotion (专业词与新闻公文词自动降权):
   - Demotes 4-char industrial terms (机电设备, 机器设备, etc.) and 3-char news/statistical terms (采访中, 摄入量, 排放量, etc.) and rare characters (脧, etc.).
3. Prefix-Consistent Single-Char Wubi Extraction (防容错码污染单字取码):
   - Ensures zero-weight tolerance codes in wubi86.dict.yaml never overwrite standard root codes used for word compounding.
4. No 80,000 Truncation (保留全量标准五笔二字/三字词):
   - Retains up to 160,000 entries so common words are never truncated.
5. Smart Idiom & Contextual Chat Associations (智能成语补全与聊天联想):
   - Builds prefix->suffix completion for 2-char and 3-char idiom prefixes (e.g. 莫名->其妙, 迫不->及待, 一模->一样) plus contextual idiom suggestions.
"""
import math
import os
import urllib.request
from collections import defaultdict

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
RIME_ICE_8105_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/8105.dict.yaml"
RIME_ICE_BASE_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/base.dict.yaml"
RIME_ICE_ENG_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/en_dicts/en.dict.yaml"
LUNA_PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"

CHAR_TO_T14 = {
    'q': '1', 'w': '1',
    'e': '2', 'r': '2',
    't': '3', 'y': '3',
    'u': '4', 'i': '4',
    'o': '5', 'p': '5',
    'a': '6', 's': '6',
    'd': '7', 'f': '7',
    'g': '8', 'h': '8',
    'j': '9', 'k': '9',
    'l': '0',
    'z': 'a', 'x': 'a',
    'c': 'b', 'v': 'b',
    'b': 'c', 'n': 'c',
    'm': 'd'
}

LEVEL1_WUBI_MAP = {
    'g': '一', 'f': '地', 'd': '在', 's': '要', 'a': '工',
    'h': '上', 'j': '是', 'k': '中', 'l': '国', 'm': '同',
    't': '和', 'r': '的', 'e': '有', 'w': '人', 'q': '我',
    'y': '主', 'u': '产', 'i': '不', 'o': '为', 'p': '这',
    'n': '民', 'b': '了', 'v': '发', 'c': '以', 'x': '经'
}

JARGON_SUBSTRINGS = (
    "机电", "设备", "机器", "机械", "工程", "管理", "委员会", "代表大会", "有限公司",
    "社会主义", "资本主义", "帝国主义", "企事业", "研究所", "检察院", "国务院", "生产队",
    "加工厂", "流水线", "零部件", "采访中", "摄入量", "排放量", "含水量", "降雨量",
    "生产率", "积极性", "现代化", "工业化", "农业化", "自动化", "电气化", "拖拉机",
    "发电机", "电动机", "变压器", "半导体", "化合物", "混合物", "氧化物", "综合征",
    "办事处", "居委会", "党委", "支部", "总支", "团委", "妇联", "工会"
)

NEWS_3CHAR_SUFFIXES = (
    "中", "量", "率", "度", "性", "化", "器", "员", "局", "部", "委", "处", "科", "室", "厂", "矿", "队", "制", "法"
)

ARCHAIC_LOW_PRIORITY_WORDS = {
    "乃是", "腹中", "用嘴", "插嘴", "可放", "划入", "何况乎", "莫过于", "岂不是", "庶几"
}

def is_jargon_or_news_word(word):
    if word in ARCHAIC_LOW_PRIORITY_WORDS:
        return True
    for sub in JARGON_SUBSTRINGS:
        if sub in word:
            return True
    if len(word) == 3 and word.endswith(NEWS_3CHAR_SUFFIXES):
        if word not in ("为什么", "怎么办", "没问题", "差不多", "不知道", "说实话", "打工人", "显眼包", "氛围感", "松弛感", "破碎感", "高级感"):
            return True
    return False

def to_t14(s):
    return "".join(CHAR_TO_T14.get(c, "") for c in s.lower())

def to_t14_abbr(seg_py):
    if "'" not in seg_py:
        return ""
    return "".join(CHAR_TO_T14.get(p[0], "") for p in seg_py.split("'") if p)

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def clean_py_syllable(s):
    s = s.strip().lower()
    return "".join(ch for ch in s if 'a' <= ch <= 'z')

def parse_rime_yaml(lines):
    in_body = False
    for line in lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip()
            weight = -1
            stem = ""
            if len(parts) >= 3:
                w_str = parts[2].strip().rstrip("%")
                try:
                    weight = int(float(w_str))
                except ValueError:
                    weight = -1
            if len(parts) >= 4:
                stem = parts[3].strip().lower()
            yield word, code, weight, stem

def normalize_wubi_weight(word, code, raw_weight):
    if len(code) == 1 and LEVEL1_WUBI_MAP.get(code) == word:
        return 14000
    if raw_weight <= 0:
        base = 5200 if len(word) == 2 else (4800 if len(word) == 1 else 3800)
    elif raw_weight <= 12000:
        base = max(3000, min(9200, int(3000 + math.log10(max(1.0, raw_weight)) * 1550)))
    else:
        lv = math.log10(max(10.0, float(raw_weight)))
        base = int(3200 + (lv - 3.5) * 1320)
        if len(word) == 1 and len(code) <= 2:
            base += 450
    base = max(2600, min(9400, base))
    if is_jargon_or_news_word(word):
        base = max(2200, base - 2600)
    elif len(word) == 4:
        base = max(2600, base - 650)
    elif len(word) >= 5:
        base = max(2200, base - 1800)
    return base

def normalize_ice_weight(word, raw_weight):
    if raw_weight <= 0:
        base = 6400 if len(word) == 2 else (5400 if len(word) == 3 else 4800)
    else:
        lv = math.log10(max(1.0, float(raw_weight)))
        base = int(4800 + lv * 1180)
    if len(word) == 2 and not is_jargon_or_news_word(word):
        base += 650
    elif len(word) == 4:
        base -= 350
    elif len(word) >= 5:
        base -= 1400
    if is_jargon_or_news_word(word):
        base -= 2600
    return max(2400, min(9550, base))

def main():
    wubi_lines = download_lines(WUBI_URL)
    ice_8105_lines = download_lines(RIME_ICE_8105_URL)
    ice_base_lines = download_lines(RIME_ICE_BASE_URL)
    ice_eng_lines = download_lines(RIME_ICE_ENG_URL)
    luna_lines = download_lines(LUNA_PINYIN_URL)

    # 1. Compile English dictionary
    eng_words = []
    seen_eng = set()
    curated_en_path = os.path.join(ASSETS_DIR, "en_daily_words.txt")
    if os.path.exists(curated_en_path):
        with open(curated_en_path, "r", encoding="utf-8") as cf:
            for line in cf:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split("\t")
                w = parts[0].strip()
                wt = int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 85000
                if w and w not in seen_eng:
                    seen_eng.add(w)
                    seen_eng.add(w.lower())
                    eng_words.append((wt, w))

    if ice_eng_lines:
        for word, code, weight, _ in parse_rime_yaml(ice_eng_lines):
            clean_w = word.strip()
            if 2 <= len(clean_w) <= 20 and clean_w.isalpha() and clean_w.lower() not in seen_eng:
                seen_eng.add(clean_w.lower())
                eff_wt = weight if weight > 0 else max(500, 16000 - len(clean_w) * 700)
                eng_words.append((eff_wt, clean_w))

    eng_words.sort(key=lambda x: (-x[0], len(x[1]), x[1].lower()))
    if eng_words:
        eng_path = os.path.join(ASSETS_DIR, "english_words.tsv")
        with open(eng_path, "w", encoding="utf-8") as ef:
            for wt, w in eng_words[:30000]:
                ef.write(f"{w}\t{wt}\n")
        print(f"Compiled {min(len(eng_words), 30000)} English words!")

    if not wubi_lines:
        print("Offline mode: keeping starter dictionary.")
        return

    single_char_wubi = {}
    single_char_wubi_wt = {}
    single_char_py = {}
    single_char_weight = {}
    common_8105_chars = set()
    word_py_map = {}

    for word, raw_py, weight, _ in parse_rime_yaml(ice_8105_lines):
        wt = weight if weight > 0 else 10
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if len(word) == 1 and syllables:
            if wt >= 25:
                common_8105_chars.add(word)
            if word not in single_char_py or wt > single_char_weight.get(word, 0):
                single_char_py[word] = syllables[0]
                single_char_weight[word] = wt

    for word, raw_py, weight, _ in parse_rime_yaml(luna_lines):
        wt = normalize_ice_weight(word, weight)
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables:
            continue
        seg_py = "'".join(syllables)
        if len(word) == 1 and word not in single_char_py:
            single_char_py[word] = syllables[0]
        if word not in word_py_map:
            word_py_map[word] = (seg_py, wt)

    for word, raw_py, weight, _ in parse_rime_yaml(ice_base_lines):
        wt = normalize_ice_weight(word, weight)
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables or len(word) > 8:
            continue
        seg_py = "'".join(syllables)
        if word not in word_py_map or wt > word_py_map[word][1]:
            word_py_map[word] = (seg_py, wt)

    # First pass over wubi_lines: extract accurate canonical single-char Wubi codes (preventing 0-weight tolerance codes from overwriting primary codes)
    char_codes_list = defaultdict(list)
    raw_wubi_rows = []
    for word, raw_code, raw_wt, stem in parse_rime_yaml(wubi_lines):
        code = raw_code.strip().lower()
        if not word or not code or not code.isalpha():
            continue
        raw_wubi_rows.append((word, code, raw_wt, stem))
        if len(word) == 1:
            char_codes_list[word].append((code, raw_wt, stem))

    for ch, clist in char_codes_list.items():
        # Sort by raw_wt DESC first to find the true primary root prefix!
        clist_by_wt = sorted(clist, key=lambda x: (1 if x[1] > 0 else 0, x[1], len(x[0])), reverse=True)
        primary_code, primary_wt, primary_stem = clist_by_wt[0]
        best_full = primary_stem if (len(primary_stem) >= 2 and primary_stem.isalpha()) else primary_code
        # Now look for the longest code (up to 4 chars) that shares the exact same first-2-letter root prefix as best_full (or primary_code)
        prefix_to_match = best_full[:2] if len(best_full) >= 2 else primary_code[:1]
        for c_code, c_wt, c_stem in clist:
            cand = c_stem if (len(c_stem) >= 2 and c_stem.isalpha()) else c_code
            if cand.startswith(prefix_to_match) and len(cand) > len(best_full):
                best_full = cand
        single_char_wubi[ch] = best_full[:4]
        single_char_wubi_wt[ch] = primary_wt

    wubi_entries = []
    seen_pairs = set()
    for word, code, raw_wt, stem in raw_wubi_rows:
        norm_wt = normalize_wubi_weight(word, code, raw_wt)
        if len(word) == 1:
            # Demote obscure single characters not in common_8105_chars (like 脧, 齐 variant)
            if common_8105_chars and word not in common_8105_chars and LEVEL1_WUBI_MAP.get(code) != word:
                norm_wt = min(norm_wt, 3200)
            elif word in single_char_weight:
                c_wt = single_char_weight[word]
                if c_wt < 80 and LEVEL1_WUBI_MAP.get(code) != word:
                    norm_wt = min(norm_wt, 4100)
        else:
            py_info = word_py_map.get(word)
            if py_info is not None:
                py_wt = py_info[1]
                # Modern rime-ice everyday frequency takes precedence! Never drag down a common 2-char word!
                if len(word) == 2 and not is_jargon_or_news_word(word):
                    norm_wt = max(norm_wt, py_wt + 750)
                else:
                    norm_wt = max(norm_wt, py_wt)
            else:
                # Word in wubi86.dict.yaml but NOT in modern rime-ice/luna dictionary -> old newspaper/mechanical phrase!
                if not is_jargon_or_news_word(word):
                    norm_wt = min(norm_wt, 5100 if len(word) == 2 else 4300)
                else:
                    norm_wt = min(norm_wt, 3200)

        if (word, code) not in seen_pairs:
            seen_pairs.add((word, code))
            wubi_entries.append((word, code, norm_wt))

    def gen_wubi86(word):
        if len(word) == 1:
            return single_char_wubi.get(word, "")[:4]
        codes = [single_char_wubi.get(ch, "") for ch in word]
        if any(not c for c in codes):
            return ""
        if len(word) == 2:
            return codes[0][:2] + codes[1][:2]
        elif len(word) == 3:
            return codes[0][:1] + codes[1][:1] + codes[2][:2]
        else:
            return codes[0][:1] + codes[1][:1] + codes[2][:1] + codes[-1][:1]

    def gen_seg_pinyin(word):
        if word in word_py_map:
            return word_py_map[word][0]
        syls = [single_char_py.get(ch, "") for ch in word]
        if all(syls):
            return "'".join(syls)
        return ""

    # Inject curated cn_daily_phrases.txt with length-aware everyday weights:
    # - 2-char everyday words: 9,600 .. 9,920 (highest priority for 4-key typing!)
    # - 3-char everyday chat words: 8,900 .. 9,250
    # - 4-char idioms/phrases: 8,150 .. 8,550
    # - 5+ char long phrases: 6,900 .. 7,300 (never crowds out 2-char words at 4 keys!)
    curated_cn_path = os.path.join(ASSETS_DIR, "cn_daily_phrases.txt")
    curated_words_order = []
    if os.path.exists(curated_cn_path):
        with open(curated_cn_path, "r", encoding="utf-8") as cf:
            idx_2 = 0
            idx_3 = 0
            idx_4 = 0
            idx_long = 0
            for line in cf:
                w = line.strip()
                if not w or w.startswith("#"):
                    continue
                curated_words_order.append(w)
                if len(w) == 2:
                    wt = max(9550, 9920 - idx_2 // 3)
                    idx_2 += 1
                elif len(w) == 3:
                    wt = max(8850, 9250 - idx_3 // 2)
                    idx_3 += 1
                elif len(w) == 4:
                    wt = max(8100, 8550 - idx_4 // 2)
                    idx_4 += 1
                else:
                    wt = max(6800, 7300 - idx_long)
                    idx_long += 1

                seg_py = gen_seg_pinyin(w)
                if seg_py:
                    word_py_map[w] = (seg_py, wt)
                wcode = gen_wubi86(w)
                if wcode:
                    wubi_entries.append((w, wcode, wt))

    # Deduplicate (word, wcode) keeping highest weight
    best_wubi_map = {}
    for word, wcode, weight in wubi_entries:
        key = (word, wcode)
        if key not in best_wubi_map or weight > best_wubi_map[key]:
            best_wubi_map[key] = weight

    compiled_rows = []
    seen_words_for_py = set()
    for (word, wcode), weight in best_wubi_map.items():
        seg_py = gen_seg_pinyin(word)
        seen_words_for_py.add(word)
        compiled_rows.append((word, wcode, seg_py, weight))

    # Add modern rime-ice words that weren't in wubi86.dict.yaml (strongly prioritizing 2-char and 3-char everyday words & 4-char idioms)
    extra_py_candidates = []
    for word, (seg_py, weight) in word_py_map.items():
        if word not in seen_words_for_py and 1 <= len(word) <= 6:
            # Boost 2-char words in selection priority so all common modern 2-char words are included
            sort_score = weight + (1200 if len(word) == 2 else (400 if len(word) == 3 else 0))
            extra_py_candidates.append((sort_score, weight, word, seg_py))
    extra_py_candidates.sort(reverse=True)

    for _, weight, word, seg_py in extra_py_candidates[:55000]:
        wcode = gen_wubi86(word)
        if wcode or seg_py:
            compiled_rows.append((word, wcode, seg_py, weight))
            seen_words_for_py.add(word)

    compiled_rows.sort(key=lambda x: (
        x[3],
        1 if len(x[0]) == 2 else (0 if len(x[0]) <= 3 else -1)
    ), reverse=True)
    compiled_rows = compiled_rows[:160000]

    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, seg_py, weight in compiled_rows:
            t14_w = to_t14(wcode) if wcode else ""
            t14_p = to_t14(seg_py.replace("'", "")) if seg_py else ""
            t14_a = to_t14_abbr(seg_py)
            f.write(f"{word}\t{wcode}\t{seg_py}\t{t14_w}\t{t14_p}\t{t14_a}\t{weight}\n")

    # Build Smart Idiom Completion & Contextual Chat Associations
    assoc_map = defaultdict(list)

    def add_assoc(prefix, suffix, max_len=22):
        if not prefix or not suffix or prefix == suffix:
            return
        lst = assoc_map[prefix]
        if len(lst) < max_len and suffix not in lst:
            lst.append(suffix)

    # 1. Contextual trigger words -> idioms & natural chat follow-ups
    contextual_triggers = {
        "真是": ["哭笑不得", "莫名其妙", "绝了", "服了", "太好了", "心疼", "无语了", "让人头秃"],
        "简直": ["匪夷所思", "难以置信", "一模一样", "太绝了", "完美", "不要太爽", "神了"],
        "令人": ["哭笑不得", "匪夷所思", "难以置信", "头秃", "心旷神怡", "赏心悦目", "佩服"],
        "让人": ["哭笑不得", "心疼", "捉摸不透", "眼前一亮", "欲罢不能", "爱不释手"],
        "觉得": ["莫名其妙", "不可思议", "挺好的", "没必要", "可以", "很舒服", "很有意思"],
        "感觉": ["莫名其妙", "精疲力尽", "身体被掏空", "挺好的", "还可以", "怪怪的"],
        "完全": ["不知所措", "没问题", "绷不住了", "没想到", "一模一样", "不在乎", "可以"],
        "果然": ["名不虚传", "不出所料", "一语成谶", "是这样", "还得是你"],
        "依然": ["我行我素", "恋恋不舍", "念念不忘", "清晰可见"],
        "实在": ["无可奈何", "哭笑不得", "太难了", "不好意思", "受不了", "不知道"],
        "特别": ["喜欢", "好看", "舒服", "开心", "赏心悦目", "爱不释手", "贴心"],
        "非常": ["感谢", "喜欢", "满意", "抱歉", "开心", "完美", "顺利"],
        "祝你": ["心想事成", "万事如意", "一帆风顺", "天天开心", "生日快乐", "好运连连"],
        "希望": ["一切顺利", "得偿所愿", "心想事成", "越来越好", "你能喜欢"],
        "老婆": ["最棒", "辛苦啦", "贴贴", "抱抱", "爱你", "么么哒", "早点休息"],
        "老公": ["最棒", "辛苦啦", "太棒了", "抱抱", "贴贴", "爱你"]
    }
    for trig, sufs in contextual_triggers.items():
        for s in sufs:
            add_assoc(trig, s)

    # 2. High-priority 4-char Idiom completion (2-char prefix -> 2-char suffix, 3-char prefix -> 1-char suffix)
    for w in curated_words_order:
        if len(w) == 4:
            add_assoc(w[:2], w[2:])
            add_assoc(w[:3], w[3:])
            add_assoc(w[:1], w[1:])

    for word, _, _, weight in compiled_rows:
        if len(word) == 4 and weight >= 7200 and not is_jargon_or_news_word(word):
            add_assoc(word[:2], word[2:])
            add_assoc(word[:3], word[3:])

    # 3. Everyday 2-char & 3-char word completions (excluding jargon/news suffixes)
    for word, _, _, weight in compiled_rows:
        if is_jargon_or_news_word(word):
            continue
        if len(word) == 2 and weight >= 7600:
            add_assoc(word[0], word[1:])
        elif len(word) == 3 and weight >= 7800:
            add_assoc(word[:2], word[2:])
            add_assoc(word[0], word[1:])

    assoc_path = os.path.join(ASSETS_DIR, "assoc_dict.tsv")
    with open(assoc_path, "w", encoding="utf-8") as f:
        for prefix, suffixes in assoc_map.items():
            if suffixes:
                f.write(f"{prefix}\t{','.join(suffixes)}\n")

    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    with open(single_path, "w", encoding="utf-8") as f:
        all_chars = set(single_char_wubi.keys()) | set(single_char_py.keys())
        for ch in sorted(all_chars):
            wcode = single_char_wubi.get(ch, "")
            py = single_char_py.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    print(f"Pre-compiled {len(compiled_rows)} entries and {len(assoc_map)} association prefixes!")

if __name__ == "__main__":
    main()
