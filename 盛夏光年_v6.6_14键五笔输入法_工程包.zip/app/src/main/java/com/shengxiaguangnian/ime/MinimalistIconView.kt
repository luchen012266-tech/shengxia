package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 1:1 复刻视频 1 (1000127927.mp4) 的全键盘跨键柔光聚光灯背光层：
 * - 覆盖整个键盘区（不拦截任何触摸事件），彻底打破单个按键边框限制！
 * - 当按下任意按键时，以该按键为中心绽放一团半径达 112dp（横跨周围邻键与按键缝隙）的暖金琥珀流光光球，
 *   松手后前 150ms 保持满亮度（确保手指移开瞬间肉眼清晰可见），随后在 680ms 内如呼吸灯般柔和消散；
 *   连续打字时，键盘上会同时浮现多团温暖交织的流光余晖！
 */
class KeyboardBacklightOverlayView(context: Context) : View(context) {

    private class SpotlightOrb(
        val sourceView: View,
        val cx: Float,
        val cy: Float,
        val keyRect: RectF,
        val cornerRadius: Float,
        val glowColor: Int,
        var releaseTime: Long = 0L
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val keyRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    fun triggerKeyDown(keyView: View, cornerRadius: Float, glowColor: Int) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + keyView.width
        val bottom = top + keyView.height
        val cx = (left + right) * 0.5f
        val cy = (top + bottom) * 0.5f

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(
            SpotlightOrb(
                sourceView = keyView,
                cx = cx,
                cy = cy,
                keyRect = RectF(left, top, right, bottom),
                cornerRadius = cornerRadius,
                glowColor = glowColor,
                releaseTime = 0L
            )
        )
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val holdMs = 150f
        val fadeMs = 660f
        val totalMs = holdMs + fadeMs
        val spotRadius = dpF(112f)

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    // 松手后前 150ms 保持 92%~100% 满亮度，手指移开后清晰可见！
                    1.0f - 0.08f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.92f * (1f - t) * (1f - t)
                }
            }

            val rCol = Color.red(orb.glowColor)
            val gCol = Color.green(orb.glowColor)
            val bCol = Color.blue(orb.glowColor)

            // 1. 绘制视频 1 同款大范围跨键暖金琥珀流光光球（半径 112dp，照亮按键缝隙并晕染邻键边缘！）
            val aCore = (180 * progress).toInt().coerceIn(0, 255)
            val aMid1 = (165 * progress).toInt().coerceIn(0, 255)
            val aMid2 = (105 * progress).toInt().coerceIn(0, 255)
            val aEdge = (42 * progress).toInt().coerceIn(0, 255)

            orbPaint.shader = RadialGradient(
                orb.cx,
                orb.cy,
                spotRadius,
                intArrayOf(
                    Color.argb(aCore, 255, 248, 220),
                    Color.argb(aMid1, rCol, gCol, bCol),
                    Color.argb(aMid2, rCol, gCol, bCol),
                    Color.argb(aEdge, rCol, gCol, bCol),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.25f, 0.52f, 0.78f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(orb.cx, orb.cy, spotRadius, orbPaint)

            // 2. 在被按下的键帽四周缝隙勾勒温暖明亮的羽化背光光环
            val haloLayers = listOf(
                Triple(dpF(5.0f), dpF(4.2f), 90),
                Triple(dpF(2.8f), dpF(3.0f), 155),
                Triple(dpF(1.0f), dpF(2.0f), 220)
            )
            for ((outDist, strokeW, baseAlpha) in haloLayers) {
                keyRimPaint.strokeWidth = strokeW
                val mr = ((rCol + 255) / 2).coerceIn(0, 255)
                val mg = ((gCol + 250) / 2).coerceIn(0, 255)
                val mb = ((bCol + 225) / 2).coerceIn(0, 255)
                keyRimPaint.color = Color.argb((baseAlpha * progress).toInt().coerceIn(0, 255), mr, mg, mb)
                tmpRectF.set(
                    orb.keyRect.left - outDist,
                    orb.keyRect.top - outDist,
                    orb.keyRect.right + outDist,
                    orb.keyRect.bottom + outDist
                )
                canvas.drawRoundRect(tmpRectF, orb.cornerRadius + outDist, orb.cornerRadius + outDist, keyRimPaint)
            }
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#FFB03B"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (enableGlow) {
                    val overlay = findBacklightOverlay()
                    if (value) {
                        overlay?.triggerKeyDown(this, cornerRadiusPx, glowColor)
                    } else {
                        overlay?.triggerKeyUp(this)
                    }
                }
                invalidate()
            }
        }

    private fun findBacklightOverlay(): KeyboardBacklightOverlayView? {
        var p = parent
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    return child
                }
            }
            p = p.parent
        }
        return null
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (fallbackBgTop != Color.TRANSPARENT) {
            fallbackFillPaint.color = fallbackBgTop
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        if (bitmap != null) {
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        }
        canvas.restoreToCount(saveCount)
    }
}

/**
 * 顶部状态栏 4 图标视图：
 * - 当 useBotanicalStyle = true 时，直接渲染高清水彩晕染的「小莲花、双生睡莲花苞、缺口浮叶、双叶托莲水波」4 枚纯植物图标（彻底告别搞笑圆脸！）
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = true
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (useBotanicalStyle) {
            val bmp = MonetTextureManager.getTopIconBitmap(context, iconType)
            if (bmp != null) {
                val pad = minOf(w, h) * 0.04f
                dstRectF.set(pad, pad, w - pad, h - pad)
                srcRect.set(0, 0, bmp.width, bmp.height)
                canvas.drawBitmap(bmp, srcRect, dstRectF, bmpPaint)
                return
            }
        }

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.36f
        drawClassicMinimalistIcon(canvas, cx, cy, r)
    }

    private fun drawClassicMinimalistIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
