package com.shengxiaguangnian.ime

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ClipItem(
    val id: Long,
    val content: String,
    val isPinned: Boolean,
    val timestamp: Long
)

data class PhraseItem(
    val id: Long,
    val category: String,
    val content: String,
    val isStarred: Boolean,
    val lastUsed: Long
)

class ImeDatabaseHelper(context: Context) : SQLiteOpenHelper(context, "shengxia_ime.db", null, 1) {

    companion object {
        const val MAX_CLIPBOARD_ITEMS = 300
        val DEFAULT_CATEGORIES = listOf("收藏", "最近", "邮", "号", "叮", "演", "扮", "模块", "api")
    }

    override fun onCreate(db: SQLiteDatabase) {
        // 1. 剪贴板表：TEXT 类型无字数上限（支持万字以上长文），自动保留 300 条
        db.execSQL("""
            CREATE TABLE clipboard_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL UNIQUE ON CONFLICT REPLACE,
                is_pinned INTEGER DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())

        // 2. 常用语分类标签表
        db.execSQL("""
            CREATE TABLE phrase_categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                sort_order INTEGER NOT NULL
            )
        """.trimIndent())

        // 3. 常用语内容表（无字数上限）
        db.execSQL("""
            CREATE TABLE phrases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                content TEXT NOT NULL,
                is_starred INTEGER DEFAULT 0,
                last_used INTEGER DEFAULT 0
            )
        """.trimIndent())

        // 4. 用户自定义/导入的五笔词库表（流行歌、动画、名人、自造词）
        db.execSQL("""
            CREATE TABLE user_dict (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                word TEXT NOT NULL,
                wubi_code TEXT NOT NULL,
                pinyin_code TEXT NOT NULL,
                t14_wubi TEXT NOT NULL,
                t14_pinyin TEXT NOT NULL,
                weight INTEGER DEFAULT 5000
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_user_t14_wubi ON user_dict(t14_wubi)")
        db.execSQL("CREATE INDEX idx_user_t14_pinyin ON user_dict(t14_pinyin)")

        // 5. 用户自定义颜文字表
        db.execSQL("""
            CREATE TABLE custom_kaomoji (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                text TEXT NOT NULL UNIQUE
            )
        """.trimIndent())

        // 初始化预设分类标签：收藏、最近、邮、号、叮、演、扮、模块、api
        DEFAULT_CATEGORIES.forEachIndexed { idx, name ->
            val cv = ContentValues().apply {
                put("name", name)
                put("sort_order", idx)
            }
            db.insert("phrase_categories", null, cv)
        }

        // 预置示例常用语卡片（可在输入法内随时编辑或删除）
        val samplePhrases = listOf(
            Triple("演", "### 角色扮演规则指令：《盛夏光年》 **【核心世界观】** 这是一个支持无限字数、零截断的专属常用语模板，点击卡片直接全文上屏，点击右侧箭头可展开或编辑。", 1),
            Triple("模块", "【模块指令模板】可在此分类下存放常用的系统提示词模块与世界观插件，不限字数。", 1),
            Triple("api", "【API 快捷配置】可在此处存放常用的接口地址、模型名称或参数片段。", 0)
        )
        samplePhrases.forEach { (cat, text, starred) ->
            val cv = ContentValues().apply {
                put("category", cat)
                put("content", text)
                put("is_starred", starred)
                put("last_used", System.currentTimeMillis())
            }
            db.insert("phrases", null, cv)
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // --- 剪贴板操作 (无字数上限 + 保留 300 条) ---
    fun addClip(text: String) {
        if (text.isBlank()) return
        val db = writableDatabase
        // 若此前已存在且被置顶，保留置顶状态
        var pinned = 0
        db.rawQuery("SELECT is_pinned FROM clipboard_history WHERE content = ?", arrayOf(text)).use { c ->
            if (c.moveToFirst()) pinned = c.getInt(0)
        }
        val cv = ContentValues().apply {
            put("content", text)
            put("is_pinned", pinned)
            put("created_at", System.currentTimeMillis())
        }
        db.insertWithOnConflict("clipboard_history", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

        // 清理超出 300 条的非置顶旧记录
        db.execSQL("""
            DELETE FROM clipboard_history
            WHERE is_pinned = 0 AND id NOT IN (
                SELECT id FROM clipboard_history
                ORDER BY is_pinned DESC, created_at DESC
                LIMIT $MAX_CLIPBOARD_ITEMS
            )
        """.trimIndent())
    }

    fun getClips(): List<ClipItem> {
        val list = mutableListOf<ClipItem>()
        readableDatabase.rawQuery(
            "SELECT id, content, is_pinned, created_at FROM clipboard_history ORDER BY is_pinned DESC, created_at DESC LIMIT $MAX_CLIPBOARD_ITEMS",
            null
        ).use { c ->
            while (c.moveToNext()) {
                list.add(ClipItem(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getLong(3)))
            }
        }
        return list
    }

    fun toggleClipPin(id: Long, currentPinned: Boolean) {
        val cv = ContentValues().apply { put("is_pinned", if (currentPinned) 0 else 1) }
        writableDatabase.update("clipboard_history", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deleteClip(id: Long) {
        writableDatabase.delete("clipboard_history", "id = ?", arrayOf(id.toString()))
    }

    fun clearUnpinnedClips() {
        writableDatabase.delete("clipboard_history", "is_pinned = 0", null)
    }

    // --- 常用语与分类标签操作 ---
    fun getCategories(): List<String> {
        val list = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT name FROM phrase_categories ORDER BY sort_order ASC, id ASC", null).use { c ->
            while (c.moveToNext()) list.add(c.getString(0))
        }
        if (!list.contains("收藏")) list.add(0, "收藏")
        if (!list.contains("最近")) list.add(1, "最近")
        return list.distinct()
    }

    fun addCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) return
        val cv = ContentValues().apply {
            put("name", trimmed)
            put("sort_order", 99)
        }
        writableDatabase.insertWithOnConflict("phrase_categories", null, cv, SQLiteDatabase.CONFLICT_IGNORE)
    }

    fun deleteCategory(name: String) {
        if (name == "收藏" || name == "最近") return
        writableDatabase.delete("phrase_categories", "name = ?", arrayOf(name))
        writableDatabase.delete("phrases", "category = ?", arrayOf(name))
    }

    fun getPhrasesByCategory(category: String): List<PhraseItem> {
        val list = mutableListOf<PhraseItem>()
        val query = when (category) {
            "收藏" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE is_starred = 1 ORDER BY id DESC"
            "最近" -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE last_used > 0 ORDER BY last_used DESC LIMIT 50"
            else -> "SELECT id, category, content, is_starred, last_used FROM phrases WHERE category = ? ORDER BY is_starred DESC, id DESC"
        }
        val args = if (category == "收藏" || category == "最近") null else arrayOf(category)
        readableDatabase.rawQuery(query, args).use { c ->
            while (c.moveToNext()) {
                list.add(PhraseItem(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4)))
            }
        }
        return list
    }

    fun addOrUpdatePhrase(id: Long?, category: String, content: String, isStarred: Boolean) {
        if (content.isBlank()) return
        val targetCat = if (category == "收藏" || category == "最近") "演" else category
        val cv = ContentValues().apply {
            put("category", targetCat)
            put("content", content)
            put("is_starred", if (isStarred || category == "收藏") 1 else 0)
            put("last_used", System.currentTimeMillis())
        }
        if (id == null || id <= 0L) {
            writableDatabase.insert("phrases", null, cv)
        } else {
            writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
        }
    }

    fun togglePhraseStar(id: Long, currentStarred: Boolean) {
        val cv = ContentValues().apply { put("is_starred", if (currentStarred) 0 else 1) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun markPhraseUsed(id: Long) {
        val cv = ContentValues().apply { put("last_used", System.currentTimeMillis()) }
        writableDatabase.update("phrases", cv, "id = ?", arrayOf(id.toString()))
    }

    fun deletePhrase(id: Long) {
        writableDatabase.delete("phrases", "id = ?", arrayOf(id.toString()))
    }

    // --- 用户自定义/外部导入词库 ---
    fun insertUserWord(word: String, wubiCode: String, pinyinCode: String, weight: Int = 6000) {
        val t14Wubi = T14WubiEngine.letterToT14Code(wubiCode)
        val t14Pinyin = T14WubiEngine.letterToT14Code(pinyinCode)
        val cv = ContentValues().apply {
            put("word", word)
            put("wubi_code", wubiCode)
            put("pinyin_code", pinyinCode)
            put("t14_wubi", t14Wubi)
            put("t14_pinyin", t14Pinyin)
            put("weight", weight)
        }
        writableDatabase.insert("user_dict", null, cv)
    }
}
