package com.shengxiaguangnian.ime

import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.abs

class ShengXiaImeService : InputMethodService() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private lateinit var clipboardManager: ClipboardManager

    private val composingT14 = StringBuilder()
    private val composingRawLetters = StringBuilder()
    private var currentCandidates: List<Candidate> = emptyList()

    private var isEnglishMode = false
    private var isShiftLocked = false
    private var isNumberPadMode = false

    private enum class PanelState { KEYBOARD, CLIPBOARD_PHRASE, EMOJI_KAOMOJI, SYMBOLS }
    private var currentPanel = PanelState.KEYBOARD

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainVerticalLayout: LinearLayout
    private lateinit var topIdleBar: LinearLayout
    private lateinit var topCandidateBar: LinearLayout
    private lateinit var composingTextView: TextView
    private lateinit var candidateScrollContainer: LinearLayout
    private lateinit var bodyFrame: FrameLayout

    private var popupWindow: PopupWindow? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
            if (text.isNotBlank()) {
                dbHelper.addClip(text)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        dbHelper = ImeDatabaseHelper(this)
        Thread { T14WubiEngine.ensureInitialized(this, dbHelper) }.start()
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            clipboardManager.removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {}
    }

    override fun onCreateInputView(): View {
        T14WubiEngine.ensureInitialized(this, dbHelper)
        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#E6E7EB"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        mainVerticalLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(10))
        }

        buildTopBar()
        bodyFrame = FrameLayout(this)
        mainVerticalLayout.addView(bodyFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(236)
        ))

        rootContainer.addView(mainVerticalLayout)
        showKeyboardPanel()
        return rootContainer
    }

    override fun onWindowShown() {
        super.onWindowShown()
        T14WubiEngine.ReloadIfNeeded(dbHelper)
    }

    private fun T14WubiEngine.ReloadIfNeeded(db: ImeDatabaseHelper) {
        reloadUserDict(db)
    }

    // ==================== 顶栏（工具栏 + 候选词栏） ====================
    private fun buildTopBar() {
        val topWrapper = FrameLayout(this).apply {
            background = roundRect("#F3F4F6", dp(14))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }

        // 1. 未打字时的极简 4 图标顶栏：⚙️ 设置/词库 | 😎 Emoji/颜文字 | 📋 剪贴板/常用语 | ↘ 收起
        topIdleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
        }

        fun makeTopIcon(symbol: String, desc: String, onClick: () -> Unit): TextView {
            return TextView(this).apply {
                text = "$symbol $desc"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(Color.parseColor("#44474E"))
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { onClick() }
            }
        }

        topIdleBar.addView(makeTopIcon("⚙️", "词库/设置") {
            val intent = Intent(this, SettingsActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        })
        topIdleBar.addView(makeTopIcon("😎", "表情/颜文字") {
            if (currentPanel == PanelState.EMOJI_KAOMOJI) showKeyboardPanel() else showEmojiKaomojiPanel()
        })
        topIdleBar.addView(makeTopIcon("📋", "剪贴/常用语") {
            if (currentPanel == PanelState.CLIPBOARD_PHRASE) showKeyboardPanel() else showClipboardPhrasePanel()
        })
        topIdleBar.addView(makeTopIcon("↘", "收起") {
            requestHideSelf(0)
        })

        // 2. 打字时的候选词栏
        topCandidateBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(10), 0, dp(8), 0)
        }

        composingTextView = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTextColor(Color.parseColor("#E53935"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, dp(8), 0)
        }
        topCandidateBar.addView(composingTextView)

        val hScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }
        candidateScrollContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        hScroll.addView(candidateScrollContainer)
        topCandidateBar.addView(hScroll)

        val clearBtn = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(dp(10), 0, dp(6), 0)
            setOnClickListener { clearComposing() }
        }
        topCandidateBar.addView(clearBtn)

        topWrapper.addView(topIdleBar)
        topWrapper.addView(topCandidateBar)
        mainVerticalLayout.addView(topWrapper)
    }

    // ==================== 主键盘面板（1:1 复刻截图 1 的 14 键黑白极简布局） ====================
    private fun showKeyboardPanel() {
        currentPanel = PanelState.KEYBOARD
        bodyFrame.removeAllViews()

        if (isNumberPadMode) {
            bodyFrame.addView(buildNumberPadView())
            return
        }

        val kbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 第一行：QW(1), ER(2), TY(3), UI(4), OP(5)
        val row1 = makeRow()
        row1.addView(makeDualKey("Q", "W", "1", "1"))
        row1.addView(makeDualKey("E", "R", "2", "2"))
        row1.addView(makeDualKey("T", "Y", "3", "3"))
        row1.addView(makeDualKey("U", "I", "4", "4"))
        row1.addView(makeDualKey("O", "P", "5", "5"))
        kbLayout.addView(row1)

        // 第二行：AS(6), DF(7), GH(8), JK(9), L(0)
        val row2 = makeRow()
        row2.addView(makeDualKey("A", "S", "6", "6"))
        row2.addView(makeDualKey("D", "F", "7", "7"))
        row2.addView(makeDualKey("G", "H", "8", "8"))
        row2.addView(makeDualKey("J", "K", "9", "9"))
        row2.addView(makeDualKey("L", "", "0", "0"))
        kbLayout.addView(row2)

        // 第三行：Shift(▲), ZX(!), CV(:), BN(;), M(?), 退格(⌫)
        val row3 = makeRow()
        row3.addView(makeFuncKey(if (isShiftLocked) "▲" else "△", weight = 0.85f) {
            isShiftLocked = !isShiftLocked
            showKeyboardPanel()
        })
        row3.addView(makeDualKey("Z", "X", "!", "a"))
        row3.addView(makeDualKey("C", "V", ":", "b"))
        row3.addView(makeDualKey("B", "N", ";", "c"))
        row3.addView(makeDualKey("M", "", "?", "d"))
        row3.addView(makeBackspaceKey(weight = 0.95f))
        kbLayout.addView(row3)

        // 第四行：符号 | 123 | ， | 空格 | 。 | 中/英 | 盛夏光年(回车)
        val row4 = makeRow()
        row4.addView(makeFuncKey("符", weight = 0.85f) { showSymbolsPanel() })
        row4.addView(makeFuncKey("123\nNumber", smallText = true, weight = 0.9f) {
            isNumberPadMode = true
            showKeyboardPanel()
        })
        row4.addView(makeFuncKey("，", weight = 0.65f) { commitOrSelectFirst("，") })
        row4.addView(makeSpaceKey(weight = 1.9f))
        row4.addView(makeFuncKey("。", weight = 0.65f) { commitOrSelectFirst("。") })
        val modeLabel = if (isEnglishMode) "英/中" else "中/英"
        row4.addView(makeFuncKey(modeLabel, weight = 0.85f) {
            clearComposing()
            isEnglishMode = !isEnglishMode
            showKeyboardPanel()
        })
        row4.addView(makeFuncKey("盛夏\n光年", smallText = false, weight = 1.0f, bgColor = "#F9FAFB") {
            handleEnterKey()
        })
        kbLayout.addView(row4)

        bodyFrame.addView(kbLayout)
    }

    private fun makeRow(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
    }

    /**
     * 构建 14 键双字母按键：
     * - 轻点：送入 14 键五笔+拼音混输编码（无需手选字母）
     * - 长按（>180ms）并左右滑动：弹出图 2 同款 "D  F  7  d  f" 五合一气泡，松手直接上屏
     */
    private fun makeDualKey(leftUpper: String, rightUpper: String, topHint: String, t14Code: String): View {
        val container = FrameLayout(this).apply {
            background = roundRect("#FFFFFF", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
            elevation = dp(1).toFloat()
        }

        // 右上角小数字/符号提示 (1-9, 0, !, :, ;, ?)
        val hintTv = TextView(this).apply {
            text = topHint
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            setTextColor(Color.parseColor("#C4C7CE"))
            gravity = Gravity.END or Gravity.TOP
            setPadding(0, dp(3), dp(6), 0)
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        // 中央主字母标签（如 "Q W" 或 "D F" 或 "L"）
        val mainLabel = if (rightUpper.isEmpty()) {
            if (isEnglishMode && !isShiftLocked) leftUpper.lowercase() else leftUpper
        } else {
            if (isEnglishMode && !isShiftLocked) "${leftUpper.lowercase()} ${rightUpper.lowercase()}" else "$leftUpper $rightUpper"
        }
        val mainTv = TextView(this).apply {
            text = mainLabel
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTextColor(Color.parseColor("#222428"))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        // 构造长按五选一气泡选项列表：如 ["D", "F", "7", "d", "f"] 或 ["L", "0", "l"]
        val popupOptions = if (rightUpper.isNotEmpty()) {
            listOf(leftUpper, rightUpper, topHint, leftUpper.lowercase(), rightUpper.lowercase())
        } else {
            listOf(leftUpper, topHint, leftUpper.lowercase())
        }
        val defaultIdx = popupOptions.size / 2 // 默认高亮正中间的数字/符号（如 "7"）

        var isLongPressActive = false
        var selectedIdx = defaultIdx
        var downX = 0f
        val optionViews = mutableListOf<TextView>()

        val longPressRunnable = Runnable {
            isLongPressActive = true
            optionViews.clear()
            selectedIdx = defaultIdx
            showFiveChoicePopup(container, popupOptions, defaultIdx, optionViews)
        }

        container.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    isLongPressActive = false
                    v.background = roundRect("#ECEEF2", dp(12))
                    mainHandler.postDelayed(longPressRunnable, 190L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isLongPressActive && optionViews.isNotEmpty()) {
                        val deltaX = event.rawX - downX
                        val stepPx = dp(32).toFloat()
                        val offsetSteps = (deltaX / stepPx).toInt()
                        val newIdx = (defaultIdx + offsetSteps).coerceIn(0, popupOptions.lastIndex)
                        if (newIdx != selectedIdx) {
                            selectedIdx = newIdx
                            updatePopupHighlight(optionViews, selectedIdx)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    v.background = roundRect("#FFFFFF", dp(12))
                    if (isLongPressActive) {
                        dismissPopup()
                        if (event.actionMasked == MotionEvent.ACTION_UP) {
                            val chosen = popupOptions[selectedIdx]
                            commitDirectString(chosen)
                        }
                        isLongPressActive = false
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        // 轻点逻辑：
                        if (isEnglishMode) {
                            // 英文模式下：点左半侧输出左字母，点右半侧输出右字母
                            val isRightHalf = rightUpper.isNotEmpty() && event.x > v.width / 2f
                            val ch = if (isRightHalf) rightUpper else leftUpper
                            commitDirectString(if (isShiftLocked) ch else ch.lowercase())
                        } else {
                            // 中文 14 键五笔+拼音混输模式：直接追加 14 键编码，自动匹配！
                            appendT14Input(t14Code, leftUpper.lowercase())
                        }
                    }
                    true
                }
                else -> false
            }
        }

        return container
    }

    /**
     * 弹出图 2 同款的 "D  F  7  d  f" 横向滑动气泡
     */
    private fun showFiveChoicePopup(
        anchor: View,
        options: List<String>,
        activeIndex: Int,
        outViews: MutableList<TextView>
    ) {
        dismissPopup()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = roundRect("#FFFFFF", dp(12), strokeColor = "#DCDFE6", strokeWidth = dp(1))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            elevation = dp(8).toFloat()
        }

        options.forEachIndexed { idx, label ->
            val tv = TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(42))
            }
            outViews.add(tv)
            row.addView(tv)
        }
        updatePopupHighlight(outViews, activeIndex)

        popupWindow = PopupWindow(
            row,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            false
        ).apply {
            isClippingEnabled = false
            val loc = IntArray(2)
            anchor.getLocationInWindow(loc)
            val popupWidth = dp(36 * options.size + 16)
            val xOff = (anchor.width - popupWidth) / 2
            val yOff = -anchor.height - dp(52)
            showAsDropDown(anchor, xOff, yOff)
        }
    }

    private fun updatePopupHighlight(views: List<TextView>, activeIdx: Int) {
        views.forEachIndexed { idx, tv ->
            if (idx == activeIdx) {
                tv.background = roundRect("#FDE7EA", dp(8))
                tv.setTextColor(Color.parseColor("#E53935"))
                tv.typeface = Typeface.DEFAULT_BOLD
            } else {
                tv.background = null
                tv.setTextColor(Color.parseColor("#222428"))
                tv.typeface = Typeface.DEFAULT
            }
        }
    }

    private fun dismissPopup() {
        try {
            popupWindow?.dismiss()
        } catch (_: Exception) {}
        popupWindow = null
    }

    private fun makeFuncKey(
        label: String,
        smallText: Boolean = false,
        weight: Float = 1f,
        bgColor: String = "#F5F6F8",
        onClick: () -> Unit
    ): View {
        return TextView(this).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (smallText) 11f else 14f)
            setTextColor(Color.parseColor("#33363C"))
            gravity = Gravity.CENTER
            background = roundRect(bgColor, dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun makeBackspaceKey(weight: Float): View {
        val tv = TextView(this).apply {
            text = "⌫"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            setTextColor(Color.parseColor("#222428"))
            gravity = Gravity.CENTER
            background = roundRect("#ECEEF2", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
        }
        val repeatDelete = object : Runnable {
            override fun run() {
                handleBackspace()
                mainHandler.postDelayed(this, 65L)
            }
        }
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    handleBackspace()
                    mainHandler.postDelayed(repeatDelete, 350L)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(repeatDelete)
                    true
                }
                else -> false
            }
        }
        return tv
    }

    private fun makeSpaceKey(weight: Float): View {
        val tv = TextView(this).apply {
            text = "空格"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#33363C"))
            gravity = Gravity.CENTER
            background = roundRect("#FFFFFF", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
        }
        var startX = 0f
        var movedCursor = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = ev.rawX
                    movedCursor = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - startX
                    if (abs(dx) > dp(18)) {
                        val keyCode = if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
                        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
                        startX = ev.rawX
                        movedCursor = true
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!movedCursor) {
                        if (composingT14.isNotEmpty()) {
                            // 正在打字时按空格：首选词直接上屏
                            val first = currentCandidates.firstOrNull()?.word ?: composingRawLetters.toString()
                            commitCandidate(first)
                        } else {
                            currentInputConnection?.commitText(" ", 1)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        return tv
    }

    // ==================== 14 键编码输入与候选词刷新 ====================
    private fun appendT14Input(t14Key: String, displayHint: String) {
        composingT14.append(t14Key)
        composingRawLetters.append(displayHint)
        refreshCandidates()
    }

    private fun refreshCandidates() {
        if (composingT14.isEmpty()) {
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
            candidateScrollContainer.removeAllViews()
            currentCandidates = emptyList()
            return
        }

        topIdleBar.visibility = View.GONE
        topCandidateBar.visibility = View.VISIBLE
        composingTextView.text = composingRawLetters.toString()

        currentCandidates = T14WubiEngine.queryCandidates(composingT14.toString(), 60)
        candidateScrollContainer.removeAllViews()

        currentCandidates.forEachIndexed { index, cand ->
            val itemTv = TextView(this).apply {
                val label = if (!cand.isWubiMatch && !cand.wubiHint.isNullOrEmpty()) {
                    "${cand.word}(${cand.wubiHint})"
                } else {
                    cand.word
                }
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setTextColor(if (index == 0) Color.parseColor("#1A1C1E") else Color.parseColor("#44474E"))
                typeface = if (index == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener {
                    commitCandidate(cand.word)
                }
            }
            candidateScrollContainer.addView(itemTv)
        }
    }

    private fun commitCandidate(word: String) {
        currentInputConnection?.commitText(word, 1)
        clearComposing()
    }

    private fun commitDirectString(str: String) {
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        currentInputConnection?.commitText(str, 1)
    }

    private fun commitOrSelectFirst(punct: String) {
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        currentInputConnection?.commitText(punct, 1)
    }

    private fun clearComposing() {
        composingT14.clear()
        composingRawLetters.clear()
        refreshCandidates()
    }

    private fun handleBackspace() {
        if (composingT14.isNotEmpty()) {
            composingT14.deleteCharAt(composingT14.length - 1)
            if (composingRawLetters.isNotEmpty()) {
                composingRawLetters.deleteCharAt(composingRawLetters.length - 1)
            }
            refreshCandidates()
        } else {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
    }

    private fun handleEnterKey() {
        if (composingT14.isNotEmpty()) {
            // 有编码时回车直接上屏首选词
            val first = currentCandidates.firstOrNull()?.word ?: composingRawLetters.toString()
            commitCandidate(first)
            return
        }
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        if (editorInfo != null && (editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            val action = editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_MASK_ACTION
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_NONE &&
                action != android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        ic.commitText("\n", 1)
    }

    // ==================== 剪贴板(300条无上限) + 多分类常用语面板（1:1 复刻图 3） ====================
    private var isPhraseSubTab = true
    private var currentPhraseCategory = "收藏"

    private fun showClipboardPhrasePanel() {
        currentPanel = PanelState.CLIPBOARD_PHRASE
        bodyFrame.removeAllViews()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect("#F7F8FA", dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 顶部切换栏：< 返回 | 剪贴板 | 常用语 | ＋新建/管理（彻底砍掉“推荐”和“更多语录”）
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#EAECEF"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#333333"))
            setPadding(dp(10), dp(6), dp(12), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        val clipTabBtn = TextView(this).apply {
            text = "剪贴板"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (!isPhraseSubTab) Color.parseColor("#E53935") else Color.parseColor("#555555"))
            typeface = if (!isPhraseSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            background = if (!isPhraseSubTab) roundRect("#FFFFFF", dp(8)) else null
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isPhraseSubTab = false
                showClipboardPhrasePanel()
            }
        }
        header.addView(clipTabBtn)

        val phraseTabBtn = TextView(this).apply {
            text = "常用语"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (isPhraseSubTab) Color.parseColor("#E53935") else Color.parseColor("#555555"))
            typeface = if (isPhraseSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            background = if (isPhraseSubTab) roundRect("#FFFFFF", dp(8)) else null
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isPhraseSubTab = true
                showClipboardPhrasePanel()
            }
        }
        header.addView(phraseTabBtn)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        header.addView(spacer)

        val actionBtn = TextView(this).apply {
            text = if (isPhraseSubTab) "＋加常用语" else "清空未置顶"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#1E88E5"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener {
                if (isPhraseSubTab) {
                    val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra("open_tab", "phrases")
                        putExtra("default_category", currentPhraseCategory)
                    }
                    startActivity(intent)
                } else {
                    dbHelper.clearUnpinnedClips()
                    showClipboardPhrasePanel()
                }
            }
        }
        header.addView(actionBtn)
        root.addView(header)

        if (isPhraseSubTab) {
            // 二级分类标签栏：收藏 | 最近 | 邮 | 号 | 叮 | 演 | 扮 | 模块 | api
            val catScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                setBackgroundColor(Color.WHITE)
            }
            val catRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            val categories = dbHelper.getCategories()
            if (!categories.contains(currentPhraseCategory)) {
                currentPhraseCategory = categories.firstOrNull() ?: "收藏"
            }
            categories.forEach { cat ->
                val active = (cat == currentPhraseCategory)
                val tv = TextView(this).apply {
                    text = cat
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    setTextColor(if (active) Color.parseColor("#E53935") else Color.parseColor("#333333"))
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    setPadding(dp(12), dp(4), dp(12), dp(4))
                    setOnClickListener {
                        currentPhraseCategory = cat
                        showClipboardPhrasePanel()
                    }
                }
                catRow.addView(tv)
            }
            catScroll.addView(catRow)
            root.addView(catScroll)

            // 常用语卡片列表（带 ★ 星标、两行预览与展开/收起箭头，不限字数）
            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val cardList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            val phrases = dbHelper.getPhrasesByCategory(currentPhraseCategory)
            if (phrases.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = "当前「$currentPhraseCategory」分类暂无常用语\n可点击右上角「＋加常用语」或在剪贴板中一键转存"
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#888888"))
                    setPadding(dp(16), dp(36), dp(16), dp(36))
                }
                cardList.addView(emptyTv)
            } else {
                phrases.forEach { item ->
                    cardList.addView(buildPhraseCard(item))
                }
            }
            vScroll.addView(cardList)
            root.addView(vScroll)
        } else {
            // 剪贴板 300 条无字数上限列表
            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val clipList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            val clips = dbHelper.getClips()
            if (clips.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = "剪贴板暂无记录（自动保留最近 300 条，无字数上限）"
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#888888"))
                    setPadding(dp(16), dp(36), dp(16), dp(36))
                }
                clipList.addView(emptyTv)
            } else {
                clips.forEach { clip ->
                    clipList.addView(buildClipCard(clip))
                }
            }
            vScroll.addView(clipList)
            root.addView(vScroll)
        }

        bodyFrame.addView(root)
    }

    private fun buildPhraseCard(item: PhraseItem): View {
        var expanded = false
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect("#ECEEF1", dp(10), strokeColor = "#D5D8DE", strokeWidth = dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val starTv = TextView(this).apply {
            text = if (item.isStarred) "★" else "☆"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (item.isStarred) Color.parseColor("#F5A623") else Color.parseColor("#999999"))
            setPadding(dp(4), dp(4), dp(8), dp(4))
            setOnClickListener {
                dbHelper.togglePhraseStar(item.id, item.isStarred)
                showClipboardPhrasePanel()
            }
        }
        card.addView(starTv)

        val contentTv = TextView(this).apply {
            text = item.content
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#222428"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                dbHelper.markPhraseUsed(item.id)
                currentInputConnection?.commitText(item.content, 1)
            }
        }
        card.addView(contentTv)

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(dp(10), dp(4), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.maxLines = if (expanded) 500 else 2
                text = if (expanded) "⌃" else "⌄"
            }
        }
        card.addView(expandTv)

        val delTv = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#999999"))
            setPadding(dp(6), dp(4), dp(4), dp(4))
            setOnClickListener {
                dbHelper.deletePhrase(item.id)
                showClipboardPhrasePanel()
            }
        }
        card.addView(delTv)

        return card
    }

    private fun buildClipCard(clip: ClipItem): View {
        var expanded = false
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect("#ECEEF1", dp(10), strokeColor = "#D5D8DE", strokeWidth = dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val pinTv = TextView(this).apply {
            text = if (clip.isPinned) "📌" else "○"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(4), dp(4), dp(8), dp(4))
            setOnClickListener {
                dbHelper.toggleClipPin(clip.id, clip.isPinned)
                showClipboardPhrasePanel()
            }
        }
        card.addView(pinTv)

        val contentTv = TextView(this).apply {
            text = clip.content
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#222428"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                currentInputConnection?.commitText(clip.content, 1)
            }
        }
        card.addView(contentTv)

        // 一键转存到当前常用语分类
        val saveToPhraseTv = TextView(this).apply {
            text = "存常用"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(Color.parseColor("#1E88E5"))
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener {
                dbHelper.addOrUpdatePhrase(null, currentPhraseCategory, clip.content, true)
                Toast.makeText(this@ShengXiaImeService, "已存入常用语「$currentPhraseCategory」", Toast.LENGTH_SHORT).show()
            }
        }
        card.addView(saveToPhraseTv)

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(dp(8), dp(4), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.maxLines = if (expanded) 500 else 2
                text = if (expanded) "⌃" else "⌄"
            }
        }
        card.addView(expandTv)

        val delTv = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#999999"))
            setPadding(dp(6), dp(4), dp(4), dp(4))
            setOnClickListener {
                dbHelper.deleteClip(clip.id)
                showClipboardPhrasePanel()
            }
        }
        card.addView(delTv)

        return card
    }

    // ==================== Emoji & 颜文字纯净双标签面板（1:1 复刻图 4 & 图 5） ====================
    private var isKaomojiSubTab = false
    private var currentEmojiCat = "笑脸"
    private var currentKaomojiCat = "经典"

    private fun showEmojiKaomojiPanel() {
        currentPanel = PanelState.EMOJI_KAOMOJI
        bodyFrame.removeAllViews()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect("#F3F4F6", dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 顶部栏：‹ 返回 | Emoji | 颜文字（砍掉“斗图”、“我的”和商店）
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#E5E6EB"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#333333"))
            setPadding(dp(10), dp(6), dp(14), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        val emojiTab = TextView(this).apply {
            text = "Emoji"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (!isKaomojiSubTab) Color.parseColor("#E53935") else Color.parseColor("#444444"))
            typeface = if (!isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                isKaomojiSubTab = false
                showEmojiKaomojiPanel()
            }
        }
        header.addView(emojiTab)

        val kaomojiTab = TextView(this).apply {
            text = "颜文字"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (isKaomojiSubTab) Color.parseColor("#E53935") else Color.parseColor("#444444"))
            typeface = if (isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                isKaomojiSubTab = true
                showEmojiKaomojiPanel()
            }
        }
        header.addView(kaomojiTab)
        root.addView(header)

        // 内容网格滚动区
        val vScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val gridContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        if (!isKaomojiSubTab) {
            val emojis = EmojiKaomojiData.EMOJI_CATEGORIES[currentEmojiCat] ?: emptyList()
            val cols = 8
            emojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { em ->
                    val tv = TextView(this).apply {
                        text = em
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
                        setOnClickListener { currentInputConnection?.commitText(em, 1) }
                    }
                    row.addView(tv)
                }
                for (i in 0 until (cols - rowItems.size)) {
                    row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f) })
                }
                gridContainer.addView(row)
            }
        } else {
            val kaomojis = EmojiKaomojiData.KAOMOJI_CATEGORIES[currentKaomojiCat] ?: emptyList()
            val cols = 3
            kaomojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { km ->
                    val tv = TextView(this).apply {
                        text = km
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        setTextColor(Color.parseColor("#222428"))
                        gravity = Gravity.CENTER
                        background = roundRect("#E2E4E9", dp(8))
                        val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                        layoutParams = lp
                        setOnClickListener { currentInputConnection?.commitText(km, 1) }
                    }
                    row.addView(tv)
                }
                gridContainer.addView(row)
            }
        }
        vScroll.addView(gridContainer)
        root.addView(vScroll)

        // 底部子分类栏 + 右侧退格键（复刻图 4 & 图 5）
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#E5E6EB"))
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        val catNames = if (!isKaomojiSubTab) EmojiKaomojiData.EMOJI_CATEGORIES.keys else EmojiKaomojiData.KAOMOJI_CATEGORIES.keys
        catNames.forEach { cName ->
            val active = if (!isKaomojiSubTab) (cName == currentEmojiCat) else (cName == currentKaomojiCat)
            val tv = TextView(this).apply {
                text = cName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(if (active) Color.parseColor("#111111") else Color.parseColor("#666666"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                background = if (active) roundRect("#FFFFFF", dp(6)) else null
                layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f)
                setOnClickListener {
                    if (!isKaomojiSubTab) currentEmojiCat = cName else currentKaomojiCat = cName
                    showEmojiKaomojiPanel()
                }
            }
            bottomBar.addView(tv)
        }
        val delBtn = TextView(this).apply {
            text = "⌫"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = roundRect("#D5D7DD", dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(34))
            setOnClickListener { handleBackspace() }
        }
        bottomBar.addView(delBtn)
        root.addView(bottomBar)

        bodyFrame.addView(root)
    }

    // ==================== 常用标点面板与纯数字小键盘 ====================
    private fun showSymbolsPanel() {
        currentPanel = PanelState.SYMBOLS
        bodyFrame.removeAllViews()
        val symbols = listOf(
            "，", "。", "？", "！", "：", "；", "“", "”",
            "（", "）", "【", "】", "《", "》", "、", "…",
            "—", "～", "·", "@", "#", "*", "%", "&",
            "+", "-", "=", "/", "\\", "|", "<", ">"
        )
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        symbols.chunked(8).forEach { rowSyms ->
            val r = makeRow()
            rowSyms.forEach { s ->
                r.addView(makeFuncKey(s, bgColor = "#FFFFFF") {
                    commitOrSelectFirst(s)
                    showKeyboardPanel()
                })
            }
            root.addView(r)
        }
        val bottomRow = makeRow()
        bottomRow.addView(makeFuncKey("返回 14 键五笔", bgColor = "#ECEEF2") { showKeyboardPanel() })
        root.addView(bottomRow)
        bodyFrame.addView(root)
    }

    private fun buildNumberPadView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val rows = listOf(
            listOf("1", "2", "3", "+"),
            listOf("4", "5", "6", "-"),
            listOf("7", "8", "9", "⌫"),
            listOf("返回五笔", "0", ".", "盛夏\n光年")
        )
        rows.forEach { rItems ->
            val r = makeRow()
            rItems.forEach { key ->
                when (key) {
                    "⌫" -> r.addView(makeBackspaceKey(1f))
                    "返回五笔" -> r.addView(makeFuncKey("返回五笔", bgColor = "#ECEEF2") {
                        isNumberPadMode = false
                        showKeyboardPanel()
                    })
                    "盛夏\n光年" -> r.addView(makeFuncKey("盛夏\n光年", bgColor = "#ECEEF2") { handleEnterKey() })
                    else -> r.addView(makeFuncKey(key, bgColor = "#FFFFFF") { commitDirectString(key) })
                }
            }
            root.addView(r)
        }
        return root
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun roundRect(fillHex: String, radiusPx: Int, strokeColor: String? = null, strokeWidth: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.parseColor(fillHex))
            if (strokeColor != null && strokeWidth > 0) {
                setStroke(strokeWidth, Color.parseColor(strokeColor))
            }
        }
    }
}
