package com.shengxiaguangnian.ime

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class Candidate(
    val word: String,
    val wubiHint: String?, // 当通过拼音匹配出字时，显示 86 五笔拆分码提示
    val weight: Int,
    val isWubiMatch: Boolean
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val pinyinCode: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val weight: Int
)

object T14WubiEngine {
    // 14键键位映射：
    // QW->1, ER->2, TY->3, UI->4, OP->5
    // AS->6, DF->7, GH->8, JK->9, L->0
    // ZX->a, CV->b, BN->c, M->d
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    private var initialized = false
    private val entries = ArrayList<DictEntry>(90000)
    private val singleCharWubi = HashMap<Char, String>(9000)
    private val singleCharPinyin = HashMap<Char, String>(9000)

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    @Synchronized
    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        if (initialized) return
        entries.clear()
        singleCharWubi.clear()
        singleCharPinyin.clear()

        // 1. 加载单字五笔与拼音码表（用于新词/导入词库自动计算86五笔编码）
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. 加载内置 86 五笔 + 拼音混输主词库
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2) {
                        val word = parts[0].trim()
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        val weight = if (parts.size >= 4) parts[3].trim().toIntOrNull() ?: 500 else 500
                        if (word.isNotEmpty()) {
                            if (word.length == 1) {
                                if (wcode.isNotEmpty() && !singleCharWubi.containsKey(word[0])) {
                                    singleCharWubi[word[0]] = wcode
                                }
                                if (py.isNotEmpty() && !singleCharPinyin.containsKey(word[0])) {
                                    singleCharPinyin[word[0]] = py
                                }
                            }
                            entries.add(
                                DictEntry(
                                    word = word,
                                    wubiCode = wcode,
                                    pinyinCode = py,
                                    t14Wubi = if (wcode.isNotEmpty()) letterToT14Code(wcode) else "",
                                    t14Pinyin = if (py.isNotEmpty()) letterToT14Code(py) else "",
                                    weight = weight
                                )
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载用户自定义与导入词库
        reloadUserDict(dbHelper)
        initialized = true
    }

    private val userEntries = ArrayList<DictEntry>()

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        userEntries.clear()
        dbHelper.readableDatabase.rawQuery(
            "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
            null
        ).use { c ->
            while (c.moveToNext()) {
                userEntries.add(
                    DictEntry(
                        word = c.getString(0),
                        wubiCode = c.getString(1),
                        pinyinCode = c.getString(2),
                        t14Wubi = c.getString(3),
                        t14Pinyin = c.getString(4),
                        weight = c.getInt(5)
                    )
                )
            }
        }
    }

    /**
     * 根据 86 五笔标准组词规则，为任意中文词组自动生成 86 五笔四码：
     * - 单字：直接取单字全码
     * - 二字词：第1字前两码 + 第2字前两码 (2+2)
     * - 三字词：第1字首码 + 第2字首码 + 第3字前两码 (1+1+2)
     * - 四字及以上词：前3字各取首码 + 最后1字首码 (1+1+1+末1)
     */
    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generatePinyinForWord(word: String): String {
        val sb = StringBuilder()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: continue
            sb.append(py)
        }
        return sb.toString()
    }

    /**
     * 查询 14 键编码对应的候选词：
     * 1. 优先精确匹配 14 键五笔码（无需手选字母）
     * 2. 其次前缀匹配 14 键五笔码
     * 3. 同时匹配 14 键拼音码（不会拆的字直接打拼音，自动附带 86 五笔拆法反查提示）
     */
    fun queryCandidates(t14Input: String, limit: Int = 60): List<Candidate> {
        if (t14Input.isEmpty()) return emptyList()
        val exactWubi = ArrayList<Candidate>()
        val prefixWubi = ArrayList<Candidate>()
        val pinyinMatches = ArrayList<Candidate>()
        val seen = HashSet<String>()

        fun scanList(list: List<DictEntry>, bonusWeight: Int) {
            for (e in list) {
                if (e.t14Wubi.isNotEmpty()) {
                    if (e.t14Wubi == t14Input) {
                        if (seen.add(e.word)) {
                            exactWubi.add(Candidate(e.word, null, e.weight + bonusWeight + 100000, true))
                        }
                        continue
                    } else if (t14Input.length <= 4 && e.t14Wubi.startsWith(t14Input)) {
                        if (seen.add(e.word)) {
                            prefixWubi.add(Candidate(e.word, null, e.weight + bonusWeight, true))
                        }
                        continue
                    }
                }
                if (e.t14Pinyin.isNotEmpty() && (e.t14Pinyin == t14Input || e.t14Pinyin.startsWith(t14Input))) {
                    if (seen.add(e.word)) {
                        val hint = e.wubiCode.ifEmpty { singleCharWubi[e.word.firstOrNull() ?: ' '] }
                        val exactPyBonus = if (e.t14Pinyin == t14Input) 5000 else 0
                        pinyinMatches.add(Candidate(e.word, hint, e.weight + bonusWeight + exactPyBonus, false))
                    }
                }
            }
        }

        scanList(userEntries, 50000)
        scanList(entries, 0)

        exactWubi.sortByDescending { it.weight }
        prefixWubi.sortByDescending { it.weight }
        pinyinMatches.sortByDescending { it.weight }

        val result = ArrayList<Candidate>(limit)
        for (c in exactWubi) {
            result.add(c)
            if (result.size >= limit) return result
        }
        // 交错融合五笔前缀与精确拼音匹配，确保忘字根打拼音时一眼就能看到
        for (c in pinyinMatches.take(15)) {
            result.add(c)
            if (result.size >= limit) return result
        }
        for (c in prefixWubi) {
            result.add(c)
            if (result.size >= limit) return result
        }
        for (c in pinyinMatches.drop(15)) {
            result.add(c)
            if (result.size >= limit) return result
        }
        return result
    }

    /**
     * 解析搜狗细胞词库 (.scel) 二进制文件，提取其中的中文词条（流行歌、动画、名人等）
     */
    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()
        val words = ArrayList<String>()
        try {
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            // 搜狗 .scel 词条区通常从 0x2628 开始
            var pos = 0x2628
            while (pos + 4 < bytes.size) {
                val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                pos += 4 + pyIdxBytesLen
                if (samePyCount <= 0 || samePyCount > 100 || pos >= bytes.size) break
                for (i in 0 until samePyCount) {
                    if (pos + 2 >= bytes.size) break
                    val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2
                    if (wordByteLen <= 0 || wordByteLen > 64 || pos + wordByteLen > bytes.size) break
                    val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                    pos += wordByteLen
                    if (pos + 2 > bytes.size) break
                    val extLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2 + extLen
                    if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 2..12) {
                        words.add(word)
                    }
                }
            }
        } catch (_: Exception) {}
        return words.distinct()
    }
}
