#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Downloads open-source 86 Wubi (rime/rime-wubi) and Pinyin dictionaries during GitHub Actions build,
and compiles them into app/src/main/assets/wubi86_dict.tsv and single_char_wubi.tsv.
If offline, keeps the built-in starter dictionary so the build always succeeds.
"""
import os
import urllib.request

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def main():
    print("Fetching full 86 Wubi dictionary from rime/rime-wubi...")
    wubi_lines = download_lines(WUBI_URL)
    pinyin_lines = download_lines(PINYIN_URL)

    if not wubi_lines:
        print("Using built-in starter dictionary (offline mode).")
        return

    entries = []
    single_char_map = {}
    in_body = False
    for line in wubi_lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip().lower()
            weight = 1000
            if len(parts) >= 3:
                try:
                    weight = int(parts[2].strip())
                except ValueError:
                    weight = 500
            if word and code and code.isalpha():
                entries.append((word, code, "", weight))
                if len(word) == 1:
                    if word not in single_char_map or len(code) > len(single_char_map[word]):
                        single_char_map[word] = code

    # Parse single-character & common word pinyin from luna_pinyin
    py_map = {}
    in_py_body = False
    for line in pinyin_lines:
        line = line.strip()
        if line == "...":
            in_py_body = True
            continue
        if not in_py_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            py = parts[1].strip().replace(" ", "").lower()
            if word and py.isalpha() and len(word) <= 4:
                if word not in py_map:
                    py_map[word] = py

    # Merge and write to assets/wubi86_dict.tsv
    # Format: word \t wubi_code \t pinyin_code \t weight
    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, _, weight in entries:
            py = py_map.get(word, "")
            f.write(f"{word}\t{wcode}\t{py}\t{weight}\n")
        # Also include single chars that only exist in pinyin table
        for word, py in py_map.items():
            if len(word) == 1 and word not in single_char_map:
                f.write(f"{word}\t\t{py}\t200\n")

    # Write single-character full Wubi code table for automatic new-word code generation
    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    with open(single_path, "w", encoding="utf-8") as f:
        for ch, wcode in single_char_map.items():
            py = py_map.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    print(f"Successfully compiled {len(entries)} Wubi entries and {len(single_char_map)} single chars!")

if __name__ == "__main__":
    main()
