package com.shengxiaguangnian.ime

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * 深空星盘 · 第一颗星（DeepStarFx 1:1 轻盈扩散 · 端正零抖动 · 原生同色系和谐取色版）
 *
 * 针对实机体验的四大核心升级：
 * 1. 【从小变大的轻盈扩散感】：
 *    彻底废除瞬间撑满与回弹抽动（easeOutBack），采用全程单向丝滑缓出扩张曲线（0.14x -> 1.00x）。
 *    点击瞬间从键中心极小一颗星（14%）轻盈亮起，内层八芒星罗盘与外层圆角胖五角星差速向外舒展扩散，如星光水波般轻盈呼吸。
 * 2. 【100% 端正对称、末尾绝不歪斜】：
 *    锁定五角星正上方 -90.0°（12点钟方向），彻底移除旋转偏角（canvas.rotate）与纵向漂移；
 *    不对称的流光丝带与左上弯月随内层星盘在中后段（t = 0.35..0.76）先一步温柔化开，
 *    使末尾消散阶段留下的始终是一颗 100% 端正对称的圆角五角星柔光圈。
 * 3. 【零抖动、丝滑自然】：
 *    移除所有正弦半径缩放频闪与回弹抽搐，星珠与四芒星随扩散平滑舒展、柔顺淡出。
 * 4. 【键盘原生同色系莫兰迪取色（零深紫墨团、零土黄脏印、同键盘色彩统一）】：
 *    星心八芒星、弯月、四芒星恒定采用纯净星光白（#FFFFFF），绝不画成比键面更暗的深色墨水；
 *    外围光晕直接将当前按键底色与键盘自身的原生主题伴生色做柔和 RGB 混合，和原键盘底色浑然一体。
 */
object DeepStarFx {
    const val EMBLEM = "deep_star"
    const val DURATION_MS = 500

    private const val PI_F = 3.1415927f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val octPath = Path()
    private val moonOuterPath = Path()
    private val moonCutPath = Path()
    private val sparklePath = Path()
    private val segPath = Path()
    private val hsvBuf = FloatArray(3)

    // 五角星 10 个顶点坐标缓存（0,2,4,6,8 为五个圆润外星尖）
    private val starVx = FloatArray(10)
    private val starVy = FloatArray(10)

    // 丝带采样点缓存（零 GC）
    private const val RIBBON_STEPS = 18
    private val rib1X = FloatArray(RIBBON_STEPS + 1)
    private val rib1Y = FloatArray(RIBBON_STEPS + 1)
    private val rib2X = FloatArray(RIBBON_STEPS + 1)
    private val rib2Y = FloatArray(RIBBON_STEPS + 1)

    // 5 层高斯钟形柔光描边权重
    private val GAUSS_WIDTH_MULTS = floatArrayOf(2.40f, 1.60f, 1.05f, 0.65f, 0.32f)
    private val GAUSS_ALPHA_MULTS = floatArrayOf(0.05f, 0.10f, 0.18f, 0.32f, 0.65f)

    // 精简轻盈的星珠点缀：(x/R, y/R, radius/R) —— 半径固定不频闪，保持画面干净通透
    private val PEARLS = floatArrayOf(
        -0.18f, -0.66f, 0.014f,
         0.18f, -0.66f, 0.014f,
         0.76f, -0.18f, 0.026f,
         0.72f, -0.02f, 0.019f,
         0.14f,  0.66f, 0.015f,
        -0.60f, -0.30f, 0.013f
    )

    private data class HarmoniousPalette(
        val isLight: Boolean,
        val innerStarWhite: Int,
        val coreColor: Int,
        val rimColor: Int,
        val glowColor: Int,
        val cushionColor: Int
    )

    private fun mixRgb(c1: Int, c2: Int, ratioC2: Float): Int {
        val t = ratioC2.coerceIn(0f, 1f)
        val inv = 1f - t
        val r = (Color.red(c1) * inv + Color.red(c2) * t).toInt().coerceIn(0, 255)
        val g = (Color.green(c1) * inv + Color.green(c2) * t).toInt().coerceIn(0, 255)
        val b = (Color.blue(c1) * inv + Color.blue(c2) * t).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    /**
     * 柔化高饱和或过暗伴生色，确保调制出的光晕永远是高级莫兰迪柔光，绝不出现刺眼荧光或土黄暗褐
     */
    private fun sanitizeCompanionColor(rawCompanion: Int, isLightKey: Boolean): Int {
        Color.colorToHSV(rawCompanion, hsvBuf)
        val h = hsvBuf[0]
        val s = hsvBuf[1]
        val v = hsvBuf[2]
        if (s < 0.06f) {
            // 纯黑白灰无色相皮肤：使用温柔浅星河蓝紫 (#A8B2E8)
            return Color.rgb(168, 178, 232)
        }
        return if (isLightKey) {
            // 浅色键帽上：限制饱和度 <= 0.42，保证明度 >= 0.74（防止黄色/米色变土棕，防止蓝紫变深紫墨水）
            val safeS = s.coerceIn(0.18f, 0.42f)
            val safeV = v.coerceIn(0.74f, 0.90f)
            Color.HSVToColor(floatArrayOf(h, safeS, safeV))
        } else {
            // 深色键帽上：保持高明度柔光 (v = 0.88..0.98) 与清透低饱和度 (s = 0.22..0.45)
            val safeS = s.coerceIn(0.20f, 0.45f)
            val safeV = v.coerceIn(0.88f, 0.98f)
            Color.HSVToColor(floatArrayOf(h, safeS, safeV))
        }
    }

    private fun resolvePalette(surfaceBg: Int?, companionGlow: Int?): HarmoniousPalette {
        val keyBg = surfaceBg ?: Color.parseColor("#E8EAF2")
        val lum = (0.299f * Color.red(keyBg) + 0.587f * Color.green(keyBg) + 0.114f * Color.blue(keyBg)) / 255f
        val isLight = lum > 0.54f

        // 检查按键自身是否带有柔和色彩（如莫兰迪浅蓝键、浅薰衣草键）
        Color.colorToHSV(keyBg, hsvBuf)
        val keySat = hsvBuf[1]

        val rawComp = when {
            companionGlow != null && isLight && keySat >= 0.14f -> {
                // 彩色浅底键帽（如浅蓝、浅紫）：70% 采用该键自身色系 + 30% 键盘伴生色，保证跟键帽底色严丝合缝
                mixRgb(keyBg, companionGlow, 0.35f)
            }
            companionGlow != null -> companionGlow
            else -> keyBg
        }

        val safeComp = sanitizeCompanionColor(rawComp, isLight)
        val white = Color.WHITE

        return if (isLight) {
            HarmoniousPalette(
                isLight = true,
                innerStarWhite = white,
                coreColor = mixRgb(safeComp, white, 0.84f),
                rimColor = mixRgb(safeComp, white, 0.46f),
                glowColor = mixRgb(keyBg, safeComp, 0.62f),
                cushionColor = mixRgb(keyBg, safeComp, 0.72f)
            )
        } else {
            HarmoniousPalette(
                isLight = false,
                innerStarWhite = white,
                coreColor = white,
                rimColor = mixRgb(safeComp, white, 0.58f),
                glowColor = mixRgb(keyBg, safeComp, 0.75f),
                cushionColor = safeComp
            )
        }
    }

    fun draw(
        canvas: Canvas,
        rect: RectF,
        t: Float,
        surfaceBg: Int?,
        accentGlow: Int? = null,
        density: Float = 0.65f,
        range: Float = 0.65f
    ) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX()
        val cy = rect.centerY()
        val rangeScale = 0.82f + 0.30f * range.coerceIn(0f, 1f)
        // 控制最大半径恰好处在键帽舒适范围内，绝不撑出键外与邻键重叠打架
        val maxR = min(rect.width(), rect.height()) * 0.32f * rangeScale
        if (maxR <= 2f) return

        // ====================================================================
        // 核心时序：全程从小变大（0.14x -> 1.00x）单向丝滑轻盈扩散，零回弹、零旋转、零抖动！
        // ====================================================================
        val progress = t.coerceIn(0f, 1f)
        val outerScale = 0.14f + 0.86f * easeOutCube(progress)

        val dialProgress = (progress / 0.68f).coerceIn(0f, 1f)
        val dialScale = 0.18f + 0.76f * easeOutQuad(dialProgress)

        val R = maxR * outerScale
        val rDial = maxR * dialScale
        if (R <= 1.2f) return

        // 透明度包络：快速柔和亮起 -> 舒展扩散 -> 丝滑淡出
        val fadeIn = (progress / 0.12f).coerceIn(0f, 1f)
        val outerFadeOut = smooth(0.42f, 1.00f, progress)
        val outerAlpha = (fadeIn * (1f - outerFadeOut)).coerceIn(0f, 1f)
        if (outerAlpha <= 0.01f) return

        // 内层八芒星罗盘、左上弯月与不对称流光丝带在中后段先一步温柔化开，
        // 确保末尾消散时留下 100% 端正对称的圆角五角星轮廓，彻底消除“最后看起来是歪的”视觉错觉！
        val dialFadeOut = smooth(0.28f, 0.72f, progress)
        val dialAlpha = (fadeIn * (1f - dialFadeOut)).coerceIn(0f, 1f)

        val ribbonFadeOut = smooth(0.34f, 0.80f, progress)
        val ribbonAlpha = (fadeIn * (1f - ribbonFadeOut)).coerceIn(0f, 1f)

        val pal = resolvePalette(surfaceBg, accentGlow)

        canvas.save()
        // 死死锁定在键帽正中心 (cx, cy)，零旋转、零纵向漂移，彻底端正不歪！
        canvas.translate(cx, cy)

        // 严格正上方 -90.0°（指北 12 点钟方向）构建圆角胖五角星
        buildRoundedStarPath(starPath, 0f, 0f, R, R * 0.58f, 5, -90.0f, 0.38f)

        // ====================================================================
        // 1. 同色系柔光底晕（在浅色键帽上衬托纯白星芒，浑然一体不发脏）
        // ====================================================================
        p.style = Paint.Style.FILL
        val auraR = R * 1.32f
        val auraPeakA = if (pal.isLight) 0.34f else 0.24f
        p.shader = RadialGradient(
            0f, 0f, auraR,
            intArrayOf(
                withA(pal.cushionColor, (outerAlpha * auraPeakA * 255f).toInt()),
                withA(pal.glowColor, (outerAlpha * auraPeakA * 0.45f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, 0f, auraR, p)
        p.shader = null

        // 五角星内部薄雾呼吸层
        canvas.save()
        canvas.clipPath(starPath)
        val innerFillA = if (pal.isLight) 0.26f else 0.18f
        p.shader = RadialGradient(
            0f, 0f, R * 1.0f,
            intArrayOf(
                withA(pal.cushionColor, (outerAlpha * innerFillA * 255f).toInt()),
                withA(pal.glowColor, (outerAlpha * innerFillA * 0.55f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(-R * 1.1f, -R * 1.1f, R * 1.1f, R * 1.1f, p)
        p.shader = null
        canvas.restore()

        // ====================================================================
        // 2. 端正大圆角胖五角星轮廓（高斯柔雾边 + 纯白高光内丝 + 五角星尖聚光）
        // ====================================================================
        drawGaussianStrokePath(
            canvas, starPath, R * 0.088f,
            pal.glowColor, pal.rimColor, pal.coreColor, outerAlpha
        )

        // 五个圆润外星尖聚光高光（5 个角对称分布，保持视觉绝对平衡）
        p.style = Paint.Style.FILL
        for (idx in 0 until 10 step 2) {
            val vx = starVx[idx]
            val vy = starVy[idx]
            val tipR = R * 0.28f
            p.shader = RadialGradient(
                vx, vy, tipR,
                intArrayOf(
                    withA(pal.innerStarWhite, (outerAlpha * 0.52f * 255f).toInt()),
                    withA(pal.rimColor, (outerAlpha * 0.18f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.50f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(vx, vy, tipR, p)
        }
        p.shader = null

        // ====================================================================
        // 3. 双星轨彗星流光丝带 + 领航实心四芒星（✦）+ 右下空心四芒星（✧）
        // ====================================================================
        if (ribbonAlpha > 0.02f) {
            sampleCubicBezier(
                0.42f * R, -0.70f * R,
                0.90f * R, -0.60f * R,
                0.82f * R, -0.04f * R,
                0.42f * R,  0.28f * R,
                rib1X, rib1Y
            )
            sampleCubicBezier(
                -0.84f * R, 0.28f * R,
                -0.84f * R, 0.78f * R,
                -0.36f * R, 0.74f * R,
                 0.04f * R, 0.56f * R,
                rib2X, rib2Y
            )

            drawTaperedCometRibbon(canvas, rib1X, rib1Y, R, pal, ribbonAlpha, isArch = true)
            drawTaperedCometRibbon(canvas, rib2X, rib2Y, R, pal, ribbonAlpha, isArch = false)

            // 右上领航四芒星（✦）与左下领航四芒星（✦）—— 正向不歪
            drawSolidSparkle4(
                canvas,
                cx = 0.55f * R,
                cy = -0.65f * R,
                r = R * 0.125f,
                waistK = 0.20f,
                rotDeg = 0f,
                alpha = ribbonAlpha,
                pal = pal
            )
            drawSolidSparkle4(
                canvas,
                cx = -0.84f * R,
                cy = 0.28f * R,
                r = R * 0.078f,
                waistK = 0.22f,
                rotDeg = 0f,
                alpha = ribbonAlpha * 0.92f,
                pal = pal
            )

            // 右下空心四芒星（✧）
            drawHollowSparkle4(
                canvas,
                cx = 0.72f * R,
                cy = 0.40f * R,
                r = R * 0.095f,
                waistK = 0.28f,
                rotDeg = 45f,
                alpha = ribbonAlpha * 0.88f,
                pal = pal
            )
        }

        // ====================================================================
        // 4. 左上斜弯月（🌙）与星心八芒星轨罗盘（纯白星芯 + 同色柔光衬底）
        // ====================================================================
        if (dialAlpha > 0.02f && rDial > 1.5f) {
            drawCrescentMoon(
                canvas,
                mcx = -0.66f * R,
                mcy = -0.50f * R,
                outerR = R * 0.128f,
                cutR = R * 0.110f,
                offset = R * 0.048f,
                openAngleDeg = -48f,
                alpha = dialAlpha,
                pal = pal
            )

            val rRing = rDial * 0.24f

            // (a) 星心同色系柔光放射底衬（让纯白八芒星在浅色键帽上也清晰耀眼）
            p.style = Paint.Style.FILL
            val centerGlowR = rDial * 0.46f
            val cGlowA = if (pal.isLight) 0.48f else 0.36f
            p.shader = RadialGradient(
                0f, 0f, centerGlowR,
                intArrayOf(
                    withA(pal.cushionColor, (dialAlpha * cGlowA * 255f).toInt()),
                    withA(pal.glowColor, (dialAlpha * cGlowA * 0.48f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, centerGlowR, p)
            p.shader = null

            // (b) 内层实线星盘圆环
            p.style = Paint.Style.STROKE
            p.strokeWidth = rDial * 0.055f
            p.color = withA(pal.glowColor, (dialAlpha * 0.32f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)
            p.strokeWidth = max(1.2f, rDial * 0.022f)
            p.color = withA(pal.innerStarWhite, (dialAlpha * 0.94f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)

            // (c) 四长四短对称八芒星（纯白星光芯）
            buildOctagramPath(
                octPath,
                cx = 0f,
                cy = 0f,
                rMajor = rDial * 0.36f,
                rMinor = rDial * 0.245f,
                rWaist = rDial * 0.116f
            )
            p.style = Paint.Style.STROKE
            p.strokeJoin = Paint.Join.ROUND
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = rDial * 0.068f
            p.color = withA(pal.glowColor, (dialAlpha * 0.34f * 255f).toInt())
            canvas.drawPath(octPath, p)

            p.style = Paint.Style.FILL
            p.color = withA(pal.innerStarWhite, (dialAlpha * 0.98f * 255f).toInt())
            canvas.drawPath(octPath, p)

            // (d) 左上 (-135°) 与右下 (+45°) 对角双行星圆点
            val planetOrbitR = rDial * 0.295f
            val planetR = max(1.2f, rDial * 0.028f)
            for (deg in intArrayOf(-135, 45)) {
                val rad = Math.toRadians(deg.toDouble())
                val px = (planetOrbitR * cos(rad)).toFloat()
                val py = (planetOrbitR * sin(rad)).toFloat()
                p.color = withA(pal.glowColor, (dialAlpha * 0.38f * 255f).toInt())
                canvas.drawCircle(px, py, planetR * 2.0f, p)
                p.color = withA(pal.innerStarWhite, (dialAlpha * 0.96f * 255f).toInt())
                canvas.drawCircle(px, py, planetR, p)
            }
        }

        // ====================================================================
        // 5. 轻盈星珠点缀（纯白微光，不频闪、不抖动）
        // ====================================================================
        if (density > 0.15f && ribbonAlpha > 0.02f) {
            p.style = Paint.Style.FILL
            val activeCount = ((PEARLS.size / 3) * density.coerceIn(0.2f, 1f)).toInt().coerceIn(2, PEARLS.size / 3)
            for (idx in 0 until activeCount) {
                val base = idx * 3
                val px = PEARLS[base] * R
                val py = PEARLS[base + 1] * R
                val pr = max(1.0f, PEARLS[base + 2] * R)
                p.color = withA(pal.glowColor, (ribbonAlpha * 0.32f * 255f).toInt())
                canvas.drawCircle(px, py, pr * 2.0f, p)
                p.color = withA(pal.innerStarWhite, (ribbonAlpha * 0.90f * 255f).toInt())
                canvas.drawCircle(px, py, pr, p)
            }
        }

        canvas.restore()
    }

    private fun drawGaussianStrokePath(
        canvas: Canvas,
        path: Path,
        baseWidth: Float,
        glowColor: Int,
        rimColor: Int,
        coreColor: Int,
        alpha: Float
    ) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        for (k in 0 until GAUSS_WIDTH_MULTS.size) {
            p.strokeWidth = max(1f, baseWidth * GAUSS_WIDTH_MULTS[k])
            val col = when {
                k < 2 -> glowColor
                k < 4 -> rimColor
                else -> coreColor
            }
            val layerA = (alpha * GAUSS_ALPHA_MULTS[k] * 255f).toInt()
            p.color = withA(col, layerA)
            canvas.drawPath(path, p)
        }
    }

    private fun drawTaperedCometRibbon(
        canvas: Canvas,
        xs: FloatArray,
        ys: FloatArray,
        R: Float,
        pal: HarmoniousPalette,
        alpha: Float,
        isArch: Boolean
    ) {
        segPath.reset()
        segPath.moveTo(xs[0], ys[0])
        for (i in 1..RIBBON_STEPS) {
            segPath.lineTo(xs[i], ys[i])
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = max(1.5f, R * 0.085f)
        p.color = withA(pal.glowColor, (alpha * 0.22f * 255f).toInt())
        canvas.drawPath(segPath, p)
        p.strokeWidth = max(1.2f, R * 0.042f)
        p.color = withA(pal.rimColor, (alpha * 0.36f * 255f).toInt())
        canvas.drawPath(segPath, p)

        for (i in 0 until RIBBON_STEPS) {
            val u = i.toFloat() / RIBBON_STEPS.toFloat()
            val env = if (isArch) {
                sin(u * PI_F).pow(0.65f)
            } else {
                (1f - 0.72f * u) * min(1f, u * 5.5f)
            }
            if (env <= 0.05f) continue
            p.strokeWidth = max(1f, R * 0.024f * env)
            p.color = withA(pal.innerStarWhite, (alpha * 0.82f * env * 255f).toInt())
            canvas.drawLine(xs[i], ys[i], xs[i + 1], ys[i + 1], p)
        }
    }

    private fun sampleCubicBezier(
        x0: Float, y0: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        outX: FloatArray,
        outY: FloatArray
    ) {
        for (s in 0..RIBBON_STEPS) {
            val u = s.toFloat() / RIBBON_STEPS.toFloat()
            val inv = 1f - u
            val b0 = inv * inv * inv
            val b1 = 3f * inv * inv * u
            val b2 = 3f * inv * u * u
            val b3 = u * u * u
            outX[s] = b0 * x0 + b1 * x1 + b2 * x2 + b3 * x3
            outY[s] = b0 * y0 + b1 * y1 + b2 * y2 + b3 * y3
        }
    }

    private fun drawSolidSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: HarmoniousPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(1.2f, r * 0.38f)
        p.color = withA(pal.glowColor, (alpha * 0.38f * 255f).toInt())
        canvas.drawPath(sparklePath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.innerStarWhite, (alpha * 0.98f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    private fun drawHollowSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: HarmoniousPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(1.5f, r * 0.45f)
        p.color = withA(pal.glowColor, (alpha * 0.30f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
        p.strokeWidth = max(1.2f, r * 0.22f)
        p.color = withA(pal.innerStarWhite, (alpha * 0.92f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    private fun drawCrescentMoon(
        canvas: Canvas,
        mcx: Float,
        mcy: Float,
        outerR: Float,
        cutR: Float,
        offset: Float,
        openAngleDeg: Float,
        alpha: Float,
        pal: HarmoniousPalette
    ) {
        val rad = Math.toRadians(openAngleDeg.toDouble())
        val cutX = mcx + (offset * cos(rad)).toFloat()
        val cutY = mcy + (offset * sin(rad)).toFloat()

        moonOuterPath.reset()
        moonOuterPath.addCircle(mcx, mcy, outerR, Path.Direction.CW)
        moonCutPath.reset()
        moonCutPath.addCircle(cutX, cutY, cutR, Path.Direction.CW)
        moonOuterPath.op(moonCutPath, Path.Op.DIFFERENCE)

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(1.2f, outerR * 0.42f)
        p.color = withA(pal.glowColor, (alpha * 0.32f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.innerStarWhite, (alpha * 0.95f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)
    }

    private fun buildOctagramPath(
        out: Path,
        cx: Float,
        cy: Float,
        rMajor: Float,
        rMinor: Float,
        rWaist: Float
    ) {
        out.reset()
        for (i in 0 until 16) {
            val ang = Math.toRadians(-90.0 + i * 22.5)
            val r = when {
                i % 4 == 0 -> rMajor
                i % 2 == 0 -> rMinor
                else -> rWaist
            }
            val x = cx + (r * cos(ang)).toFloat()
            val y = cy + (r * sin(ang)).toFloat()
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }

    private fun buildSparkle4Path(
        out: Path,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float
    ) {
        out.reset()
        for (i in 0 until 4) {
            val a0 = Math.toRadians((rotDeg + i * 90f - 90f).toDouble())
            val a1 = Math.toRadians((rotDeg + (i + 1) * 90f - 90f).toDouble())
            val amid = Math.toRadians((rotDeg + i * 90f - 45f).toDouble())
            val x0 = cx + (r * cos(a0)).toFloat()
            val y0 = cy + (r * sin(a0)).toFloat()
            val xm = cx + (r * waistK * cos(amid)).toFloat()
            val ym = cy + (r * waistK * sin(amid)).toFloat()
            val x1 = cx + (r * cos(a1)).toFloat()
            val y1 = cy + (r * sin(a1)).toFloat()
            if (i == 0) out.moveTo(x0, y0)
            out.quadTo(xm, ym, x1, y1)
        }
        out.close()
    }

    private fun buildRoundedStarPath(
        out: Path,
        cx: Float,
        cy: Float,
        outer: Float,
        inner: Float,
        points: Int,
        rotDeg: Float,
        k: Float
    ) {
        out.reset()
        val n = points * 2
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians(rotDeg + i * 180.0 / points)
            starVx[i] = cx + (r * cos(a)).toFloat()
            starVy[i] = cy + (r * sin(a)).toFloat()
        }
        var first = true
        for (i in 0 until n) {
            val pv = (i - 1 + n) % n
            val nv = (i + 1) % n
            val px = starVx[i] + (starVx[pv] - starVx[i]) * k
            val py = starVy[i] + (starVy[pv] - starVy[i]) * k
            val qx = starVx[i] + (starVx[nv] - starVx[i]) * k
            val qy = starVy[i] + (starVy[nv] - starVy[i]) * k
            if (first) {
                out.moveTo(px, py)
                first = false
            } else {
                out.lineTo(px, py)
            }
            out.quadTo(starVx[i], starVy[i], qx, qy)
        }
        out.close()
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun easeOutQuad(x: Float): Float {
        val d = 1f - x
        return 1f - d * d
    }

    private fun easeOutCube(x: Float): Float {
        val d = 1f - x
        return 1f - d * d * d
    }

    private fun withA(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
