package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 位于键盘最底层的「单键同色系柔光背光层」（Z-order 在所有按键下方）：
 * - 严格垫在所有键帽底部（index = 0），绝不覆盖或染色任何键帽表面与文字；
 * - 光晕形状贴合被按下的单颗圆角按键，仅向按键四周缝隙柔化扩散约 8~9dp（采用原生高斯模糊 BlurMaskFilter，过渡丝滑无圈纹、绝不夸张外溢）；
 * - 光晕颜色严格跟随被按下按键自身的色系（池水蓝键发冰蓝光、睡莲粉键发柔粉光、嫩荷叶绿键发嫩绿光、深苔绿键发森绿光）；
 * - 松手后前 150ms 保持峰值亮度，随后在 620ms 内柔和消散。
 */
class KeyboardBacklightOverlayView(context: Context) : View(context) {

    private class SpotlightOrb(
        val sourceView: View,
        val keyRect: RectF,
        val cornerRadius: Float,
        val glowColor: Int,
        var releaseTime: Long = 0L
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val outerBlurFilter = android.graphics.BlurMaskFilter(dpF(5.6f), android.graphics.BlurMaskFilter.Blur.NORMAL)
    private val innerBlurFilter = android.graphics.BlurMaskFilter(dpF(2.6f), android.graphics.BlurMaskFilter.Blur.NORMAL)

    private val outerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = outerBlurFilter
    }
    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = innerBlurFilter
    }
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
        // 使用软件渲染层确保 BlurMaskFilter 在所有品牌的安卓机型与系统版本上都能 100% 呈现丝滑无断层的高斯柔光
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun triggerKeyDown(keyView: View, cornerRadius: Float, glowColor: Int) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + keyView.width
        val bottom = top + keyView.height

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(
            SpotlightOrb(
                sourceView = keyView,
                keyRect = RectF(left, top, right, bottom),
                cornerRadius = cornerRadius,
                glowColor = glowColor,
                releaseTime = 0L
            )
        )
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val holdMs = 150f
        val fadeMs = 620f
        val totalMs = holdMs + fadeMs

        val outExpand = dpF(3.8f)
        val inExpand = dpF(1.6f)

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.06f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.94f * (1f - t) * (1f - t)
                }
            }

            val rCol = Color.red(orb.glowColor)
            val gCol = Color.green(orb.glowColor)
            val bCol = Color.blue(orb.glowColor)

            // 1. 外层同色系柔光晕（从键帽底部向四周缝隙柔和晕开约 3.8dp + 5.6dp 高斯羽化，绝不波及远处按键）
            val alphaOuter = (242 * progress).toInt().coerceIn(0, 255)
            outerGlowPaint.color = Color.argb(alphaOuter, rCol, gCol, bCol)
            tmpRectF.set(
                orb.keyRect.left - outExpand,
                orb.keyRect.top - outExpand,
                orb.keyRect.right + outExpand,
                orb.keyRect.bottom + outExpand
            )
            canvas.drawRoundRect(
                tmpRectF,
                orb.cornerRadius + outExpand,
                orb.cornerRadius + outExpand,
                outerGlowPaint
            )

            // 2. 紧贴键帽底缘的明亮同色系内圈光晕（提升缝隙贴边处的清透发光感）
            val rInner = (rCol * 0.78f + 255 * 0.22f).toInt().coerceIn(0, 255)
            val gInner = (gCol * 0.78f + 255 * 0.22f).toInt().coerceIn(0, 255)
            val bInner = (bCol * 0.78f + 255 * 0.22f).toInt().coerceIn(0, 255)
            val alphaInner = (210 * progress).toInt().coerceIn(0, 255)
            innerGlowPaint.color = Color.argb(alphaInner, rInner, gInner, bInner)
            tmpRectF.set(
                orb.keyRect.left - inExpand,
                orb.keyRect.top - inExpand,
                orb.keyRect.right + inExpand,
                orb.keyRect.bottom + inExpand
            )
            canvas.drawRoundRect(
                tmpRectF,
                orb.cornerRadius + inExpand,
                orb.cornerRadius + inExpand,
                innerGlowPaint
            )
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#76A2F2"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (enableGlow) {
                    val overlay = findBacklightOverlay()
                    if (value) {
                        overlay?.triggerKeyDown(this, cornerRadiusPx, glowColor)
                    } else {
                        overlay?.triggerKeyUp(this)
                    }
                }
                invalidate()
            }
        }

    private fun findBacklightOverlay(): KeyboardBacklightOverlayView? {
        var p = parent
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    return child
                }
            }
            p = p.parent
        }
        return null
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            // 莫奈油画键帽纹理内部 100% 不透明，直接绘制可确保键帽完全遮挡底部的背光层，绝不被背光染色
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (fallbackBgTop != Color.TRANSPARENT) {
            // 非莫奈皮肤下使用实心不透明键帽底色，同样确保键帽不被底部背光染色
            fallbackFillPaint.color = Color.argb(
                255,
                Color.red(fallbackBgTop),
                Color.green(fallbackBgTop),
                Color.blue(fallbackBgTop)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)
    }
}

/**
 * 顶部状态栏 4 图标视图：
 * - 当 useBotanicalStyle = true 时，直接渲染高清水彩晕染的「小莲花、双生睡莲花苞、缺口浮叶、双叶托莲水波」4 枚纯植物图标（彻底告别搞笑圆脸！）
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = true
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (useBotanicalStyle) {
            val bmp = MonetTextureManager.getTopIconBitmap(context, iconType)
            if (bmp != null) {
                val pad = minOf(w, h) * 0.04f
                dstRectF.set(pad, pad, w - pad, h - pad)
                srcRect.set(0, 0, bmp.width, bmp.height)
                canvas.drawBitmap(bmp, srcRect, dstRectF, bmpPaint)
                return
            }
        }

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.36f
        drawClassicMinimalistIcon(canvas, cx, cy, r)
    }

    private fun drawClassicMinimalistIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
