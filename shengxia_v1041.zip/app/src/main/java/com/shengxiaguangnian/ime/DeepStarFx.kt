package com.shengxiaguangnian.ime

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * 深空星盘 · 第一颗星（DeepStarFx 1:1 复刻 · 饱满粗线条 · 浅色高显色同色系光晕 · 慢速轻盈扩散版）
 *
 * 针对实机浅色键盘体验的三大核心升级：
 * 1. 【饱满线条（加粗 2.2 倍）+ 纯白发光芯】：
 *    将五角星轮廓、流光丝带、星盘圆环、空心四芒星与弯月的线条全面加粗，彻底告别细若游丝的蜘蛛网感。
 * 2. 【浅色键盘高显色同色系柔光衬底（绝不隐身、绝不发脏）】：
 *    直接提取每颗按键自身的真实色相（粉色键出深樱粉柔光、浅蓝键出晴空蓝柔光、浅紫键出薰衣草紫柔光、奶黄/米白键出暖香槟金柔光），
 *    在浅色键面上先铺设一层饱满柔和的同色系深一度高斯柔光垫（5 层高不透明度柔焦羽化），
 *    再在正中央叠加 100% 纯白（#FFFFFF）加粗发光星芯——既像真正的发光星体，又在任何浅色键面上清晰醒目！
 * 3. 【真正舒缓的从小变大轻盈扩散（支持最慢 2.0 秒慢放）】：
 *    废除前段暴冲的 easeOutCube，改用舒缓均匀的 progress.pow(0.75f) 扩张曲线，基础时长提升至 1100ms（最慢档可达 2035ms），
 *    肉眼可清晰欣赏星星从中心小晶核一圈圈轻盈舒展放大的全过程。
 */
object DeepStarFx {
    const val EMBLEM = "deep_star"
    const val DURATION_MS = 1100

    private const val PI_F = 3.1415927f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val starPath = Path()
    private val octPath = Path()
    private val moonOuterPath = Path()
    private val moonCutPath = Path()
    private val sparklePath = Path()
    private val segPath = Path()
    private val hsvKey = FloatArray(3)
    private val hsvComp = FloatArray(3)

    // 五角星 10 个顶点坐标缓存（0,2,4,6,8 为五个圆润外星尖）
    private val starVx = FloatArray(10)
    private val starVy = FloatArray(10)

    // 丝带采样点缓存（零 GC）
    private const val RIBBON_STEPS = 20
    private val rib1X = FloatArray(RIBBON_STEPS + 1)
    private val rib1Y = FloatArray(RIBBON_STEPS + 1)
    private val rib2X = FloatArray(RIBBON_STEPS + 1)
    private val rib2Y = FloatArray(RIBBON_STEPS + 1)

    // 浅色键面专用：5 层高显色同色系柔焦光晕权重 + 2 层加粗纯白星芯
    private val LIGHT_HALO_WIDTH_MULTS = floatArrayOf(3.40f, 2.50f, 1.85f, 1.38f, 1.05f)
    private val LIGHT_HALO_ALPHA_MULTS = floatArrayOf(0.14f, 0.25f, 0.40f, 0.58f, 0.78f)

    // 深色键面专用：5 层清透星河柔光权重
    private val DARK_HALO_WIDTH_MULTS = floatArrayOf(3.00f, 2.15f, 1.55f, 1.15f, 0.88f)
    private val DARK_HALO_ALPHA_MULTS = floatArrayOf(0.08f, 0.16f, 0.28f, 0.44f, 0.65f)

    // 星珠点缀：(x/R, y/R, radius/R)
    private val PEARLS = floatArrayOf(
        -0.18f, -0.66f, 0.020f,
         0.18f, -0.66f, 0.020f,
         0.76f, -0.18f, 0.032f,
         0.72f, -0.02f, 0.024f,
         0.14f,  0.66f, 0.020f,
        -0.60f, -0.30f, 0.018f
    )

    private data class StarPalette(
        val isLight: Boolean,
        val coreWhite: Int,
        val midRimColor: Int,
        val bloomColor: Int,
        val fillTintColor: Int
    )

    /**
     * 提取同色系高显色柔光调色板：
     * - 浅色按键（粉、浅蓝、浅紫、浅冰蓝、奶黄、米白）：
     *   优先使用该颗按键自身的色相（如粉色键 CV 用深樱粉，浅蓝键 ER 用晴空蓝，浅紫键 DF 用薰衣草紫），
     *   将该色相适度加深明度（v = 0.52..0.64）并提升柔和饱和度（s = 0.46..0.60）作为柔焦光晕底衬，
     *   正中央核心线条恒定使用 100% 纯白（#FFFFFF），从而在任何浅色键面上都清晰醒目且色彩严丝合缝！
     */
    private fun resolvePalette(surfaceBg: Int?, companionGlow: Int?): StarPalette {
        val keyBg = surfaceBg ?: Color.parseColor("#E8EAF2")
        val lum = (0.299f * Color.red(keyBg) + 0.587f * Color.green(keyBg) + 0.114f * Color.blue(keyBg)) / 255f
        val isLight = lum > 0.56f

        Color.colorToHSV(keyBg, hsvKey)
        val hk = hsvKey[0]
        val sk = hsvKey[1]
        val vk = hsvKey[2]

        var hc = 232f
        var sc = 0.38f
        if (companionGlow != null) {
            Color.colorToHSV(companionGlow, hsvComp)
            hc = hsvComp[0]
            sc = hsvComp[1]
        }

        // 若当前按键自身带有色彩（sk >= 0.05，涵盖浅粉 CV、浅蓝 ER、浅冰蓝 ,、浅紫 DF、奶黄 OP），直接使用当前按键自身色相！
        // 仅当按键是纯白/纯灰/纯黑（sk < 0.05）时，才借用整套皮肤的伴生主题色相。
        var hue = when {
            sk >= 0.05f -> hk
            sc >= 0.06f -> hc
            else -> 232f
        }
        // 防止暖黄/米色（36°..62°）加深明度时偏橄榄绿，温和校准至香槟暖琥珀色相（34°）
        if (hue in 36f..62f) {
            hue = 34f
        }

        return if (isLight) {
            val bloomS = (sk + 0.32f).coerceIn(0.46f, 0.62f)
            val bloomV = (vk - 0.28f).coerceIn(0.48f, 0.64f)
            val bloomCol = Color.HSVToColor(floatArrayOf(hue, bloomS, bloomV))
            val midRimCol = Color.HSVToColor(floatArrayOf(hue, (bloomS * 0.72f).coerceIn(0.30f, 0.50f), (bloomV + 0.16f).coerceIn(0.66f, 0.82f)))
            val fillCol = Color.HSVToColor(floatArrayOf(hue, (bloomS * 0.80f).coerceIn(0.35f, 0.54f), (bloomV + 0.08f).coerceIn(0.56f, 0.72f)))
            StarPalette(
                isLight = true,
                coreWhite = Color.WHITE,
                midRimColor = midRimCol,
                bloomColor = bloomCol,
                fillTintColor = fillCol
            )
        } else {
            val bloomS = (max(sk, sc) * 0.85f + 0.15f).coerceIn(0.30f, 0.55f)
            val bloomCol = Color.HSVToColor(floatArrayOf(hue, bloomS, 0.94f))
            val midRimCol = Color.HSVToColor(floatArrayOf(hue, (bloomS * 0.55f).coerceIn(0.16f, 0.35f), 0.99f))
            StarPalette(
                isLight = false,
                coreWhite = Color.WHITE,
                midRimColor = midRimCol,
                bloomColor = bloomCol,
                fillTintColor = bloomCol
            )
        }
    }

    fun draw(
        canvas: Canvas,
        rect: RectF,
        t: Float,
        surfaceBg: Int?,
        accentGlow: Int? = null,
        density: Float = 0.65f,
        range: Float = 0.65f
    ) {
        if (rect.width() <= 1f || rect.height() <= 1f) return
        val cx = rect.centerX()
        val cy = rect.centerY()
        val rangeScale = 0.85f + 0.32f * range.coerceIn(0f, 1f)
        val maxR = min(rect.width(), rect.height()) * 0.34f * rangeScale
        if (maxR <= 2f) return

        // ====================================================================
        // 核心时序：采用舒缓均匀的 pow(0.75f) 曲线（不再前段暴冲），从 0.12x 慢速轻盈扩散至 1.00x
        // ====================================================================
        val progress = t.coerceIn(0f, 1f)
        val gentleExpand = progress.pow(0.75f)
        val outerScale = 0.12f + 0.88f * gentleExpand

        val dialProgress = (progress / 0.74f).coerceIn(0f, 1f)
        val dialScale = 0.16f + 0.80f * dialProgress.pow(0.75f)

        val R = maxR * outerScale
        val rDial = maxR * dialScale
        if (R <= 1.2f) return

        // 透明度包络：柔和亮起 -> 饱满停留 -> 慢速渐隐
        val fadeIn = (progress / 0.10f).coerceIn(0f, 1f)
        val outerFadeOut = smooth(0.52f, 1.00f, progress)
        val outerAlpha = (fadeIn * (1f - outerFadeOut)).coerceIn(0f, 1f)
        if (outerAlpha <= 0.01f) return

        // 内层星盘与丝带在后半段温柔化开，末尾留下一颗 100% 端正对称的圆角五角星
        val dialFadeOut = smooth(0.38f, 0.78f, progress)
        val dialAlpha = (fadeIn * (1f - dialFadeOut)).coerceIn(0f, 1f)

        val ribbonFadeOut = smooth(0.44f, 0.86f, progress)
        val ribbonAlpha = (fadeIn * (1f - ribbonFadeOut)).coerceIn(0f, 1f)

        val pal = resolvePalette(surfaceBg, accentGlow)

        canvas.save()
        canvas.translate(cx, cy)

        // 严格正上方 -90.0° 构建圆角胖五角星
        buildRoundedStarPath(starPath, 0f, 0f, R, R * 0.58f, 5, -90.0f, 0.38f)

        // ====================================================================
        // 1. 同色系柔光底晕（在浅色键帽上提供充足显色对比度，衬托纯白星芯）
        // ====================================================================
        p.style = Paint.Style.FILL
        val auraR = R * 1.35f
        val auraPeakA = if (pal.isLight) 0.46f else 0.28f
        p.shader = RadialGradient(
            0f, 0f, auraR,
            intArrayOf(
                withA(pal.fillTintColor, (outerAlpha * auraPeakA * 255f).toInt()),
                withA(pal.bloomColor, (outerAlpha * auraPeakA * 0.52f * 255f).toInt()),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.58f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, 0f, auraR, p)
        p.shader = null

        // 五角星内部饱满同色系柔雾衬底（让内部纯白星盘清晰跃出）
        canvas.save()
        canvas.clipPath(starPath)
        val innerFillA = if (pal.isLight) 0.42f else 0.22f
        p.shader = RadialGradient(
            0f, 0f, R * 1.02f,
            intArrayOf(
                withA(pal.fillTintColor, (outerAlpha * innerFillA * 255f).toInt()),
                withA(pal.bloomColor, (outerAlpha * innerFillA * 0.72f * 255f).toInt()),
                withA(pal.bloomColor, (outerAlpha * innerFillA * 0.35f * 255f).toInt())
            ),
            floatArrayOf(0f, 0.65f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(-R * 1.1f, -R * 1.1f, R * 1.1f, R * 1.1f, p)
        p.shader = null
        canvas.restore()

        // ====================================================================
        // 2. 加粗版大圆角胖五角星轮廓（外层同色系柔焦光晕 + 内层加粗纯白发光芯）
        // ====================================================================
        val starBaseW = R * 0.082f
        drawPlumpGlowingPath(canvas, starPath, starBaseW, pal, outerAlpha)

        // 五个圆润外星尖聚光高光
        p.style = Paint.Style.FILL
        for (idx in 0 until 10 step 2) {
            val vx = starVx[idx]
            val vy = starVy[idx]
            val tipR = R * 0.30f
            p.shader = RadialGradient(
                vx, vy, tipR,
                intArrayOf(
                    withA(pal.coreWhite, (outerAlpha * 0.70f * 255f).toInt()),
                    withA(pal.midRimColor, (outerAlpha * 0.28f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.52f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(vx, vy, tipR, p)
        }
        p.shader = null

        // ====================================================================
        // 3. 加粗版双星轨彗星流光丝带 + 领航实心四芒星（✦）+ 右下空心四芒星（✧）
        // ====================================================================
        if (ribbonAlpha > 0.02f) {
            sampleCubicBezier(
                0.42f * R, -0.70f * R,
                0.90f * R, -0.60f * R,
                0.82f * R, -0.04f * R,
                0.42f * R,  0.28f * R,
                rib1X, rib1Y
            )
            sampleCubicBezier(
                -0.84f * R, 0.28f * R,
                -0.84f * R, 0.78f * R,
                -0.36f * R, 0.74f * R,
                 0.04f * R, 0.56f * R,
                rib2X, rib2Y
            )

            drawTaperedCometRibbon(canvas, rib1X, rib1Y, R, pal, ribbonAlpha, isArch = true)
            drawTaperedCometRibbon(canvas, rib2X, rib2Y, R, pal, ribbonAlpha, isArch = false)

            // 右上领航大四芒星（✦）与左下领航小四芒星（✦）
            drawSolidSparkle4(
                canvas,
                cx = 0.55f * R,
                cy = -0.65f * R,
                r = R * 0.142f,
                waistK = 0.22f,
                rotDeg = 0f,
                alpha = ribbonAlpha,
                pal = pal
            )
            drawSolidSparkle4(
                canvas,
                cx = -0.84f * R,
                cy = 0.28f * R,
                r = R * 0.092f,
                waistK = 0.23f,
                rotDeg = 0f,
                alpha = ribbonAlpha * 0.95f,
                pal = pal
            )

            // 右下空心四芒星（✧）
            drawHollowSparkle4(
                canvas,
                cx = 0.72f * R,
                cy = 0.40f * R,
                r = R * 0.108f,
                waistK = 0.28f,
                rotDeg = 45f,
                alpha = ribbonAlpha * 0.94f,
                pal = pal
            )
        }

        // ====================================================================
        // 4. 左上斜弯月（🌙）与星心八芒星轨罗盘（饱满粗线条 + 纯白星芯）
        // ====================================================================
        if (dialAlpha > 0.02f && rDial > 1.5f) {
            drawCrescentMoon(
                canvas,
                mcx = -0.66f * R,
                mcy = -0.50f * R,
                outerR = R * 0.138f,
                cutR = R * 0.114f,
                offset = R * 0.050f,
                openAngleDeg = -48f,
                alpha = dialAlpha,
                pal = pal
            )

            val rRing = rDial * 0.245f

            // (a) 星心浓郁同色系柔光底衬（确保中心纯白八芒星在任何浅色键面上都清晰耀眼）
            p.style = Paint.Style.FILL
            val centerGlowR = rDial * 0.48f
            val cGlowA = if (pal.isLight) 0.62f else 0.38f
            p.shader = RadialGradient(
                0f, 0f, centerGlowR,
                intArrayOf(
                    withA(pal.bloomColor, (dialAlpha * cGlowA * 255f).toInt()),
                    withA(pal.bloomColor, (dialAlpha * cGlowA * 0.55f * 255f).toInt()),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.58f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, centerGlowR, p)
            p.shader = null

            // (b) 加粗版内层实线星盘圆环（同色柔光外环 + 纯白粗内环）
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(3.5f, rDial * 0.11f)
            p.color = withA(pal.bloomColor, (dialAlpha * (if (pal.isLight) 0.68f else 0.38f) * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)

            p.strokeWidth = max(2.2f, rDial * 0.048f)
            p.color = withA(pal.coreWhite, (dialAlpha * 0.98f * 255f).toInt())
            canvas.drawCircle(0f, 0f, rRing, p)

            // (c) 四长四短对称八芒星（外层同色柔焦光晕 + 纯白饱满星体）
            buildOctagramPath(
                octPath,
                cx = 0f,
                cy = 0f,
                rMajor = rDial * 0.375f,
                rMinor = rDial * 0.255f,
                rWaist = rDial * 0.126f
            )
            p.style = Paint.Style.STROKE
            p.strokeJoin = Paint.Join.ROUND
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = max(4.0f, rDial * 0.12f)
            p.color = withA(pal.bloomColor, (dialAlpha * (if (pal.isLight) 0.68f else 0.40f) * 255f).toInt())
            canvas.drawPath(octPath, p)
            p.strokeWidth = max(2.4f, rDial * 0.06f)
            p.color = withA(pal.midRimColor, (dialAlpha * (if (pal.isLight) 0.78f else 0.55f) * 255f).toInt())
            canvas.drawPath(octPath, p)

            p.style = Paint.Style.FILL
            p.color = withA(pal.coreWhite, (dialAlpha * 1.0f * 255f).toInt())
            canvas.drawPath(octPath, p)

            // (d) 左上 (-135°) 与右下 (+45°) 对角双行星圆点
            val planetOrbitR = rDial * 0.305f
            val planetR = max(2.0f, rDial * 0.036f)
            for (deg in intArrayOf(-135, 45)) {
                val rad = Math.toRadians(deg.toDouble())
                val px = (planetOrbitR * cos(rad)).toFloat()
                val py = (planetOrbitR * sin(rad)).toFloat()
                p.color = withA(pal.bloomColor, (dialAlpha * (if (pal.isLight) 0.72f else 0.45f) * 255f).toInt())
                canvas.drawCircle(px, py, planetR * 2.1f, p)
                p.color = withA(pal.coreWhite, (dialAlpha * 0.98f * 255f).toInt())
                canvas.drawCircle(px, py, planetR, p)
            }
        }

        // ====================================================================
        // 5. 饱满星珠点缀
        // ====================================================================
        if (density > 0.15f && ribbonAlpha > 0.02f) {
            p.style = Paint.Style.FILL
            val activeCount = ((PEARLS.size / 3) * density.coerceIn(0.2f, 1f)).toInt().coerceIn(2, PEARLS.size / 3)
            for (idx in 0 until activeCount) {
                val base = idx * 3
                val px = PEARLS[base] * R
                val py = PEARLS[base + 1] * R
                val pr = max(1.6f, PEARLS[base + 2] * R)
                p.color = withA(pal.bloomColor, (ribbonAlpha * (if (pal.isLight) 0.68f else 0.40f) * 255f).toInt())
                canvas.drawCircle(px, py, pr * 2.1f, p)
                p.color = withA(pal.coreWhite, (ribbonAlpha * 0.96f * 255f).toInt())
                canvas.drawCircle(px, py, pr, p)
            }
        }

        canvas.restore()
    }

    /**
     * 绘制饱满发光路径：5 层同色系柔焦羽化光晕垫底 + 2 层加粗纯白星芯
     */
    private fun drawPlumpGlowingPath(
        canvas: Canvas,
        path: Path,
        baseWidth: Float,
        pal: StarPalette,
        alpha: Float
    ) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        val wMults = if (pal.isLight) LIGHT_HALO_WIDTH_MULTS else DARK_HALO_WIDTH_MULTS
        val aMults = if (pal.isLight) LIGHT_HALO_ALPHA_MULTS else DARK_HALO_ALPHA_MULTS

        for (k in 0 until wMults.size) {
            p.strokeWidth = max(2.2f, baseWidth * wMults[k])
            val col = if (k < 4) pal.bloomColor else pal.midRimColor
            val layerA = (alpha * aMults[k] * 255f).toInt()
            p.color = withA(col, layerA)
            canvas.drawPath(path, p)
        }

        // 内层加粗纯白发光芯（比上一版加粗 2.2 倍，浅色/深色键面上都饱满清晰）
        p.strokeWidth = max(2.8f, baseWidth * 0.78f)
        p.color = withA(pal.coreWhite, (alpha * 0.72f * 255f).toInt())
        canvas.drawPath(path, p)

        p.strokeWidth = max(2.0f, baseWidth * 0.52f)
        p.color = withA(pal.coreWhite, (alpha * 0.98f * 255f).toInt())
        canvas.drawPath(path, p)
    }

    private fun drawTaperedCometRibbon(
        canvas: Canvas,
        xs: FloatArray,
        ys: FloatArray,
        R: Float,
        pal: StarPalette,
        alpha: Float,
        isArch: Boolean
    ) {
        segPath.reset()
        segPath.moveTo(xs[0], ys[0])
        for (i in 1..RIBBON_STEPS) {
            segPath.lineTo(xs[i], ys[i])
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        // 丝带外围同色系柔焦光晕
        p.strokeWidth = max(4.0f, R * 0.14f)
        p.color = withA(pal.bloomColor, (alpha * (if (pal.isLight) 0.42f else 0.25f) * 255f).toInt())
        canvas.drawPath(segPath, p)

        p.strokeWidth = max(2.8f, R * 0.085f)
        p.color = withA(pal.bloomColor, (alpha * (if (pal.isLight) 0.68f else 0.42f) * 255f).toInt())
        canvas.drawPath(segPath, p)

        // 分段绘制加粗收尖纯白亮芯
        for (i in 0 until RIBBON_STEPS) {
            val u = i.toFloat() / RIBBON_STEPS.toFloat()
            val env = if (isArch) {
                sin(u * PI_F).pow(0.62f)
            } else {
                (1f - 0.68f * u) * min(1f, u * 5.0f)
            }
            if (env <= 0.05f) continue
            p.strokeWidth = max(1.8f, R * 0.048f * env)
            p.color = withA(pal.coreWhite, (alpha * 0.95f * env * 255f).toInt())
            canvas.drawLine(xs[i], ys[i], xs[i + 1], ys[i + 1], p)
        }
    }

    private fun sampleCubicBezier(
        x0: Float, y0: Float,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        x3: Float, y3: Float,
        outX: FloatArray,
        outY: FloatArray
    ) {
        for (s in 0..RIBBON_STEPS) {
            val u = s.toFloat() / RIBBON_STEPS.toFloat()
            val inv = 1f - u
            val b0 = inv * inv * inv
            val b1 = 3f * inv * inv * u
            val b2 = 3f * inv * u * u
            val b3 = u * u * u
            outX[s] = b0 * x0 + b1 * x1 + b2 * x2 + b3 * x3
            outY[s] = b0 * y0 + b1 * y1 + b2 * y2 + b3 * y3
        }
    }

    private fun drawSolidSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: StarPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(3.2f, r * 0.65f)
        p.color = withA(pal.bloomColor, (alpha * (if (pal.isLight) 0.68f else 0.42f) * 255f).toInt())
        canvas.drawPath(sparklePath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.coreWhite, (alpha * 1.0f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    private fun drawHollowSparkle4(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float,
        alpha: Float,
        pal: StarPalette
    ) {
        if (r <= 0.5f || alpha <= 0.01f) return
        buildSparkle4Path(sparklePath, cx, cy, r, waistK, rotDeg)
        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(3.6f, r * 0.72f)
        p.color = withA(pal.bloomColor, (alpha * (if (pal.isLight) 0.68f else 0.40f) * 255f).toInt())
        canvas.drawPath(sparklePath, p)

        p.strokeWidth = max(2.0f, r * 0.34f)
        p.color = withA(pal.coreWhite, (alpha * 0.96f * 255f).toInt())
        canvas.drawPath(sparklePath, p)
    }

    private fun drawCrescentMoon(
        canvas: Canvas,
        mcx: Float,
        mcy: Float,
        outerR: Float,
        cutR: Float,
        offset: Float,
        openAngleDeg: Float,
        alpha: Float,
        pal: StarPalette
    ) {
        val rad = Math.toRadians(openAngleDeg.toDouble())
        val cutX = mcx + (offset * cos(rad)).toFloat()
        val cutY = mcy + (offset * sin(rad)).toFloat()

        moonOuterPath.reset()
        moonOuterPath.addCircle(mcx, mcy, outerR, Path.Direction.CW)
        moonCutPath.reset()
        moonCutPath.addCircle(cutX, cutY, cutR, Path.Direction.CW)
        moonOuterPath.op(moonCutPath, Path.Op.DIFFERENCE)

        p.style = Paint.Style.STROKE
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = max(3.2f, outerR * 0.62f)
        p.color = withA(pal.bloomColor, (alpha * (if (pal.isLight) 0.68f else 0.40f) * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)

        p.style = Paint.Style.FILL
        p.color = withA(pal.coreWhite, (alpha * 0.98f * 255f).toInt())
        canvas.drawPath(moonOuterPath, p)
    }

    private fun buildOctagramPath(
        out: Path,
        cx: Float,
        cy: Float,
        rMajor: Float,
        rMinor: Float,
        rWaist: Float
    ) {
        out.reset()
        for (i in 0 until 16) {
            val ang = Math.toRadians(-90.0 + i * 22.5)
            val r = when {
                i % 4 == 0 -> rMajor
                i % 2 == 0 -> rMinor
                else -> rWaist
            }
            val x = cx + (r * cos(ang)).toFloat()
            val y = cy + (r * sin(ang)).toFloat()
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }

    private fun buildSparkle4Path(
        out: Path,
        cx: Float,
        cy: Float,
        r: Float,
        waistK: Float,
        rotDeg: Float
    ) {
        out.reset()
        for (i in 0 until 4) {
            val a0 = Math.toRadians((rotDeg + i * 90f - 90f).toDouble())
            val a1 = Math.toRadians((rotDeg + (i + 1) * 90f - 90f).toDouble())
            val amid = Math.toRadians((rotDeg + i * 90f - 45f).toDouble())
            val x0 = cx + (r * cos(a0)).toFloat()
            val y0 = cy + (r * sin(a0)).toFloat()
            val xm = cx + (r * waistK * cos(amid)).toFloat()
            val ym = cy + (r * waistK * sin(amid)).toFloat()
            val x1 = cx + (r * cos(a1)).toFloat()
            val y1 = cy + (r * sin(a1)).toFloat()
            if (i == 0) out.moveTo(x0, y0)
            out.quadTo(xm, ym, x1, y1)
        }
        out.close()
    }

    private fun buildRoundedStarPath(
        out: Path,
        cx: Float,
        cy: Float,
        outer: Float,
        inner: Float,
        points: Int,
        rotDeg: Float,
        k: Float
    ) {
        out.reset()
        val n = points * 2
        for (i in 0 until n) {
            val r = if (i % 2 == 0) outer else inner
            val a = Math.toRadians(rotDeg + i * 180.0 / points)
            starVx[i] = cx + (r * cos(a)).toFloat()
            starVy[i] = cy + (r * sin(a)).toFloat()
        }
        var first = true
        for (i in 0 until n) {
            val pv = (i - 1 + n) % n
            val nv = (i + 1) % n
            val px = starVx[i] + (starVx[pv] - starVx[i]) * k
            val py = starVy[i] + (starVy[pv] - starVy[i]) * k
            val qx = starVx[i] + (starVx[nv] - starVx[i]) * k
            val qy = starVy[i] + (starVy[nv] - starVy[i]) * k
            if (first) {
                out.moveTo(px, py)
                first = false
            } else {
                out.lineTo(px, py)
            }
            out.quadTo(starVx[i], starVy[i], qx, qy)
        }
        out.close()
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun withA(color: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(color), Color.green(color), Color.blue(color))
}
