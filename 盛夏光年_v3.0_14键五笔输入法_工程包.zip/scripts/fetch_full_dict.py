#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pre-compiles 86 Wubi + Segmented Pinyin + T14 Codes + Word Associations at build time
so the Android app loads in <150ms and queries in <0.1ms with zero UI lag.
"""
import os
import urllib.request
from collections import defaultdict

ASSETS_DIR = "app/src/main/assets"
os.makedirs(ASSETS_DIR, exist_ok=True)

WUBI_URL = "https://raw.githubusercontent.com/rime/rime-wubi/master/wubi86.dict.yaml"
RIME_ICE_8105_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/8105.dict.yaml"
RIME_ICE_BASE_URL = "https://raw.githubusercontent.com/iDvel/rime-ice/main/cn_dicts/base.dict.yaml"
LUNA_PINYIN_URL = "https://raw.githubusercontent.com/rime/rime-luna-pinyin/master/luna_pinyin.dict.yaml"

CHAR_TO_T14 = {
    'q': '1', 'w': '1',
    'e': '2', 'r': '2',
    't': '3', 'y': '3',
    'u': '4', 'i': '4',
    'o': '5', 'p': '5',
    'a': '6', 's': '6',
    'd': '7', 'f': '7',
    'g': '8', 'h': '8',
    'j': '9', 'k': '9',
    'l': '0',
    'z': 'a', 'x': 'a',
    'c': 'b', 'v': 'b',
    'b': 'c', 'n': 'c',
    'm': 'd'
}

def to_t14(s):
    return "".join(CHAR_TO_T14.get(c, "") for c in s.lower())

def to_t14_abbr(seg_py):
    if "'" not in seg_py:
        return ""
    return "".join(CHAR_TO_T14.get(p[0], "") for p in seg_py.split("'") if p)

def download_lines(url):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=25) as resp:
            return resp.read().decode("utf-8", errors="ignore").splitlines()
    except Exception as e:
        print(f"Warning: Could not download {url}: {e}")
        return []

def clean_py_syllable(s):
    s = s.strip().lower()
    return "".join(ch for ch in s if 'a' <= ch <= 'z')

def parse_rime_yaml(lines):
    in_body = False
    for line in lines:
        line = line.strip()
        if line == "...":
            in_body = True
            continue
        if not in_body or not line or line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            word = parts[0].strip()
            code = parts[1].strip()
            weight = 500
            if len(parts) >= 3:
                w_str = parts[2].strip().rstrip("%")
                try:
                    weight = int(float(w_str))
                except ValueError:
                    weight = 500
            yield word, code, weight

def main():
    wubi_lines = download_lines(WUBI_URL)
    ice_8105_lines = download_lines(RIME_ICE_8105_URL)
    ice_base_lines = download_lines(RIME_ICE_BASE_URL)
    luna_lines = download_lines(LUNA_PINYIN_URL)

    if not wubi_lines:
        print("Offline mode: keeping starter dictionary.")
        return

    single_char_wubi = {}
    single_char_py = {}
    single_char_weight = {}
    word_py_map = {}

    for word, raw_py, weight in parse_rime_yaml(ice_8105_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if len(word) == 1 and syllables:
            if word not in single_char_py or weight > single_char_weight.get(word, 0):
                single_char_py[word] = syllables[0]
                single_char_weight[word] = max(weight, 500)

    for word, raw_py, weight in parse_rime_yaml(luna_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables:
            continue
        seg_py = "'".join(syllables)
        if len(word) == 1 and word not in single_char_py:
            single_char_py[word] = syllables[0]
        if word not in word_py_map:
            word_py_map[word] = (seg_py, max(weight, 500))

    for word, raw_py, weight in parse_rime_yaml(ice_base_lines):
        syllables = [clean_py_syllable(x) for x in raw_py.split(" ") if clean_py_syllable(x)]
        if not syllables or len(word) > 6:
            continue
        seg_py = "'".join(syllables)
        if word not in word_py_map or weight > word_py_map[word][1]:
            word_py_map[word] = (seg_py, max(weight, 500))

    wubi_entries = []
    seen_pairs = set()
    for word, raw_code, weight in parse_rime_yaml(wubi_lines):
        code = raw_code.strip().lower()
        if not word or not code or not code.isalpha():
            continue
        if len(word) == 1:
            if word not in single_char_wubi or len(code) > len(single_char_wubi[word]):
                single_char_wubi[word] = code
            # Boost common single characters using 8105 weight
            weight = max(weight, single_char_weight.get(word, 400))
        else:
            weight = max(weight, word_py_map.get(word, ("", 400))[1])
        if (word, code) not in seen_pairs:
            seen_pairs.add((word, code))
            wubi_entries.append((word, code, weight))

    def gen_wubi86(word):
        if len(word) == 1:
            return single_char_wubi.get(word, "")[:4]
        codes = [single_char_wubi.get(ch, "") for ch in word]
        if any(not c for c in codes):
            return ""
        if len(word) == 2:
            return codes[0][:2] + codes[1][:2]
        elif len(word) == 3:
            return codes[0][:1] + codes[1][:1] + codes[2][:2]
        else:
            return codes[0][:1] + codes[1][:1] + codes[2][:1] + codes[-1][:1]

    def gen_seg_pinyin(word):
        if word in word_py_map:
            return word_py_map[word][0]
        syls = [single_char_py.get(ch, "") for ch in word]
        if all(syls):
            return "'".join(syls)
        return ""

    extra_modern = [
        ("薅羊毛", "hao'yang'mao", 9500),
        ("高羊茅", "gao'yang'mao", 6000),
        ("盛夏光年", "sheng'xia'guang'nian", 9900),
        ("尴尬", "gan'ga", 9000),
        ("角色扮演", "jue'se'ban'yan", 8500),
        ("世界观", "shi'jie'guan", 8500)
    ]
    for w, py, wt in extra_modern:
        word_py_map[w] = (py, wt)

    compiled_rows = []
    seen_words_for_py = set()

    for word, wcode, weight in wubi_entries:
        seg_py = gen_seg_pinyin(word)
        seen_words_for_py.add(word)
        compiled_rows.append((word, wcode, seg_py, weight))

    # Add top 22,000 popular Pinyin words not already in wubi_entries
    extra_py_candidates = []
    for word, (seg_py, weight) in word_py_map.items():
        if word not in seen_words_for_py and 1 <= len(word) <= 5:
            extra_py_candidates.append((weight, word, seg_py))
    extra_py_candidates.sort(reverse=True)

    for weight, word, seg_py in extra_py_candidates[:22000]:
        wcode = gen_wubi86(word)
        if wcode or seg_py:
            compiled_rows.append((word, wcode, seg_py, weight))
            seen_words_for_py.add(word)

    # Sort all rows by weight descending so the Android app doesn't even need to sort at runtime!
    compiled_rows.sort(key=lambda x: x[3], reverse=True)
    compiled_rows = compiled_rows[:72000]

    # Write pre-compiled TSV:
    # word \t wubi_code \t seg_pinyin \t t14_wubi \t t14_pinyin \t t14_abbr \t weight
    out_path = os.path.join(ASSETS_DIR, "wubi86_dict.tsv")
    with open(out_path, "w", encoding="utf-8") as f:
        for word, wcode, seg_py, weight in compiled_rows:
            t14_w = to_t14(wcode) if wcode else ""
            t14_p = to_t14(seg_py.replace("'", "")) if seg_py else ""
            t14_a = to_t14_abbr(seg_py)
            f.write(f"{word}\t{wcode}\t{seg_py}\t{t14_w}\t{t14_p}\t{t14_a}\t{weight}\n")

    # Build word association table (assoc_dict.tsv): prefix -> suffix1,suffix2,...
    assoc_map = defaultdict(list)
    for word, _, _, weight in compiled_rows:
        if len(word) >= 2:
            # 1-char prefix -> remaining suffix
            p1 = word[0]
            s1 = word[1:]
            if len(assoc_map[p1]) < 16 and s1 not in assoc_map[p1]:
                assoc_map[p1].append(s1)
            # 2-char prefix -> remaining suffix (for 3-4 char idioms/phrases)
            if len(word) >= 3:
                p2 = word[:2]
                s2 = word[2:]
                if len(assoc_map[p2]) < 12 and s2 not in assoc_map[p2]:
                    assoc_map[p2].append(s2)

    assoc_path = os.path.join(ASSETS_DIR, "assoc_dict.tsv")
    with open(assoc_path, "w", encoding="utf-8") as f:
        for prefix, suffixes in assoc_map.items():
            if suffixes:
                f.write(f"{prefix}\t{','.join(suffixes)}\n")

    # Write single_char_wubi.tsv
    single_path = os.path.join(ASSETS_DIR, "single_char_wubi.tsv")
    with open(single_path, "w", encoding="utf-8") as f:
        all_chars = set(single_char_wubi.keys()) | set(single_char_py.keys())
        for ch in all_chars:
            wcode = single_char_wubi.get(ch, "")
            py = single_char_py.get(ch, "")
            f.write(f"{ch}\t{wcode}\t{py}\n")

    print(f"Pre-compiled {len(compiled_rows)} entries and {len(assoc_map)} association prefixes!")

if __name__ == "__main__":
    main()
