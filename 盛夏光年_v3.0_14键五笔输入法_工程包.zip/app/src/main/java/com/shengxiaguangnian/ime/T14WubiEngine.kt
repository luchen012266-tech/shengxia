package com.shengxiaguangnian.ime

import android.content.Context
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

data class Candidate(
    val word: String,
    val wubiHint: String?,     // 拼音打出字时显示 86 五笔拆分码
    val displayCode: String,   // 左上角浮窗显示的编码，如 "hao'yang'mao" 或 "autf"
    val weight: Int,
    val isWubiMatch: Boolean,
    val consumedKeys: Int = 0
)

data class DictEntry(
    val word: String,
    val wubiCode: String,
    val segmentedPinyin: String,
    val t14Wubi: String,
    val t14Pinyin: String,
    val t14PyAbbr: String,
    val weight: Int
)

object T14WubiEngine {
    private val CHAR_TO_T14 = mapOf(
        'q' to '1', 'w' to '1',
        'e' to '2', 'r' to '2',
        't' to '3', 'y' to '3',
        'u' to '4', 'i' to '4',
        'o' to '5', 'p' to '5',
        'a' to '6', 's' to '6',
        'd' to '7', 'f' to '7',
        'g' to '8', 'h' to '8',
        'j' to '9', 'k' to '9',
        'l' to '0',
        'z' to 'a', 'x' to 'a',
        'c' to 'b', 'v' to 'b',
        'b' to 'c', 'n' to 'c',
        'm' to 'd'
    )

    private val VALID_SYLLABLES = listOf(
        "zhuang", "shuang", "chuang", "zhuan", "shuan", "chuan", "guang", "kuang", "huang",
        "zhang", "shang", "chang", "zhong", "chong", "zheng", "sheng", "cheng",
        "liang", "niang", "jiang", "qiang", "xiang", "xiong", "qiong", "jiong",
        "zhan", "shan", "chan", "zhen", "shen", "chen", "zhou", "shou", "chou",
        "zhua", "shua", "chua", "zhui", "shui", "chui", "zhuo", "shuo", "chuo", "zhai", "shai", "chai", "zhao", "shao", "chao",
        "bang", "pang", "mang", "fang", "dang", "tang", "nang", "lang", "gang", "kang", "hang", "wang", "yang", "zang", "cang", "sang", "rang",
        "beng", "peng", "meng", "feng", "deng", "teng", "neng", "leng", "geng", "keng", "heng", "weng", "ying", "zeng", "ceng", "seng", "reng",
        "bing", "ping", "ming", "ding", "ting", "ning", "ling", "jing", "qing", "xing",
        "dong", "tong", "nong", "long", "gong", "kong", "hong", "yong", "zong", "cong", "song", "rong",
        "bian", "pian", "mian", "dian", "tian", "nian", "lian", "jian", "qian", "xian",
        "biao", "piao", "miao", "diao", "tiao", "niao", "liao", "jiao", "qiao", "xiao",
        "duan", "tuan", "nuan", "luan", "guan", "kuan", "huan", "juan", "quan", "xuan", "zuan", "cuan", "suan", "ruan",
        "yuan",
        "ban", "pan", "man", "fan", "dan", "tan", "nan", "lan", "gan", "kan", "han", "wan", "yan", "zan", "can", "san", "ran",
        "ben", "pen", "men", "fen", "den", "nen", "gen", "ken", "hen", "wen", "zen", "cen", "sen", "ren",
        "bin", "pin", "min", "nin", "lin", "jin", "qin", "xin", "yin",
        "dun", "tun", "lun", "gun", "kun", "hun", "jun", "qun", "xun", "zun", "cun", "sun", "run",
        "bai", "pai", "mai", "dai", "tai", "nai", "lai", "gai", "kai", "hai", "wai", "zai", "cai", "sai",
        "bei", "pei", "mei", "fei", "dei", "nei", "lei", "gei", "kei", "hei", "wei", "zei",
        "bao", "pao", "mao", "dao", "tao", "nao", "lao", "gao", "kao", "hao", "yao", "zao", "cao", "sao", "rao",
        "bou", "pou", "mou", "fou", "dou", "tou", "nou", "lou", "gou", "kou", "hou", "you", "zou", "cou", "sou", "rou",
        "dui", "tui", "gui", "kui", "hui", "zui", "cui", "sui", "rui",
        "duo", "tuo", "nuo", "luo", "guo", "kuo", "huo", "zuo", "cuo", "suo", "ruo",
        "dia", "lia", "jia", "qia", "xia", "gua", "kua", "hua",
        "bie", "pie", "mie", "die", "tie", "nie", "lie", "jie", "qie", "xie", "yue", "jue", "que", "xue", "nue", "lue",
        "diu", "niu", "liu", "jiu", "qiu", "xiu",
        "zhi", "chi", "shi", "zhu", "chu", "shu", "zha", "cha", "sha", "zhe", "che", "she",
        "ba", "pa", "ma", "fa", "da", "ta", "na", "la", "ga", "ka", "ha", "wa", "ya", "za", "ca", "sa",
        "bo", "po", "mo", "fo", "lo", "wo", "yo",
        "me", "de", "te", "ne", "le", "ge", "ke", "he", "ze", "ce", "se", "re", "ye",
        "bi", "pi", "mi", "di", "ti", "ni", "li", "ji", "qi", "xi", "yi", "zi", "ci", "si", "ri",
        "bu", "pu", "mu", "fu", "du", "tu", "nu", "lu", "gu", "ku", "hu", "wu", "yu", "zu", "cu", "su", "ru", "ju", "qu", "xu",
        "lv", "nv", "ai", "ei", "ao", "ou", "an", "en", "ang", "eng", "er", "a", "o", "e"
    )

    // O(1) 哈希索引表（消灭全表遍历，打字零延迟！）
    private val wubiExactIndex = HashMap<String, MutableList<DictEntry>>(20000)
    private val wubiPrefixIndex = HashMap<String, MutableList<DictEntry>>(6000)
    private val pinyinExactIndex = HashMap<String, MutableList<DictEntry>>(35000)
    private val pinyinPrefixIndex = HashMap<String, MutableList<DictEntry>>(30000)
    private val pinyinAbbrIndex = HashMap<String, MutableList<DictEntry>>(12000)

    private val t14SyllableMap = LinkedHashMap<String, String>()
    private val t14SingleCharByPy = HashMap<String, MutableList<DictEntry>>()

    private val singleCharWubi = HashMap<Char, String>(9500)
    private val singleCharPinyin = HashMap<Char, String>(9500)
    private val userEntries = ArrayList<DictEntry>()

    // 个人高频词频与前后词联想缓存
    private val userFreqMap = HashMap<String, Int>()
    private val userBigramMap = HashMap<String, MutableList<String>>()
    private val builtInAssocMap = HashMap<String, List<String>>(15000)
    private val defaultCommonAssoc = listOf("的", "了", "是", "在", "我", "有", "和", "就", "不", "都", "也", "很", "可以", "什么", "自己", "知道", "觉得", "现在")

    private val isLoaded = AtomicBoolean(false)
    private val isLoading = AtomicBoolean(false)
    private val userDictDirty = AtomicBoolean(false)

    fun markUserDictDirty() {
        userDictDirty.set(true)
    }

    fun letterToT14Code(letters: String): String {
        val sb = StringBuilder(letters.length)
        for (ch in letters.lowercase()) {
            val mapped = CHAR_TO_T14[ch]
            if (mapped != null) sb.append(mapped)
        }
        return sb.toString()
    }

    private fun extractPyAbbrT14(segmentedPy: String): String {
        if (!segmentedPy.contains('\'')) return ""
        val sb = StringBuilder()
        for (part in segmentedPy.split('\'')) {
            if (part.isNotEmpty()) {
                val m = CHAR_TO_T14[part[0].lowercaseChar()]
                if (m != null) sb.append(m)
            }
        }
        return sb.toString()
    }

    fun ensureInitializedAsync(context: Context, dbHelper: ImeDatabaseHelper) {
        if (isLoaded.get()) {
            if (userDictDirty.compareAndSet(true, false)) {
                Thread { reloadUserDict(dbHelper) }.start()
            }
            return
        }
        if (!isLoading.compareAndSet(false, true)) return
        val appCtx = context.applicationContext
        Thread {
            loadAllInternal(appCtx, dbHelper)
            isLoaded.set(true)
            isLoading.set(false)
        }.start()
    }

    // 兼容同步调用（若已加载则 0ms 立即返回）
    fun ensureInitialized(context: Context, dbHelper: ImeDatabaseHelper) {
        ensureInitializedAsync(context, dbHelper)
    }

    private fun loadAllInternal(context: Context, dbHelper: ImeDatabaseHelper) {
        for (syl in VALID_SYLLABLES) {
            val code = letterToT14Code(syl)
            if (!t14SyllableMap.containsKey(code)) {
                t14SyllableMap[code] = syl
            }
        }

        // 1. 加载单字五笔与拼音码表
        try {
            context.assets.open("single_char_wubi.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 2 && parts[0].length == 1) {
                        val ch = parts[0][0]
                        val wcode = parts[1].trim().lowercase()
                        val py = if (parts.size >= 3) parts[2].trim().lowercase() else ""
                        if (wcode.isNotEmpty()) singleCharWubi[ch] = wcode
                        if (py.isNotEmpty()) singleCharPinyin[ch] = py
                    }
                }
            }
        } catch (_: Exception) {}

        // 2. 加载词语联想表 (assoc_dict.tsv)
        try {
            context.assets.open("assoc_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).forEachLine { line ->
                    val tab = line.indexOf('\t')
                    if (tab > 0) {
                        val prefix = line.substring(0, tab)
                        val suffixes = line.substring(tab + 1).split(',').filter { it.isNotEmpty() }
                        if (suffixes.isNotEmpty()) {
                            builtInAssocMap[prefix] = suffixes
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. 加载主词库并建立 O(1) 哈希索引（支持 7 列预编译格式与 4 列兼容格式）
        try {
            context.assets.open("wubi86_dict.tsv").use { ins ->
                BufferedReader(InputStreamReader(ins, Charsets.UTF_8), 65536).forEachLine { line ->
                    val parts = line.split('\t')
                    if (parts.size >= 4) {
                        val word = parts[0]
                        val wcode = parts[1]
                        val segPy = parts[2]
                        val t14W: String
                        val t14P: String
                        val t14A: String
                        val weight: Int
                        if (parts.size >= 7) {
                            t14W = parts[3]
                            t14P = parts[4]
                            t14A = parts[5]
                            weight = parts[6].toIntOrNull() ?: 500
                        } else {
                            t14W = if (wcode.isNotEmpty()) letterToT14Code(wcode) else ""
                            t14P = if (segPy.isNotEmpty()) letterToT14Code(segPy.replace("'", "")) else ""
                            t14A = extractPyAbbrT14(segPy)
                            weight = parts[3].toIntOrNull() ?: 500
                        }

                        if (word.isNotEmpty()) {
                            val de = DictEntry(word, wcode, segPy, t14W, t14P, t14A, weight)
                            indexEntry(de)
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        userFreqMap.putAll(dbHelper.loadUserFreqMap())
        userBigramMap.putAll(dbHelper.loadUserBigramMap())
        reloadUserDict(dbHelper)
    }

    private fun indexEntry(de: DictEntry) {
        // 索引 1：五笔精确与前缀索引
        if (de.t14Wubi.isNotEmpty()) {
            val exactList = wubiExactIndex.getOrPut(de.t14Wubi) { ArrayList(4) }
            if (exactList.size < 45) exactList.add(de)

            val maxPref = minOf(3, de.t14Wubi.length - 1)
            for (len in 1..maxPref) {
                val pref = de.t14Wubi.substring(0, len)
                val pList = wubiPrefixIndex.getOrPut(pref) { ArrayList(8) }
                if (pList.size < 35) pList.add(de)
            }
        }

        // 索引 2：拼音精确、前缀与简拼索引
        if (de.t14Pinyin.isNotEmpty()) {
            val pyExact = pinyinExactIndex.getOrPut(de.t14Pinyin) { ArrayList(4) }
            if (pyExact.size < 45) pyExact.add(de)

            if (de.word.length == 1 && pyExact.size <= 6) {
                val scList = t14SingleCharByPy.getOrPut(de.t14Pinyin) { ArrayList(4) }
                if (scList.size < 6) scList.add(de)
            }

            val maxPyPref = minOf(8, de.t14Pinyin.length - 1)
            for (len in 1..maxPyPref) {
                val pref = de.t14Pinyin.substring(0, len)
                val pList = pinyinPrefixIndex.getOrPut(pref) { ArrayList(8) }
                if (pList.size < 30) pList.add(de)
            }
        }

        if (de.t14PyAbbr.length in 2..5) {
            val aList = pinyinAbbrIndex.getOrPut(de.t14PyAbbr) { ArrayList(4) }
            if (aList.size < 25) aList.add(de)
        }
    }

    fun reloadUserDict(dbHelper: ImeDatabaseHelper) {
        val temp = ArrayList<DictEntry>()
        try {
            dbHelper.readableDatabase.rawQuery(
                "SELECT word, wubi_code, pinyin_code, t14_wubi, t14_pinyin, weight FROM user_dict ORDER BY id DESC",
                null
            ).use { c ->
                while (c.moveToNext()) {
                    val w = c.getString(0)
                    val wc = c.getString(1)
                    val py = c.getString(2).ifEmpty { generateSegmentedPinyinForWord(w) }
                    temp.add(
                        DictEntry(
                            word = w,
                            wubiCode = wc,
                            segmentedPinyin = py,
                            t14Wubi = c.getString(3),
                            t14Pinyin = c.getString(4),
                            t14PyAbbr = extractPyAbbrT14(py),
                            weight = c.getInt(5)
                        )
                    )
                }
            }
            synchronized(userEntries) {
                userEntries.clear()
                userEntries.addAll(temp)
            }
        } catch (_: Exception) {}
    }

    /**
     * 记录用户输入的高频字词与前后词联想（内存即时生效 + 数据库异步持久化）
     */
    fun onWordCommitted(word: String, prevWord: String?, dbHelper: ImeDatabaseHelper) {
        if (word.isEmpty()) return
        userFreqMap[word] = (userFreqMap[word] ?: 0) + 1
        if (!prevWord.isNullOrEmpty() && prevWord != word) {
            val list = userBigramMap.getOrPut(prevWord) { ArrayList() }
            list.remove(word)
            list.add(0, word)
            if (list.size > 12) list.removeAt(list.lastIndex)
        }
        dbHelper.recordWordUsageAsync(word, prevWord)
    }

    /**
     * 获取词语联想（上屏后自动联想下一词或词尾后缀）
     */
    fun getAssociations(committedWord: String, limit: Int = 28): List<String> {
        if (committedWord.isEmpty()) return emptyList()
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>()

        // 1. 优先推荐用户自己平时高频连打的下一词 (user_bigram)
        userBigramMap[committedWord]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }
        val lastCharStr = committedWord.takeLast(1)
        userBigramMap[lastCharStr]?.forEach { nextW ->
            if (seen.add(nextW)) result.add(nextW)
        }

        // 2. 推荐词库中以该词开头的常见词后缀（如打 "喜" 联想 "欢", "爱"；打 "角色" 联想 "扮演"）
        builtInAssocMap[committedWord]?.forEach { suffix ->
            if (seen.add(suffix) && result.size < limit) result.add(suffix)
        }
        if (committedWord.length >= 2) {
            builtInAssocMap[lastCharStr]?.forEach { suffix ->
                if (seen.add(suffix) && result.size < limit) result.add(suffix)
            }
        }

        // 3. 补充高频通用衔接词
        for (cw in defaultCommonAssoc) {
            if (cw != committedWord && seen.add(cw) && result.size < limit) {
                result.add(cw)
            }
        }
        return result
    }

    fun generateWubi86CodeForWord(word: String): String {
        val clean = word.trim()
        if (clean.isEmpty()) return ""
        val codes = clean.map { ch -> singleCharWubi[ch] ?: "" }
        if (codes.any { it.isEmpty() }) return ""
        return when (clean.length) {
            1 -> codes[0].take(4)
            2 -> codes[0].take(2) + codes[1].take(2)
            3 -> codes[0].take(1) + codes[1].take(1) + codes[2].take(2)
            else -> codes[0].take(1) + codes[1].take(1) + codes[2].take(1) + codes.last().take(1)
        }
    }

    fun generateSegmentedPinyinForWord(word: String): String {
        val syls = ArrayList<String>()
        for (ch in word.trim()) {
            val py = singleCharPinyin[ch] ?: return ""
            syls.add(py)
        }
        return syls.joinToString("'")
    }

    fun segmentT14ToPinyinDisplay(t14Input: String, fallbackRaw: String): String {
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isEmpty()) return fallbackRaw
        return sylCodes.joinToString("'") { code -> t14SyllableMap[code] ?: code }
    }

    private fun segmentT14SyllableCodes(t14Input: String): List<String> {
        val res = ArrayList<String>()
        var i = 0
        val n = t14Input.length
        while (i < n) {
            var matchedLen = 0
            val maxLen = minOf(6, n - i)
            for (len in maxLen downTo 1) {
                val sub = t14Input.substring(i, i + len)
                if (t14SyllableMap.containsKey(sub)) {
                    matchedLen = len
                    res.add(sub)
                    break
                }
            }
            if (matchedLen == 0) {
                res.add(t14Input.substring(i, i + 1))
                i += 1
            } else {
                i += matchedLen
            }
        }
        return res
    }

    /**
     * O(1) 哈希索引极速查询（<0.1ms）：
     * - 严格保证 1~4 码时：五笔词排前面（精确五笔 -> 前缀五笔），拼音词排后面（精确拼音 -> 简拼 -> 前缀拼音）！
     * - 结合个人输入习惯（userFreqMap）：常打的字词在各自组内自动排在最前面！
     */
    fun queryCandidates(t14Input: String, rawFallback: String, limit: Int = 90): List<Candidate> {
        if (t14Input.isEmpty() || !isLoaded.get()) return emptyList()

        val exactWubi = ArrayList<Candidate>(32)
        val prefixWubi = ArrayList<Candidate>(32)
        val exactPinyin = ArrayList<Candidate>(40)
        val abbrPinyin = ArrayList<Candidate>(24)
        val prefixPinyin = ArrayList<Candidate>(32)
        val seen = HashSet<String>(128)

        val isLongPinyinMode = t14Input.length > 4
        val segmentedDisplay = segmentT14ToPinyinDisplay(t14Input, rawFallback)

        fun userBoost(word: String): Int {
            val f = userFreqMap[word] ?: 0
            return if (f > 0) (f * 80000).coerceAtMost(2000000) else 0
        }

        // 1. 先查用户自造词/导入词库
        synchronized(userEntries) {
            for (e in userEntries) {
                val uBoost = 100000 + userBoost(e.word)
                if (!isLongPinyinMode && e.t14Wubi.isNotEmpty()) {
                    if (e.t14Wubi == t14Input && seen.add(e.word)) {
                        exactWubi.add(Candidate(e.word, null, e.wubiCode, e.weight + uBoost + 500000, true))
                        continue
                    } else if (e.t14Wubi.startsWith(t14Input) && seen.add(e.word)) {
                        prefixWubi.add(Candidate(e.word, null, e.wubiCode.take(t14Input.length), e.weight + uBoost, true))
                        continue
                    }
                }
                if (e.t14Pinyin.isNotEmpty()) {
                    if (e.t14Pinyin == t14Input && seen.add(e.word)) {
                        exactPinyin.add(Candidate(e.word, e.wubiCode, e.segmentedPinyin.ifEmpty { segmentedDisplay }, e.weight + uBoost + 300000, false))
                    } else if (e.t14Pinyin.startsWith(t14Input) && seen.add(e.word)) {
                        prefixPinyin.add(Candidate(e.word, e.wubiCode, segmentedDisplay, e.weight + uBoost, false))
                    }
                }
            }
        }

        // 2. O(1) 查五笔精确与前缀哈希索引（仅 1~4 码时启用）
        if (!isLongPinyinMode) {
            wubiExactIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    exactWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
            wubiPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    prefixWubi.add(
                        Candidate(
                            word = e.word,
                            wubiHint = null,
                            displayCode = e.wubiCode.take(t14Input.length),
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = true
                        )
                    )
                }
            }
        }

        // 3. O(1) 查拼音精确、简拼与前缀哈希索引
        pinyinExactIndex[t14Input]?.forEach { e ->
            if (seen.add(e.word)) {
                val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                exactPinyin.add(
                    Candidate(
                        word = e.word,
                        wubiHint = wHint,
                        displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                        weight = e.weight + userBoost(e.word) + e.word.length * 2000,
                        isWubiMatch = false
                    )
                )
            }
        }

        if (t14Input.length in 2..5) {
            pinyinAbbrIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    abbrPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = e.segmentedPinyin.ifEmpty { segmentedDisplay },
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        if (t14Input.length <= 8) {
            pinyinPrefixIndex[t14Input]?.forEach { e ->
                if (seen.add(e.word)) {
                    val wHint = e.wubiCode.ifEmpty { generateWubi86CodeForWord(e.word) }
                    prefixPinyin.add(
                        Candidate(
                            word = e.word,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = e.weight + userBoost(e.word),
                            isWubiMatch = false
                        )
                    )
                }
            }
        }

        // 各组内部按（个人高频加成 + 基础词频）降序排列
        if (exactWubi.size > 1) exactWubi.sortByDescending { it.weight }
        if (prefixWubi.size > 1) prefixWubi.sortByDescending { it.weight }
        if (exactPinyin.size > 1) exactPinyin.sortByDescending { it.weight }
        if (abbrPinyin.size > 1) abbrPinyin.sortByDescending { it.weight }
        if (prefixPinyin.size > 1) prefixPinyin.sortByDescending { it.weight }

        val result = ArrayList<Candidate>(limit)

        // 严格按照用户要求：五笔词排前面（精确五笔 -> 前缀五笔），拼音词排后面（精确拼音 -> 简拼 -> 前缀拼音）！
        if (!isLongPinyinMode) {
            for (c in exactWubi) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixWubi) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
        } else {
            for (c in exactPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in abbrPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
            for (c in prefixPinyin) {
                result.add(c)
                if (result.size >= limit) return result
            }
        }

        // 4. 多音节长拼音自动组词与首音节单字兜底
        val sylCodes = segmentT14SyllableCodes(t14Input)
        if (sylCodes.isNotEmpty()) {
            if (sylCodes.size >= 2) {
                val sbWord = StringBuilder()
                for (sc in sylCodes) {
                    val topChar = t14SingleCharByPy[sc]?.maxByOrNull { it.weight + userBoost(it.word) }?.word
                    if (topChar != null) sbWord.append(topChar)
                }
                val synthWord = sbWord.toString()
                if (synthWord.length >= 2 && seen.add(synthWord) && result.size < limit) {
                    val wHint = generateWubi86CodeForWord(synthWord)
                    val insertPos = if (isLongPinyinMode) exactPinyin.size.coerceAtMost(result.size) else result.size
                    result.add(
                        insertPos,
                        Candidate(
                            word = synthWord,
                            wubiHint = wHint,
                            displayCode = segmentedDisplay,
                            weight = 10000,
                            isWubiMatch = false
                        )
                    )
                }
            }
            val firstSyl = sylCodes[0]
            val firstChars = t14SingleCharByPy[firstSyl] ?: emptyList()
            for (fc in firstChars) {
                if (seen.add(fc.word) && result.size < limit) {
                    result.add(
                        Candidate(
                            word = fc.word,
                            wubiHint = fc.wubiCode,
                            displayCode = segmentedDisplay,
                            weight = fc.weight + userBoost(fc.word),
                            isWubiMatch = false,
                            consumedKeys = firstSyl.length
                        )
                    )
                }
            }
        }

        return result
    }

    fun parseSogouScel(inputStream: InputStream): List<String> {
        val bytes = inputStream.readBytes()
        if (bytes.size < 0x2628) return emptyList()
        val words = ArrayList<String>()
        try {
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var pos = 0x2628
            while (pos + 4 < bytes.size) {
                val samePyCount = buf.getShort(pos).toInt() and 0xFFFF
                val pyIdxBytesLen = buf.getShort(pos + 2).toInt() and 0xFFFF
                pos += 4 + pyIdxBytesLen
                if (samePyCount <= 0 || samePyCount > 100 || pos >= bytes.size) break
                for (i in 0 until samePyCount) {
                    if (pos + 2 >= bytes.size) break
                    val wordByteLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2
                    if (wordByteLen <= 0 || wordByteLen > 64 || pos + wordByteLen > bytes.size) break
                    val word = String(bytes, pos, wordByteLen, Charsets.UTF_16LE)
                    pos += wordByteLen
                    if (pos + 2 > bytes.size) break
                    val extLen = buf.getShort(pos).toInt() and 0xFFFF
                    pos += 2 + extLen
                    if (word.all { it in '\u4e00'..'\u9fa5' } && word.length in 2..12) {
                        words.add(word)
                    }
                }
            }
        } catch (_: Exception) {}
        return words.distinct()
    }
}
