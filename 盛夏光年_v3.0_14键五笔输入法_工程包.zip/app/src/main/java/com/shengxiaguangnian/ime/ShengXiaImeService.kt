package com.shengxiaguangnian.ime

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.math.abs

class ShengXiaImeService : InputMethodService() {

    private lateinit var dbHelper: ImeDatabaseHelper
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var prefs: SharedPreferences

    private val composingT14 = StringBuilder()
    private val composingRawLetters = StringBuilder()
    private var currentCandidates: List<Candidate> = emptyList()
    private var currentAssociations: List<String> = emptyList()
    private var lastCommittedWord: String? = null

    private var isEnglishMode = false
    private var isShiftLocked = false
    private var isNumberPadMode = false
    private var isSymbolLocked = false
    private var currentSymbolCategory = "最近"

    private enum class PanelState {
        KEYBOARD,
        CANDIDATE_GRID,
        CLIPBOARD_PHRASE,
        EMOJI_KAOMOJI,
        SYMBOLS,
        QUICK_HEIGHT_SETTINGS
    }
    private var currentPanel = PanelState.KEYBOARD

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainVerticalLayout: LinearLayout
    private lateinit var floatingComposingPill: TextView
    private lateinit var topIdleBar: LinearLayout
    private lateinit var topCandidateBar: LinearLayout
    private lateinit var candidateHScroll: HorizontalScrollView
    private lateinit var candidateScrollContainer: LinearLayout
    private val candidatePoolViews = ArrayList<TextView>(36)
    private lateinit var bodyFrame: FrameLayout

    private var popupWindow: PopupWindow? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val clip = clipboardManager.primaryClip
        if (clip != null && clip.itemCount > 0) {
            val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: ""
            if (text.isNotBlank()) {
                dbHelper.addClip(text)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        dbHelper = ImeDatabaseHelper(this)
        prefs = getSharedPreferences("shengxia_prefs", Context.MODE_PRIVATE)
        T14WubiEngine.ensureInitializedAsync(this, dbHelper)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            clipboardManager.removePrimaryClipChangedListener(clipListener)
        } catch (_: Exception) {}
    }

    private fun getKeyboardHeightDp(): Int {
        val screenWidthDp = resources.configuration.screenWidthDp
        val defaultDp = if (screenWidthDp >= 600) 330 else 285
        return prefs.getInt("keyboard_height_dp", defaultDp).coerceIn(200, 500)
    }

    private fun setKeyboardHeightDp(newDp: Int) {
        val clamped = newDp.coerceIn(200, 500)
        prefs.edit().putInt("keyboard_height_dp", clamped).apply()
        if (::bodyFrame.isInitialized) {
            val lp = bodyFrame.layoutParams
            lp.height = dp(clamped)
            bodyFrame.layoutParams = lp
        }
    }

    private fun getKeyFontScale(): Float {
        return prefs.getFloat("key_font_scale", 1.0f).coerceIn(0.8f, 1.4f)
    }

    private fun setKeyFontScale(scale: Float) {
        prefs.edit().putFloat("key_font_scale", scale.coerceIn(0.8f, 1.4f)).apply()
    }

    override fun onCreateInputView(): View {
        T14WubiEngine.ensureInitializedAsync(this, dbHelper)
        rootContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#E6E7EB"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        mainVerticalLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(8))
        }

        buildTopBarWithFloatingComposing()
        bodyFrame = FrameLayout(this)
        mainVerticalLayout.addView(bodyFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(getKeyboardHeightDp())
        ))

        rootContainer.addView(mainVerticalLayout)
        showKeyboardPanel()
        return rootContainer
    }

    override fun onWindowShown() {
        super.onWindowShown()
        T14WubiEngine.ensureInitializedAsync(this, dbHelper)
        if (::bodyFrame.isInitialized) {
            val lp = bodyFrame.layoutParams
            lp.height = dp(getKeyboardHeightDp())
            bodyFrame.layoutParams = lp
        }
    }

    // ==================== 左上角独立编码浮窗 + 预分配复用池顶栏（打字 0 卡顿） ====================
    private fun buildTopBarWithFloatingComposing() {
        floatingComposingPill = TextView(this).apply {
            visibility = View.GONE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#222428"))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = roundRect("#DCDFE6", dp(8))
            setPadding(dp(10), dp(2), dp(10), dp(2))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.gravity = Gravity.START
            lp.leftMargin = dp(4)
            lp.bottomMargin = dp(2)
            layoutParams = lp
        }
        mainVerticalLayout.addView(floatingComposingPill)

        val topWrapper = FrameLayout(this).apply {
            background = roundRect("#F3F4F6", dp(16))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }

        topIdleBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(8), 0)
        }

        fun makeTopIcon(symbol: String, twoCharLabel: String, onClick: () -> Unit): TextView {
            return TextView(this).apply {
                text = "$symbol $twoCharLabel"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(Color.parseColor("#33363C"))
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                maxLines = 1
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { onClick() }
            }
        }

        topIdleBar.addView(makeTopIcon("⚙️", "设置") {
            if (currentPanel == PanelState.QUICK_HEIGHT_SETTINGS) showKeyboardPanel() else showQuickHeightAndSettingsPanel()
        })
        topIdleBar.addView(makeTopIcon("😎", "表情") {
            if (currentPanel == PanelState.EMOJI_KAOMOJI) showKeyboardPanel() else showEmojiKaomojiPanel()
        })
        topIdleBar.addView(makeTopIcon("📋", "常用") {
            if (currentPanel == PanelState.CLIPBOARD_PHRASE) showKeyboardPanel() else showClipboardPhrasePanel()
        })
        topIdleBar.addView(makeTopIcon("↘", "收起") {
            requestHideSelf(0)
        })

        topCandidateBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            setPadding(dp(10), 0, dp(8), 0)
        }

        candidateHScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        }
        candidateScrollContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // 预分配 36 个候选词 TextView 复用池：打字时只改文字不新建控件，彻底告别卡顿！
        candidatePoolViews.clear()
        for (i in 0 until 36) {
            val tv = TextView(this).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                visibility = View.GONE
            }
            candidatePoolViews.add(tv)
            candidateScrollContainer.addView(tv)
        }

        candidateHScroll.addView(candidateScrollContainer)
        topCandidateBar.addView(candidateHScroll)

        val expandBtn = TextView(this).apply {
            text = "›"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            setTextColor(Color.parseColor("#33363C"))
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(8), 0)
            setOnClickListener {
                if (composingT14.isEmpty()) {
                    hideAssociationBar()
                } else if (currentPanel == PanelState.CANDIDATE_GRID) {
                    showKeyboardPanel()
                } else {
                    showFullCandidateGridPanel()
                }
            }
        }
        topCandidateBar.addView(expandBtn)

        topWrapper.addView(topIdleBar)
        topWrapper.addView(topCandidateBar)
        mainVerticalLayout.addView(topWrapper)
    }

    // ==================== 主键盘面板：中文 14 键 vs 英文标准 26 键 ====================
    private fun showKeyboardPanel() {
        currentPanel = PanelState.KEYBOARD
        bodyFrame.removeAllViews()

        if (isNumberPadMode) {
            bodyFrame.addView(buildNumberPadView())
            return
        }

        if (isEnglishMode) {
            bodyFrame.addView(buildEnglish26KeyboardView())
        } else {
            bodyFrame.addView(buildChinese14KeyboardView())
        }
    }

    private fun buildChinese14KeyboardView(): View {
        val kbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val row1 = makeRow()
        row1.addView(makeDualKey("Q", "W", "1", "1"))
        row1.addView(makeDualKey("E", "R", "2", "2"))
        row1.addView(makeDualKey("T", "Y", "3", "3"))
        row1.addView(makeDualKey("U", "I", "4", "4"))
        row1.addView(makeDualKey("O", "P", "5", "5"))
        kbLayout.addView(row1)

        val row2 = makeRow()
        row2.addView(makeDualKey("A", "S", "6", "6"))
        row2.addView(makeDualKey("D", "F", "7", "7"))
        row2.addView(makeDualKey("G", "H", "8", "8"))
        row2.addView(makeDualKey("J", "K", "9", "9"))
        row2.addView(makeDualKey("L", "", "0", "0"))
        kbLayout.addView(row2)

        val row3 = makeRow()
        row3.addView(makeFuncKey("通配", weight = 0.85f) {
            appendT14Input("a", "z")
        })
        row3.addView(makeDualKey("Z", "X", "!", "a"))
        row3.addView(makeDualKey("C", "V", ":", "b"))
        row3.addView(makeDualKey("B", "N", ";", "c"))
        row3.addView(makeDualKey("M", "", "?", "d"))
        row3.addView(makeBackspaceKey(weight = 0.95f))
        kbLayout.addView(row3)

        kbLayout.addView(buildBottomRow(isEng = false))
        return kbLayout
    }

    private fun buildEnglish26KeyboardView(): View {
        val kbLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val row1 = makeRow()
        val r1Keys = listOf(
            "q" to "1", "w" to "2", "e" to "3", "r" to "4", "t" to "5",
            "y" to "6", "u" to "7", "i" to "8", "o" to "9", "p" to "0"
        )
        r1Keys.forEach { (letter, hint) ->
            row1.addView(makeSingle26Key(letter, hint))
        }
        kbLayout.addView(row1)

        val row2 = makeRow().apply {
            setPadding(dp(14), 0, dp(14), 0)
        }
        val r2Keys = listOf(
            "a" to "!", "s" to "@", "d" to "#", "f" to "$", "g" to "%",
            "h" to "&", "j" to "*", "k" to "(", "l" to ")"
        )
        r2Keys.forEach { (letter, hint) ->
            row2.addView(makeSingle26Key(letter, hint))
        }
        kbLayout.addView(row2)

        val row3 = makeRow()
        row3.addView(makeFuncKey(if (isShiftLocked) "▲" else "△", weight = 1.25f) {
            isShiftLocked = !isShiftLocked
            showKeyboardPanel()
        })
        val r3Keys = listOf(
            "z" to "'", "x" to "/", "c" to "-", "v" to "_",
            "b" to ":", "n" to ";", "m" to "?"
        )
        r3Keys.forEach { (letter, hint) ->
            row3.addView(makeSingle26Key(letter, hint))
        }
        row3.addView(makeBackspaceKey(weight = 1.25f))
        kbLayout.addView(row3)

        kbLayout.addView(buildBottomRow(isEng = true))
        return kbLayout
    }

    private fun buildBottomRow(isEng: Boolean): LinearLayout {
        val row4 = makeRow()
        row4.addView(makeFuncKey("符", weight = 0.85f) { showSymbolsPanel() })
        row4.addView(makeFuncKey("123\nNumber", smallText = true, weight = 0.9f) {
            isNumberPadMode = true
            showKeyboardPanel()
        })
        val leftPunct = if (isEng) "," else "，"
        val rightPunct = if (isEng) "." else "。"
        row4.addView(makeFuncKey(leftPunct, weight = 0.65f) { commitOrSelectFirst(leftPunct) })
        row4.addView(makeSpaceKey(weight = 1.9f))
        row4.addView(makeFuncKey(rightPunct, weight = 0.65f) { commitOrSelectFirst(rightPunct) })
        val modeLabel = if (isEng) "英'中" else "中'英"
        row4.addView(makeFuncKey(modeLabel, weight = 0.85f) {
            clearComposing()
            hideAssociationBar()
            isEnglishMode = !isEnglishMode
            showKeyboardPanel()
        })
        row4.addView(makeFuncKey("盛夏\n光年", smallText = false, weight = 1.0f, bgColor = "#F9FAFB") {
            handleEnterKey()
        })
        return row4
    }

    private fun makeRow(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
    }

    private fun makeSingle26Key(letterLower: String, topHint: String): View {
        val scale = getKeyFontScale()
        val container = FrameLayout(this).apply {
            background = roundRect("#FFFFFF", dp(10))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            layoutParams = lp
        }

        val hintTv = TextView(this).apply {
            text = topHint
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f * scale)
            setTextColor(Color.parseColor("#C4C7CE"))
            gravity = Gravity.END or Gravity.TOP
            setPadding(0, dp(2), dp(4), 0)
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val displayChar = if (isShiftLocked) letterLower.uppercase() else letterLower
        val mainTv = TextView(this).apply {
            text = displayChar
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * scale)
            setTextColor(Color.parseColor("#222428"))
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val popupOptions = listOf(letterLower.uppercase(), topHint, letterLower.lowercase())
        val defaultIdx = 1
        var isLongPressActive = false
        var selectedIdx = defaultIdx
        var downX = 0f
        val optionViews = mutableListOf<TextView>()

        val longPressRunnable = Runnable {
            isLongPressActive = true
            optionViews.clear()
            selectedIdx = defaultIdx
            showFiveChoicePopup(container, popupOptions, defaultIdx, optionViews)
        }

        container.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    isLongPressActive = false
                    v.background = roundRect("#ECEEF2", dp(10))
                    mainHandler.postDelayed(longPressRunnable, 190L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isLongPressActive && optionViews.isNotEmpty()) {
                        val deltaX = event.rawX - downX
                        val stepPx = dp(30).toFloat()
                        val offsetSteps = (deltaX / stepPx).toInt()
                        val newIdx = (defaultIdx + offsetSteps).coerceIn(0, popupOptions.lastIndex)
                        if (newIdx != selectedIdx) {
                            selectedIdx = newIdx
                            updatePopupHighlight(optionViews, selectedIdx)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    v.background = roundRect("#FFFFFF", dp(10))
                    if (isLongPressActive) {
                        dismissPopup()
                        if (event.actionMasked == MotionEvent.ACTION_UP) {
                            commitDirectString(popupOptions[selectedIdx])
                        }
                        isLongPressActive = false
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        commitDirectString(displayChar)
                    }
                    true
                }
                else -> false
            }
        }
        return container
    }

    private fun makeDualKey(leftUpper: String, rightUpper: String, topHint: String, t14Code: String): View {
        val scale = getKeyFontScale()
        val container = FrameLayout(this).apply {
            background = roundRect("#FFFFFF", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
        }

        val hintTv = TextView(this).apply {
            text = topHint
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f * scale)
            setTextColor(Color.parseColor("#C4C7CE"))
            gravity = Gravity.END or Gravity.TOP
            setPadding(0, dp(3), dp(6), 0)
        }
        container.addView(hintTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val mainLabel = if (rightUpper.isEmpty()) leftUpper else "$leftUpper $rightUpper"
        val mainTv = TextView(this).apply {
            text = mainLabel
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * scale)
            setTextColor(Color.parseColor("#222428"))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        container.addView(mainTv, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val popupOptions = if (rightUpper.isNotEmpty()) {
            listOf(leftUpper, rightUpper, topHint, leftUpper.lowercase(), rightUpper.lowercase())
        } else {
            listOf(leftUpper, topHint, leftUpper.lowercase())
        }
        val defaultIdx = popupOptions.size / 2

        var isLongPressActive = false
        var selectedIdx = defaultIdx
        var downX = 0f
        val optionViews = mutableListOf<TextView>()

        val longPressRunnable = Runnable {
            isLongPressActive = true
            optionViews.clear()
            selectedIdx = defaultIdx
            showFiveChoicePopup(container, popupOptions, defaultIdx, optionViews)
        }

        container.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    isLongPressActive = false
                    v.background = roundRect("#ECEEF2", dp(12))
                    mainHandler.postDelayed(longPressRunnable, 190L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (isLongPressActive && optionViews.isNotEmpty()) {
                        val deltaX = event.rawX - downX
                        val stepPx = dp(32).toFloat()
                        val offsetSteps = (deltaX / stepPx).toInt()
                        val newIdx = (defaultIdx + offsetSteps).coerceIn(0, popupOptions.lastIndex)
                        if (newIdx != selectedIdx) {
                            selectedIdx = newIdx
                            updatePopupHighlight(optionViews, selectedIdx)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    v.background = roundRect("#FFFFFF", dp(12))
                    if (isLongPressActive) {
                        dismissPopup()
                        if (event.actionMasked == MotionEvent.ACTION_UP) {
                            val chosen = popupOptions[selectedIdx]
                            commitDirectString(chosen)
                        }
                        isLongPressActive = false
                    } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                        appendT14Input(t14Code, leftUpper.lowercase())
                    }
                    true
                }
                else -> false
            }
        }

        return container
    }

    private fun showFiveChoicePopup(
        anchor: View,
        options: List<String>,
        activeIndex: Int,
        outViews: MutableList<TextView>
    ) {
        dismissPopup()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = roundRect("#FFFFFF", dp(12), strokeColor = "#DCDFE6", strokeWidth = dp(1))
            setPadding(dp(8), dp(6), dp(8), dp(6))
            elevation = dp(8).toFloat()
        }

        options.forEach { label ->
            val tv = TextView(this).apply {
                text = label
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(dp(36), dp(42))
            }
            outViews.add(tv)
            row.addView(tv)
        }
        updatePopupHighlight(outViews, activeIndex)

        popupWindow = PopupWindow(
            row,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            false
        ).apply {
            isClippingEnabled = false
            val popupWidth = dp(36 * options.size + 16)
            val xOff = (anchor.width - popupWidth) / 2
            val yOff = -anchor.height - dp(52)
            showAsDropDown(anchor, xOff, yOff)
        }
    }

    private fun updatePopupHighlight(views: List<TextView>, activeIdx: Int) {
        views.forEachIndexed { idx, tv ->
            if (idx == activeIdx) {
                tv.background = roundRect("#FDE7EA", dp(8))
                tv.setTextColor(Color.parseColor("#E53935"))
                tv.typeface = Typeface.DEFAULT_BOLD
            } else {
                tv.background = null
                tv.setTextColor(Color.parseColor("#222428"))
                tv.typeface = Typeface.DEFAULT
            }
        }
    }

    private fun dismissPopup() {
        try {
            popupWindow?.dismiss()
        } catch (_: Exception) {}
        popupWindow = null
    }

    private fun makeFuncKey(
        label: String,
        smallText: Boolean = false,
        weight: Float = 1f,
        bgColor: String = "#F5F6F8",
        onClick: () -> Unit
    ): View {
        val scale = getKeyFontScale()
        return TextView(this).apply {
            text = label
            setTextSize(TypedValue.COMPLEX_UNIT_SP, (if (smallText) 11f else 14f) * scale)
            setTextColor(Color.parseColor("#33363C"))
            gravity = Gravity.CENTER
            background = roundRect(bgColor, dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    /**
     * 退格键（⌫）：
     * - 轻点：删一个字母或一个字
     * - 长按：连续快速删除
     * - 上滑（↑）：一键清空闪烁竖线（光标）前面的所有文字（并自动备份到剪贴板防误删！）
     */
    private fun makeBackspaceKey(weight: Float): View {
        val tv = TextView(this).apply {
            text = "⌫"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            setTextColor(Color.parseColor("#222428"))
            gravity = Gravity.CENTER
            background = roundRect("#ECEEF2", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
        }
        var downY = 0f
        var swipedUp = false
        val repeatDelete = object : Runnable {
            override fun run() {
                if (!swipedUp) {
                    handleBackspace()
                    mainHandler.postDelayed(this, 65L)
                }
            }
        }
        tv.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = ev.rawY
                    swipedUp = false
                    v.background = roundRect("#DCDFE6", dp(12))
                    mainHandler.postDelayed(repeatDelete, 350L)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = ev.rawY - downY
                    if (!swipedUp && dy < -dp(24)) {
                        swipedUp = true
                        mainHandler.removeCallbacks(repeatDelete)
                        deleteAllTextBeforeCursor()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(repeatDelete)
                    v.background = roundRect("#ECEEF2", dp(12))
                    if (!swipedUp && ev.actionMasked == MotionEvent.ACTION_UP) {
                        handleBackspace()
                    }
                    true
                }
                else -> false
            }
        }
        return tv
    }

    /**
     * 删除闪烁竖线（光标）前面所有的文字，并自动备份进剪贴板防止误删
     */
    private fun deleteAllTextBeforeCursor() {
        if (composingT14.isNotEmpty()) {
            clearComposing()
            return
        }
        hideAssociationBar()
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(100000, 0)
        if (!before.isNullOrEmpty()) {
            val str = before.toString()
            dbHelper.addClip(str)
            ic.deleteSurroundingText(str.length, 0)
        }
    }

    private fun makeSpaceKey(weight: Float): View {
        val tv = TextView(this).apply {
            text = "空格"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * getKeyFontScale())
            setTextColor(Color.parseColor("#33363C"))
            gravity = Gravity.CENTER
            background = roundRect("#FFFFFF", dp(12))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            layoutParams = lp
        }
        var startX = 0f
        var movedCursor = false
        tv.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = ev.rawX
                    movedCursor = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - startX
                    if (abs(dx) > dp(18)) {
                        val keyCode = if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
                        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
                        startX = ev.rawX
                        movedCursor = true
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!movedCursor) {
                        if (composingT14.isNotEmpty()) {
                            val first = currentCandidates.firstOrNull()
                            if (first != null) {
                                selectCandidate(first)
                            } else {
                                commitWordWithAssociation(composingRawLetters.toString())
                            }
                        } else {
                            hideAssociationBar()
                            currentInputConnection?.commitText(" ", 1)
                        }
                    }
                    true
                }
                else -> false
            }
        }
        return tv
    }

    // ==================== 0ms 极速候选词刷新 + 词语联想显示 ====================
    private fun appendT14Input(t14Key: String, displayHint: String) {
        currentAssociations = emptyList()
        composingT14.append(t14Key)
        composingRawLetters.append(displayHint)
        refreshCandidates()
    }

    private fun refreshCandidates() {
        if (composingT14.isEmpty()) {
            floatingComposingPill.visibility = View.GONE
            currentCandidates = emptyList()
            if (currentPanel == PanelState.CANDIDATE_GRID) showKeyboardPanel()
            if (currentAssociations.isNotEmpty()) {
                renderAssociationBar()
            } else {
                topCandidateBar.visibility = View.GONE
                topIdleBar.visibility = View.VISIBLE
            }
            return
        }

        topIdleBar.visibility = View.GONE
        topCandidateBar.visibility = View.VISIBLE
        floatingComposingPill.visibility = View.VISIBLE

        currentCandidates = T14WubiEngine.queryCandidates(
            composingT14.toString(),
            composingRawLetters.toString(),
            90
        )

        val topDisplayCode = currentCandidates.firstOrNull()?.displayCode?.ifEmpty { null }
            ?: T14WubiEngine.segmentT14ToPinyinDisplay(composingT14.toString(), composingRawLetters.toString())
        floatingComposingPill.text = "$topDisplayCode ✎"

        // 直接复用预分配的 36 个 TextView，零新建对象、零卡顿！
        val countToShow = minOf(currentCandidates.size, candidatePoolViews.size)
        for (i in 0 until candidatePoolViews.size) {
            val tv = candidatePoolViews[i]
            if (i < countToShow) {
                val cand = currentCandidates[i]
                val label = if (!cand.isWubiMatch && !cand.wubiHint.isNullOrEmpty()) {
                    "${cand.word}(${cand.wubiHint})"
                } else {
                    cand.word
                }
                tv.text = label
                tv.setTextColor(if (i == 0) Color.parseColor("#D94336") else Color.parseColor("#1E2024"))
                tv.typeface = if (i == 0) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                tv.visibility = View.VISIBLE
                tv.setOnClickListener { selectCandidate(cand) }
            } else {
                tv.visibility = View.GONE
            }
        }
        candidateHScroll.scrollTo(0, 0)

        if (currentPanel == PanelState.CANDIDATE_GRID) {
            showFullCandidateGridPanel()
        }
    }

    private fun renderAssociationBar() {
        floatingComposingPill.visibility = View.GONE
        if (currentAssociations.isEmpty()) {
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
            return
        }
        topIdleBar.visibility = View.GONE
        topCandidateBar.visibility = View.VISIBLE

        val countToShow = minOf(currentAssociations.size, candidatePoolViews.size)
        for (i in 0 until candidatePoolViews.size) {
            val tv = candidatePoolViews[i]
            if (i < countToShow) {
                val assocWord = currentAssociations[i]
                tv.text = assocWord
                tv.setTextColor(Color.parseColor("#33363C"))
                tv.typeface = Typeface.DEFAULT
                tv.visibility = View.VISIBLE
                tv.setOnClickListener {
                    commitWordWithAssociation(assocWord)
                }
            } else {
                tv.visibility = View.GONE
            }
        }
        candidateHScroll.scrollTo(0, 0)
    }

    private fun hideAssociationBar() {
        currentAssociations = emptyList()
        if (composingT14.isEmpty()) {
            topCandidateBar.visibility = View.GONE
            topIdleBar.visibility = View.VISIBLE
        }
    }

    private fun selectCandidate(cand: Candidate) {
        currentInputConnection?.commitText(cand.word, 1)
        T14WubiEngine.onWordCommitted(cand.word, lastCommittedWord, dbHelper)
        lastCommittedWord = cand.word

        if (cand.consumedKeys > 0 && cand.consumedKeys < composingT14.length) {
            composingT14.delete(0, cand.consumedKeys)
            val rawDel = cand.consumedKeys.coerceAtMost(composingRawLetters.length)
            composingRawLetters.delete(0, rawDel)
            refreshCandidates()
        } else {
            composingT14.clear()
            composingRawLetters.clear()
            currentAssociations = T14WubiEngine.getAssociations(cand.word)
            if (currentPanel == PanelState.CANDIDATE_GRID) {
                showKeyboardPanel()
            }
            refreshCandidates()
        }
    }

    private fun commitWordWithAssociation(word: String) {
        currentInputConnection?.commitText(word, 1)
        T14WubiEngine.onWordCommitted(word, lastCommittedWord, dbHelper)
        lastCommittedWord = word
        composingT14.clear()
        composingRawLetters.clear()
        currentAssociations = T14WubiEngine.getAssociations(word)
        refreshCandidates()
    }

    private fun showFullCandidateGridPanel() {
        currentPanel = PanelState.CANDIDATE_GRID
        bodyFrame.removeAllViews()
        val scroll = ScrollView(this).apply {
            background = roundRect("#F3F4F6", dp(12))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        currentCandidates.chunked(3).forEach { rowCands ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowCands.forEach { cand ->
                val label = if (!cand.isWubiMatch && !cand.wubiHint.isNullOrEmpty()) {
                    "${cand.word}(${cand.wubiHint})"
                } else {
                    cand.word
                }
                val tv = TextView(this).apply {
                    text = label
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                    setTextColor(if (cand.isWubiMatch) Color.parseColor("#1E2024") else Color.parseColor("#44474E"))
                    gravity = Gravity.CENTER
                    background = roundRect("#FFFFFF", dp(8))
                    val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                    layoutParams = lp
                    setOnClickListener { selectCandidate(cand) }
                }
                r.addView(tv)
            }
            container.addView(r)
        }
        scroll.addView(container)
        bodyFrame.addView(scroll)
    }

    private fun commitDirectString(str: String) {
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        hideAssociationBar()
        currentInputConnection?.commitText(str, 1)
    }

    private fun commitOrSelectFirst(punct: String) {
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word
            if (first != null) currentInputConnection?.commitText(first, 1)
            clearComposing()
        }
        hideAssociationBar()
        currentInputConnection?.commitText(punct, 1)
    }

    private fun clearComposing() {
        composingT14.clear()
        composingRawLetters.clear()
        currentAssociations = emptyList()
        refreshCandidates()
    }

    private fun handleBackspace() {
        if (composingT14.isNotEmpty()) {
            composingT14.deleteCharAt(composingT14.length - 1)
            if (composingRawLetters.isNotEmpty()) {
                composingRawLetters.deleteCharAt(composingRawLetters.length - 1)
            }
            refreshCandidates()
        } else {
            hideAssociationBar()
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
    }

    private fun handleEnterKey() {
        if (composingT14.isNotEmpty()) {
            val first = currentCandidates.firstOrNull()?.word ?: composingRawLetters.toString()
            commitWordWithAssociation(first)
            return
        }
        hideAssociationBar()
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        if (editorInfo != null && (editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            val action = editorInfo.imeOptions and android.view.inputmethod.EditorInfo.IME_MASK_ACTION
            if (action != android.view.inputmethod.EditorInfo.IME_ACTION_NONE &&
                action != android.view.inputmethod.EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        ic.commitText("\n", 1)
    }

    // ==================== 图 2 同款丰富符号面板 ====================
    private fun showSymbolsPanel() {
        currentPanel = PanelState.SYMBOLS
        bodyFrame.removeAllViews()

        val outerVertical = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val upperHorizontal = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }

        val leftCatScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            background = roundRect("#F3F4F6", dp(14))
            val lp = LinearLayout.LayoutParams(dp(64), ViewGroup.LayoutParams.MATCH_PARENT)
            lp.rightMargin = dp(6)
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }
        val leftCatCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        EmojiKaomojiData.SYMBOL_CATEGORIES.keys.forEach { catName ->
            val active = (catName == currentSymbolCategory)
            val tv = TextView(this).apply {
                text = catName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(if (active) Color.parseColor("#D94336") else Color.parseColor("#222428"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                background = if (active) roundRect("#E3E5EA", dp(12)) else null
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
                setOnClickListener {
                    currentSymbolCategory = catName
                    showSymbolsPanel()
                }
            }
            leftCatCol.addView(tv)
        }
        leftCatScroll.addView(leftCatCol)
        upperHorizontal.addView(leftCatScroll)

        val rightGridScroll = ScrollView(this).apply {
            background = roundRect("#FFFFFF", dp(16))
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            lp.bottomMargin = dp(6)
            layoutParams = lp
        }
        val rightGridCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        val symList = EmojiKaomojiData.SYMBOL_CATEGORIES[currentSymbolCategory] ?: emptyList()
        symList.chunked(5).forEach { rowSyms ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
            }
            rowSyms.forEach { entry ->
                val cell = FrameLayout(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                    setOnClickListener {
                        commitOrSelectFirst(entry.text)
                        if (!isSymbolLocked) {
                            showKeyboardPanel()
                        }
                    }
                }
                if (entry.isEnglish) {
                    val engBadge = TextView(this).apply {
                        text = "英"
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 9f)
                        setTextColor(Color.parseColor("#9AA0A6"))
                        gravity = Gravity.END or Gravity.TOP
                        setPadding(0, dp(3), dp(6), 0)
                    }
                    cell.addView(engBadge, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                }
                val symTv = TextView(this).apply {
                    text = entry.text
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                    setTextColor(Color.parseColor("#222428"))
                    gravity = Gravity.CENTER
                }
                cell.addView(symTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                r.addView(cell)
            }
            for (i in 0 until (5 - rowSyms.size)) {
                r.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f) })
            }
            rightGridCol.addView(r)
        }
        rightGridScroll.addView(rightGridCol)
        upperHorizontal.addView(rightGridScroll)
        outerVertical.addView(upperHorizontal)

        val bottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48))
        }
        bottomRow.addView(makeFuncKey("返回", weight = 0.85f, bgColor = "#F3F4F6") { showKeyboardPanel() })
        bottomRow.addView(makeFuncKey("△", weight = 1.1f, bgColor = "#F3F4F6") {
            rightGridScroll.smoothScrollBy(0, -dp(140))
        })
        bottomRow.addView(makeFuncKey("▽", weight = 1.1f, bgColor = "#F3F4F6") {
            rightGridScroll.smoothScrollBy(0, dp(140))
        })
        bottomRow.addView(makeFuncKey(if (isSymbolLocked) "🔒已锁" else "🔓不锁", weight = 1.1f, bgColor = "#F3F4F6") {
            isSymbolLocked = !isSymbolLocked
            showSymbolsPanel()
        })
        bottomRow.addView(makeBackspaceKey(weight = 0.95f))
        outerVertical.addView(bottomRow)

        bodyFrame.addView(outerVertical)
    }

    // ==================== 键盘内实时调节面板高度与字号 ====================
    private fun showQuickHeightAndSettingsPanel() {
        currentPanel = PanelState.QUICK_HEIGHT_SETTINGS
        bodyFrame.removeAllViews()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect("#F7F8FA", dp(14))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val backBtn = TextView(this).apply {
            text = "‹ 返回键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#1E88E5"))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(4), dp(14), dp(4))
            setOnClickListener { showKeyboardPanel() }
        }
        val titleTv = TextView(this).apply {
            text = "面板高度与词库快捷设置"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#222428"))
        }
        header.addView(backBtn)
        header.addView(titleTv)
        root.addView(header)

        val heightLabel = TextView(this).apply {
            text = "当前键盘面板高度：${getKeyboardHeightDp()} dp（点击下方按钮实时预览高矮）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#44474E"))
            setPadding(dp(4), dp(10), dp(4), dp(6))
        }
        root.addView(heightLabel)

        val heightBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44))
        }
        heightBtnRow.addView(makeFuncKey("➖ 调矮 (-15)", bgColor = "#FFFFFF") {
            setKeyboardHeightDp(getKeyboardHeightDp() - 15)
            heightLabel.text = "当前键盘面板高度：${getKeyboardHeightDp()} dp（点击下方按钮实时预览高矮）"
        })
        heightBtnRow.addView(makeFuncKey("手机标准(285)", bgColor = "#FFFFFF") {
            setKeyboardHeightDp(285)
            heightLabel.text = "当前键盘面板高度：${getKeyboardHeightDp()} dp（点击下方按钮实时预览高矮）"
        })
        heightBtnRow.addView(makeFuncKey("平板加高(345)", bgColor = "#FFFFFF") {
            setKeyboardHeightDp(345)
            heightLabel.text = "当前键盘面板高度：${getKeyboardHeightDp()} dp（点击下方按钮实时预览高矮）"
        })
        heightBtnRow.addView(makeFuncKey("➕ 加高 (+15)", bgColor = "#FFFFFF") {
            setKeyboardHeightDp(getKeyboardHeightDp() + 15)
            heightLabel.text = "当前键盘面板高度：${getKeyboardHeightDp()} dp（点击下方按钮实时预览高矮）"
        })
        root.addView(heightBtnRow)

        val fontLabel = TextView(this).apply {
            text = "按键字母大小：${(getKeyFontScale() * 100).toInt()}%"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#44474E"))
            setPadding(dp(4), dp(8), dp(4), dp(4))
        }
        root.addView(fontLabel)

        val fontBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
        }
        fontBtnRow.addView(makeFuncKey("➖ 缩小字号", bgColor = "#FFFFFF") {
            setKeyFontScale(getKeyFontScale() - 0.08f)
            fontLabel.text = "按键字母大小：${(getKeyFontScale() * 100).toInt()}%"
        })
        fontBtnRow.addView(makeFuncKey("默认字号(100%)", bgColor = "#FFFFFF") {
            setKeyFontScale(1.0f)
            fontLabel.text = "按键字母大小：100%"
        })
        fontBtnRow.addView(makeFuncKey("➕ 放大字号", bgColor = "#FFFFFF") {
            setKeyFontScale(getKeyFontScale() + 0.08f)
            fontLabel.text = "按键字母大小：${(getKeyFontScale() * 100).toInt()}%"
        })
        root.addView(fontBtnRow)

        val openFullBtn = TextView(this).apply {
            text = "📂 打开完整词库导入（.scel/.txt）与常用语管理后台"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = roundRect("#1E88E5", dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42))
            lp.topMargin = dp(10)
            layoutParams = lp
            setOnClickListener {
                val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            }
        }
        root.addView(openFullBtn)

        bodyFrame.addView(root)
    }

    // ==================== 剪贴板(300条无上限) + 多分类常用语面板 ====================
    private var isPhraseSubTab = true
    private var currentPhraseCategory = "收藏"

    private fun showClipboardPhrasePanel() {
        currentPanel = PanelState.CLIPBOARD_PHRASE
        bodyFrame.removeAllViews()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect("#F7F8FA", dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#EAECEF"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#333333"))
            setPadding(dp(10), dp(6), dp(12), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        val clipTabBtn = TextView(this).apply {
            text = "剪贴板"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (!isPhraseSubTab) Color.parseColor("#E53935") else Color.parseColor("#555555"))
            typeface = if (!isPhraseSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            background = if (!isPhraseSubTab) roundRect("#FFFFFF", dp(8)) else null
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isPhraseSubTab = false
                showClipboardPhrasePanel()
            }
        }
        header.addView(clipTabBtn)

        val phraseTabBtn = TextView(this).apply {
            text = "常用语"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (isPhraseSubTab) Color.parseColor("#E53935") else Color.parseColor("#555555"))
            typeface = if (isPhraseSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            background = if (isPhraseSubTab) roundRect("#FFFFFF", dp(8)) else null
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                isPhraseSubTab = true
                showClipboardPhrasePanel()
            }
        }
        header.addView(phraseTabBtn)

        val spacer = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        }
        header.addView(spacer)

        val actionBtn = TextView(this).apply {
            text = if (isPhraseSubTab) "＋加常用语" else "清空未置顶"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#1E88E5"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setOnClickListener {
                if (isPhraseSubTab) {
                    val intent = Intent(this@ShengXiaImeService, SettingsActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra("open_tab", "phrases")
                        putExtra("default_category", currentPhraseCategory)
                    }
                    startActivity(intent)
                } else {
                    dbHelper.clearUnpinnedClips()
                    showClipboardPhrasePanel()
                }
            }
        }
        header.addView(actionBtn)
        root.addView(header)

        if (isPhraseSubTab) {
            val catScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                setBackgroundColor(Color.WHITE)
            }
            val catRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), dp(6), dp(8), dp(6))
            }
            val categories = dbHelper.getCategories()
            if (!categories.contains(currentPhraseCategory)) {
                currentPhraseCategory = categories.firstOrNull() ?: "收藏"
            }
            categories.forEach { cat ->
                val active = (cat == currentPhraseCategory)
                val tv = TextView(this).apply {
                    text = cat
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                    setTextColor(if (active) Color.parseColor("#E53935") else Color.parseColor("#333333"))
                    typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                    setPadding(dp(12), dp(4), dp(12), dp(4))
                    setOnClickListener {
                        currentPhraseCategory = cat
                        showClipboardPhrasePanel()
                    }
                }
                catRow.addView(tv)
            }
            catScroll.addView(catRow)
            root.addView(catScroll)

            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val cardList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            val phrases = dbHelper.getPhrasesByCategory(currentPhraseCategory)
            if (phrases.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = "当前「$currentPhraseCategory」分类暂无常用语\n可点击右上角「＋加常用语」或在剪贴板中一键转存"
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#888888"))
                    setPadding(dp(16), dp(36), dp(16), dp(36))
                }
                cardList.addView(emptyTv)
            } else {
                phrases.forEach { item ->
                    cardList.addView(buildPhraseCard(item))
                }
            }
            vScroll.addView(cardList)
            root.addView(vScroll)
        } else {
            val vScroll = ScrollView(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val clipList = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(8), dp(6), dp(8), dp(8))
            }
            val clips = dbHelper.getClips()
            if (clips.isEmpty()) {
                val emptyTv = TextView(this).apply {
                    text = "剪贴板暂无记录（自动保留最近 300 条，无字数上限）"
                    gravity = Gravity.CENTER
                    setTextColor(Color.parseColor("#888888"))
                    setPadding(dp(16), dp(36), dp(16), dp(36))
                }
                clipList.addView(emptyTv)
            } else {
                clips.forEach { clip ->
                    clipList.addView(buildClipCard(clip))
                }
            }
            vScroll.addView(clipList)
            root.addView(vScroll)
        }

        bodyFrame.addView(root)
    }

    private fun buildPhraseCard(item: PhraseItem): View {
        var expanded = false
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect("#ECEEF1", dp(10), strokeColor = "#D5D8DE", strokeWidth = dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val starTv = TextView(this).apply {
            text = if (item.isStarred) "★" else "☆"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(if (item.isStarred) Color.parseColor("#F5A623") else Color.parseColor("#999999"))
            setPadding(dp(4), dp(4), dp(8), dp(4))
            setOnClickListener {
                dbHelper.togglePhraseStar(item.id, item.isStarred)
                showClipboardPhrasePanel()
            }
        }
        card.addView(starTv)

        val contentTv = TextView(this).apply {
            text = item.content
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#222428"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                dbHelper.markPhraseUsed(item.id)
                currentInputConnection?.commitText(item.content, 1)
            }
        }
        card.addView(contentTv)

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(dp(10), dp(4), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.maxLines = if (expanded) 500 else 2
                text = if (expanded) "⌃" else "⌄"
            }
        }
        card.addView(expandTv)

        val delTv = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#999999"))
            setPadding(dp(6), dp(4), dp(4), dp(4))
            setOnClickListener {
                dbHelper.deletePhrase(item.id)
                showClipboardPhrasePanel()
            }
        }
        card.addView(delTv)

        return card
    }

    private fun buildClipCard(clip: ClipItem): View {
        var expanded = false
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundRect("#ECEEF1", dp(10), strokeColor = "#D5D8DE", strokeWidth = dp(1))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = dp(6)
            layoutParams = lp
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val pinTv = TextView(this).apply {
            text = if (clip.isPinned) "📌" else "○"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(4), dp(4), dp(8), dp(4))
            setOnClickListener {
                dbHelper.toggleClipPin(clip.id, clip.isPinned)
                showClipboardPhrasePanel()
            }
        }
        card.addView(pinTv)

        val contentTv = TextView(this).apply {
            text = clip.content
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#222428"))
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                currentInputConnection?.commitText(clip.content, 1)
            }
        }
        card.addView(contentTv)

        val saveToPhraseTv = TextView(this).apply {
            text = "存常用"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            setTextColor(Color.parseColor("#1E88E5"))
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener {
                dbHelper.addOrUpdatePhrase(null, currentPhraseCategory, clip.content, true)
                Toast.makeText(this@ShengXiaImeService, "已存入常用语「$currentPhraseCategory」", Toast.LENGTH_SHORT).show()
            }
        }
        card.addView(saveToPhraseTv)

        val expandTv = TextView(this).apply {
            text = "⌄"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(Color.parseColor("#666666"))
            setPadding(dp(8), dp(4), dp(6), dp(4))
            setOnClickListener {
                expanded = !expanded
                contentTv.maxLines = if (expanded) 500 else 2
                text = if (expanded) "⌃" else "⌄"
            }
        }
        card.addView(expandTv)

        val delTv = TextView(this).apply {
            text = "✕"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#999999"))
            setPadding(dp(6), dp(4), dp(4), dp(4))
            setOnClickListener {
                dbHelper.deleteClip(clip.id)
                showClipboardPhrasePanel()
            }
        }
        card.addView(delTv)

        return card
    }

    // ==================== Emoji & 颜文字纯净双标签面板 ====================
    private var isKaomojiSubTab = false
    private var currentEmojiCat = "笑脸"
    private var currentKaomojiCat = "经典"

    private fun showEmojiKaomojiPanel() {
        currentPanel = PanelState.EMOJI_KAOMOJI
        bodyFrame.removeAllViews()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect("#F3F4F6", dp(12))
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#E5E6EB"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }

        val backBtn = TextView(this).apply {
            text = "‹ 键盘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#333333"))
            setPadding(dp(10), dp(6), dp(14), dp(6))
            setOnClickListener { showKeyboardPanel() }
        }
        header.addView(backBtn)

        val emojiTab = TextView(this).apply {
            text = "Emoji"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (!isKaomojiSubTab) Color.parseColor("#E53935") else Color.parseColor("#444444"))
            typeface = if (!isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                isKaomojiSubTab = false
                showEmojiKaomojiPanel()
            }
        }
        header.addView(emojiTab)

        val kaomojiTab = TextView(this).apply {
            text = "颜文字"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(if (isKaomojiSubTab) Color.parseColor("#E53935") else Color.parseColor("#444444"))
            typeface = if (isKaomojiSubTab) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            setPadding(dp(16), dp(6), dp(16), dp(6))
            setOnClickListener {
                isKaomojiSubTab = true
                showEmojiKaomojiPanel()
            }
        }
        header.addView(kaomojiTab)
        root.addView(header)

        val vScroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val gridContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        if (!isKaomojiSubTab) {
            val emojis = EmojiKaomojiData.EMOJI_CATEGORIES[currentEmojiCat] ?: emptyList()
            val cols = 8
            emojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { em ->
                    val tv = TextView(this).apply {
                        text = em
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f)
                        setOnClickListener { currentInputConnection?.commitText(em, 1) }
                    }
                    row.addView(tv)
                }
                for (i in 0 until (cols - rowItems.size)) {
                    row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f) })
                }
                gridContainer.addView(row)
            }
        } else {
            val kaomojis = EmojiKaomojiData.KAOMOJI_CATEGORIES[currentKaomojiCat] ?: emptyList()
            val cols = 3
            kaomojis.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                rowItems.forEach { km ->
                    val tv = TextView(this).apply {
                        text = km
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        setTextColor(Color.parseColor("#222428"))
                        gravity = Gravity.CENTER
                        background = roundRect("#E2E4E9", dp(8))
                        val lp = LinearLayout.LayoutParams(0, dp(40), 1f)
                        lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                        layoutParams = lp
                        setOnClickListener { currentInputConnection?.commitText(km, 1) }
                    }
                    row.addView(tv)
                }
                gridContainer.addView(row)
            }
        }
        vScroll.addView(gridContainer)
        root.addView(vScroll)

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#E5E6EB"))
            setPadding(dp(6), dp(2), dp(6), dp(2))
        }
        val catNames = if (!isKaomojiSubTab) EmojiKaomojiData.EMOJI_CATEGORIES.keys else EmojiKaomojiData.KAOMOJI_CATEGORIES.keys
        catNames.forEach { cName ->
            val active = if (!isKaomojiSubTab) (cName == currentEmojiCat) else (cName == currentKaomojiCat)
            val tv = TextView(this).apply {
                text = cName
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(if (active) Color.parseColor("#111111") else Color.parseColor("#666666"))
                typeface = if (active) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                gravity = Gravity.CENTER
                background = if (active) roundRect("#FFFFFF", dp(6)) else null
                layoutParams = LinearLayout.LayoutParams(0, dp(34), 1f)
                setOnClickListener {
                    if (!isKaomojiSubTab) currentEmojiCat = cName else currentKaomojiCat = cName
                    showEmojiKaomojiPanel()
                }
            }
            bottomBar.addView(tv)
        }
        val delBtn = TextView(this).apply {
            text = "⌫"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            gravity = Gravity.CENTER
            background = roundRect("#D5D7DD", dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(34))
            setOnClickListener { handleBackspace() }
        }
        bottomBar.addView(delBtn)
        root.addView(bottomBar)

        bodyFrame.addView(root)
    }

    private fun buildNumberPadView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val rows = listOf(
            listOf("1", "2", "3", "+"),
            listOf("4", "5", "6", "-"),
            listOf("7", "8", "9", "⌫"),
            listOf("返回", "0", ".", "盛夏\n光年")
        )
        rows.forEach { rItems ->
            val r = makeRow()
            rItems.forEach { key ->
                when (key) {
                    "⌫" -> r.addView(makeBackspaceKey(1f))
                    "返回" -> r.addView(makeFuncKey("返回", bgColor = "#ECEEF2") {
                        isNumberPadMode = false
                        showKeyboardPanel()
                    })
                    "盛夏\n光年" -> r.addView(makeFuncKey("盛夏\n光年", bgColor = "#ECEEF2") { handleEnterKey() })
                    else -> r.addView(makeFuncKey(key, bgColor = "#FFFFFF") { commitDirectString(key) })
                }
            }
            root.addView(r)
        }
        return root
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun roundRect(fillHex: String, radiusPx: Int, strokeColor: String? = null, strokeWidth: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.parseColor(fillHex))
            if (strokeColor != null && strokeWidth > 0) {
                setStroke(strokeWidth, Color.parseColor(strokeColor))
            }
        }
    }
}
