package com.shengxiaguangnian.ime

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "top_icon_0", "top_icon_1", "top_icon_2", "top_icon_3",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getTopIconBitmap(context: Context, index: Int): Bitmap? {
        ensureLoaded(context)
        return cache["top_icon_${index.coerceIn(0, 3)}"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 位于键盘最底层的「莫奈浅色水彩发散柔光层」（Z-order 在所有按键下方）：
 * - 严格垫在所有键帽底部（index = 0），绝不覆盖或染色任何键帽表面；
 * - 摒弃死板的矩形窄圈，采用随按键宽高自适应的「椭圆径向水彩发散云团」（向按键四周柔和发散约 36dp），
 *   像光线在睡莲池水底下自然晕染开来；
 * - 光晕采用比键帽本身更浅、更清透粉嫩的同色系水彩浅色（内圈奶油珠光白粉/浅冰蓝/浅嫩绿 -> 中圈清透粉彩 -> 外圈柔雾消散），
 *   松手后前 150ms 保持峰值亮度，随后在 650ms 内如呼吸般柔和退去。
 */
class KeyboardBacklightOverlayView(context: Context) : View(context) {

    private class SpotlightOrb(
        val sourceView: View,
        val keyRect: RectF,
        val glowColor: Int,
        var releaseTime: Long = 0L
    )

    private val orbs = ArrayList<SpotlightOrb>(12)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val shaderMatrix = android.graphics.Matrix()
    private val tmpRectF = RectF()
    private val selfLoc = IntArray(2)
    private val targetLoc = IntArray(2)

    init {
        isClickable = false
        isFocusable = false
    }

    fun triggerKeyDown(keyView: View, @Suppress("UNUSED_PARAMETER") cornerRadius: Float, glowColor: Int) {
        getLocationInWindow(selfLoc)
        keyView.getLocationInWindow(targetLoc)
        val left = (targetLoc[0] - selfLoc[0]).toFloat()
        val top = (targetLoc[1] - selfLoc[1]).toFloat()
        val right = left + keyView.width
        val bottom = top + keyView.height

        orbs.removeAll { it.sourceView === keyView && it.releaseTime == 0L }
        orbs.add(
            SpotlightOrb(
                sourceView = keyView,
                keyRect = RectF(left, top, right, bottom),
                glowColor = glowColor,
                releaseTime = 0L
            )
        )
        if (orbs.size > 10) {
            orbs.removeAt(0)
        }
        invalidate()
    }

    fun triggerKeyUp(keyView: View) {
        val now = SystemClock.uptimeMillis()
        for (orb in orbs) {
            if (orb.sourceView === keyView && orb.releaseTime == 0L) {
                orb.releaseTime = now
            }
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (orbs.isEmpty()) return

        val now = SystemClock.uptimeMillis()
        val holdMs = 150f
        val fadeMs = 650f
        val totalMs = holdMs + fadeMs
        val spread = dpF(36f)
        val baseRadius = 100f

        val iter = orbs.iterator()
        while (iter.hasNext()) {
            val orb = iter.next()
            val progress: Float
            if (orb.releaseTime == 0L) {
                progress = 1.0f
            } else {
                val elapsed = (now - orb.releaseTime).toFloat()
                if (elapsed >= totalMs) {
                    iter.remove()
                    continue
                }
                progress = if (elapsed <= holdMs) {
                    1.0f - 0.06f * (elapsed / holdMs)
                } else {
                    val t = ((elapsed - holdMs) / fadeMs).coerceIn(0f, 1f)
                    0.94f * (1f - t) * (1f - t)
                }
            }

            val cx = orb.keyRect.centerX()
            val cy = orb.keyRect.centerY()
            val rx = (orb.keyRect.width() * 0.5f + spread).coerceAtLeast(dpF(52f))
            val ry = (orb.keyRect.height() * 0.5f + spread).coerceAtLeast(dpF(52f))

            val rMid = Color.red(orb.glowColor)
            val gMid = Color.green(orb.glowColor)
            val bMid = Color.blue(orb.glowColor)

            // 内圈（刚从键帽底缘透出处，stop = 0.44）：比键帽更浅、更通透的奶油珠光浅粉彩
            val rInner = (rMid * 0.42f + 255 * 0.58f).toInt().coerceIn(0, 255)
            val gInner = (gMid * 0.42f + 253 * 0.58f).toInt().coerceIn(0, 255)
            val bInner = (bMid * 0.42f + 255 * 0.58f).toInt().coerceIn(0, 255)

            // 外圈柔雾（stop = 0.85 -> 1.0）：轻盈水彩雾化消散（终点保持同 RGB 且 alpha=0，杜绝发灰发暗）
            val rOuter = (rMid * 0.92f + 245 * 0.08f).toInt().coerceIn(0, 255)
            val gOuter = (gMid * 0.92f + 248 * 0.08f).toInt().coerceIn(0, 255)
            val bOuter = (bMid * 0.92f + 255 * 0.08f).toInt().coerceIn(0, 255)

            val aCore = (255 * progress).toInt().coerceIn(0, 255)
            val aEdge = (248 * progress).toInt().coerceIn(0, 255)
            val aMid = (182 * progress).toInt().coerceIn(0, 255)
            val aMist = (86 * progress).toInt().coerceIn(0, 255)

            val gradient = RadialGradient(
                0f,
                0f,
                baseRadius,
                intArrayOf(
                    Color.argb(aCore, rInner, gInner, bInner),
                    Color.argb(aEdge, rInner, gInner, bInner),
                    Color.argb(aMid, rMid, gMid, bMid),
                    Color.argb(aMist, rOuter, gOuter, bOuter),
                    Color.argb(0, rOuter, gOuter, bOuter)
                ),
                floatArrayOf(0f, 0.44f, 0.66f, 0.85f, 1.0f),
                Shader.TileMode.CLAMP
            )
            shaderMatrix.reset()
            shaderMatrix.setScale(rx / baseRadius, ry / baseRadius)
            shaderMatrix.postTranslate(cx, cy)
            gradient.setLocalMatrix(shaderMatrix)

            orbPaint.shader = gradient
            tmpRectF.set(cx - rx, cy - ry, cx + rx, cy + ry)
            canvas.drawOval(tmpRectF, orbPaint)
        }

        if (orbs.isNotEmpty()) {
            postInvalidateOnAnimation()
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.parseColor("#76A2F2"),
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    @Suppress("UNUSED_PARAMETER") private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (enableGlow) {
                    val overlay = findBacklightOverlay()
                    if (value) {
                        overlay?.triggerKeyDown(this, cornerRadiusPx, glowColor)
                    } else {
                        overlay?.triggerKeyUp(this)
                    }
                }
                invalidate()
            }
        }

    private fun findBacklightOverlay(): KeyboardBacklightOverlayView? {
        var p = parent
        while (p is ViewGroup) {
            for (i in 0 until p.childCount) {
                val child = p.getChildAt(i)
                if (child is KeyboardBacklightOverlayView) {
                    return child
                }
            }
            p = p.parent
        }
        return null
    }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        keyRectF.set(0f, 0f, w, h)
        val r = cornerRadiusPx

        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (bitmap != null) {
            // 莫奈油画键帽纹理内部 100% 不透明，直接绘制可确保键帽完全遮挡底部的背光层，绝不被背光染色
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        } else if (fallbackBgTop != Color.TRANSPARENT) {
            // 非莫奈皮肤下使用实心不透明键帽底色，同样确保键帽不被底部背光染色
            fallbackFillPaint.color = Color.argb(
                255,
                Color.red(fallbackBgTop),
                Color.green(fallbackBgTop),
                Color.blue(fallbackBgTop)
            )
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        canvas.restoreToCount(saveCount)
    }
}

/**
 * 顶部状态栏 4 图标视图：
 * - 当 useBotanicalStyle = true 时，直接渲染高清水彩晕染的「小莲花、双生睡莲花苞、缺口浮叶、双叶托莲水波」4 枚纯植物图标（彻底告别搞笑圆脸！）
 */
class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int,
    private val useBotanicalStyle: Boolean = true
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val srcRect = Rect()
    private val dstRectF = RectF()

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.65f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (useBotanicalStyle) {
            val bmp = MonetTextureManager.getTopIconBitmap(context, iconType)
            if (bmp != null) {
                val pad = minOf(w, h) * 0.04f
                dstRectF.set(pad, pad, w - pad, h - pad)
                srcRect.set(0, 0, bmp.width, bmp.height)
                canvas.drawBitmap(bmp, srcRect, dstRectF, bmpPaint)
                return
            }
        }

        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.36f
        drawClassicMinimalistIcon(canvas, cx, cy, r)
    }

    private fun drawClassicMinimalistIcon(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
