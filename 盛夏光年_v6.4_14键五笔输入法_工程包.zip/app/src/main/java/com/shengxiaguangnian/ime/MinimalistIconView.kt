package com.shengxiaguangnian.ime

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.util.TypedValue
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

object MonetTextureManager {
    private val cache = HashMap<String, Bitmap>()
    private var loaded = false

    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            val names = listOf(
                "top_bar", "space_lotus_icon",
                "key_qw", "key_er", "key_ty", "key_ui", "key_op",
                "key_as", "key_df", "key_gh", "key_jk", "key_l",
                "key_wildcard", "key_zx", "key_cv", "key_bn", "key_m", "key_backspace",
                "key_sym", "key_num", "key_comma", "key_space", "key_period", "key_lang", "key_enter"
            )
            for (n in names) {
                try {
                    context.assets.open("monet/$n.webp").use { ins ->
                        val bmp = BitmapFactory.decodeStream(ins)
                        if (bmp != null) cache[n] = bmp
                    }
                } catch (_: Exception) {}
            }
            loaded = true
        }
    }

    fun getTopBarBitmap(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["top_bar"]
    }

    fun getSpaceLotusIcon(context: Context): Bitmap? {
        ensureLoaded(context)
        return cache["space_lotus_icon"]
    }

    fun getKeyBitmap(context: Context, keyId: String): Bitmap? {
        ensureLoaded(context)
        val clean = keyId.trim().lowercase()
        val mapped = when (clean) {
            "qw", "er", "ty", "ui", "op",
            "as", "df", "gh", "jk", "l",
            "wildcard", "zx", "cv", "bn", "m", "backspace",
            "sym", "num", "comma", "space", "period", "lang", "enter" -> "key_$clean"
            "q", "u" -> "key_qw"
            "w", "i" -> "key_er"
            "t", "y" -> "key_ty"
            "e", "o" -> "key_ui"
            "r", "p" -> "key_op"
            "a", "h" -> "key_as"
            "s", "j" -> "key_df"
            "d", "k" -> "key_gh"
            "f" -> "key_jk"
            "g" -> "key_l"
            "shift", "▲", "△" -> "key_wildcard"
            "z", "n" -> "key_zx"
            "x" -> "key_cv"
            "v", "b" -> "key_bn"
            "c" -> "key_m"
            "通配" -> "key_wildcard"
            "⌫" -> "key_backspace"
            "符", "符号", "返回" -> "key_sym"
            "123" -> "key_num"
            "，", "," -> "key_comma"
            "。", "." -> "key_period"
            "中/英", "英/中" -> "key_lang"
            else -> "key_enter"
        }
        return cache[mapped]
    }
}

/**
 * 莫奈油画睡莲键帽 + 零裁剪真外发光背光视图：
 * 1. 当 enableGlow = true 时，在组件自身画布内预留 3dp 发光呼吸区（绝不会被 Android 硬件加速裁剪！），
 *    在键帽四周绘制三层高辨识度的彩色柔光外发光光晕 + 1.5dp 珠光霓虹内描边。
 * 2. 当手指按下（isKeyPressedState = true）时，按键不仅不会变暗，反而会瞬间点亮高光背光，
 *    并在松手后带有 280ms 的柔和余晖渐变消散（打字时能清晰看到刚按过的键亮起微光！）。
 */
class MonetPaintedBgView(
    context: Context,
    private val bitmap: Bitmap?,
    private val cornerRadiusPx: Float,
    initialAlpha: Int = 255,
    private val enableGlow: Boolean = false,
    private val glowColor: Int = Color.WHITE,
    private val fallbackBgTop: Int = Color.TRANSPARENT,
    private val fallbackBgBottom: Int = Color.TRANSPARENT
) : View(context) {

    private var pressGlowProgress: Float = 0f
    private var fadeAnimator: ValueAnimator? = null

    var isKeyPressedState: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                if (value) {
                    fadeAnimator?.cancel()
                    pressGlowProgress = 1.0f
                    invalidate()
                } else {
                    fadeAnimator?.cancel()
                    fadeAnimator = ValueAnimator.ofFloat(pressGlowProgress, 0f).apply {
                        duration = 280L
                        interpolator = DecelerateInterpolator()
                        addUpdateListener { anim ->
                            pressGlowProgress = anim.animatedValue as Float
                            invalidate()
                        }
                        start()
                    }
                }
            }
        }

    var textureAlpha: Int = initialAlpha.coerceIn(0, 255)
        set(value) {
            val clamped = value.coerceIn(0, 255)
            if (field != clamped) {
                field = clamped
                bmpPaint.alpha = clamped
                invalidate()
            }
        }

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = initialAlpha.coerceIn(0, 255)
    }
    private val fallbackFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pressBloomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val haloOuterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(3.2f)
    }
    private val haloMidPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(2.2f)
    }
    private val haloInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.4f)
    }
    private val srcRect = Rect()
    private val keyRectF = RectF()
    private val glowRectF = RectF()
    private val clipPath = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // 在画布内部留出 2.6dp 的外发光缓冲区，确保三层外发光光晕 100% 落在 View 内部，绝不被系统裁剪！
        val inset = if (enableGlow) dpF(2.6f) else 0f
        keyRectF.set(inset, inset, w - inset, h - inset)
        val r = (cornerRadiusPx - inset * 0.3f).coerceAtLeast(dpF(6f))

        val rCol = Color.red(glowColor)
        val gCol = Color.green(glowColor)
        val bCol = Color.blue(glowColor)
        val p = pressGlowProgress.coerceIn(0f, 1f)

        // 1. 绘制键帽外围三层柔光背光光晕（常驻微光 + 按下时流光绽放）
        if (enableGlow) {
            val aOuter = (85 + (140 * p).toInt()).coerceIn(0, 255)
            val aMid = (150 + (100 * p).toInt()).coerceIn(0, 255)
            val aInner = (225 + (30 * p).toInt()).coerceIn(0, 255)

            haloOuterPaint.color = Color.argb(aOuter, rCol, gCol, bCol)
            haloMidPaint.color = Color.argb(aMid, rCol, gCol, bCol)
            // 最内圈采用高亮珠光白与背光色的混合色，勾勒出精致的发光灯带感
            haloInnerPaint.color = Color.argb(
                aInner,
                ((rCol + 255 * 2) / 3).coerceIn(0, 255),
                ((gCol + 255 * 2) / 3).coerceIn(0, 255),
                ((bCol + 255 * 2) / 3).coerceIn(0, 255)
            )

            // 最外层弥散光圈
            val d1 = dpF(1.6f)
            glowRectF.set(keyRectF.left - d1, keyRectF.top - d1, keyRectF.right + d1, keyRectF.bottom + d1)
            canvas.drawRoundRect(glowRectF, r + d1, r + d1, haloOuterPaint)

            // 中层柔光光圈
            val d2 = dpF(0.7f)
            glowRectF.set(keyRectF.left - d2, keyRectF.top - d2, keyRectF.right + d2, keyRectF.bottom + d2)
            canvas.drawRoundRect(glowRectF, r + d2, r + d2, haloMidPaint)
        }

        // 2. 绘制键帽主体（若未开睡莲纹理则画纯色底，若开了则画油画睡莲纹理）
        clipPath.reset()
        clipPath.addRoundRect(keyRectF, r, r, Path.Direction.CW)
        val saveCount = canvas.save()
        canvas.clipPath(clipPath)

        if (fallbackBgTop != Color.TRANSPARENT) {
            fallbackFillPaint.color = fallbackBgTop
            canvas.drawRect(keyRectF, fallbackFillPaint)
        }
        if (bitmap != null) {
            srcRect.set(0, 0, bitmap.width, bitmap.height)
            canvas.drawBitmap(bitmap, srcRect, keyRectF, bmpPaint)
        }

        // 3. 按键点亮背光（按下及余晖期间，键帽内部泛起柔光流光，而不是变黑！）
        if (p > 0.01f) {
            val bloomAlpha = (95f * p).toInt().coerceIn(0, 255)
            pressBloomPaint.shader = RadialGradient(
                keyRectF.centerX(),
                keyRectF.centerY(),
                maxOf(keyRectF.width(), keyRectF.height()) * 0.72f,
                intArrayOf(
                    Color.argb(bloomAlpha, 255, 255, 255),
                    Color.argb((bloomAlpha * 0.7f).toInt(), rCol, gCol, bCol),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(keyRectF, pressBloomPaint)
        }
        canvas.restoreToCount(saveCount)

        // 4. 键帽边缘珠光背光灯带环
        if (enableGlow) {
            canvas.drawRoundRect(keyRectF, r, r, haloInnerPaint)
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}

class MinimalistIconView(
    context: Context,
    private val iconType: Int,
    private var iconColor: Int
) : View(context) {

    companion object {
        const val TYPE_SETTINGS = 0
        const val TYPE_EMOJI = 1
        const val TYPE_PHRASE = 2
        const val TYPE_COLLAPSE = 3
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpF(1.75f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = iconColor
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = iconColor
    }

    private val rectF = RectF()
    private val path = Path()

    fun setColor(newColor: Int) {
        iconColor = newColor
        strokePaint.color = newColor
        fillPaint.color = newColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.36f

        when (iconType) {
            TYPE_SETTINGS -> {
                val outerR = r * 0.92f
                val innerR = r * 0.38f
                canvas.drawCircle(cx, cy, outerR * 0.78f, strokePaint)
                canvas.drawCircle(cx, cy, innerR, fillPaint)
                for (i in 0 until 6) {
                    val angle = Math.toRadians((i * 60).toDouble())
                    val x1 = cx + (outerR * 0.72f) * cos(angle).toFloat()
                    val y1 = cy + (outerR * 0.72f) * sin(angle).toFloat()
                    val x2 = cx + outerR * cos(angle).toFloat()
                    val y2 = cy + outerR * sin(angle).toFloat()
                    canvas.drawLine(x1, y1, x2, y2, strokePaint)
                }
            }
            TYPE_EMOJI -> {
                canvas.drawCircle(cx, cy, r, strokePaint)
                val eyeOffsetX = r * 0.35f
                val eyeOffsetY = r * 0.18f
                val eyeRadius = dpF(1.25f)
                canvas.drawCircle(cx - eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                canvas.drawCircle(cx + eyeOffsetX, cy - eyeOffsetY, eyeRadius, fillPaint)
                val smileR = r * 0.48f
                rectF.set(cx - smileR, cy - smileR * 0.65f, cx + smileR, cy + smileR * 1.05f)
                canvas.drawArc(rectF, 22f, 136f, false, strokePaint)
            }
            TYPE_PHRASE -> {
                val w = r * 1.65f
                val h = r * 1.9f
                rectF.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
                canvas.drawRoundRect(rectF, dpF(3.5f), dpF(3.5f), strokePaint)
                val lineHalfW = w * 0.26f
                canvas.drawLine(cx - lineHalfW, cy - h * 0.18f, cx + lineHalfW, cy - h * 0.18f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.06f, cx + lineHalfW, cy + h * 0.06f, strokePaint)
                canvas.drawLine(cx - lineHalfW, cy + h * 0.30f, cx + lineHalfW * 0.4f, cy + h * 0.30f, strokePaint)
            }
            TYPE_COLLAPSE -> {
                val w = r * 0.78f
                val h = r * 0.42f
                path.reset()
                path.moveTo(cx - w, cy - h * 0.6f)
                path.lineTo(cx, cy + h * 0.65f)
                path.lineTo(cx + w, cy - h * 0.6f)
                canvas.drawPath(path, strokePaint)
                canvas.drawLine(cx - w * 0.65f, cy + r * 0.72f, cx + w * 0.65f, cy + r * 0.72f, strokePaint)
            }
        }
    }

    private fun dpF(value: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            resources.displayMetrics
        )
    }
}
