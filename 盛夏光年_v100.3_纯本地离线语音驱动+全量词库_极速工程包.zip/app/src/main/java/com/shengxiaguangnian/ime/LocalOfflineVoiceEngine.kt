package com.shengxiaguangnian.ime

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.k2fsa.sherpa.onnx.*

/**
 * 盛夏光年 · 纯本地离线端侧语音识别引擎 (基于 Sherpa-ONNX 流式 Zipformer 中文模型)
 *
 * 特性：
 * 1. 100% 纯本地离线运行，无需连网，无 API 延迟，无高峰期排队，地铁/飞行模式皆可顺畅使用；
 * 2. 彻底解决小米澎湃系统 (com.xiaomi.mibrain.speech) 5.0 秒强制超时断连的问题；
 * 3. 懒加载单例模式：平时打字时内存与 CPU 占用为 0，只有长按语音时按需唤醒模型；
 * 4. 实时音频采样驱动音浪动效 (RMS 计算)，识别字词流式实时上屏。
 */
object LocalOfflineVoiceEngine {

    private var recognizer: OnlineRecognizer? = null
    private var isModelInitialized = false
    private var isInitializing = false

    private var audioRecord: AudioRecord? = null
    @Volatile
    private var isRecording = false
    private var recordingThread: Thread? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    interface VoiceCallback {
        fun onReady()
        fun onRmsChanged(rmsdB: Float)
        fun onPartialResult(text: String)
        fun onFinalResult(text: String)
        fun onError(errorMsg: String)
        fun onStopped()
    }

    /**
     * 异步按需初始化模型（只有首次进入语音界面时才唤醒，不影响日常键盘输入流畅度）
     */
    fun ensureModelInitialized(context: Context, onReady: (() -> Unit)? = null) {
        if (isModelInitialized && recognizer != null) {
            onReady?.let { mainHandler.post(it) }
            return
        }
        if (isInitializing) return
        isInitializing = true

        Thread {
            try {
                val assetManager = context.applicationContext.assets
                val modelDir = "sherpa_model"

                val transducerConfig = OnlineTransducerModelConfig(
                    encoder = "$modelDir/encoder.onnx",
                    decoder = "$modelDir/decoder.onnx",
                    joiner = "$modelDir/joiner.onnx"
                )

                val modelConfig = OnlineModelConfig(
                    transducer = transducerConfig,
                    tokens = "$modelDir/tokens.txt",
                    numThreads = 2,
                    provider = "cpu",
                    modelType = "zipformer2"
                )

                val config = OnlineRecognizerConfig(
                    modelConfig = modelConfig,
                    decodingMethod = "greedy_search",
                    enableEndpoint = true,
                    rule1MinTrailingSilence = 2.4f,
                    rule2MinTrailingSilence = 1.2f,
                    rule3MinUtteranceLength = 30.0f
                )

                recognizer = OnlineRecognizer(assetManager, config)
                isModelInitialized = true
                isInitializing = false
                onReady?.let { mainHandler.post(it) }
            } catch (e: Throwable) {
                isInitializing = false
            }
        }.start()
    }

    /**
     * 开始纯本地离线长语音录制与识别
     */
    fun startListening(context: Context, callback: VoiceCallback) {
        if (isRecording) {
            stopListening()
        }

        ensureModelInitialized(context) {
            startAudioRecordPipeline(callback)
        }
    }

    private fun startAudioRecordPipeline(callback: VoiceCallback) {
        val rec = recognizer ?: run {
            callback.onError("语音模型尚未就绪")
            return
        }

        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
        val bufferSize = maxOf(minBufferSize, sampleRate * 2) // 1 second buffer

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                callback.onError("无法启动麦克风录音权限")
                return
            }

            audioRecord?.startRecording()
            isRecording = true
            callback.onReady()

            recordingThread = Thread {
                val stream = rec.createStream()
                val readBuffer = ShortArray(1600) // 100ms per read
                val floatBuffer = FloatArray(1600)
                var lastResultText = ""

                try {
                    while (isRecording) {
                        val readCount = audioRecord?.read(readBuffer, 0, readBuffer.size) ?: -1
                        if (readCount > 0) {
                            // 1. 计算音浪 RMS
                            var sumSquares = 0.0
                            for (i in 0 until readCount) {
                                val s = readBuffer[i].toFloat()
                                floatBuffer[i] = s / 32768.0f
                                sumSquares += (s * s).toDouble()
                            }
                            val mean = sumSquares / readCount
                            val rms = Math.sqrt(mean)
                            val rmsDb = if (rms > 1.0) (20 * Math.log10(rms)).toFloat() else 0f
                            mainHandler.post { callback.onRmsChanged(rmsDb) }

                            // 2. 送入 sherpa-onnx 流式解码
                            stream.acceptWaveform(floatBuffer.copyOf(readCount), sampleRate)
                            while (rec.isReady(stream)) {
                                rec.decode(stream)
                            }

                            val curText = rec.getResult(stream).text.trim()
                            if (curText.isNotEmpty() && curText != lastResultText) {
                                lastResultText = curText
                                mainHandler.post { callback.onPartialResult(curText) }
                            }
                        }
                    }

                    // 录音结束，提取最终识别结果
                    val finalText = rec.getResult(stream).text.trim()
                    mainHandler.post {
                        callback.onFinalResult(finalText)
                        callback.onStopped()
                    }
                } catch (t: Throwable) {
                    mainHandler.post {
                        callback.onError(t.message ?: "识别异常")
                        callback.onStopped()
                    }
                } finally {
                    try {
                        stream.release()
                    } catch (_: Throwable) {}
                }
            }.apply {
                priority = Thread.MAX_PRIORITY
                start()
            }
        } catch (e: Throwable) {
            callback.onError("启动录音失败: ${e.message}")
        }
    }

    /**
     * 停止录制
     */
    fun stopListening() {
        isRecording = false
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Throwable) {}
        audioRecord = null
    }

    /**
     * 释放模型资源
     */
    fun release() {
        stopListening()
        try {
            recognizer?.release()
        } catch (_: Throwable) {}
        recognizer = null
        isModelInitialized = false
    }
}
