package com.shengxiaguangnian.ime

import android.content.Context
import android.os.SystemClock
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.widget.FrameLayout
import android.view.View
import org.json.JSONObject
import java.io.File

/**
 * 按键效果（KeyFx）—— 可导入 / 可删除的按键按下反馈。
 *
 * 一个效果文件就是一个 JSON（扩展名 .keyfx 或 .json）：
 * {
 *   "name": "涟漪静湖",
 *   "scale": 0.93,           // 按下时键帽缩到多少（0.7 ~ 1.0）
 *   "downMs": 65,            // 按下去用多久
 *   "upMs": 150,             // 弹回来用多久
 *   "translateYdp": 2,       // 按下时往下沉几 dp
 *   "layers": [              // 可以叠很多层，按顺序画
 *     { "type": "ripple",  "color": "#3D2A3042", "durationMs": 260, "radiusPct": 1.0, "auto": true },
 *     { "type": "flash",   "color": "#22FFFFFF", "durationMs": 120 },
 *     { "type": "glow",    "color": "#554A6BD8", "durationMs": 240, "widthDp": 3 },
 *     { "type": "outline", "color": "#FF7A9B",   "durationMs": 200, "widthDp": 2 }
 *   ]
 * }
 *
 * color 支持 #RRGGBB 或 #AARRGGBB；auto=true 表示跟随浅色/深色皮肤自动选墨色或白色。
 */
data class KeyFxLayer(
    val type: String = "flash",
    val color: Int = 0x332A3042,
    val delayMs: Int = 0,
    val durationMs: Int = 220,
    val radiusPct: Float = 1.0f,
    val widthDp: Float = 2.5f,
    val auto: Boolean = false
)

data class KeyFx(
    val id: String,
    val name: String,
    val scale: Float = 0.93f,
    val downMs: Int = 65,
    val upMs: Int = 150,
    val translateYdp: Float = 2f,
    val layers: List<KeyFxLayer> = emptyList(),
    /** v3：笔刷粒子层（8 种笔刷，见 BrushFx.kt） */
    val brushLayers: List<BrushLayer> = emptyList(),
    /** v3：整段动画时长 */
    val durationMs: Int = 0,
    /** 导入时的原始 JSON 文本，导出时原样吐出来 */
    val raw: String = "",
    val builtin: Boolean = false
) {
    /** auto 颜色的层，按当前皮肤明暗换成墨色或微白 */
    fun withAdaptiveColors(isLightSkin: Boolean): KeyFx {
        if (layers.none { it.auto }) return this
        val rgb = if (isLightSkin) 0x2A3042 else 0xFFFFFF
        return copy(layers = layers.map {
            if (it.auto) it.copy(color = Color.argb(Color.alpha(it.color), Color.red(rgb), Color.green(rgb), Color.blue(rgb))) else it
        })
    }
}

object KeyFxManager {
    const val PREFS_NAME = "shengxia_prefs"
    const val KEY_ACTIVE = "keyfx_active_id"
    const val ID_DEFAULT = "builtin_ripple"
    const val ID_SOFT = "builtin_soft"
    const val ID_PLAIN = "builtin_plain"
    const val ID_BRUSH = "builtin_brush"

    // ★ 每个效果各自记住「密度 / 速度 / 范围」三个滑杆（0~100）
    const val P_DENSITY = "density"
    const val P_SPEED = "speed"
    const val P_RANGE = "range"
    const val DEFAULT_PARAM = 60

    fun getParam(ctx: Context, id: String, key: String): Int =
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt("keyfx_cfg_" + key + "_" + id, DEFAULT_PARAM).coerceIn(0, 100)

    fun setParam(ctx: Context, id: String, key: String, value: Int) {
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putInt("keyfx_cfg_" + key + "_" + id, value.coerceIn(0, 100)).apply()
    }

    fun builtins(): List<KeyFx> = listOf(
        KeyFx(
            id = ID_DEFAULT, name = "涟漪静湖（默认墨色水波）",
            scale = 0.928f, downMs = 65, upMs = 180, translateYdp = 2f,
            layers = listOf(
                KeyFxLayer("flash", 0x2E000000, 0, 480, 1f, 0f, true),
                KeyFxLayer("ripple", 0x59000000, 40, 520, 1.2f, 0f, true)
            ),
            builtin = true
        ),
        KeyFx(
            id = ID_SOFT, name = "柔光轻闪（闪白 + 蓝紫外发光）",
            scale = 0.95f, downMs = 50, upMs = 180, translateYdp = 1f,
            layers = listOf(
                KeyFxLayer("flash", 0x3DFFFFFF, 0, 300, 1f, 0f, false),
                KeyFxLayer("glow", 0x804A6BD8.toInt(), 30, 520, 1f, 3.5f, false)
            ),
            builtin = true
        ),
        // ★ 内置的 v3 笔刷效果（直接用代码写死，不经过任何解析）。
        //   作用有两个：① 给用户一个确定能用的粒子特效；② 如果它也不出粒子，
        //   就说明是渲染层的问题；如果它出粒子而导入的不出，就是解析层的问题。
        KeyFx(
            id = ID_BRUSH, name = "笔刷演示（内置星芒爆发）",
            scale = 0.93f, downMs = 60, upMs = 170,
            brushLayers = listOf(
                BrushLayer(
                    brush = BrushKind.GLOW, count = 1, sizeMin = 20f, sizeMax = 28f,
                    lifeMin = 400, lifeMax = 620,
                    colorStart = 0x55FFD9A0, colorEnd = 0x0AFFC98A,
                    alpha = 0.55f, glow = 0.5f
                ),
                BrushLayer(
                    brush = BrushKind.STAR, count = 8, sizeMin = 4f, sizeMax = 9f,
                    speedMin = 40f, speedMax = 140f, lifeMin = 400, lifeMax = 700,
                    colorStart = 0xFFFFFFFF.toInt(), colorEnd = 0xAAFFD9A0.toInt(),
                    alpha = 1f, glow = 0.8f, spin = 60f, fade = Fade.FLICKER
                ),
                BrushLayer(
                    brush = BrushKind.DOT, count = 8, sizeMin = 1.6f, sizeMax = 3.2f,
                    speedMin = 60f, speedMax = 180f, lifeMin = 350, lifeMax = 600,
                    colorStart = 0xFFFFFFFF.toInt(), colorEnd = 0x99FFC98A.toInt(),
                    alpha = 0.9f, glow = 0.45f, fade = Fade.FLICKER
                )
            ),
            durationMs = 800,
            builtin = true
        ),
        KeyFx(
            id = ID_PLAIN, name = "仅下沉（无任何光效）",
            scale = 0.95f, downMs = 55, upMs = 140, translateYdp = 2f,
            layers = emptyList(),
            builtin = true
        )
    )

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "keyfx")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun imported(ctx: Context): List<KeyFx> {
        val out = ArrayList<KeyFx>()
        val files = dir(ctx).listFiles() ?: return out
        for (f in files) {
            if (!f.isFile) continue
            val n = f.name.lowercase()
            if (!(n.endsWith(".keyfx") || n.endsWith(".json") || n.endsWith(".txt"))) continue
            try {
                val fx = parse(f.readText(), f.nameWithoutExtension)
                if (fx != null) out.add(fx)
            } catch (_: Throwable) {
            }
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /** ★ 导入的排在前面：导入多了也不会把预览/滑杆挤出屏幕 */
    fun listAll(ctx: Context): List<KeyFx> = imported(ctx) + builtins()

    fun activeId(ctx: Context): String =
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_ACTIVE, ID_DEFAULT) ?: ID_DEFAULT

    fun setActive(ctx: Context, id: String) {
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_ACTIVE, id).apply()
    }

    fun load(ctx: Context, id: String): KeyFx? {
        builtins().firstOrNull { it.id == id }?.let { return it }
        for (ext in arrayOf(".keyfx", ".json", ".txt")) {
            val f = File(dir(ctx), id + ext)
            if (f.exists()) {
                parse(f.readText(), id)?.let { return it }
            }
        }
        imported(ctx).firstOrNull { it.id == id }?.let { return it }
        return builtins().first()
    }

    fun delete(ctx: Context, fx: KeyFx): Boolean {
        if (fx.builtin) return false
        var ok = false
        for (ext in arrayOf(".keyfx", ".json", ".txt")) {
            val f = File(dir(ctx), fx.id + ext)
            if (f.exists() && f.delete()) ok = true
        }
        return ok
    }

    fun parseAndSave(ctx: Context, text: String, fileName: String): KeyFx? {
        val base = fileName.substringBeforeLast('.').trim().ifEmpty { "effect" }
        val safe = base.replace(Regex("[^\\p{L}\\p{N}_\\-]"), "_").take(40)
        val fx = parse(text, safe) ?: return null
        File(dir(ctx), safe + ".keyfx").writeText(text)
        return fx
    }

    fun parse(text: String, id: String): KeyFx? {
        return try {
            val clean = text.trim().removePrefix("\uFEFF")
            if (!clean.startsWith("{")) return null
            val o = JSONObject(clean)
            val layersJson = o.optJSONArray("layers")
            val layers = ArrayList<KeyFxLayer>()
            val brushLayers = ArrayList<BrushLayer>()
            if (layersJson != null) {
                for (i in 0 until layersJson.length()) {
                    val lo = layersJson.optJSONObject(i) ?: continue
                    if (lo.has("brush") || !lo.has("type")) {
                        brushLayers.add(parseBrushLayer(lo))
                        continue
                    }
                    val type = lo.optString("type", "flash").lowercase()
                    if (type != "ripple" && type != "flash" && type != "glow" && type != "outline") continue
                    layers.add(
                        KeyFxLayer(
                            type = type,
                            color = parseColor(lo.optString("color", "#332A3042")),
                            delayMs = lo.optInt("delayMs", lo.optInt("delay", 0)).coerceIn(0, 2000),
                            durationMs = lo.optInt("durationMs", lo.optInt("duration", 220)).coerceIn(30, 2000),
                            radiusPct = lo.optDouble("radiusPct", 1.0).toFloat().coerceIn(0.3f, 2.5f),
                            widthDp = lo.optDouble("widthDp", 2.5).toFloat().coerceIn(0.5f, 8f),
                            auto = lo.optBoolean("auto", false)
                        )
                    )
                }
            }
            KeyFx(
                id = id,
                name = o.optString("name", id).take(24),
                scale = o.optDouble("scale", 0.93).toFloat().coerceIn(0.7f, 1.0f),
                downMs = o.optInt("downMs", 65).coerceIn(0, 400),
                upMs = o.optInt("upMs", 150).coerceIn(0, 800),
                translateYdp = o.optDouble("translateYdp", 2.0).toFloat().coerceIn(0f, 8f),
                layers = layers,
                brushLayers = brushLayers,
                durationMs = o.optInt("durationMs", 0).let { d ->
                    if (d > 0) d else brushLayers.maxOfOrNull { it.lifeMax + it.delayMs } ?: 0
                },
                raw = clean,
                builtin = false
            )
        } catch (_: Throwable) {
            null
        }
    }

    /** 解析 [最小, 最大] 区间；也接受单个数字 */
    private fun rangeOf(lo: JSONObject, key: String, dMin: Float, dMax: Float): Pair<Float, Float> {
        val arr = lo.optJSONArray(key)
        if (arr != null && arr.length() >= 2) {
            val a = arr.optDouble(0, dMin.toDouble()).toFloat()
            val b = arr.optDouble(1, dMax.toDouble()).toFloat()
            return a.coerceIn(-2000f, 2000f) to b.coerceIn(-2000f, 2000f)
        }
        if (lo.has(key)) {
            val v = lo.optDouble(key, dMin.toDouble()).toFloat()
            return v to v
        }
        return dMin to dMax
    }

    /**
     * v3 笔刷层。★ 永远不会返回 null：
     * 名字认不出来就按关键字猜，实在猜不出就当 dot。
     * 宁可画错一种笔刷，也绝不能"导入后什么都不发生"。
     */
    private fun parseBrushLayer(lo: JSONObject): BrushLayer {
        val raw = (lo.optString("brush", "") + " " + lo.optString("type", "")).lowercase().trim()
        val kind = when {
            raw.contains("glow") || raw.contains("光") -> BrushKind.GLOW
            raw.contains("spike") || raw.contains("filament") || raw.contains("丝") || raw.contains("尖") -> BrushKind.SPIKE
            raw.contains("ring") || raw.contains("ripple") || raw.contains("环") || raw.contains("波") -> BrushKind.RING
            raw.contains("star") || raw.contains("spark") || raw.contains("星") -> BrushKind.STAR
            raw.contains("bubble") || raw.contains("泡") -> BrushKind.BUBBLE
            raw.contains("arc") || raw.contains("ribbon") || raw.contains("带") -> BrushKind.ARC
            raw.contains("glyph") || raw.contains("char") || raw.contains("字") -> BrushKind.GLYPH
            else -> BrushKind.DOT
        }
        val size = rangeOf(lo, "size", 3f, 6f)
        val len = rangeOf(lo, "length", 0f, 0f)
        val spd = rangeOf(lo, "speed", 20f, 60f)
        val life = rangeOf(lo, "lifeMs", 400f, 800f)
        val ang = rangeOf(lo, "angle", 0f, 360f)
        val cArr = lo.optJSONArray("color")
        val c0s: String
        val c1s: String
        if (cArr != null && cArr.length() >= 2) {
            c0s = cArr.optString(0, "#FFFFFF")
            c1s = cArr.optString(1, c0s)
        } else {
            c0s = lo.optString("color", "#FFFFFF")
            c1s = c0s
        }
        val follow = c0s.equals("auto", true) || c0s.equals("skin", true) || c0s.contains("跟随")
        val glyphs = ArrayList<String>()
        lo.optJSONArray("glyphs")?.let { ga ->
            for (i in 0 until ga.length()) ga.optString(i, "")?.takeIf { it.isNotEmpty() }?.let { glyphs.add(it) }
        }
        val fade = when (lo.optString("fade", "out").lowercase()) {
            "hold" -> Fade.HOLD
            "flicker" -> Fade.FLICKER
            else -> Fade.OUT
        }
        return BrushLayer(
            brush = kind,
            count = lo.optInt("count", 6).coerceIn(1, 40),
            sizeMin = size.first.coerceIn(0.5f, 80f),
            sizeMax = size.second.coerceIn(0.5f, 80f),
            lengthMin = len.first.coerceIn(0f, 300f),
            lengthMax = len.second.coerceIn(0f, 300f),
            speedMin = spd.first.coerceIn(0f, 900f),
            speedMax = spd.second.coerceIn(0f, 900f),
            lifeMin = life.first.toInt().coerceIn(120, 2400),
            lifeMax = life.second.toInt().coerceIn(120, 2400),
            angleFrom = ang.first,
            angleTo = ang.second,
            curve = lo.optDouble("curve", 0.0).toFloat().coerceIn(-2f, 2f),
            colorStart = if (follow) 0xFF7C8CFF.toInt() else parseColor(c0s),
            colorEnd = if (follow) 0xFF3A3F7A.toInt() else parseColor(c1s),
            alpha = lo.optDouble("alpha", 0.9).toFloat().coerceIn(0.05f, 1f),
            glow = lo.optDouble("glow", 0.6).toFloat().coerceIn(0f, 1f),
            gravity = lo.optDouble("gravity", 0.0).toFloat().coerceIn(-400f, 400f),
            spin = lo.optDouble("spin", 0.0).toFloat().coerceIn(-360f, 360f),
            glyphs = glyphs,
            fade = fade,
            orbit = lo.optBoolean("orbit", false),
            delayMs = lo.optInt("delayMs", lo.optInt("delay", 0)).coerceIn(0, 2000),
            spreadArea = lo.optBoolean("spread", false),
            followSkin = follow
        )
    }

    /** 导出用：有原始文本就原样给，内置效果现拼一份 JSON */
    fun toJson(fx: KeyFx): String {
        if (fx.raw.isNotBlank()) return fx.raw.trim()
        val sb = StringBuilder()
        sb.append("{\n")
        sb.append("  \"format\": 3,\n")
        sb.append("  \"engine\": \"vfx\",\n")
        sb.append("  \"name\": \"").append(fx.name).append("\",\n")
        sb.append("  \"scale\": ").append(fx.scale).append(",\n")
        sb.append("  \"downMs\": ").append(fx.downMs).append(",\n")
        sb.append("  \"upMs\": ").append(fx.upMs).append(",\n")
        sb.append("  \"translateYdp\": ").append(fx.translateYdp).append(",\n")
        sb.append("  \"durationMs\": ").append(if (fx.durationMs > 0) fx.durationMs else 600).append(",\n")
        val items = ArrayList<String>()
        for (l in fx.layers) {
            val auto = if (l.auto) "\"auto\": true" else "\"auto\": false"
            val col = String.format("\"#%08X\"", l.color)
            when (l.type) {
                "ripple" -> items.add("    { \"type\": \"ripple\", \"color\": $col, \"delayMs\": ${l.delayMs}, \"durationMs\": ${l.durationMs}, \"radiusPct\": ${l.radiusPct}, $auto }")
                "glow", "outline" -> items.add("    { \"type\": \"${l.type}\", \"color\": $col, \"delayMs\": ${l.delayMs}, \"durationMs\": ${l.durationMs}, \"widthDp\": ${l.widthDp}, $auto }")
                else -> items.add("    { \"type\": \"flash\", \"color\": $col, \"delayMs\": ${l.delayMs}, \"durationMs\": ${l.durationMs}, $auto }")
            }
        }
        for (b in fx.brushLayers) {
            items.add("    { " + brushToJson(b) + " }")
        }
        sb.append("  \"layers\": [\n")
        sb.append(items.joinToString(",\n"))
        sb.append("\n  ]\n}\n")
        return sb.toString()
    }

    private fun brushToJson(b: BrushLayer): String {
        val brush = when (b.brush) {
            BrushKind.GLOW -> "glow"
            BrushKind.SPIKE -> "spike"
            BrushKind.RING -> "ring"
            BrushKind.STAR -> "star"
            BrushKind.BUBBLE -> "bubble"
            BrushKind.ARC -> "arc"
            BrushKind.DOT -> "dot"
            BrushKind.GLYPH -> "glyph"
        }
        val fade = when (b.fade) {
            Fade.HOLD -> "hold"
            Fade.FLICKER -> "flicker"
            else -> "out"
        }
        val c = if (b.followSkin) "\"auto\"" else
            String.format("[\"#%08X\", \"#%08X\"]", b.colorStart, b.colorEnd)
        val sb = StringBuilder()
        sb.append("\"brush\": \"").append(brush).append("\", ")
        sb.append("\"count\": ").append(b.count).append(", ")
        sb.append("\"size\": [").append(b.sizeMin).append(", ").append(b.sizeMax).append("], ")
        if (b.lengthMax > 0f) sb.append("\"length\": [").append(b.lengthMin).append(", ").append(b.lengthMax).append("], ")
        sb.append("\"speed\": [").append(b.speedMin).append(", ").append(b.speedMax).append("], ")
        sb.append("\"lifeMs\": [").append(b.lifeMin).append(", ").append(b.lifeMax).append("], ")
        sb.append("\"angle\": [").append(b.angleFrom).append(", ").append(b.angleTo).append("], ")
        if (b.curve != 0f) sb.append("\"curve\": ").append(b.curve).append(", ")
        sb.append("\"color\": ").append(c).append(", ")
        sb.append("\"alpha\": ").append(b.alpha).append(", ")
        sb.append("\"glow\": ").append(b.glow).append(", ")
        if (b.gravity != 0f) sb.append("\"gravity\": ").append(b.gravity).append(", ")
        if (b.spin != 0f) sb.append("\"spin\": ").append(b.spin).append(", ")
        if (b.glyphs.isNotEmpty()) sb.append("\"glyphs\": [").append(b.glyphs.joinToString(", ") { "\"$it\"" }).append("], ")
        if (b.orbit) sb.append("\"orbit\": true, ")
        if (b.spreadArea) sb.append("\"spread\": true, ")
        if (b.delayMs > 0) sb.append("\"delayMs\": ").append(b.delayMs).append(", ")
        sb.append("\"fade\": \"").append(fade).append("\"")
        return sb.toString()
    }

    fun parseColor(s: String): Int {
        return try {
            Color.parseColor(s.trim())
        } catch (_: Throwable) {
            0x332A3042
        }
    }
}

/**
 * 效果绘制层：铺在键盘根容器最上层，按键被重建也不会消失。
 * 一次按键只用一个实例，动画结束自动隐藏。
 */
class KeyFxOverlayView(ctx: Context) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private var fx: KeyFx? = null
    private var cornerPx = 0f
    private var padPx = 0f
    private var elapsed = 0f
    // ★ 不再用 ValueAnimator：这台手机的动画时长缩放可能是 0（或无动画），
    //   ValueAnimator 会立刻结束，导致覆盖层只画 1 帧（诊断里就是 draws=1）。
    //   改成自己用 postInvalidateOnAnimation 循环，和键下光效层完全一样的做法。
    private var startAt = 0L
    private var totalMs = 0
    private var ticking = false
    private var drawCount = 0
    private var onFinished: (() -> Unit)? = null

    // ---- v3 笔刷粒子 ----
    private val brushField = BrushBurstField()
    private var brushEmitted = false
    private var fallbackEmitted = false
    // 三参数（0~1）
    private var pDensity = 0.6f
    private var pSpeed = 0.6f
    private var pRange = 0.55f
    private var brushSurfaceColor: Int? = null

    init {
        setWillNotDraw(false)
        isClickable = false
        isFocusable = false
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun play(
        target: KeyFx,
        corner: Float,
        pad: Float,
        surfaceBg: Int? = null,
        onDone: () -> Unit
    ) {
        drawCount = 0
        fx = target
        brushSurfaceColor = surfaceBg
        brushEmitted = false
        fallbackEmitted = false
        brushField.clear()
        cornerPx = corner
        padPx = pad
        elapsed = 0f
        onFinished = onDone
        val cid = target.id
        pDensity = KeyFxManager.getParam(context, cid, KeyFxManager.P_DENSITY) / 100f
        pSpeed = KeyFxManager.getParam(context, cid, KeyFxManager.P_SPEED) / 100f
        pRange = KeyFxManager.getParam(context, cid, KeyFxManager.P_RANGE) / 100f
        val durScale = 0.55f + pSpeed * 0.9f
        val v2Total = target.layers.maxOfOrNull { it.delayMs + (it.durationMs * durScale).toInt() } ?: 0
        val brushTotal = target.brushLayers.maxOfOrNull { it.delayMs + it.lifeMax } ?: 0
        val total = maxOf(v2Total, brushTotal).coerceAtLeast(80)
        startAt = 0L   // 第一帧真正画出来时才起表，避免布局慢的时候一帧就结束
        totalMs = total
        ticking = true
        invalidate()
        postInvalidateOnAnimation()
        PressDiag.add("FX 开始 总时长=${total}ms 笔刷=${target.brushLayers.size} 光效=${target.layers.size}")
    }

    fun stop() {
        ticking = false
        brushField.clear()
        onFinished = null
    }

    /**
     * 把 .keyfx 里的笔刷层发射出去。
     * color 写 "auto" 的层，颜色跟着键盘底色走（浅底用深一号、深底用亮一号）。
     */
    private fun emitBrushLayers(layers: List<BrushLayer>) {
        val bg = brushSurfaceColor
        val light = isLightSurface(bg)
        val resolved = if (layers.any { it.followSkin }) {
            val hsv = FloatArray(3)
            Color.colorToHSV(bg ?: 0xFF8FA3D8.toInt(), hsv)
            val head = Color.HSVToColor(floatArrayOf(hsv[0], 0.80f, if (light) 0.50f else 1f))
            val tail = Color.HSVToColor(255, floatArrayOf(hsv[0], 0.88f, if (light) 0.32f else 0.70f))
            layers.map { if (it.followSkin) it.copy(colorStart = head, colorEnd = tail) else it }
        } else {
            layers
        }
        brushField.emit(
            rect = RectF(padPx, padPx, width - padPx, height - padPx),
            corner = cornerPx,
            layers = resolved,
            tint = bg ?: 0xFF8FA3D8.toInt(),
            tintMix = 0.22f,
            density = pDensity,
            reach = pRange,
            spread = pSpeed,
            pxScale = resources.displayMetrics.density * 0.85f,
            surfaceLight = light
        )
    }

    /** 自检用：现在场上有多少粒子 */
    fun fxParticleCount(): Int = if (brushEmitted) brushField.particleCount() else -1

    private fun isLightSurface(c: Int?): Boolean {
        if (c == null) return false
        val lum = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        return lum > 0.62f
    }

    /** 亮起(10%) → 保持(45%) → 淡出(45%)，这样才看得见，也不会一晃就没了 */
    private fun envelope(local: Float): Float {
        return when {
            local < 0.10f -> local / 0.10f
            local < 0.55f -> 1f
            else -> (1f - (local - 0.55f) / 0.45f).coerceIn(0f, 1f)
        }
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        return Color.argb(
            alpha.coerceIn(0, 255),
            Color.red(color), Color.green(color), Color.blue(color)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawCount++
        PressDiag.lastOverlayDraws = drawCount
        val f = fx ?: return
        if (ticking) {
            val nowMs = SystemClock.uptimeMillis()
            if (startAt == 0L) startAt = nowMs
            elapsed = (nowMs - startAt).toFloat().coerceAtLeast(0f)
        }
        drawFrame(canvas, f)
        // 一帧画完：没到时长就继续要下一帧（不依赖 ValueAnimator）
        if (ticking && elapsed >= totalMs) {
            ticking = false
            post { onFinished?.invoke() }
        }
        if (ticking || brushField.isActive()) {
            postInvalidateOnAnimation()
        }
    }

    private fun drawFrame(canvas: Canvas, f: KeyFx) {
        if (f.layers.isEmpty() && f.brushLayers.isEmpty() && f.id != KeyFxManager.ID_PLAIN) {
            // ★ 兜底（「仅下沉」是故意没有图层的，不兜底）：导入的文件没解析出任何图层时，至少给一个可见的爆发，
            //   避免"点了启用完全没反应"。同时在诊断里记一笔，方便排查。
            if (!fallbackEmitted && width > 0 && height > 0) {
                fallbackEmitted = true
                PressDiag.add("FX 兜底：效果「${f.name}」没有任何图层，已用默认爆发代替")
                brushField.emit(
                    rect = RectF(padPx, padPx, width - padPx, height - padPx),
                    corner = cornerPx,
                    layers = listOf(
                        BrushLayer(BrushKind.GLOW, 1, 18f, 26f, lifeMin = 400, lifeMax = 600,
                            colorStart = 0xCCFFFFFF.toInt(), colorEnd = 0x33FFFFFF, alpha = 0.5f, glow = 0.6f),
                        BrushLayer(BrushKind.STAR, 8, 4f, 8f, speedMin = 40f, speedMax = 120f,
                            lifeMin = 400, lifeMax = 700, colorStart = 0xFFFFFFFF.toInt(),
                            colorEnd = 0xAA66D9FF.toInt(), alpha = 1f, glow = 0.8f, spin = 60f, fade = Fade.FLICKER)
                    ),
                    tint = brushSurfaceColor ?: 0xFF8FA3D8.toInt(),
                    pxScale = resources.displayMetrics.density * 0.85f,
                    surfaceLight = isLightSurface(brushSurfaceColor)
                )
            }
            if (brushField.isActive()) {
                brushField.draw(canvas, SystemClock.uptimeMillis())
            }
            return
        }

        // ---- v3 笔刷粒子 ----
        if (f.brushLayers.isNotEmpty()) {
            if (!brushEmitted && width > 0 && height > 0) {
                emitBrushLayers(f.brushLayers)
                brushEmitted = true
            }
            if (brushField.isActive()) {
                brushField.draw(canvas, SystemClock.uptimeMillis())
            }
        }

        if (f.layers.isEmpty()) return
        val inner = RectF(padPx, padPx, width - padPx, height - padPx)
        val durScale = 0.55f + pSpeed * 0.9f
        val rangeScale = 0.62f + pRange * 0.9f
        val alphaScale = 0.55f + pDensity * 0.75f
        for (layer in f.layers) {
            if (elapsed < layer.delayMs) continue
            val dur = (layer.durationMs.coerceAtLeast(1).toFloat()) * durScale
            val local = ((elapsed - layer.delayMs) / dur).coerceIn(0f, 1f)
            val baseAlpha = (Color.alpha(layer.color) * alphaScale).toInt().coerceIn(0, 255)
            val fade = envelope(local)
            when (layer.type) {
                "ripple" -> {
                    val eased = 1f - (1f - local) * (1f - local) * (1f - local)
                    val maxR = inner.height() / 2f * layer.radiusPct * rangeScale
                    val r = (maxR * eased).coerceAtLeast(1f)
                    paint.style = Paint.Style.FILL
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawCircle(inner.centerX(), inner.centerY(), r, paint)
                }
                "flash" -> {
                    paint.style = Paint.Style.FILL
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawRoundRect(inner, cornerPx, cornerPx, paint)
                }
                "outline" -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = layer.widthDp * density
                    paint.color = withAlpha(layer.color, (baseAlpha * fade).toInt())
                    canvas.drawRoundRect(inner, cornerPx, cornerPx, paint)
                }
                "glow" -> {
                    paint.style = Paint.Style.STROKE
                    val step = layer.widthDp * density * rangeScale
                    for (k in 0 until 3) {
                        val grow = step * (k + 1) * 0.8f
                        val rr = RectF(inner)
                        rr.inset(-grow, -grow)
                        paint.strokeWidth = step
                        val a = (baseAlpha * fade * (0.55f - k * 0.15f)).toInt()
                        paint.color = withAlpha(layer.color, a)
                        canvas.drawRoundRect(rr, cornerPx + grow, cornerPx + grow, paint)
                    }
                }
            }
        }
    }
}


/**
 * 只是替身 FrameLayout：在事件发给按键之前先看一眼 ACTION_DOWN。
 * 用来保证"按下去一定有反馈"，不受任何按键自身的滑动手势判定影响。
 */
class TouchSpyFrameLayout(ctx: Context) : FrameLayout(ctx) {
    var onTouchDown: ((Float, Float) -> Unit)? = null

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            try {
                onTouchDown?.invoke(ev.x, ev.y)
            } catch (_: Throwable) {
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}


/** 极轻量的按键反馈诊断记录（存在内存里，设置页可以直接读） */
object PressDiag {
    private val buf = ArrayList<String>()

    fun add(msg: String) {
        try {
            synchronized(buf) {
                buf.add("${SystemClock.elapsedRealtime() % 1000000}  $msg")
                if (buf.size > 200) buf.removeAt(0)
            }
        } catch (_: Throwable) {
        }
    }

    @Volatile
    var lastOverlayDraws = 0

    fun dump(): String = synchronized(buf) {
        if (buf.isEmpty()) "（还没有记录，先回键盘按几下再来）" else buf.joinToString("\n")
    }

    fun clear() {
        synchronized(buf) { buf.clear() }
    }
}
